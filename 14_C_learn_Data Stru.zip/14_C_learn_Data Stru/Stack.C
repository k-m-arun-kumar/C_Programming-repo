/* ======================================================================
  File Name     : Stack.C
  Description   : Tree Navigate in pre order using stack, based on Tree structure:- A(B(C( D)E) F(G(H(IJ(KL)))M(N ))).
  Author        : K.M. Arun Kumar alias Arunkumar Murugeswaran
  Date          : 21st, May 2007.
  Remarks     1 : by default, global execution flow flag is disabled for debugging.
              2 : stack, is implemented with array.
  Known Bugs  1 : giving non numeric input for numeric data.
  Modification
       History  :
  Others        : Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
====================================================================== */

#include "stdio.h"
#include "stdlib.h"

#define TREE_NODE_MSG          1  /* stack data has sample's tree node's addr */
#define EMP_MSG                2  /* stack's data has Employee's record */
#define ALPHA                  1  /* tree node's data has sample alpha data */
#define ALPHA_DATALEN          sizeof(char)
#define TRUE                   0
#define FALSE                 -1
#define NO_MEMORY             -2
#define MAX_TREE_NODES        15  /* max number of nodes in tree from tree's root */
#define MAX_TREE_DATA         20  /* max data size does queue & tree can have */
#define QUIT_OPER              1
#define PUSH_DATA_OPER         2
#define POP_DATA_OPER          3
#define DESTROY_STACK_OPER     4  /* destroy stack */
#define DESTROY_TREE_OPER      5  /* destroy's whole tree from root */
#define DISPLAY_OPER           6
#define RETRIEVE_TOP           1
#define RETRIEVE_STACK         2  /* display stack node's data */
#define STACK_MEGA_HEAD        3
#define TREE_MEGA_HEAD         4
#define WHOLE_DATA_PRE         5  /*display whole data using preorder */
#define WHOLE_DATA_IN          6
#define WHOLE_DATA_POST        7
#define WHOLE_DATA_BREATH
#define PRE_MEGA_DATA          8
#define IN_MEGA_DATA           9
#define POST_MEGADATA         10
#define BREATH_MEGA_DATA      11
#define MAX_STACK_SIZE        20  /* maximum no of stack nodes */
#define OPER_SIZE             15
#define MAX_NAME              MAX_TREE_DATA - sizeof(unsigned) - sizeof(unsigned char)
#define NO_ACCESS              1  /* does not allow access to queue */
#define FREE_ACCESS            0  /* allow access to queue */
#define LEFT_NODE              1  /* indicates left node */
#define RIGHT_NODE             2  /* indicates right node */
#define INVALID_DATA         255  /* invalid data that tree node can have */
#define TRACE_ON               1  /* enable global to trace execution flow for debugging */
#define TRACE_OFF              0  /* disable global to trace execution flow for debugging */

typedef struct treenode
{
   struct treenode *subtree_leftptr;      /* node's left subtree */
   struct treenode *subtree_rightptr;     /* node's right subtree */
   unsigned char msgtype;                 /* differentiate's kind of data in tree  */
   unsigned char datalen;                 /* variable data's length */
   char databuff[1];                      /* starting point of variable data's size > 1*/
}tree_node;

typedef struct
{
	unsigned char tree_count;       /* num of nodes in the tree */
	unsigned char max_treesize;     /* max num of nodes in tree */
	unsigned char max_datasize;     /* max data size that tree node can have */
	char access_tree;               /* control's access to tree */
	tree_node *rootptr;             /* points tree's root */
} tree_head;

typedef struct
{
	unsigned char msgtype;      /* differentiate kind of data in stack */
	unsigned char datalen;      /* variable data's length */
	unsigned stack_databuff[1]; /* contains variable data */
} stack_node;

typedef struct
{
   unsigned char stack_count;       /* number of nodes in stack */
   unsigned char max_stacksize;     /* Max number of allowable nodes in stack */
   char top_index;                  /* holds stack's top index, where new data will be push. top index - 1 has data, to be poped */
   char access_stack;               /* control access to stack */
   unsigned char max_datasize;      /* max memory size req for data in stack node */
   stack_node *stack_array;         /* starting address of stack implemented by 1D array */
} stack_head;

typedef struct
{
	unsigned emp_id;              /* Employee ID, used as key */
	unsigned char name_len;       /* Total length of Emp's Name */
	char emp_name[1];             /* variable Employee Name */
} emp_info;

/* global variable declaration */
char trace_flag = TRACE_OFF;
tree_head tree_megahead;
stack_head stack_megahead;

/* function prototype */
tree_node *Add_TreeNode(char mode, tree_head *tree_megaptr, tree_node *parentnode, const tree_node * const datanode );

/*******************************************************************
 Function Name  : main()
 Description    : navigation operation on automatically created tree
 Remarks        :
 Func ID        : 1
*******************************************************************/
int main()
{
    int nav_mode = QUIT_OPER;
    unsigned char stack_datalen;
    stack_node *pop_data = NULL;
    int ret_state;
    emp_info *pop_emp = NULL;

    clrscr();
    if(!Initialize_Stack(&stack_megahead, MAX_STACK_SIZE,MAX_TREE_DATA ))
	  if(!Initialize_Tree(&tree_megahead, MAX_TREE_NODES, sizeof(char)))
        if((ret_state = Sample_Tree_Structure(&tree_megahead)) != TRUE)
          return FALSE;
    do
    {
       printf("\n MENU: 1:Quit, 2:Push, 3:Pop, 4:Destroy S, 5:Destroy T, 6:Display: Enter: ");
       scanf("%d", &nav_mode);
       switch(nav_mode)
       {
		   case PUSH_DATA_OPER:
		     if(Push_EmpData(&stack_megahead))
		        continue;
		     break;
		   case POP_DATA_OPER:
		     if(GetStack_Data(nav_mode, &stack_megahead, &stack_datalen, &pop_data ) <= FALSE )
		        continue;
		     pop_emp =  (emp_info *)pop_data->stack_databuff;
		     printf("\n EmpID: %u, name_len: %u, emp_name: %s",pop_emp->emp_id,pop_emp->name_len,pop_emp->emp_name  );
		     /* on successful Pop, pop_data contains the poped data, no more process req for pop_data */
             free(pop_data);
		     break;
		   case DESTROY_STACK_OPER:
		     if(StackData_Range(nav_mode, &stack_megahead) <= FALSE)
		       continue;
		     /* allows u to start stack oper */
		     if(Initialize_Stack(&stack_megahead, MAX_STACK_SIZE, MAX_TREE_DATA) <= FALSE)
	           return FALSE;
             break;
           case DESTROY_TREE_OPER:
             TreeData_Range(nav_mode, &tree_megahead);
             /* cannot operate on tree, unless initialized and tree structure is created */
             break;
		   case DISPLAY_OPER:
		     Display_Data();
		     break;
		   case QUIT_OPER:
		     /* destroy stack & tree, before quit */
		     StackData_Range(DESTROY_STACK_OPER, &stack_megahead );
		     TreeData_Range(DESTROY_TREE_OPER, &tree_megahead);
		      break;
		   default:
		     printf("\n ERR[1.3]: Invalid navigation oper: %d", nav_mode);
       }
    } while (nav_mode != QUIT_OPER);
    return TRUE;
}

/*******************************************************************
 Function Name  : Initialize_Tree(tree_head *tree_megaptr, unsigned char max_nodes, unsigned char max_datasize)
 Description    : initialize Tree's mega head
 Remarks        :
 Func ID        : 2
*******************************************************************/
int Initialize_Tree(tree_head *tree_megaptr, unsigned char max_nodes, unsigned char max_datasize)
{
    if(tree_megaptr == NULL)
	{
		printf("\n ERR[31.1]: Invalid T megahead address to initialize");
		return FALSE;
    }
    tree_megaptr->tree_count = 0;
    tree_megaptr->max_treesize = max_nodes;
    /* max data size that quedatabuff, will contain */
    tree_megaptr->max_datasize = max_datasize;
    /* empty tree */
    tree_megaptr->rootptr = NULL;
    Control_Tree(tree_megaptr,FREE_ACCESS );
    if(trace_flag)
       printf("\n TRACE[2.1]:Initialized T's head: %#X, Max T elements: %u, T's element data_size: %u",\
        tree_megaptr, tree_megaptr->max_treesize, tree_megaptr->max_datasize);
    return TRUE;
}

/*******************************************************************
 Function Name : Control_Tree(tree_head *tree_megaptr, char access_mode)
 Description   : control access of the tree
 Remarks       : useful for multi operation be performed in it
 Func ID       : 3
 *******************************************************************/
int Control_Tree(tree_head *tree_megaptr, char access_mode)
{
  	int istrue = FALSE;

  	if( tree_megaptr == NULL)
 	{
 		printf("\n ERR[3.1]: Invalid T's head's address to control its access ");
 		return istrue;
     }
  	switch(access_mode)
  	{
  		case FREE_ACCESS:
  		case NO_ACCESS:
  		  tree_megaptr->access_tree = access_mode;
  		  istrue = TRUE;
  		  break;
  		default:
  		  printf("\n ERR[3.2]: Invalid T's Addr: %#X, access mode: %d", tree_megaptr,access_mode);
     }
     return istrue;
 }

/*******************************************************************
 Function Name  : Empty_Tree(tree_head *tree_megaptr)
 Description    : checks for empty tree
 Remarks        :
 Func ID        : 4
 *******************************************************************/
 int Empty_Tree(tree_head *tree_megaptr)
 {
	 int ret_state = FALSE;

     if(!Access_Tree(tree_megaptr))
	 {
		Control_Tree(tree_megaptr, NO_ACCESS);
		if(tree_megaptr->tree_count > 0)
		   ret_state = TRUE;
	    Control_Tree(tree_megaptr, FREE_ACCESS);
	 }
     return ret_state;
 }

 /*******************************************************************
  Function Name  : Full_Tree(tree_head *tree_megaptr)
  Description    : checks for tree been full & also checks availability memory,
  Remarks        : This func is designed to called be just before a new tree node is added
  Func ID        : 5
  *******************************************************************/
 int Full_Tree(tree_head *tree_megaptr)
 {
	 int ret_state = FALSE;
     void *check_alloc = NULL;

	 if(!Access_Tree(tree_megaptr))
	 {
		 Control_Tree(tree_megaptr, NO_ACCESS);
		 /* tree node count >= max limit, tree is full */
		 if(tree_megaptr->tree_count < tree_megaptr->max_treesize && (check_alloc = calloc(1, sizeof(tree_megaptr->max_datasize))))
		 {
			 free(check_alloc);
			 ret_state = TRUE;
	     }
	     else
	       printf("\n ERR[5.1]: No new memory in T's head addr: %#X OR no of nodes [%u] exceeds its max [%u]", tree_megaptr,tree_megaptr->tree_count, tree_megaptr->max_treesize);
	     Control_Tree(tree_megaptr, FREE_ACCESS);
	 }
	 return ret_state;
 }

/*******************************************************************
 Function Name  : Access_Tree(tree_head *tree_megaptr)
 Description    : check for tree access
 Remarks        :
 Func ID        : 6
 *******************************************************************/
int Access_Tree(tree_head *tree_megaptr)
{
   if(tree_megaptr == NULL)
   {
   	  printf("\n ERR[6.1]: Invalid T head's address to access");
   	  return FALSE;
   }
   if(tree_megaptr->access_tree != FREE_ACCESS)
   {
      /* printf("\n ERR[6.2]: Unable for T's Head Addr: %#X to access: %d",tree_megaptr, tree_megaptr->access_tree ); */
       return FALSE;
   }
   return TRUE;
}

/*******************************************************************
  Function Name  : Tree_Count(Tree_head *tree_megaptr )
  Description    : number of nodes in the tree
  Remarks        :
  Func ID        : 7
 *******************************************************************/
 int Tree_Count(tree_head *tree_megaptr )
 {
	if(!Access_Tree(tree_megaptr))
 	{
 	   if(trace_flag)
    	   printf("\n TRACE[7.1]: T Head's Addr: %#X, current num of tree nodes: %u",tree_megaptr, tree_megaptr->tree_count);
 	    return tree_megaptr->tree_count;
    }
    else
      return FALSE;
 }

/*******************************************************************
 Function Name  : Sample_Tree_Structure(tree_head *tree_megaptr)
 Description    : creates a structure tree:- A(B(C( D)E) F(G(H(IJ(KL)))M(N )))
 Remarks        : tree should be empty, before crating tree
 Func ID        : 8
*******************************************************************/
int Sample_Tree_Structure(tree_head *tree_megaptr)
{
    char ch_data = 'A';
    tree_node *parentnode = NULL;
    tree_node *childnode = NULL;
    tree_node data_node;

    data_node.msgtype = ALPHA;
    data_node.datalen = ALPHA_DATALEN;
    data_node.databuff[0] =  ch_data++;
    if(Access_Tree(tree_megaptr))
	  return FALSE;
    /* A (root) node */
    if(!(tree_megaptr->rootptr = Add_TreeNode(LEFT_NODE, tree_megaptr,tree_megaptr->rootptr, &data_node)))
    /* Failed to alloc memory, skip adding new tree node */
       goto create_fail;
    /* B node: parent A, Left */
    parentnode = tree_megaptr->rootptr;
    data_node.databuff[0] =  ch_data++;
    if(!( childnode = Add_TreeNode(LEFT_NODE,tree_megaptr, parentnode, &data_node)))
       goto create_fail;
    /* C node: parent B, Left */
    parentnode = childnode;
    data_node.databuff[0] =  ch_data++;
	if(!( childnode = Add_TreeNode(LEFT_NODE,tree_megaptr, parentnode, &data_node)))
       goto create_fail;
    /* D node: parent C, right */
    parentnode = childnode;
    data_node.databuff[0] =  ch_data++;
	if(!( childnode = Add_TreeNode(RIGHT_NODE,tree_megaptr, parentnode, &data_node)))
       goto create_fail;
    /* E node: parent B, right */
    parentnode = tree_megaptr->rootptr->subtree_leftptr;
    data_node.databuff[0] =  ch_data++;
    if(!( childnode = Add_TreeNode(RIGHT_NODE, tree_megaptr,parentnode, &data_node)))
       goto create_fail;
    /* F node: parent A, right */
    parentnode = tree_megaptr->rootptr;
    data_node.databuff[0] =  ch_data++;
    if(!( childnode = Add_TreeNode(RIGHT_NODE,tree_megaptr, parentnode, &data_node)))
       goto create_fail;
    /* G node: parent F, left */
    parentnode = childnode;
    data_node.databuff[0] =  ch_data++;
    if(!( childnode = Add_TreeNode(LEFT_NODE,tree_megaptr, parentnode, &data_node)))
       goto create_fail;
    /* H node: parent G, left */
    parentnode = childnode;
    data_node.databuff[0] =  ch_data++;
    if(!( childnode = Add_TreeNode(LEFT_NODE,tree_megaptr, parentnode, &data_node)))
       goto create_fail;
    /* I node: parent H, left */
    parentnode = childnode;
	data_node.databuff[0] =  ch_data++;
	if(!( childnode = Add_TreeNode(LEFT_NODE,tree_megaptr, parentnode, &data_node)))
       goto create_fail;
    /* J node: parent H, right */
	data_node.databuff[0] =  ch_data++;
	if(!( childnode = Add_TreeNode(RIGHT_NODE,tree_megaptr, parentnode, &data_node)))
       goto create_fail;
    /* K node: parent J, left */
	parentnode = childnode;
	data_node.databuff[0] =  ch_data++;
	if(!( childnode = Add_TreeNode(LEFT_NODE,tree_megaptr, parentnode, &data_node)))
       goto create_fail;
    /* L node: parent J, right */
	data_node.databuff[0] =  ch_data++;
	if(!( childnode = Add_TreeNode(RIGHT_NODE,tree_megaptr, parentnode, &data_node)))
	  goto create_fail;
    /* M node: parent F, right */
	parentnode = tree_megaptr->rootptr->subtree_rightptr;
	data_node.databuff[0] =  ch_data++;
	if(!( childnode = Add_TreeNode(RIGHT_NODE,tree_megaptr, parentnode, &data_node)))
	   goto create_fail;
	/* N node: parent M, left */
	parentnode = childnode;
	data_node.databuff[0] =  ch_data++;
	if(!( childnode = Add_TreeNode(LEFT_NODE,tree_megaptr, parentnode, &data_node)))
	   goto create_fail;
	printf("\n INFO[8.1]: Tree Structure: A(B(C( D)E) F(G(H(IJ(KL)))M(N ))) is available ");
	return TRUE;
    create_fail:
	  printf("\n ERR[8.1]: Create Tree Stop in Parent: %#X", parentnode);
	  Destroy_Tree(tree_megaptr);
	  return FALSE;
}

/*******************************************************************
 Function Name  : *Add_TreeNode(tree_node *parentnode, tree_node *datanode )
 Description    : adds a tree node.
 Remarks        : designed only for sample tree struction.
                  datanode's pointing address & its data cannnot be modified.
 Func ID        : 9
*******************************************************************/
tree_node *Add_TreeNode(char mode, tree_head *tree_megaptr, tree_node *parentnode, const tree_node * const datanode )
{
    tree_node *subrootptr = NULL;
    unsigned char allocnode_datalen;

    if(mode != LEFT_NODE && mode != RIGHT_NODE && Full_Tree(tree_megaptr))
    {
	   printf("\n ERR[9.1]: Invalid's parent node's: %#X, mode: %d OR Tree FULL",parentnode,mode );
	   return NULL;
    }
    if(Access_Tree(tree_megaptr))
	  return NULL;
    Control_Tree(tree_megaptr, NO_ACCESS);
    /* we are using only msgtype as data and not using tree's databuff */
    if(datanode->datalen == 0)
    {
		allocnode_datalen = sizeof(tree_node);
		if(!(subrootptr = calloc(1, allocnode_datalen)))
		{
		    printf("ERR[9.2]: Unable T's Head Addr: %#X to alloc node: datasize: %u",tree_megaptr,allocnode_datalen);
		    Control_Tree(tree_megaptr, FREE_ACCESS);
		    return NULL;
        }
        subrootptr->databuff[0] = INVALID_DATA;
    }
    else
    {   /* total size of tree node is data's len + control info,
       Note: databuff[1] holds one byte of variable data, that's why - char size byte */
       allocnode_datalen = datanode->datalen + sizeof(tree_node) - sizeof(char);
       if(datanode->datalen > tree_megaptr->max_datasize || !(subrootptr = calloc(1, allocnode_datalen)))
       {
          printf("ERR[9.3]: Unable T's Head Addr: %#X to alloc node OR datasize[%u]>limit[%u]",tree_megaptr,allocnode_datalen,tree_megaptr->max_datasize);
          Control_Tree(tree_megaptr, FREE_ACCESS);
          return NULL;
       }
       memcpy(subrootptr->databuff, datanode->databuff, datanode->datalen);
    }
    subrootptr->msgtype = datanode->msgtype;
    subrootptr->datalen = datanode->datalen;
    /* new tree node has no outbound (ie) a leaf node */
    subrootptr->subtree_leftptr = NULL;
    subrootptr->subtree_rightptr = NULL;
    ++tree_megaptr->tree_count;
    /* some case, such as in empty tree, parentnode is NULL */
    if(parentnode)
      /* new allocated node is left node in its parent node */
      if( mode == LEFT_NODE)
        parentnode->subtree_leftptr = subrootptr;
      else
        parentnode->subtree_rightptr = subrootptr;

    if(trace_flag)
    {
	  printf("\n TRACE[9.1]: Parent node: %#X - Left Node: %#X, Right Node: %#X",parentnode, parentnode->subtree_leftptr, parentnode->subtree_rightptr);
      printf("\n TRACE[9.2]: Alloc T Node: %#X, tot_datalen:%u - Msgtype:%u, datalen:%u, data:%c ", \
       subrootptr,allocnode_datalen, subrootptr->msgtype,subrootptr->datalen, subrootptr->databuff[0] );
    }
    Control_Tree(tree_megaptr, FREE_ACCESS);
    return subrootptr;
}

/*******************************************************************
 Function Name  : Destroy_Tree(tree_node *rootptr)
 Description    : destroys tree.
 Remarks        :
 Func ID        : 10
*******************************************************************/
int Destroy_Tree(tree_node *rootptr)
{
   tree_node *nodeptr = NULL;
    /* we use post order depth first traversal, because it transverse child nodes, before deleting its parent.
      using, inorder, preorder or breath first, lose its either one or both of its child node's respective,in each parent,
      if, we didn't backup, undeleted child's node's address, before deleting its parent */
   nodeptr = rootptr;
   if(nodeptr)
   {
      Destroy_Tree(nodeptr->subtree_leftptr);
      Destroy_Tree(nodeptr->subtree_rightptr);
      if(trace_flag)
         printf("\n TRACE[10.1]: Delete T node:%#X - msgtype:%u, datalen:%u, data:%c",nodeptr,nodeptr->msgtype,nodeptr->datalen,nodeptr->databuff[0]);
      free(nodeptr);
   }
   return TRUE;
}

/*******************************************************************
 Function Name  : TreeData_Range(int mode, tree_head *megaptr)
 Description    : operates on range in tree
 Remarks        :
 Func ID        : 11
*******************************************************************/
int TreeData_Range(int mode, tree_head *tree_megaptr)
{
   int ret_state = FALSE;

   if(mode == DESTROY_TREE_OPER && !Empty_Tree(tree_megaptr))
   {
     if(!Access_Tree(tree_megaptr))
	 {
	    Control_Tree(tree_megaptr, NO_ACCESS);
        Destroy_Tree(tree_megaptr->rootptr);
        tree_megaptr->tree_count = 0;
        tree_megaptr->max_treesize = 0;
        tree_megaptr->max_datasize = 0;
        /* empty tree */
        tree_megaptr->rootptr = NULL;
        Control_Tree(tree_megaptr, FREE_ACCESS);
        ret_state = TRUE;
     }
   }
   else
     printf("\n ERR[11.1]: T's Head Addr:%#X, already empty to destroy or Invalid mode:%d",tree_megaptr, mode);
   return ret_state;
}

/*******************************************************************
 Function Name  : PreOrder_NavData(tree_head *tree_megaptr, tree_node *rootptr)
 Description    : preorder tranversal of tree's data, using recursive
 Remarks        :
 Func ID        : 12
*******************************************************************/
int PreOrder_NavData(tree_head *tree_megaptr, tree_node *rootptr)
{
	static char node_count = 0;

	if(rootptr)
	{   /* process sub tree root (current node) */
	    printf("\n Count:%2d:: T Node: %#X - Msg:%u, datalen:%u, Data:%c", \
	     ++node_count,rootptr, rootptr->msgtype, rootptr->datalen,rootptr->databuff[0]);
	    /* process current's node left */
		PreOrder_NavData(tree_megaptr, rootptr->subtree_leftptr);
		/* process current's node right */
		PreOrder_NavData(tree_megaptr, rootptr->subtree_rightptr);
    }
    else if(node_count == tree_megaptr->tree_count)
     /* reset node_count, after transveral the whole tree */
      node_count = 0;
    return TRUE;
}

/*******************************************************************
 Function Name  : PreOrder_NavHead(tree_head *tree_megaptr, stack_head *stack_megaptr)
 Description    : preorder tranversal of tree's head, using loop
 Remarks        :
 Func ID        : 13
*******************************************************************/
int PreOrder_NavHead(tree_head *tree_megaptr, stack_head *stack_megaptr)
{
	char node_count = 0;
    tree_node *nodeptr = NULL;
	unsigned char stack_datalen;
	stack_node *pop_data = NULL;
    int ret_state = FALSE;

	/* make the stack empty, before we use the its dedicated stack */
	if(!Empty_Stack(stack_megaptr))
      StackData_Range(DESTROY_STACK_OPER, stack_megaptr );
	/* databuff of stack, will have tree node's address & its data len holds address of tree's node */
	if(Initialize_Stack(stack_megaptr, MAX_STACK_SIZE, sizeof(tree_node *) ) <= FALSE)
	   return ret_state;
	nodeptr = tree_megaptr->rootptr;
	while(nodeptr)
	{
	   /* process current tree node */
	   printf("\n Count:%2d:: T's Node's Addr:%#X - Node's Data:%c, Left:%#6X, Right:%#6X",\
	     ++node_count, nodeptr,nodeptr->databuff[0],nodeptr->subtree_leftptr, nodeptr->subtree_rightptr);
	   /* push the current node's right node is to be processed, after current node's left node */
	   if(nodeptr->subtree_rightptr)
	      if((ret_state = Push_TreeNode(stack_megaptr, nodeptr->subtree_rightptr)) <= FALSE)
	         break;
	   /* push the current node's left node is to be processed, after current node */
	   if(nodeptr->subtree_leftptr)
	      if((ret_state = Push_TreeNode(stack_megaptr, nodeptr->subtree_leftptr)) <= FALSE)
	         break;
	   if(!Empty_Stack(stack_megaptr))
	   {
		  /* retrieve latest node been pushed, to process it */
		  if((ret_state = GetStack_Data(POP_DATA_OPER, stack_megaptr, &stack_datalen, &pop_data )) <= FALSE)
			 break;
	      if(ret_state == TREE_NODE_MSG)
	         nodeptr = (tree_node *)pop_data->stack_databuff[0];
              else
               ret_state  printf("\n ERR[13.1]: Rcvd non tree node's msg[%d] from stack",ret_stateret_state); 
	      free(pop_data);   
	   }
	   else /* stack is empty, no more node need to transveral */
	      nodeptr = NULL;
    }
    if(ret_state >= TRUE)
       ret_state = TRUE;
    else if(ret_state == FALSE)
    {
       StackData_Range(DESTROY_STACK_OPER, stack_megaptr );
       printf("\n ERR[13.2]: Faced some problem during preorder oper");
    }
    else
       printf("\n ERR[13.3]: Might be due to memory shortage");
    return ret_state;
}

/*******************************************************************
 Function Name  : InOrder_NavData(tree_node *rootptr)
 Description    : inorder tranversal of tree's data, using recursive
 Remarks        :
 Func ID        : 14
*******************************************************************/
int InOrder_NavData(tree_node *rootptr)
{
	static char node_count = 0;

	if(rootptr)
	{
		/* first, process current's node left */
		InOrder_NavData(rootptr->subtree_leftptr);
		/* process sub tree root (current node) */
	    printf("\n Count:%2d:: T Node: %#X - Msg:%u, datalen:%u, Data:%c", \
	     ++node_count,rootptr, rootptr->msgtype, rootptr->datalen,rootptr->databuff[0]);
	    /* process current's node right */
		InOrder_NavData(rootptr->subtree_rightptr);
    }
    else if(node_count == tree_megahead.tree_count)
    /* if not reset, node_count, been static, next time, continue from where we left */
      node_count = 0;
    return TRUE;
}

/*******************************************************************
 Function Name  : InOrder_NavHead(tree_head *tree_megaptr, stack_head *stack_megaptr)
 Description    : Inorder tranversal of tree's head, using loop
 Remarks        : working
 Func ID        : 15
*******************************************************************/
int InOrder_NavHead(tree_head *tree_megaptr, stack_head *stack_megaptr)
{

}

/*******************************************************************
 Function Name  : PostOrder_NavData(tree_head *tree_megaptr,treenode *rootptr)
 Description    : postorder tranversal of tree's data, using recursive
 Remarks        :
 Func ID        : 16
*******************************************************************/
int PostOrder_NavData(tree_head *tree_megaptr, tree_node *rootptr)
{
	static char node_count = 0;

	if(rootptr)
	{
		/* first, process current's node left */
		PostOrder_NavData(tree_megaptr, rootptr->subtree_leftptr);
		/* process current's node right */
		PostOrder_NavData(tree_megaptr, rootptr->subtree_rightptr);
		/* process sub tree root (current node) */
	    printf("\n Count:%2d:: T Node: %#X - Msg:%u, datalen:%u, Data:%c", \
	     ++node_count,rootptr, rootptr->msgtype, rootptr->datalen,rootptr->databuff[0]);
    }
    else if(node_count == tree_megaptr->tree_count)
      node_count = 0;
    return TRUE;
}

/*******************************************************************
 Function Name  : PostOrder_NavHead(tree_head *tree_megaptr, stack_head *stack_megaptr)
 Description    : postorder tranversal of tree's data, using loop
 Remarks        : working
 Func ID        : 17
*******************************************************************/
int PostOrder_NavHead(tree_head *tree_megaptr, stack_head *stack_megaptr)
{

}

/*******************************************************************
 Function Name  : Breath_NavHead(treenode *rootptr)
 Description    : Breath first  tranversal of tree's data, using recursive
 Remarks        :
 Func ID        : 18
*******************************************************************/
int Breath_NavHead(tree_node *rootptr)
{

}
/*******************************************************************
 Function Name  : Display_Data(void *disp_data)
 Description    : gets display mode, and display related data
 Remarks        :
 Func ID        : 19
*******************************************************************/
 int Display_Data(void)
 {
 	 int display_mode;
     int ret_state = TRUE;
     tree_head *tree_megaptr = &tree_megahead;
     stack_head *stack_megaptr = &stack_megahead;

     printf("\n Stack            :: 1: Top,   2: Whole,    3: S Head, 4: Tree's Head");
     printf("\n Tree's Data      :: 5: Pre,   6: Inorder,  7: Post    8: T's Link(Pre)");
 	 printf("\n Tree Structure   :: 8: Pre,    Enter Display Mode: ");
     scanf("%d", &display_mode);
     switch(display_mode)
     {
 		case STACK_MEGA_HEAD:
        case RETRIEVE_TOP:
 	    case RETRIEVE_STACK:
 	      ret_state = Display_Stack(display_mode, &stack_megahead);
 	      break;
 		case WHOLE_DATA_PRE:
 		case WHOLE_DATA_IN:
        case WHOLE_DATA_POST:
        case PRE_MEGA_DATA:
        case TREE_MEGA_HEAD:
          if(!Access_Tree(tree_megaptr))
          {
			 if(Empty_Tree(tree_megaptr))
			 {
				 printf("\n ERR[19.1]: T Head Addr: %#X is already empty tree",tree_megaptr);
				 ret_state = FALSE;
				 break;
		     }
	         Control_Tree(tree_megaptr, NO_ACCESS);
             ret_state = Display_Tree(display_mode, tree_megaptr, stack_megaptr);
             Control_Tree(tree_megaptr, FREE_ACCESS);
	      }
          break;
        default:
           printf("\n ERR[19.2]: Invalid display mode: %d",display_mode );
           ret_state = FALSE;
     }
     return ret_state;
}

/*******************************************************************
 Function Name  : Display_Tree(int display_mode, void *dataptr)
 Description    : display whole tree from root, using some tranversal order
 Remarks        :
 Func ID        : 20
*******************************************************************/
 int Display_Tree(int display_mode, tree_head *tree_megaptr, stack_head *stack_megaptr)
 {
	 int ret_state = TRUE;

	 switch(display_mode)
	 {
		 case WHOLE_DATA_PRE:
		   ret_state = PreOrder_NavData(tree_megaptr,tree_megaptr->rootptr);
		   break;
         case WHOLE_DATA_IN:
           ret_state = InOrder_NavData(tree_megaptr->rootptr);
           break;
         case WHOLE_DATA_POST:
           ret_state = PostOrder_NavData(tree_megaptr, tree_megaptr->rootptr);
           break;
         case PRE_MEGA_DATA:
           ret_state = PreOrder_NavHead(tree_megaptr, stack_megaptr);
           break;
         case TREE_MEGA_HEAD:
           printf("\n Tree Head's Addr: %#X, nodes count  : %u, max nodes  : %u", tree_megaptr,tree_megaptr->tree_count,tree_megaptr->max_treesize);
           printf("\n Tree Root's Addr: %#X, max data size: %u, tree access: %d", tree_megaptr->rootptr, tree_megaptr->max_datasize,tree_megaptr->access_tree);
           break;
         default:
           printf("\n ERR[20.1]: Doesn't support display mode: %d", display_mode);
           ret_state = FALSE;
     }
     return ret_state;
 }

/*******************************************************************
 Function Name  : Initialize_Stack(stack_head *stack_megaptr, int max_nodes, unsigned max_datasize)
 Description    : initialize of stack's mega head node
 Remarks        : assume that input parameter are valid
 Func ID        : 21
 *******************************************************************/
int Initialize_Stack(stack_head *stack_megaptr, unsigned max_nodes, unsigned max_datasize )
{
	if(stack_megaptr == NULL)
	{
		printf("\n ERR[21.1]: Invalid stack megahead address to initialize");
		return FALSE;
    }
    if(!(stack_megaptr->stack_array = calloc(max_nodes, sizeof(stack_node))))
      return NO_MEMORY;
    stack_megaptr->stack_count = 0;
    stack_megaptr->max_stacksize = max_nodes;
    /* max data size that quedatabuff, will contain */
    stack_megaptr->max_datasize = max_datasize;
    stack_megaptr->top_index = 0;
    Control_Stack(stack_megaptr,FREE_ACCESS );
    if(trace_flag)
       printf("\n TRACE[21.1]:Initialized S's head: %#X, S array Addr: %#X , Max S elements: %u, S's element data_size: %u",\
        stack_megaptr,stack_megaptr->stack_array,stack_megaptr->max_stacksize, stack_megaptr->max_datasize);
    return TRUE;
}

/*******************************************************************
 Function Name : Control_Stack(stack_head *stack_megaptr, int access_mode)
 Description   : control access of the stack
 Remarks       : useful for multi operation be performed in it
 Func ID       : 22
 *******************************************************************/
int Control_Stack(stack_head *stack_megaptr, char access_mode)
{
  	int istrue = FALSE;

  	if(stack_megaptr == NULL)
 	{
 		printf("\n ERR[22.1]: Invalid S head's address to control its access ");
 		return istrue;
     }
  	switch(access_mode)
  	{
  		case FREE_ACCESS:
  		case NO_ACCESS:
  		  stack_megaptr->access_stack = access_mode;
  		  istrue = TRUE;
  		  break;
  		default:
  		  printf("\n ERR[22.2]: Invalid S's Addr: %#X access mode: %d", stack_megaptr,access_mode);
     }
     return istrue;
 }

/*******************************************************************
 Function Name  : Empty_Stack(stack_head *stack_megaptr)
 Description    : checks for empty stack
 Remarks        :
 Func ID        : 23
 *******************************************************************/
 int Empty_Stack(stack_head *stack_megaptr)
 {
	 int ret_state = FALSE;

     if(!Access_Stack(stack_megaptr))
	 {
		Control_Stack(stack_megaptr, NO_ACCESS);
		if(stack_megaptr->stack_count > 0)
		   ret_state = TRUE;
	    Control_Stack(stack_megaptr, FREE_ACCESS);
	 }
     return ret_state;
 }

 /*******************************************************************
  Function Name  : Full_Stack(stack_head *stack_megaptr)
  Description    : checks for stack been full
  Remarks        : also checks availability memory
  Func ID        : 24
  *******************************************************************/
 int Full_Stack(stack_head *stack_megaptr)
 {
	 int ret_state = FALSE;
     void *check_alloc = NULL;

	 if(!Access_Stack(stack_megaptr))
	 {
		 Control_Stack(stack_megaptr, NO_ACCESS);
		 if(stack_megaptr->stack_count < stack_megaptr->max_stacksize && (check_alloc = calloc(1, sizeof(stack_megaptr->max_datasize))))
		 {
			 free(check_alloc);
			 ret_state = TRUE;
	     }
	     else
	       printf("\n ERR[24.1]: No new memory in S's head addr: %#X OR no of nodes [%u] exceeds its max [%u]", stack_megaptr,stack_megaptr->stack_count, stack_megaptr->max_stacksize);
	     Control_Stack(stack_megaptr, FREE_ACCESS);
	 }
	 return ret_state;
 }

/*******************************************************************
 Function Name  : Access_Stack(stack_head *stack_megaptr)
 Description    : check for stack access
 Remarks        :
 Func ID        : 25
 *******************************************************************/
int Access_Stack(stack_head *stack_megaptr)
{
   if(stack_megaptr == NULL)
   {
   	  printf("\n ERR[25.1]: Invalid S head's address to access");
   	  return FALSE;
   }
   if(stack_megaptr->access_stack != FREE_ACCESS)
   {
      /* printf("\n ERR[25.2]: Unable for S's Head Addr: %#X, to access: %d",stack_megaptr,stack_megaptr->access_stack );*/
       return FALSE;
   }
   return TRUE;
}

/*******************************************************************
  Function Name  : Stack_Count(stack_head *stack_megaptr )
  Description    : number of nodes in the stack
  Remarks        :
  Func ID        : 26
 *******************************************************************/
 int Stack_Count(stack_head *stack_megaptr)
 {
	if(!Access_Stack(stack_megaptr))
 	{
 	   if(trace_flag)
    	   printf("\n TRACE[26.1]: S Head's Addr: %#X, current num of stack nodes: %u",stack_megaptr, stack_megaptr->stack_count);
 	    return stack_megaptr->stack_count;
    }
    else
      return FALSE;
 }

/*******************************************************************
 Function Name  : Push_Data(stack_head *stack_megaptr, stack_node *push_data )
 Description    : insert data provided through its address at top of stack
 Remarks        :
 Func ID        : 27
 *******************************************************************/
int Push_Data(stack_head *stack_megaptr, unsigned char stack_datalen, stack_node *push_data )
{
	void *allocptr = NULL;

	if(Full_Stack(stack_megaptr))
	   return FALSE;
	if(!Access_Stack(stack_megaptr))
	{
	   /* Stack is not full */
	   Control_Stack(stack_megaptr, NO_ACCESS);
	   /* total size that stack's data buffer requires should not exceeds the limit */
	   if(push_data->datalen > stack_megaptr->max_datasize)
	   {
	      printf("\n ERR[27.1]: Try to Push S's Head Addr: %#X, datalen [%u] > max [%u]",stack_megaptr,push_data->datalen, stack_megaptr->max_datasize);
		  Control_Stack(stack_megaptr, FREE_ACCESS);
	      return FALSE;
       }
       /* if stack's data buffer either contains a char, interger or no data, no need to alloc memory */
	   if(push_data->datalen > sizeof(unsigned))
	   {
	      if(!(allocptr = calloc(1, push_data->datalen )))
          {
	         printf("\n ERR[27.2]: No New Memory for S's Head Addr: %#X, datalen: %u",stack_megaptr,push_data->datalen);
	         return NO_MEMORY;
          }
          /* stack_databuff contains pointer's address, where stack's variable data exist */
	      memcpy(allocptr, push_data->stack_databuff, push_data->datalen);
	      stack_megaptr->stack_array[stack_megaptr->top_index].stack_databuff[0] = (unsigned)allocptr;
       }
       /* stack's var data does not exist */
       else if(push_data->datalen == 0)
         stack_megaptr->stack_array[stack_megaptr->top_index].stack_databuff[0] = 0;
       else  /* if stack's var data, contains only a char or interger */
         stack_megaptr->stack_array[stack_megaptr->top_index].stack_databuff[0] = push_data->stack_databuff[0];
         /* copy's data's info until, variable data buffer */
         memcpy(stack_megaptr->stack_array + stack_megaptr->top_index, push_data, sizeof(stack_node) - sizeof(unsigned));
        if(trace_flag)
        {
           printf("\n TRACE[27.1]: S's Head's Addr: %#X, stack_top: %d, Push Node: %#X", \
            stack_megaptr, stack_megaptr->top_index, stack_megaptr->stack_array + stack_megaptr->top_index);
           printf("\n TRACE[27.2]: MsgType: %u, S's var datalen: %u, DataBuff: %#X", stack_megaptr->stack_array[stack_megaptr->top_index].msgtype, \
            stack_megaptr->stack_array[stack_megaptr->top_index].datalen, stack_megaptr->stack_array[stack_megaptr->top_index].stack_databuff[0] );
         }
         ++stack_megaptr->stack_count;
         ++stack_megaptr->top_index;
         Control_Stack(stack_megaptr, FREE_ACCESS);
         return TRUE;
    }
    return FALSE;
}

/*******************************************************************
 Function Name  : Pop_Data(stack_head *stack_megaptr, unsigned char *stack_datalen, void *pop_data)
 Description    : delete node's data provided through its address at top of stack
 Remarks        :
 Func ID        : 28
 *******************************************************************/
 int Pop_Data(stack_head *stack_megaptr, unsigned char *stack_datalen, stack_node **pop_data)
 {
	 unsigned char pop_datalen;
     stack_node *pop_node = NULL;

     if(Empty_Stack(stack_megaptr))
     {
		 printf("\n ERR[28.1]: S's Head Addr: %#X is empty to pop",stack_megaptr);
         return FALSE;
     }
     if(Access_Stack(stack_megaptr))
        return FALSE;
     Control_Stack(stack_megaptr, NO_ACCESS);
     /* get stack node to be poped. data to be poped is located at stack's top_index - 1 */
     pop_node = stack_megaptr->stack_array + stack_megaptr->top_index - 1;
     /* if its stack's data buffer holds char data only or no var data */
	 if(pop_node->datalen <= sizeof(unsigned))
	   pop_datalen = sizeof(stack_node);
	 else
       pop_datalen = sizeof(stack_node) + pop_node->datalen - sizeof(unsigned);
     /* pop_data is assigned memory location, shall be freed either directly or indirecty by its called func */
     if(!(*pop_data = calloc(1, pop_datalen )))
     {
		 printf("\n ERR[28.2]: NO new memory for S's head addr: %#X, pop data's len :%u, S's var datalen: %u",stack_megaptr, pop_datalen, pop_node->datalen );
		 Control_Stack(stack_megaptr, FREE_ACCESS);
		 return NO_MEMORY;
     }
     /* copy's data's info until, variable data buffer */
     memcpy(*pop_data, pop_node, sizeof(stack_node) - sizeof(unsigned ));
     /* retrieves variable data */
     if(pop_node->datalen > sizeof(unsigned))
	 { /* stack's databuff has pointer address only, where stack's variable data exist */
	    memcpy((*pop_data)->stack_databuff, (void *)pop_node->stack_databuff[0], pop_node->datalen);
	    /* don't forget to free the allocated variable data buffer, depending on datalen */
	 	if(pop_node->stack_databuff[0])
	      free((void *)pop_node->stack_databuff[0]);
	 }
	 else if(pop_node->datalen == 0)
	   (*pop_data)->stack_databuff[0] = 0;
	 else
	   (*pop_data)->stack_databuff[0] = pop_node->stack_databuff[0];
     /* total data retrieved from stack including overhead's */
     *stack_datalen = pop_datalen;
     --stack_megaptr->top_index;
     --stack_megaptr->stack_count;
     if(trace_flag)
     {
	     printf("\n TRACE[28.1]: S's Head Addr: %#X, pop_index: %d, Pop Node: %#X", \
	      stack_megaptr, stack_megaptr->top_index, pop_node );
	     printf("\n TRACE[28.2]: *pop_data Addr: %#X, tot_stackdatalen: %u, Node's stack_databuff: %#X",*pop_data, pop_datalen,pop_node->stack_databuff[0]);
     }
     Control_Stack(stack_megaptr, FREE_ACCESS);
     return TRUE;
 }

/*******************************************************************
  Function Name  : Retrieve_StackData(stack_head *stack_megaptr, stack_node *cur_node, unsigned char *stack_datalen, void **pop_data)
  Description    : retrieves data either at top or intermediate stack node
  Remarks        : doesnt delete its node
  Func ID        : 29
  *******************************************************************/
 int Retrieve_StackData(int ret_mode,stack_head *stack_megaptr, stack_node *cur_node, unsigned char *stack_datalen, stack_node **pop_data)
 {
	int ret_state = FALSE;
    unsigned char totstack_datalen;
    char retrieve_index;
    stack_node *get_node = NULL;

	if(Empty_Stack(stack_megaptr))
	{
	   printf("\n ERR[29.1]: Try in S Head's Ptr: %#X to retrive in empty stack",stack_megaptr);
	   return ret_state;
    }
	/* not a empty stack */
   if(Access_Stack(stack_megaptr))
       return FALSE;
    Control_Stack(stack_megaptr, NO_ACCESS);
    switch(ret_mode)
    {
       case RETRIEVE_TOP:
         /* data to be retrieve from stack's top, is located at stack's top_index - 1 */
         get_node = stack_megaptr->stack_array + stack_megaptr->top_index - 1;
         retrieve_index = stack_megaptr->top_index - 1;
         ret_state = TRUE;
	     if(trace_flag)
	        printf("\n TRACE[29.1]: S Head's Addr:%#X, Var_datalen: %u, retrieve index[%u]", \
	         stack_megaptr,get_node->datalen, stack_megaptr->top_index - 1);
         break;
       case RETRIEVE_STACK:
         /* make sure that cur_node points to stack node or empty node */
         if(cur_node == NULL || cur_node > stack_megaptr->stack_array + stack_megaptr->top_index - 1 || cur_node < stack_megaptr->stack_array )
	     {
	         printf("\n ERR[29.2]: Curnode's of S's head addr: %#X, is invalid  ",stack_megaptr );
	         break;
	     }
	     get_node = cur_node;
	     retrieve_index = get_node - stack_megaptr->stack_array;
		 ret_state = TRUE;
		 if(trace_flag)
		    printf("\n TRACE[29.2]: S Head's Addr:%#X, Var_datalen: %u, retrieve index[%u]", \
	         stack_megaptr,get_node->datalen,retrieve_index);
         break;
       default:
         printf("\n ERR[29.3]: Invalid S's head addr: %#X, retrieve mode: %d", stack_megaptr, ret_mode );
    }
    if(ret_state == TRUE)
    {
		/* if its queue's data buffer holds address only */
		if(get_node->datalen <= sizeof(unsigned))
		   totstack_datalen = sizeof(stack_node);
		else
           totstack_datalen = sizeof(stack_node) + get_node->datalen - sizeof(unsigned);
		if(!(*pop_data = calloc(1, totstack_datalen)))
		{
		    printf("\n ERR[29.4]: NO new memory for S's head addr: %#X,retrieve data,whose totlen:%u",stack_megaptr, totstack_datalen );
		    Control_Stack(stack_megaptr, FREE_ACCESS);
		    return NO_MEMORY;
        }
        *stack_datalen = totstack_datalen;
        /* copy's data's info until, variable data buffer */
        memcpy(*pop_data, get_node, sizeof(stack_node) - sizeof(unsigned));
        /* retrieves variable data */
        if(get_node->datalen > sizeof(unsigned))
           memcpy((*pop_data)->stack_databuff, (void *)get_node->stack_databuff[0], get_node->datalen);
        else if(get_node->datalen == 0)
	      (*pop_data)->stack_databuff[0] = 0;
	    else
	      (*pop_data)->stack_databuff[0] = get_node->stack_databuff[0];
     }
     if(trace_flag)
        printf("\n TRACE[29.4]: retrive S node: %#X:: totstack_datalen: %u, Node's stack_databuff: %#X, pop_data Addr: %#X",\
         get_node, totstack_datalen, get_node->stack_databuff[0],*pop_data);
     Control_Stack(stack_megaptr, FREE_ACCESS);
	 return ret_state;
 }

 /*******************************************************************
  Function Name  : Destroy_Stack(stack_head *stack_megaptr )
  Description    : makes the stack empty
  Remarks        :
  Func ID        : 30
  *******************************************************************/
   int Destroy_Stack(stack_head *stack_megaptr )
   {
 	  int ret_state = FALSE;
      stack_node *cur_node = NULL;
      void *del_buff = NULL;
      char node_count = 0, cur_index;

 	  if(!Empty_Stack(stack_megaptr))
 	  {   /* not a empty stack  */
 	      if(Access_Stack(stack_megaptr))
             return FALSE;
 	      Control_Stack(stack_megaptr, NO_ACCESS);
 	      /* stack's top most data is located at stack's top_index - 1 */
 	      cur_index = stack_megaptr->top_index - 1;
 	      /* deleting each node from stack's top */
           while(node_count < stack_megaptr->stack_count)
           {
			  /* current stack node & its data buffer */
			  cur_node = stack_megaptr->stack_array + cur_index;
 			  del_buff = (void *)stack_megaptr->stack_array[cur_index].stack_databuff[0];
 			  /* add codes here, if you want to retrive data from node, before been deleted */
 			  if(cur_node->datalen > sizeof(unsigned) && del_buff)
 			  /* free's stack's variable data buffer */
 			    free(del_buff);
 			  ++node_count;
 			  --cur_index;
 	      }
 	      /* free dynamic 1D array */
 	      if(stack_megaptr->stack_array)
 	         free(stack_megaptr->stack_array);
 	      /* initialize with invalid data */
 	      stack_megaptr->stack_array = NULL;
 	      stack_megaptr->stack_count = 0;
          stack_megaptr->max_stacksize = 0;
          stack_megaptr->max_datasize = 0;
          stack_megaptr->top_index = 0;
          Control_Stack(stack_megaptr,FREE_ACCESS );
          ret_state = TRUE;
       }
       else
         printf("\n ERR[30.1]: S's Head Ptr: %#X, is already empty to destroy",stack_megaptr);
       return ret_state;
  }

/*******************************************************************
   Function Name : Display_Stack(int mode, void *disp_input)
   Description   : display's stack related info
   Remarks       :
   fUNC_ID       : 31
 *******************************************************************/
int Display_Stack(int mode, void *disp_input)
{
	stack_head *stack_megaptr = NULL;
	int ret_state = TRUE;
    unsigned char stack_datalen;
    stack_node *pop_data = NULL;

    stack_megaptr = (stack_head *)disp_input;
	switch(mode)
	{
	   case STACK_MEGA_HEAD:
	     printf("\n S Head Addr: %#X:: No of nodes: %u, max stack nodes: %u, max_datasize: %u", \
	       stack_megaptr,stack_megaptr->stack_count, stack_megaptr->max_stacksize, stack_megaptr->max_datasize);
	     printf("\n top index: %d, access_stack: %d, stack_array: %#X", \
	       stack_megaptr->top_index, stack_megaptr->access_stack,stack_megaptr->stack_array);
         break;
       case RETRIEVE_TOP:
	     if((ret_state = GetStack_Data(mode, stack_megaptr, &stack_datalen, &pop_data )) >= TRUE)
	        free(pop_data);
	     break;
	   case RETRIEVE_STACK:
	     if(StackData_Range(mode, stack_megaptr))
	        ret_state = FALSE;
	     break;
	   default:
	      printf("\n ERR[31.1]: Invalid display mode: %d", mode);
          ret_state = FALSE;
     }
     return ret_state;
}

/*******************************************************************
   Function Name : GetStack_Data(unsigned get_mode, stack_head *stack_megaptr,unsigned char *stack_datalen, stack_node **pop_data )
   Description   : user level deque or retrieve queue's data
   Remarks       : returns either kind of data it possess, or failed queue oper.
   fUNC_ID       : 32
 *******************************************************************/
int GetStack_Data(unsigned get_mode, stack_head *stack_megaptr,unsigned char *stack_datalen, stack_node **pop_data )
{  /* holds starting address of pop data & start_datalen holds pop data's total length */
   int ret_state = TRUE;

   switch(get_mode)
   {
	   case POP_DATA_OPER:
	     ret_state = Pop_Data(stack_megaptr, stack_datalen, pop_data);
         break;
       case RETRIEVE_TOP:
         ret_state = Retrieve_StackData(get_mode, stack_megaptr, NULL, stack_datalen, pop_data);
         break;
       default:
         printf("\n ERR[32.1]: Invalid S's Head Addr: %#X, get mode: %d",stack_megaptr, get_mode);
         ret_state = FALSE;
   }
   /* pop_data has data from stack, which was either retrieved or poped */
   if(ret_state == TRUE)
      ret_state = GetStack_MsgData(*pop_data, *stack_datalen);
   return ret_state;
}

/*******************************************************************
   Function Name : Pop_EmpData(stack_node *pop_data)
   Description   : retrive employee info from pop data
   Remarks       : pop_data has info about customer.
   fUNC_ID       : 33
 *******************************************************************/
 int Pop_EmpData(stack_node *pop_data)
 {
	 emp_info *pop_emp = NULL;

     if(pop_data->datalen != sizeof(emp_info) - sizeof(char) + ((emp_info *)pop_data->stack_databuff)->name_len)
	 {  /* might be due to data corruption in stack oper */
		 printf("\n ERR[33.1]: stack_datalen[%u] != total len of emp data [%u] ", pop_data->datalen, sizeof(emp_info) - sizeof(char) + ((emp_info *)pop_data->stack_databuff)->name_len);
		 /* remember to be free poped data, after been allocated in pop operation */
		 free(pop_data);
		 return FALSE;
     }
     /* decapulation of emp info from stack_data's databuff */
     pop_emp = (emp_info *) pop_data->stack_databuff;
     if(trace_flag)
       printf("\n TRACE[33.1]: Emp_Data Addr: %#X:: Emp Datalen: %u, emp_name Ptr: %#X",\
        pop_emp,pop_data->datalen, pop_emp->emp_name  );
     if(trace_flag)
       printf("\n TRACE[33.2]: EmpID: %u, name_len: %u, emp_name: %s",\
         pop_emp->emp_id,pop_emp->name_len,pop_emp->emp_name  );
     return TRUE;
 }

/*******************************************************************
   Function Name : Pop_TreeNode(stack_node *pop_data)
   Description   : retrive a sub Tree Root Node's Addr info from poped data
   Remarks       :
   fUNC_ID       : 34
 *******************************************************************/
 int Pop_TreeNode(stack_node *pop_data)
 {
	 tree_node *rootptr = NULL;

     if(pop_data->datalen != sizeof(tree_node *) )
	 {  /* might be due to data corruption in queue oper */
		 printf("\n ERR[34.1]: pop data len[%u] != tree_node's Ptr [%u] ", pop_data->datalen, sizeof(tree_node *));
		 /* remember to be free poped data, after been allocated in pop operation */
		 free(pop_data);
		 return FALSE;
     }
     /* decapulation of emp info from stack_data's databuff */
     rootptr = (tree_node *) pop_data->stack_databuff[0];
     if(trace_flag)
     {
       printf("\n TRACE[34.1]: Pop Tree Node: %#X, Tree Data: Msgtype:%u, datalen:%u, databuff:%c", rootptr, \
	     rootptr->msgtype, rootptr->datalen, rootptr->databuff[0]);
       printf("\n TRACE[34.2]: pop Tree Node's:%#X:: Left Node:%#X, Right Node:%#X",rootptr,rootptr->subtree_leftptr,rootptr->subtree_rightptr);
     }
     return TRUE;
 }

/*******************************************************************
  Function Name : GetStack_MsgData(stack_node *pop_data, unsigned char stack_datalen)
  Description   : depending on data retrived from stack,
  Remarks       : pop_data has info about either employee or tree node data
  fUNC_ID       : 35
*******************************************************************/
  int GetStack_MsgData(stack_node *pop_data, unsigned char stack_datalen)
  {
      int ret_state = FALSE;

      if(trace_flag)
         printf("\n TRACE[35.1]: pop_data Addr: %#X, totstack_datalen: %u, msgtype: %u",pop_data, stack_datalen, pop_data->msgtype);
      switch(pop_data->msgtype)
      {
	     case TREE_NODE_MSG:
	      /* retrieve sample tree's info */
	       if((ret_state = Pop_TreeNode(pop_data)) == TRUE)
	         ret_state = TREE_NODE_MSG;
	       break;
	     case EMP_MSG:
	       /* retrive employee's info */
	       if((ret_state = Pop_EmpData(pop_data )) == TRUE)
	          ret_state = EMP_MSG;
	       break;
	     default:
	        printf("\n ERR[35.1]: Get Invalid msgtype %u from stack, with datalen: %u",pop_data->msgtype, stack_datalen);
	        free(pop_data);
	        ret_state = FALSE;
	  }
      return ret_state;
   }

/*******************************************************************
  Function Name : StackData_Range(unsigned mode, stack_head *stack_megaptr)
  Description   : process on partial or whole operation in stack's  data
  Remarks       : pop_data has info about either customer or tree node's data
  fUNC_ID       : 36
 *******************************************************************/
 int StackData_Range(unsigned mode, stack_head *stack_megaptr)
 {
	 stack_node *curptr = NULL;         /* local temp ptr contains current node */
	 int ret_state = TRUE;
     char cur_index;
     unsigned char stack_datalen;
     stack_node *pop_data = NULL;
     int node_count = 0;

     if(Empty_Stack(stack_megaptr))
     {
		 printf("\n ERR[36.1]: S Head's Ptr: %#X, already stack empty",stack_megaptr);
	     return FALSE;
     }
     if(Access_Stack(stack_megaptr))
        return FALSE;
     switch(mode)
     {
		 case RETRIEVE_STACK:
	        Control_Stack(stack_megaptr, NO_ACCESS);
	        /* stack top most data is located at stack's top_index - 1 */
	        cur_index = stack_megaptr->top_index - 1;
    	    while(node_count < stack_megaptr->stack_count)
		    {
				curptr = stack_megaptr->stack_array + cur_index;
				if(trace_flag)
		           printf("\n\n %02d: retrieve_index: %d, Stack Node: %#X", node_count + 1, cur_index, curptr );
		        Control_Stack(stack_megaptr, FREE_ACCESS);
		        if((ret_state = Retrieve_StackData((int)mode, stack_megaptr, curptr, &stack_datalen, &pop_data )) <= FALSE)
		        /* unable to retrieve data, give up */
		           break;
		        Control_Stack(stack_megaptr, NO_ACCESS);
		        /* GetStack_MsgData already frees when encountered some problems */
			    if((ret_state = GetStack_MsgData(pop_data, stack_datalen)) >= TRUE)
			    /* no more process req on retrieve data, free it */
                   free(pop_data);
		        ++node_count;
		        --cur_index;
	        }
	        if(ret_state >= TRUE)
	          ret_state = TRUE;
	        Control_Stack(stack_megaptr, FREE_ACCESS);
	        /* printf("\n ============================================"); */
            break;
          case DESTROY_STACK_OPER:
            if((node_count = Stack_Count(stack_megaptr)) <= FALSE)
              return ret_state;
            /* printf("\n INFO[36.1]: Before Destroy:: S Head's Addr: %#X, current num of nodes: %u", stack_megaptr,node_count); */
            ret_state = Destroy_Stack(stack_megaptr);
            break;
          default:
            printf("\n ERR[36.1]: Invalid S Head's Addr: %#X, range_mode: %u",stack_megaptr, mode);
            ret_state = FALSE;
     }
     return ret_state;
 }

/*******************************************************************
   Function Name : Push_EmpData(stack_head *stack_megaptr)
   Description   : manually getting a valid input data before push operation
   Remarks       : assume that input data are valid
   fUNC_ID       : 37
 *******************************************************************/
int Push_EmpData(stack_head *stack_megaptr)
{
    int ret_state = FALSE;
    emp_info *emp_data = NULL;
    stack_node *temp_push = NULL;
    char name[OPER_SIZE];
    unsigned char stackdata_totlen;
    char temp_data[MAX_STACK_SIZE];
    unsigned emp_id, name_len;

    printf("\n Enter Emp ID & its name: ");
    scanf(" %u %[^\n]", &emp_id, name);
    /* name's len also includes NUL character:'\0' */
    name_len = strlen(name) + 1;
    if(name_len > MAX_NAME)
    {
		printf("\n ERR[37.1]: Entered name %s, whose len %d exceeds tree's data limit: %u",name,name_len,MAX_NAME);
		return FALSE;
    }
    stackdata_totlen = sizeof(stack_node) - sizeof(unsigned) + sizeof(emp_info) - sizeof(char) + name_len;
    memset(temp_data,0,MAX_STACK_SIZE);
    temp_push = (stack_node *)temp_data;
	temp_push->msgtype = EMP_MSG;
	temp_push->datalen = sizeof(emp_info) - sizeof(char) + name_len;
	/* encapulation of employee info into stack_data's databuff */
	emp_data = (emp_info *)temp_push->stack_databuff;
	emp_data->emp_id = emp_id;
	emp_data->name_len = name_len;
	memcpy(emp_data->emp_name, name, name_len);
    if(trace_flag)
	{
	    printf("\n TRACE[37.1]: Push Data - totstack_datalen:%u:: Msgtype:%u, Emp tot_datalen:%u",stackdata_totlen,temp_push->msgtype,temp_push->datalen);
	    printf("\n TRACE[37.2]: Emp Push Data - emp_id: %u, name_len: %u, emp name: %s",\
	     emp_data->emp_id,emp_data->name_len,emp_data->emp_name);
	    printf("\n TRACE[37.3]: Push emp name Ptr: %#X, temp_data Ptr: %#X",emp_data->emp_name, temp_data);
	}
	ret_state = Push_Data(stack_megaptr, stackdata_totlen, (stack_node *)temp_data );
	return ret_state;
}

/*******************************************************************
   Function Name : Push_TreeNode(stack_head *stack_megaptr, tree_node *rootptr)
   Description   : inserts tree nodes address into stack.
   Remarks       :
   fUNC_ID       : 38
 *******************************************************************/
int Push_TreeNode(stack_head *stack_megaptr,tree_node *rootptr )
{
    int ret_state = FALSE;
    stack_node *temp_push = NULL;
    unsigned char stackdata_totlen;
    char temp_data[MAX_STACK_SIZE];

    stackdata_totlen = sizeof(stack_node);
    memset(temp_data,0,MAX_STACK_SIZE);
    temp_push = (stack_node *)temp_data;
	temp_push->msgtype = TREE_NODE_MSG;
	temp_push->datalen = sizeof(tree_node *);
	/* encapulation of tree node's address info into stack_data's databuff */
	temp_push->stack_databuff[0] = (unsigned )rootptr;
    if(trace_flag)
	{
	    printf("\n TRACE[38.1]: Push Data: totstack_datalen: %u:: Msgtype: %u, datalen: %u",stackdata_totlen,temp_push->msgtype,temp_push->datalen);
	    printf("\n TRACE[38.2]: Push Tree Node: %#X, Tree Data: Msgtype:%u, datalen:%u, databuff:%c", (tree_node *)temp_push->stack_databuff[0], \
	     ((tree_node *)temp_push->stack_databuff[0])->msgtype, ((tree_node *)temp_push->stack_databuff[0])->datalen, ((tree_node *)temp_push->stack_databuff[0])->databuff[0]);
	    printf("\n TRACE[38.3]: Push Tree Node: %#X's: Left Node: %#X, Right Node: %#X",(tree_node *)temp_push->stack_databuff[0], \
	     ((tree_node *)temp_push->stack_databuff[0])->subtree_leftptr, ((tree_node *)temp_push->stack_databuff[0])->subtree_rightptr );
	}
	  ret_state = Push_Data(stack_megaptr, stackdata_totlen, (stack_node *)temp_data );
	return ret_state;
}
