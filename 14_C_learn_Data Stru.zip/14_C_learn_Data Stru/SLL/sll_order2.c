/* ********************************************************************
FILE                   : sll_order2.c

PROGRAM DESCRIPTION    : ascending ordered based on unique value single linked list with 
                         operations of insert, delete, search, display and modify node of 
                         single linked list.
                              

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

/* create_sll.c --  */
#include <stdio.h>
#include <stdlib.h>
 
/* symbolic constants declared */
#define INSERT 1
#define DISP   2
#define SEARCH 3
#define MODIFY 4
#define DEL    5
#define QUIT   6

#define BETTER_PERFORMANCE   (1)

/* structure declaration */
typedef struct  NODE
 {
                      struct NODE *link;
                      int value;
        } Node;
 
void insert_sll(Node **, const int);
void disp_sll(Node **linkp);
void free_sll(Node *const linkp);
void delete_sll(Node **linkp, const int value);
Node *search_sll(Node *startp, Node * lastp, const int srch_value);
void modify_sll(Node *linkp ,const int value, const int modify_value);
Node *find_next_node(const Node *const startp, const Node *const delimitp, const int value);

int main(void)
{
    Node root, *p2r = &root;     /* pointer-to-root */
    int value, modify_value;
    int op;
    
    puts("\n**Let's do oper on a Singly Linked List**\n");
    printf("\n p2r = %p, root = %p", p2r, root);
    printf("\n User, enter 1 - INSERT, 2 - DISP, 3 - SEARCH, 4 - MODIFY, 5 - DEL, 6 - QUIT: ");
    while (1) {
        while (scanf("%d", &op) == 1 && (op == INSERT || op == DISP || op == SEARCH|| op == MODIFY || op == DEL|| op == QUIT ))
		 {
 
            switch(op)
            {
            	case INSERT:
			       printf("\n p2r = %p, *p2r = %p, root = %p", p2r, *p2r, root);
                   printf("\n User, enter an integer value to insert: ");
                   scanf("%d", &value);
                   insert_sll(p2r, value);                  
                break;
                case DISP:
                   disp_sll(p2r); 
                break; 
				case  SEARCH:
			       printf("\n User, enter an integer value to search: ");
                   scanf("%d", &value);	
				   found = search_sll(*p2r, NULL, value );
				break;
				case MODIFY:
				   printf("\n User, enter an integer value that has to modify: ");
                   scanf("%d", &value);	
                   printf("\n User, enter an new integer value for modification: ");
                   scanf("%d", &modify_value);
                   modify_sll(*p2r,value, modify_value);
				break;	
				case DEL:
				    printf("\n User, enter an integer value to delete: ");
                    scanf("%d", &value);
					delete_sll(p2r, value); 
			    break;		 
				case QUIT:
				  free_sll(p2r);
				  printf("\n Thank You!\n");
                  exit(0);
                break;  
            }
            printf("\nWant to continue sll oper ,\n enter "
                   "1 - INSERT, 2 - DISP, 3 - SEARCH, 4 - MODIFY, 5 - DEL, 6 - QUIT: ");
        }
            puts("Entered is a WRONG choice, enter 1 - INSERT, 2 - DISP, 3 - SEARCH, 4 - MODIFY, 5 - DEL, 6 - QUIT: ");
    }
}
 
void insert_sll(Node **linkp, const int value)
{
    Node *current = NULL;
    Node *newnode = NULL;
 
    /* Let's create an ordered singly linked list */
    /* firstly, ensure if value isn't already in the list */
    /* if value is already in the list, we won't add duplicate */
    while ((current = *linkp) != NULL && current->value < value)
    {
       printf("\n cmp value = %d, at node %p",current->value, current);	
       linkp = &current->link;
    }
     /* if value is already in the list */
    if (current != NULL && current->value == value) 
	{
        printf("\n\a Value %d at node %p is already in the list.\n", value, current);
        return ;
    }
    printf("\n currentp = %p", current);	
    /* value isn't already in the list */
    /* Let's allocate memory to newnode */
    newnode = (Node *)malloc(sizeof(Node));
 
    /* If memory allocated to newnode successfully */
    if (newnode == NULL)
	{
        printf("\n \aNot sufficient Memory!\n");
        free_sll(*linkp);
        exit(EXIT_FAILURE);
    }
    
    /* write in value in value field of newnode */
    newnode->value = value;
 
    /* insert newnode in the list */
    /* between current and previous */
    newnode->link = current;
    *linkp = newnode;
     printf("\n value = %d, newnode = %p, current = %p, *linkp = %p",newnode->value, newnode , current, *linkp);
	      
}

void disp_sll(Node **linkp)
{
    Node *current = NULL;
    size_t num_nodes = 0;
	 
    while((current = *linkp) != NULL)
	{
		printf("\n value = %d, current = %p, next = %p", current->value, current, current->link);
		linkp = &current->link;
		++num_nodes; 
   	}
   	printf("\n num of nodes = %u", num_nodes);
}


void free_sll(Node *const startp)
{
	Node *current, *linkp = startp;
	
	while((current = linkp)  != NULL)
	{
	    printf("\n free node : %p, value = %d", current, current->value);
	   	linkp = current->link;
	   	free(current);
	}
	startp->link = NULL;
}

void delete_sll(Node **linkp, const int value)
{
	Node *currentp = NULL;
	
	while((currentp = *linkp) != NULL && currentp->value != value )	
    {
      	  linkp = &currentp->link;
	}
	if(currentp == NULL)
	{
	  	  printf("\n value = %d not found ", value); 
	  	  return;
	} 
	*linkp = currentp->link;
	printf("\n delete node = %p for value = %d", currentp, value);
	free(currentp);
}

Node *search_sll( Node *startp, Node *lastp, const int srch_value)
{
     Node *endp = lastp, *thisp = startp;
     
     if(startp == NULL)
     {
     	printf("\n startp is NULL");
     	return NULL;
	 }
	 //startp must be node in search sll
     if(lastp != NULL)
	 {
	 	//startp and lastp must be node in search sll and startp->value <= lastp->value
	 	endp = lastp->link;
	 }
	 while(thisp != endp && thisp->value < srch_value )	
     {
        printf("\n cmp value = %d at node %p",thisp->value, thisp );
		thisp = thisp->link;
	 }
	 
 	if(thisp == endp || thisp->value != srch_value)
	{
	  	  printf("\n value = %d not found in nodes between [%p, %p]", srch_value, startp, lastp);	  	  
	  	  return NULL;
	}
	printf("\n value = %d found at node = %p between[%p, %p]", thisp->value, thisp, startp, lastp);
	return thisp;
}

Node *find_next_node(const Node *const startp, const Node *const delimitp, const int value)
{
     Node currentp = *startp, *thisp =  &currentp;
     
     if(startp == NULL)
     {
     	printf("\n startp is NULL");
     	return NULL;
	 }
	 //startp and delimitp(if != NULL) must be node in search sll and startp->value <= delimitp->value
     while(thisp != delimitp && thisp != NULL && thisp->value < value )	
     {
        printf("\n cmp value = %d at node %p",thisp->value, thisp );
		thisp = thisp->link;
	 }
	 
 	if((thisp == delimitp) || thisp != NULL && thisp->value == value )
	{
	  	printf("\n srch value = %d & value = %d at delimitp %p in nodes between [%p, %p]", value, delimitp->value, delimitp, startp, delimitp);	  	  
	  	return NULL;
	}
	printf("\n srch value = %d > value = %d at node = %p between[%p, %p]",value, thisp->value, thisp, startp, delimitp);
	return thisp; 		
}

Node *find_prev_node(Node *startp, Node *delimitp, const int value)
{
     Node *thisp = startp , *prev = NULL;
     
     if(startp == NULL)
     {
     	printf("\n startp is NULL");
     	return NULL;
	 } 
	  //startp and delimitp(if != NULL) must be node in search sll and startp->value <= delimitp->value   
     while(thisp != delimitp && thisp->value < value )	
     {
        printf("\n cmp value = %d at node %p",thisp->value, thisp );
        prev = thisp;
		thisp = thisp->link;
	 }
	 
 	if(thisp == delimitp || thisp->value == value )
	{
	  	printf("\n srch value = %d & value = %d at delimitp %p in nodes between [%p, %p]", value, delimitp->value, delimitp, startp, delimitp);	  	  
	  	return NULL;
	}
	printf("\n last value = %d < value = %d at node = %p between[%p, %p]",value, prev->value, prev, startp, delimitp);
	return prev; 		
}

#ifdef BETTER_PERFORMANCE
void modify_sll(Node *rootp ,const int value, const int modify_value)
{
    int temp;
    Node *foundp, *currentp, *endp, *nextp, *tempp;
    
 	if(value == modify_value)
    {
	   printf("\n modify value = %d is same as value", modify_value); 
	   return;	 	
    }
	if((foundp = search_sll(rootp, NULL, value)) == NULL)
 	{
    	 printf("\n value = %d not found ", value); 
	  	 return;	
	}
	if(modify_value > value)
	{
	    currentp = foundp;
	    endp = NULL;
    } 
    else
    {
    	currentp = rootp;
    	endp = foundp;
	}
	   
    if((tempp = find_next_node(currentp, endp, modify_value)) == NULL)
    {
       	 printf("\n non unique modify value = %d and modify node %p",modify_value, foundp); 
	  	 return;	
	}
/*	foundp->value =  modify_value;
    printf("\n unique modify value = %d at node %p before sort", foundp->value, foundp);  
    if(modify_value > value)
	{
	    currentp = foundp;	    
	    endp = (tempp->link != NULL) ? tempp->link: tempp; 
    } 
    else
    {
    	currentp = tempp;
    	endp = foundp;
    	
	}
	while(currentp != endp)	
	{
          // sort with successive nodes till end node of sll    	
		currentp = foundp;
		while(( nextp = currentp->link) != NULL)
        {
        	printf("\n value = %d at currentp %p cmp value %d at nextp %p", currentp->value, currentp, nextp->value, nextp);
           	if(currentp->value > nextp->value)
 	    	{
 		    	temp = currentp->value;
 		    	currentp->value = nextp->value;
 		    	nextp->value = temp;
 		    	printf("\n swapped value = %d at current %p and value %d at nextp %p", currentp->value, currentp, nextp->value, nextp);
	    	}
 	         currentp = nextp; 	         
	    }  	 		 
	} */	
}  
#else
/*
//tested ok to modify and maintain ascending ordered sll and for better performance it is commmited
 void modify_sll(Node *rootp ,const int value, const int modify_value)
 {
 	int temp;
    Node *foundp, *currentp, *endp, *nextp, *tempp;
    
 	if(value == modify_value)
    {
	   printf("\n modify value = %d is same as value", modify_value); 
	   return;	 	
    }
	if((foundp = search_sll(rootp, NULL, value)) == NULL)
 	{
    	 printf("\n value = %d not found ", value); 
	  	 return;	
	}
	if(modify_value > value)
	{
	    currentp = foundp;
	    endp = NULL;
    } 
    else
    {
    	currentp = rootp;
    	endp = foundp;
	}
	   
    if((tempp = search_sll(currentp, endp, modify_value)) != NULL)
    {
       	 printf("\n modify value = %d match at %p and modify node %p",modify_value,tempp , foundp); 
	  	 return;	
	}	
			    	
	foundp->value =  modify_value;
    printf("\n unique modify value = %d at node %p before sort", foundp->value, foundp);  
    if(modify_value < value)	
	{
		// sort with from root with ref with thisp(node has modify value) and till thisp node 	
	   currentp = rootp;	
	   endp = foundp; 
	   
	   while( currentp != endp->link)
       {
       	    printf("\n value = %d at currentp %p cmp value %d at endp %p", currentp->value, currentp, endp->value, endp);
 	    	if(currentp->value >  endp->value)
 	    	{
 		    	temp = currentp->value;
 		    	currentp->value = endp->value;
 		    	endp->value = temp;
 		    	printf("\n swapped value = %d at current %p and value %d at endp %p", currentp->value, currentp, endp->value, endp);
	    	}
 	         currentp = currentp->link;	     
	    }	 
	}
	else
	{
    	// sort with successive nodes till end node of sll    	
		currentp = foundp;
		while(( nextp = currentp->link) != NULL)
        {
        	printf("\n value = %d at currentp %p cmp value %d at nextp %p", currentp->value, currentp, nextp->value, nextp);
           	if(currentp->value > nextp->value)
 	    	{
 		    	temp = currentp->value;
 		    	currentp->value = nextp->value;
 		    	nextp->value = temp;
 		    	printf("\n swapped value = %d at current %p and value %d at nextp %p", currentp->value, currentp, nextp->value, nextp);
	    	}
 	         currentp = nextp; 	         
	    }  	 	
	} 
}
*/
#endif
