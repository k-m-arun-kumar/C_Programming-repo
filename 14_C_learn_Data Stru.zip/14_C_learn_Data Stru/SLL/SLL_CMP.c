/* ********************************************************************
FILE                   : SLL_CMP.c

PROGRAM DESCRIPTION    : ascending ordered based on unique value single linked list with 
                         operations of insert, delete, search, display and modify node of 
                         single linked list.
                              

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
 
/* symbolic constants declared */
#define INSERT 1
#define DISP   2
#define SEARCH 3
#define MODIFY 4
#define DEL    5
#define QUIT   6

#define BETTER_PERFORMANCE         (1)

#define SRCH_VALUE_START_NODE     (1)
#define SRCH_VALUE_REACH_END_SLL  (2)
#define SRCH_VALUE_REACH_END_NODE (3)
#define SRCH_VALUE_MATCHED_SLL    (4)
#define SRCH_VALUE_NEXT_NODE      (5)
#define SRCH_VALUE_PREV_NODE      (6)
#define SRCH_INVALID_INPUT        (7)  
          
/* structure declaration */
typedef struct  NODE
 {
                      struct NODE *link;
                      int value;
        } Node;
 
void insert_sll(Node **, const int);
void disp_sll(Node **linkp);
void free_sll(Node **linkp);
void delete_sll(Node **linkp, const int value);
void delete_range_sll(Node **const linkp, const int from_del_value, const int to_del_value);
Node *search_sll(Node *start_node, Node * lastp, const int srch_value);
void modify_sll(Node *linkp ,const int value, const int modify_value);
int find_prev_node( Node *const start_node, const Node *const delimit_node, Node **const ptr_prev_node, const int value);
int find_next_node( Node *const start_node, const Node *const delimit_node, Node **const next_node, const int value);

int main(void)
{
    Node *root = NULL, *found = 0;         /* root is set to NULL */
    Node **ptr_root = &root;     /* pointer-to-root */
    int value, value_int;
    int op;
    
    puts("\n**Let's do oper on a Singly Linked List**\n");
    printf("\n ptr_root = %p, root = %p", ptr_root, root);
    printf("\n enter 1 - INSERT, 2 - DISP, 3 - SEARCH, 4 - MODIFY, 5 - DEL, 6 - QUIT: ");
    while (1) {
        while (scanf("%d", &op) == 1 && (op == INSERT || op == DISP || op == SEARCH|| op == MODIFY || op == DEL|| op == QUIT ))
		 {
 
            switch(op)
            {
            	case INSERT:
			       printf("\n ptr_root = %p, *ptr_root = %p, root = %p", ptr_root, *ptr_root, root);
                   printf("\n User, enter an integer value to insert: ");
                   scanf("%d", &value);
                   insert_sll(ptr_root, value);                  
                break;
                case DISP:
                   disp_sll(ptr_root); 
                break; 
				case  SEARCH:
			       printf("\n User, enter an integer value to search: ");
                   scanf("%d", &value);	
				   found = search_sll(*ptr_root, NULL, value );
				break;
				case MODIFY:
				   printf("\n User, enter an integer value that has to modify: ");
                   scanf("%d", &value);	
                   printf("\n User, enter an new integer value for modification: ");
                   scanf("%d", &value_int);
                   modify_sll(*ptr_root,value, value_int);
				break;	
				case DEL:
				    printf("\n User, enter from integer value to delete: ");
                    scanf("%d", &value);
                    printf("\n User, enter to integer value to delete: ");
                    scanf("%d", &value_int);
					delete_range_sll(ptr_root, value, value_int); 
			    break;		 
				case QUIT:
				  free_sll(ptr_root);
				  printf("\n Thank You!\n");
                  exit(0);
                break;				  
            }
            printf("\nWant to continue sll oper ,\n enter "
                   "1 - INSERT, 2 - DISP, 3 - SEARCH, 4 - MODIFY, 5 - DEL, 6 - QUIT: ");
        }
            puts("Entered is a WRONG choice, enter 1 - INSERT, 2 - DISP, 3 - SEARCH, 4 - MODIFY, 5 - DEL, 6 - QUIT: ");
    }
}
 
void insert_sll(Node **linkp, const int value)
{
    Node *this_node = NULL;
    Node *new_node = NULL;
 
    /* Let's create an ordered singly linked list */
    /* firstly, ensure if value isn't already in the list */
    /* if value is already in the list, we won't add duplicate */
    while ((this_node = *linkp) != NULL && this_node->value < value)
    {
       printf("\n cmp value = %d, at node %p",this_node->value, this_node);	
       linkp = &this_node->link;
    }
     /* if value is already in the list */
    if (this_node != NULL && this_node->value == value) 
	{
        printf("\n\a Value %d at node %p is already in the list.\n", value, this_node);
        return ;
    }
    printf("\n this_node = %p", this_node);	
    /* value isn't already in the list */
    /* Let's allocate memory to new_node */
    new_node = (Node *)malloc(sizeof(Node));
 
    /* If memory allocated to new_node successfully */
    if (new_node == NULL)
	{
        printf("\n \aNot sufficient Memory!\n");
        free_sll(linkp);
        exit(EXIT_FAILURE);
    }
    
    /* write in value in value field of new_node */
    new_node->value = value;
 
    /* insert new_node in the list */
    /* between this_node and previous */
    new_node->link = this_node;
    *linkp = new_node;
     printf("\n value = %d, at new_node = %p, this_node = %p",new_node->value, new_node , this_node);
	      
}

void disp_sll(Node **linkp)
{
    Node *this_node = NULL;
    size_t num_nodes = 0;
	 
    while((this_node = *linkp) != NULL)
	{
		printf("\n value = %d at node = %p, next = %p", this_node->value, this_node, this_node->link);
		linkp = &this_node->link;
		++num_nodes; 
   	}
   	printf("\n num of nodes = %u", num_nodes);
}


void free_sll(Node **start_node)
{
	Node *this_node = *start_node, *delete_node ;
	
	while( (delete_node = this_node) != NULL)
	{
	    printf("\n free node : %p, value = %d", this_node, this_node->value);
	   	this_node = this_node->link;	   	
	   	free(delete_node);
	}
	*start_node = NULL;
}

void delete_sll(Node **linkp, const int value)
{
	Node *this_node = NULL;
	
	while((this_node = *linkp) != NULL && this_node->value != value )	
    {
      	  linkp = &this_node->link;
	}
	if(this_node == NULL)
	{
	  	  printf("\n value = %d not found ", value); 
	  	  return;
	} 
	*linkp = this_node->link;
	printf("\n delete node = %p for value = %d", this_node, value);
	free(this_node);
}

void delete_range_sll(Node **const root_ptr, const int from_del_value, const int to_del_value)
{
	Node *from_node, *to_node, *this_node, *prev_node, *next_node; 
	int temp, temp_int; 
	
	temp = find_prev_node(*root_ptr, NULL, &from_node, from_del_value);
	if(from_del_value == to_del_value)
	{
        if(temp != SRCH_VALUE_MATCHED_SLL)
        {
        	printf("\n\a to del val [%d, %d] no nodes to delete",from_del_value, to_del_value);
        	return;
		}
		if()
		this_node = from_node->link;
		
		if(from_node == *root_ptr)
		{
			
		}
		return;		
	}
	temp_int = find_prev_node(from_node, NULL, &to_node, to_del_value);
	
	printf("\n for del val between [%d, %d] & del node between[%p, %p]", from_del_value, to_del_value, from_node, to_node );
}

Node *search_sll( Node *start_node, Node *last_node, const int srch_value)
{
     Node *end_node = last_node, *this_node = start_node;
     
     if(start_node == NULL)
     {
     	printf("\n start_node is NULL");
     	return NULL;
	 }
	 //start_node must be node in search sll
     if(last_node != NULL)
	 {
	 	//start_node and last_node must be node in search sll and start_node->value <= last_node->value
	 	end_node = end_node->link;
	 }
	 while(this_node != end_node  && this_node->value < srch_value )	
     {
        printf("\n cmp value = %d at node %p",this_node->value, this_node );
		this_node = this_node->link;
	 }
	 
 	if(this_node == end_node || this_node->value != srch_value)
	{
	  	  printf("\n value = %d not found in nodes between [%p, %p]", srch_value, start_node, last_node);	  	  
	  	  return NULL;
	}
	printf("\n value = %d found at node = %p between[%p, %p]", this_node->value, this_node, start_node, last_node);
	return this_node;
}

int find_next_node( Node *const start_node, const Node *const delimit_node, Node **const ptr_next_node, const int value)
{
     Node *this_node = start_node, *prev_node = start_node;
     int oper;
	    
     if(start_node == NULL)
     {
     	printf("\n start_node is NULL");
     	*ptr_next_node = NULL;
     	return SRCH_INVALID_INPUT;
	 }
	 //start_node and delimit_node(if != NULL) must be node in search sll and start_node->value <= delimit_node->value
     while(this_node != delimit_node && this_node->value < value )	
     {
        printf("\n cmp value = %d at node %p",this_node->value, this_node );
        prev_node = this_node;
		this_node = this_node->link;
	 }
	 
 	if(this_node == delimit_node) 
	{
	  	printf("\n srch value %d reached end of search in nodes between [%p, %p]", value,start_node , delimit_node);
	  	if((delimit_node == NULL))
	  	{
	  		*ptr_next_node = prev_node;
	  		return SRCH_VALUE_REACH_END_SLL;
		}
		*ptr_next_node = this_node;
	 	return SRCH_VALUE_REACH_END_NODE;
	}
	if(this_node->value == value)
	{
		printf("\n srch value = %d = value at node %p in nodes between [%p, %p]", value, this_node, start_node, delimit_node);	
	    *ptr_next_node = this_node;	  
	  	return SRCH_VALUE_MATCHED_SLL;	
	}
	printf("\n srch value = %d < value = %d at node = %p between[%p, %p]",value, this_node->value, this_node, start_node, delimit_node);
	*ptr_next_node = this_node;		
	return SRCH_VALUE_NEXT_NODE; 		
}

int find_prev_node( Node *const start_node, const Node *const delimit_node, Node **const ptr_prev_node, const int value)
{
     Node *this_node = start_node, *prev_node = start_node;
          
     if(start_node == NULL)
     {
     	printf("\n start_node is NULL");
     	*ptr_prev_node = NULL;
     	return SRCH_INVALID_INPUT;
	 }
	 //start_node and delimit_node(if != NULL) must be node in search sll and start_node->value <= delimit_node->value
     while(this_node != delimit_node && this_node->value < value)	
     {
        printf("\n cmp value = %d at node %p",this_node->value, this_node );        
        prev_node = this_node;
		this_node = this_node->link;
	 }
	 
 	if(this_node == delimit_node) 
	{
	  	printf("\n srch val %d reached end of search in nodes between [%p, %p]", value, start_node, delimit_node);
	    if((delimit_node == NULL))
	  	{
	  		*ptr_prev_node = prev_node;
	  		return SRCH_VALUE_REACH_END_SLL;
		}
		*ptr_prev_node = this_node;
	 	return SRCH_VALUE_REACH_END_NODE; 
	}
	if(this_node->value == value)
	{
		printf("\n srch val = %d = val at node %p in nodes between [%p, %p]", value, this_node, start_node, delimit_node);	
		 *ptr_prev_node = this_node;	  
	  	return SRCH_VALUE_MATCHED_SLL;	
	}
	printf("\n last srch val = %d < val = %d at node = %p between[%p, %p]",value, this_node->value, this_node, start_node, delimit_node);
	 *ptr_prev_node = prev_node;
	if(prev_node->value < value )
	   return SRCH_VALUE_PREV_NODE; 
	return SRCH_VALUE_START_NODE;  		
}

#ifdef BETTER_PERFORMANCE
// sorts in the window between found_node to modify value and new value's appropriate near node
void modify_sll(Node *root_node ,const int value, const int modify_value)
{
    int temp, temp_val ;
    Node *found_node, *this_node, *end_node, *next_node, *temp_node ;
    
 	if(value == modify_value)
    {
	   printf("\n modify value = %d is same as value", modify_value); 
	   return;	 	
    }
	if((found_node = search_sll(root_node, NULL, value)) == NULL)
 	{
    	 printf("\n value = %d not found ", value); 
	  	 return;	
	}
	if(modify_value > value)
	{
	    this_node = found_node;
	    end_node = NULL;
    } 
    else
    {
    	this_node = root_node;
    	end_node = found_node;
	}
	   
    if((temp = find_prev_node(this_node, end_node, &temp_node, modify_value)) == SRCH_VALUE_MATCHED_SLL )
    {
       	 printf("\n non unique modify value = %d at node %p and modify node %p",modify_value, temp_node, found_node); 
	  	 return;	
	}
	found_node->value =  modify_value;
	printf("\n unique modify value = %d at node %p till node %p before sort", found_node->value, found_node, temp_node);  
	if(found_node == temp_node)
	{
		//only one node that has be just modified
	   return;
    }
    if(modify_value > value)
	{
		// swap with successive nodes from modify_node till new value's next_node 
	    this_node = found_node;	
		while(this_node != temp_node)	
	    {
            next_node = this_node->link;  
	      	printf("\n value = %d at node %p > value %d at node %p", this_node->value, this_node, next_node->value, next_node);
           	temp = this_node->value;
 		    this_node->value = next_node->value;
 		    next_node->value = temp;
 		    printf("\n swapped value = %d at node %p and value %d at node %p", this_node->value, this_node, next_node->value, next_node);
	    	this_node = next_node; 	         
	    } 	    		 
	}	 
    else
    {
        if(temp == SRCH_VALUE_START_NODE)
           this_node = temp_node;
       else    
          this_node = temp_node->link;
	   	// circular right shift from this_node till modify_node		
	    temp = this_node->value;
        this_node->value = modify_value;
        this_node = this_node->link;
        while(this_node != found_node)	
	    {
	       	printf("\n before replace value %d to val = %d at node %p", temp, this_node->value, this_node);
	       	temp_val = this_node->value;
	    	this_node->value = temp;    	
	       	temp = temp_val;
	    	printf("\n after value %d val = %d at node %p", temp, this_node->value, this_node); 	    	
	       	this_node = this_node->link;			   	
	    }
	    found_node->value = temp;
	}
}  

#else
/*
//tested ok to modify and maintain ascending ordered sll and for better performance it is commmited
 void modify_sll(Node *root_node ,const int value, const int modify_value)
 {
 	int temp;
    Node *found_node, *this_node, *end_node, *next_node, *temp_node;
    
 	if(value == modify_value)
    {
	   printf("\n modify value = %d is same as value", modify_value); 
	   return;	 	
    }
	if((found_node = search_sll(root_node, NULL, value)) == NULL)
 	{
    	 printf("\n value = %d not found ", value); 
	  	 return;	
	}
	if(modify_value > value)
	{
	    this_node = found_node;
	    end_node = NULL;
    } 
    else
    {
    	this_node = root_node;
    	end_node = found_node;
	}
	   
    if((temp_node = search_sll(this_node, end_node, modify_value)) != NULL)
    {
       	 printf("\n modify value = %d match at %p and modify node %p",modify_value,temp_node , found_node); 
	  	 return;	
	}	
			    	
	found_node->value =  modify_value;
    printf("\n unique modify value = %d at node %p before sort", found_node->value, found_node);  
    if(modify_value < value)	
	{
		// sort with from root with ref with this_node(node has modify value) and till this_node node 	
	   this_node = root_node;	
	   end_node = found_node; 
	   
	   while( this_node != end_node->link)
       {
       	    printf("\n value = %d at this_node %p cmp value %d at end_node %p", this_node->value, this_node, end_node->value, end_node);
 	    	if(this_node->value >  end_node->value)
 	    	{
 		    	temp = this_node->value;
 		    	this_node->value = end_node->value;
 		    	end_node->value = temp;
 		    	printf("\n swapped value = %d at this_node %p and value %d at end_node %p", this_node->value, this_node, end_node->value, end_node);
	    	}
 	         this_node = this_node->link;	     
	    }	 
	}
	else
	{
    	// sort with successive nodes till end node of sll    	
		this_node = found_node;
		while(( next_node = this_node->link) != NULL)
        {
        	printf("\n value = %d at this_node %p cmp value %d at next_node %p", this_node->value, this_node, next_node->value, next_node);
           	if(this_node->value > next_node->value)
 	    	{
 		    	temp = this_node->value;
 		    	this_node->value = next_node->value;
 		    	next_node->value = temp;
 		    	printf("\n swapped value = %d at this_node %p and value %d at next_node %p", this_node->value, this_node, next_node->value, next_node);
	    	}
 	         this_node = next_node; 	         
	    }  	 	
	} 
}
*/
#endif


