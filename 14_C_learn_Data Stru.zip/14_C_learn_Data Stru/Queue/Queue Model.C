/* ======================================================================
  File Name     : Queue Model.C
  Description   : Simulation in Queue Modelling, based on Linked List.
  Author        : K.M. Arun Kumar alias Arunkumar Murugeswaran
  Date          : 14th May 2007.
  Remarks     1 : In simulation, max number of cust generated for service, should not overlaps
                  cust status array, if you want to know each and every cust's status.
              2 : assumes that user input are valid and within the range.
              3 : For input string, number of bytes is within its allocated memory size.
              4 : currently, only cust data is enqueued.
              5 : by default, global execution flow flag is enabled for debugging.
  Known Bugs  1 : giving non numeric input for numeric data.
  Modification
       History  :
  Others        : Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
====================================================================== */

#include "stdio.h"
#include "stdlib.h"
#include "alloc.h"
#include "string.h"

#define TRUE                     0     /* Successful oper */
#define FALSE                   -1     /* failed oper */
#define QUEUE_FAIL              -2     /* critical problem during queue operation */
#define EXCEED_CUST_SERV        -3     /* exceeds total num of cust service */
#define ENQUE_FRONT              1     /* stop Simulation's msg send at front end, to stop queue's immediately */
#define ENQUE_REAR               2     /* default */
#define QUIT_OPER                1
#define SIMULATION_START         2     /* start simulation */
#define ENQUE_DATA_OPER          3
#define DEQUE_DATA_OPER          4
#define DESTROY_QUE_OPER         5     /* destroy queue */
#define DISPLAY_OPER             6
#define RETRIEVE_QUEUE           1     /* display queue node's data */
#define RETRIEVE_FRONT           2
#define RETRIEVE_REAR            3
#define MEGA_DATA_PRINT          4     /* display queue's megahead */
#define SPEC_CUST_STATUS         5     /* display spec customer's status */
#define WHOLE_CUST_STATUS        6     /* display whole customer's status */
#define SIMULATION_STATUS        7     /* display queue simulation status */
#define CUST_MSG                 1     /* queue node has Customer info */
#define SIM_MSG                  2     /* queue node has Queue Simulation info */
#define SIM_START_MSG            1     /* simulation start message */
#define SIM_STOP_MSG             2     /* simulation stop message */
#define INVALID_CUST_ID      65535     /* invalid customer id */
#define INVALID_DATA           255     /* invalid data size to initialization queue's head */
#define OPER_SIZE               20     /* reserved for validation input data */
#define NAME_SIZE               10
#define IDLE_SIM                 0     /* Simulation is yet to start */
#define PROCESS_SIM              1     /* Simulation is under process */
#define START_CUST_ID            1     /* starting customer ID: cust id ranges from START_CUST_ID to START_CUST_ID + MAX_CUST - 1 */
#define MAX_CUST                10     /* max number of customers */
#define MAX_QUEUE_SIZE          15     /* maximum queue size */
#define MAX_CLOCK               35     /* default maximum clock */
#define GEN_NEW_CUST             1     /* generates new customer, to be served */
#define MAX_CUST_GENNUM          4     /* max random num generated for customer */
#define MAX_SERVERTIME_GENNUM    3     /* max random num generated for customer's service time */
#define NO_ACCESS                1     /* does not allow access to queue */
#define FREE_ACCESS              0     /* allow access to queue */
#define TRACE_ON                 1     /* enable global execution trace flow for debugging */
#define TRACE_OFF                0     /* disable global execution trace flow for debugging */

#define CUST_STATUS_INDEX(cust_id)  ((cust_id) - START_CUST_ID) /* mapping cust id with subscript for cust status array */

typedef struct custdata
{
	unsigned cust_num;          /* unique customer num for identification */
	unsigned arrive_time;       /* time when customer is enque before processing it */
	char cust_name[NAME_SIZE];  /* customer's name */
} cust_info;

typedef struct simdata
{
	unsigned char msgtype;      /* holds either SIM START OR STOP data */
	unsigned char datalen;      /* holds datalength of data present in simdata */
	unsigned char simdata[1];   /* variable simulation data */
} sim_data;

typedef struct queuedata
{
	unsigned char msgtype;      /* differentiate kind of data in queue */
	unsigned char datalen;      /* holds data length of data present in databuff */
	unsigned char databuff[1];  /* starting point of variable data's memory size > 1, has cust_info or sim info */
} queue_data;

typedef struct queuenode
{
	struct queuenode *fore_node;  /* points to its suuccessor queue node */
	unsigned char var_datalen;    /* holds data length of data present in var_data */
	unsigned char var_data[1];    /* variable queue data */
} queue_node;

typedef struct queuehead
{
   unsigned char count;           /* number of nodes in queue */
   unsigned char max_queuesize;   /* Max number of allowable nodes in queue */
   queue_node *frontptr;
   queue_node *rearptr;
   char access_que;               /* control access to que */
   unsigned char max_datasize;    /* max memory size req for data in queue node */
} queue_head;

typedef struct custstatus
{
	unsigned cust_num;         /* unique customer num for identification */
	unsigned arrive_time;      /* time when customer is enque before processing it */
    unsigned start_time;       /* time when customer is started processing it after deque */
    unsigned service_time;     /* time req to complete processing the cust, after deque */
} customer_status;

typedef struct simstatus
{
	unsigned char sim_state;       /* current simulation FSM state */
	unsigned num_cust;             /* total number of customers has completed its service */
	double totalsvctime;           /* total time customer's service time simulation has used */
	double totalwaittime;          /* total time customer's time waited in queue */
	unsigned maxqueuesize;         /* max number of customers present in queue at a time */
} simulator_status;

typedef struct
{
	unsigned clock;         /* counts the no of loops for simulation */
	unsigned endtime;       /* max no of loops, if all cust have complete is service */
	unsigned enque_cust_id; /* current cust id to be enqueued  */
	unsigned deque_cust_id; /* current cust id is under going its service */
} simctrl;

/* global variable defination */
customer_status cust_status[MAX_CUST];
queue_head queue_megahead;
simulator_status sim_status;
int trace_flag = TRACE_ON;     /* global trace execution for debugging */

/* function prototype */
unsigned Link_Menu(void);

/*******************************************************************
 Function Name  : main()
 Description    : Simulation and modeling of queue
 Remarks        : Customer's info & Simulation start and stop msg are stored in same queue
 Func ID        : 1
*******************************************************************/
int main()
{
	unsigned oper_mode;
    int ret_state = TRUE;
    simctrl simctrl_data;
    unsigned char quedatalen;
    void *deque_data = NULL;

    /* create a queue head with max queue's data */
    if(Initialize_Queue(&queue_megahead,MAX_QUEUE_SIZE, sizeof(queue_data) + sizeof(cust_info) - sizeof(unsigned char)))
      return FALSE;
    Initialize_SimData(&simctrl_data, MAX_CLOCK);
    do
    {
        oper_mode =  Link_Menu();
        switch(oper_mode)
        {
		    case ENQUE_DATA_OPER:
		      /* only if simulation is not running, enque can be done manually */
		      if(sim_status.sim_state != IDLE_SIM || EnQue_CustData(&queue_megahead, &simctrl_data ))
		      {
				  printf("\n ERR[1.1]: Maybe sim is not idle: %u or fail enque manually", sim_status.sim_state);
				  continue;
		      }
		      break;
		    case DEQUE_DATA_OPER:
		      /* only if simulation is not running, deque can be done manually */
		      if(sim_status.sim_state != IDLE_SIM || GetQue_Data(oper_mode, &queue_megahead, &quedatalen, &deque_data ) <= FALSE )
		      {
				  printf("\n ERR[1.2]: Maybe sim is not idle: %u or fail deque manually", sim_status.sim_state);
		          continue;
		      }
		      /* on successful deque, deque_data contains the dequeued data, no more process req for deque_data */
              free(deque_data);
		      break;
		    case SIMULATION_START:
		      if(Sim_Control(oper_mode, &queue_megahead, &simctrl_data)<= FALSE)
		        continue;
		      break;
		    case DESTROY_QUE_OPER:
		      if(QueData_Range(oper_mode, &queue_megahead) <= FALSE)
                continue;
              break;
		    case DISPLAY_OPER:
		      if(Display_Data())
		        continue;
		      break;
		    case QUIT_OPER:
		      QueData_Range(DESTROY_QUE_OPER, &queue_megahead );
		      /* if continue is given, if unable to destroy queue, it keeps on prompting for oper */
		      break;
		    default:
		      printf("\n ERR[1.3]: Invalid oper_mode: %u", oper_mode );
		      ret_state = FALSE;
	     }
    } while(oper_mode != QUIT_OPER);
    return ret_state;
}

/*******************************************************************
 Function Name  : Create_Queue(queue_head *queue_megaptr, int max_queue)
 Description    : initialize of queue's mega head node
 Remarks        : assume that input parameter are valid
 Func ID        : 2
 *******************************************************************/
int Initialize_Queue(queue_head *queue_megaptr, unsigned max_queue, unsigned data_size )
{
	if(queue_megaptr == NULL)
	{
		printf("\n ERR[2.1]: Invalid queue's head address to initialize ");
		return FALSE;
    }
    queue_megaptr->count = 0;
    queue_megaptr->max_queuesize = max_queue;
    queue_megaptr->frontptr = NULL;
    queue_megaptr->rearptr = NULL;
    queue_megaptr->max_datasize = data_size;
    Control_Queue(queue_megaptr,FREE_ACCESS );
    if(trace_flag)
       printf("\n TRACE[2.1]: Queue's head: %#X Initialized, Max nodes: %u, max datasize: %u", queue_megaptr, max_queue, data_size);
    return TRUE;
}

/*******************************************************************
 Function Name : Control_Queue(queue_head *queue_megaptr, int access_mode)
 Description   : control access of the queue
 Remarks       : useful for multi operation be performed in it
 Func ID       : 3
 *******************************************************************/
 int Control_Queue(queue_head *queue_megaptr, int access_mode)
 {
 	int istrue = FALSE;

 	if(queue_megaptr == NULL)
	{
		printf("\n ERR[3.1]: Invalid queue head's address to control its access ");
		return istrue;
    }
 	switch(access_mode)
 	{
 		case FREE_ACCESS:
 		case NO_ACCESS:
 		  queue_megaptr->access_que = access_mode;
 		  istrue = TRUE;
 		  break;
 		default:
 		  printf("\n ERR[3.2]: Invalid Queue's Addr: %#X access mode: %d", queue_megaptr,access_mode);
    }
    return istrue;
 }

/*******************************************************************
 Function Name  : Enque_Data(queue_head *queue_megaptr, void *enque_data )
 Description    : insert data provided through its address at rear end or front of queue, depends on mode
 Remarks        : make sure that enque mode is valid
 Func ID        : 4
 *******************************************************************/
int Enque_Data(int mode, queue_head *queue_megaptr, unsigned char quedata_totlen, void *enque_data )
{
	int ret_state = FALSE;
    queue_node *new_quenode = NULL;

    if(Full_Queue(queue_megaptr))
	   return FALSE;
	/* Queue is not full */
	Control_Queue(queue_megaptr, NO_ACCESS);
	/* total queue's node memory's size = data's length + queue's node excluding its size of var_data[1] */
	if(queue_megaptr->max_datasize == INVALID_DATA || quedata_totlen > queue_megaptr->max_datasize || !(new_quenode = calloc(1, sizeof(queue_node) + quedata_totlen - sizeof(unsigned char))))
	{
	   printf("\n ERR[4.1]: No memory for enque in Queue's Head Addr: %#X OR datalen [%u] > max [%u]",queue_megaptr,quedata_totlen, queue_megaptr->max_datasize);
	   Control_Queue(queue_megaptr, FREE_ACCESS);
	   return QUEUE_FAIL;
    }
    new_quenode->var_datalen = quedata_totlen;
    if(trace_flag)
      printf("\n TRACE[4.1]: new_quenode Addr: %#X, var_datalen: %u, enqueue mode: %d",new_quenode,new_quenode->var_datalen, mode);
    memcpy(new_quenode->var_data, (const void *)enque_data, new_quenode->var_datalen);
    /* add node in empty queue */
	if(queue_megaptr->frontptr == NULL)
	{
	   new_quenode->fore_node = NULL;
	   queue_megaptr->frontptr = new_quenode;
	   queue_megaptr->rearptr = new_quenode;
	   ++queue_megaptr->count;
	   Control_Queue(queue_megaptr, FREE_ACCESS);
       return TRUE;
    }
    if(mode == ENQUE_REAR)
    {  /* generally, node is added at rear end of queue */
		new_quenode->fore_node = NULL;
        queue_megaptr->rearptr->fore_node = new_quenode;
		queue_megaptr->rearptr = new_quenode;
		ret_state = TRUE;
    }
    else
    {   /* in special case, such as emergency purpose, node is added at front of queue */
		new_quenode->fore_node = queue_megaptr->frontptr;
		queue_megaptr->frontptr = new_quenode;
		ret_state = TRUE;
    }
    ++queue_megaptr->count;
    Control_Queue(queue_megaptr, FREE_ACCESS);
    return ret_state;
}

/*******************************************************************
 Function Name  : Deque_Data(queue_head *queue_megaptr, nsigned char *quedatalen, void *deque_data)
 Description    : delete node's data provided through its address at front end of queue
 Remarks        : assume that formal arg:
 Func ID        : 5
 *******************************************************************/
 int Deque_Data(queue_head *queue_megaptr, unsigned char *quedatalen, void **deque_data)
 {
	 queue_node *del_node = NULL;

     if(Empty_Queue(queue_megaptr))
        return FALSE;
     del_node = queue_megaptr->frontptr;
     Control_Queue(queue_megaptr, NO_ACCESS);
     /* deque_data is assigned memory location, shall be freed either directly or indirecty by its called func */
     if(!(*deque_data = calloc(1, del_node->var_datalen)))
     {
		 printf("\n ERR[5.1]: NO new memory for queue's head addr: %#X, deque data's len :%u",queue_megaptr,del_node->var_datalen );
		 Control_Queue(queue_megaptr, FREE_ACCESS);
		 return QUEUE_FAIL;
     }
     /* retrieves data */
     memcpy(*deque_data, del_node->var_data, del_node->var_datalen);
     *quedatalen = del_node->var_datalen;
     if(trace_flag)
        printf("\n TRACE[5.1]: deque_node: %#X, *deque_data Addr: %#X, data len: %u",del_node, *deque_data,del_node->var_datalen);
     /* delete only node in queue */
     if(queue_megaptr->frontptr == queue_megaptr->rearptr)
        queue_megaptr->rearptr = NULL;
     queue_megaptr->frontptr = queue_megaptr->frontptr->fore_node;
     free(del_node);
     --queue_megaptr->count;
     Control_Queue(queue_megaptr, FREE_ACCESS);
     return TRUE;
 }

/*******************************************************************
 Function Name  : Empty_Queue(queue_head *queue_megaptr)
 Description    : checks for empty queue
 Remarks        :
 Func ID        : 6
 *******************************************************************/
 int Empty_Queue(queue_head *queue_megaptr)
 {
     int ret_state = FALSE;

     if(!Access_Queue(queue_megaptr))
	 {
		Control_Queue(queue_megaptr, NO_ACCESS);
		if(queue_megaptr->count > 0)
		   ret_state = TRUE;
	    else
	       printf("\n ERR[6.1]: Try in Queue's head addr: %#X to deque empty queue",queue_megaptr);
	    Control_Queue(queue_megaptr, FREE_ACCESS);
	 }
     return ret_state;
 }

 /*******************************************************************
  Function Name  : Full_Queue(queue_head *queue_megaptr)
  Description    : checks for queue is full
  Remarks        : also checks availability memory
  Func ID        : 7
  *******************************************************************/
 int Full_Queue(queue_head *queue_megaptr)
 {
	 int ret_state = FALSE;
     void *check_alloc = NULL;

	 if(!Access_Queue(queue_megaptr))
	 {
		 Control_Queue(queue_megaptr, NO_ACCESS);
		 if(queue_megaptr->count < queue_megaptr->max_queuesize && (check_alloc = calloc(1, sizeof(queue_megaptr->max_datasize) + sizeof(queue_node))))
		 {
			 free(check_alloc);
			 ret_state = TRUE;
	     }
	     else
	       printf("\n ERR[7.1]: No new memory in Queue's head addr: %#X OR no of nodes [%u] exceeds its max [%u]", queue_megaptr,queue_megaptr->count, queue_megaptr->max_queuesize);
	     Control_Queue(queue_megaptr, FREE_ACCESS);
	 }
     return ret_state;
 }

 /*******************************************************************
  Function Name  : Retrieve_QueData(queue_head *queue_megaptr, queue_node *cur_node, unsigned char *quedatalen, void **quedata)
  Description    : retrieves data at either front end, rear end or intermediate queue node
  Remarks        : doesnt delete its node
  Func ID        : 8
  *******************************************************************/
 int Retrieve_QueData(int ret_mode, queue_head *queue_megaptr, queue_node *cur_node, unsigned char *quedatalen, void **quedata)
 {
	int ret_state = FALSE;

	if(Empty_Queue(queue_megaptr))
	   return ret_state;
	/* not a empty queue */
    Control_Queue(queue_megaptr, NO_ACCESS);
    switch(ret_mode)
    {
       case RETRIEVE_FRONT:
         if(!(*quedata = calloc(1, queue_megaptr->frontptr->var_datalen)))
         {
            printf("\n ERR[8.1]: NO new memory for queue's head addr: %#X, retrieve front data, whose len :%u",queue_megaptr,queue_megaptr->frontptr->var_datalen );
            ret_state = QUEUE_FAIL;
            break;
         }
         memcpy(*quedata, (const void *)queue_megaptr->frontptr->var_data,queue_megaptr->frontptr->var_datalen);
	     *quedatalen = queue_megaptr->frontptr->var_datalen;
	     ret_state = TRUE;
	     if(trace_flag)
	        printf("\n TRACE[8.1]: retrieve front queue node: %#X, *quedata Addr: %#X, datalen: %u",queue_megaptr->frontptr, *quedata,*quedatalen );
         break;
       case RETRIEVE_REAR:
         if(!(*quedata = calloc(1, queue_megaptr->rearptr->var_datalen)))
	     {
	         printf("\n ERR[8.2]: NO new memory for queue's head addr: %#X, retrieve rear data, whose len :%u",queue_megaptr,queue_megaptr->rearptr->var_datalen );
	         ret_state = QUEUE_FAIL;
	         break;
	     }
	     memcpy(*quedata, (const void *) queue_megaptr->rearptr->var_data,queue_megaptr->rearptr->var_datalen);
	     *quedatalen = queue_megaptr->rearptr->var_datalen;
	     ret_state = TRUE;
	     if(trace_flag)
	        printf("\n TRACE[8.2]: retrieve rear queue node: %#X, *quedata Addr: %#X, datalen: %u",queue_megaptr->rearptr, *quedata,*quedatalen );
	     break;
       case RETRIEVE_QUEUE:
         /* make sure that cur_node points to queue node or empty node */
         if(cur_node == NULL || !(*quedata = calloc(1, cur_node->var_datalen)))
	     {
	         printf("\n ERR[8.3]: NO new memory for queue's head addr: %#X, retrieve rear data, whose len :%u",queue_megaptr,cur_node->var_datalen );
	         ret_state = QUEUE_FAIL;
	         break;
	     }
	     memcpy(*quedata, (const void *) cur_node->var_data, cur_node->var_datalen);
	     *quedatalen = cur_node->var_datalen;
	     ret_state = TRUE;
	     if(trace_flag)
	        printf("\n TRACE[8.3]: retrieve queue node: %#X, *quedata Addr: %#X, datalen: %u",cur_node, *quedata,*quedatalen );
         break;
       default:
         printf("\n ERR[8.4]: Invalid Queue's head addr: %#X retrieve mode: %d", queue_megaptr, ret_mode );
    }
    Control_Queue(queue_megaptr, FREE_ACCESS);
	return ret_state;
 }

/*******************************************************************
 Function Name  : Queue_Count(queue_head *queue_megaptr )
 Description    : number of nodes in the queue
 Remarks        :
 Func ID        : 9
 *******************************************************************/
 int Queue_Count(queue_head *queue_megaptr)
 {
	 if(!Access_Queue(queue_megaptr))
	 {
		 if(trace_flag)
		    printf("\n TRACE[9.1]: Queue Head's Addr: %#X, current num of queue nodes: %u",queue_megaptr, queue_megaptr->count);
		 return queue_megaptr->count;
     }
     else
       return FALSE;
 }

 /*******************************************************************
 Function Name  : Destroy_Queue(queue_head *queue_megaptr )
 Description    : makes the queue empty
 Remarks        :
 Func ID        : 10
 *******************************************************************/
  int Destroy_Queue(queue_head *queue_megaptr)
  {
	  int ret_state = FALSE;
      queue_node *temp_node = NULL, *del_node = NULL;

	  if(!Empty_Queue(queue_megaptr))
	  {   /* not a empty queue */
	      Control_Queue(queue_megaptr, NO_ACCESS);
	      temp_node = queue_megaptr->frontptr;
	      /* deleting each node from queue's front */
          while(temp_node)
          {
			  del_node = temp_node;
			  temp_node = temp_node->fore_node;
			  /* add codes here, if you want to retrive data from node, before been deleted */
			  free(del_node);
	      }
          if(!Initialize_Queue(&queue_megahead,MAX_QUEUE_SIZE, INVALID_DATA))
             ret_state = TRUE;
      }
	  return ret_state;
  }

/*******************************************************************
 Function Name  : Print_Queue(int display_mode, void *data_input )
 Description    : display statistic of queue and queue modeling simulation results
 Remarks        :
 Func ID        : 11
 *******************************************************************/
int Print_Queue(int display_mode, void *data_input )
{
   int ret_state = TRUE;
   queue_head *queue_megaptr = NULL;
   customer_status *cust_ptr = NULL;
   cust_info cust_data;
   simulator_status sim_status;
   unsigned cust_num, cust_index = 0;

   switch(display_mode)
   {
	   case MEGA_DATA_PRINT:
	      queue_megaptr = (queue_head *)data_input;
         /* printf("\n TRACE[11.1]: Display Emp's Mega Node's Control Info:");
          printf("\n ===================================================");*/
          printf("\n Queue Addr: %#X:: No of nodes: %u, max queue nodes: %u, max_datasize: %u", \
            queue_megaptr,queue_megaptr->count, queue_megaptr->max_queuesize, queue_megaptr->max_datasize);
          printf("\n frontptr: %#X, rearptr: %#X, access_que: %d,", queue_megaptr->frontptr,queue_megaptr->rearptr, queue_megaptr->access_que);
          /* printf("\n ================================================="); */
          break;
        case SPEC_CUST_STATUS:
          cust_num = *(unsigned *)data_input;
          printf("\n Cust Status[%2d] :: cust_num: %2u:: time :- arrive: %2u, start: %2u, service: %2u",CUST_STATUS_INDEX(cust_num),\
           cust_status[CUST_STATUS_INDEX(cust_num)].cust_num,cust_status[CUST_STATUS_INDEX(cust_num)].arrive_time,\
           cust_status[CUST_STATUS_INDEX(cust_num)].start_time,cust_status[CUST_STATUS_INDEX(cust_num)].service_time);
          break;
        case WHOLE_CUST_STATUS:
          cust_ptr = (customer_status *)data_input;
          while (cust_index < MAX_CUST)
          {
			 printf("\n Cust Status[%2d]:: cust_num: %2u, time :- arrive: %2u, start: %2u, service: %2u",cust_index, \
			  cust_ptr[cust_index].cust_num,cust_ptr[cust_index].arrive_time,cust_ptr[cust_index].start_time,cust_ptr[cust_index].service_time);
             ++cust_index;
	      }
          break;
        case SIMULATION_STATUS:
          sim_status = *(simulator_status *)data_input;
          printf("\n Simultion Status: num_cust: %u, max queue size: %u, sim Oper State: %u", sim_status.num_cust,sim_status.maxqueuesize,sim_status.sim_state);
          /* avoids, divide error for average mainly due to divide by num_cust being 0 */
          if(sim_status.num_cust > 0)
            printf("\n Simultion Time:: Total service: %lf, Avg service: %lf, Total Wait: %lf, Avg Wait: %lf ", \
              sim_status.totalsvctime,sim_status.totalsvctime/sim_status.num_cust,\
              sim_status.totalwaittime,sim_status.totalwaittime/sim_status.num_cust);
          else
          {
             printf("\n ERR[11.2]: Cannot process divide oper due to num_cust: %d for average time svc & wait",sim_status.num_cust);
             ret_state = FALSE;
	      }
          break;
        default:
          printf("\n ERR[11.3]: Invalid Queue's Head Addr: %#X, display mode: %d",queue_megaptr,display_mode);
          ret_state = FALSE;
    }
    return ret_state;
}

/*******************************************************************
 Function Name  : Trace_Flag(void)
 Description    : control access for execution flow trace for debugging
 Remarks        :
 Func ID        : -
 *******************************************************************/
int Trace_Flag(void)
{
   printf("\n Global Trace:: 0: Disable, any other interger: Enable: Enter: ");
   scanf("%d", &trace_flag);
   return TRUE;
}

/*******************************************************************
 Function Name  : Access_Queue(queue_head *queue_megaptr)
 Description    : check for queue access
 Remarks        :
 Func ID        : 12
 *******************************************************************/
int Access_Queue(queue_head *queue_megaptr)
{
   if(queue_megaptr == NULL)
   {
   	  printf("\n ERR[12.2]: Invalid queue head's address to access");
   	  return FALSE;
   }
   if(queue_megaptr->access_que != FREE_ACCESS)
   {
       printf("\n ERR[12.1]: Unable for Queue's Addr: %#X head to access: %d",queue_megaptr,queue_megaptr->access_que );
       return FALSE;
   }
   return TRUE;
}

/*******************************************************************
   Function Name : Link_Menu()
   Description   : Gets main operation to be performed in queue
   Remarks       : assume that input data are valid
   fUNC_ID       : 13
 *******************************************************************/
unsigned Link_Menu(void)
{
  char get_oper[OPER_SIZE];
  char check_oper[OPER_SIZE];
  unsigned get_ctrl;

  printf("\n MENU for Queue Modelling & Operation :- ");
  printf("\n ========================================");
  printf("\n 1-Quit: 2-Start Sim: 3-Enque: 4-Deque: 5-Destroy: 6-Display: Enter : ");
  scanf("%u",&get_ctrl);
  return get_ctrl;
}

/*******************************************************************
   Function Name : EnQue_CustData(queue_head *queue_megaptr, simctrl *simctrl_data)
   Description   : manually or automatically getting a valid input data before enque operation
   Remarks       : assume that input data are valid
   fUNC_ID       : 14
 *******************************************************************/
int EnQue_CustData(queue_head *queue_megaptr, simctrl *simctrl_ptr )
{
    int ret_state = FALSE;
    int enque_mode;
    cust_info *cust_data = NULL;
    queue_data *temp_enque = NULL;
    char name[OPER_SIZE] = "name", *cust_id = "";
    int str_len;
    unsigned char quedata_totlen;
    char temp_data[MAX_QUEUE_SIZE];
    /* helps for manually enque the cust data */
    unsigned arrive_time = GEN_NEW_CUST;

    memset(temp_data,0,MAX_QUEUE_SIZE);
    quedata_totlen = sizeof(queue_data) + sizeof(cust_info) - sizeof(unsigned char);
	temp_enque = (queue_data *)temp_data;
	temp_enque->msgtype = CUST_MSG;
	temp_enque->datalen = sizeof(cust_info);
	/* encapulation of cust info into queue_data's databuff */
	cust_data = (cust_info *)temp_enque->databuff;
	cust_data->cust_num = simctrl_ptr->enque_cust_id;
	/* cust data is enqueued manually */
	if(sim_status.sim_state == IDLE_SIM)
    {
		printf("\n Cust num: %u to be enqued at 1: Front 2: Rear end: Enter mode: ",simctrl_ptr->enque_cust_id);
	    scanf("%d", &enque_mode);
	    /* invalid enque mode */
	    if(enque_mode != ENQUE_FRONT && enque_mode != ENQUE_REAR)
	    {
			printf("\n ERR[14.1]: Invalid entered enque mode: %u",enque_mode);
			return ret_state;
	    }
        printf("\n Enter cust name whose Cust num: %u: ",simctrl_ptr->enque_cust_id);
        scanf(" %[^\n]", name);
	    /* if name entered name is within NAME_SIZE with '\0' */
	    memcpy(cust_data->cust_name, name, NAME_SIZE);
    }
    else /* cust data is enqueued automatically */
    {  /* generate random num from ranges from 1 to 4 */
       arrive_time = ((unsigned) rand()) % MAX_CUST_GENNUM + 1;
       if(trace_flag)
         printf("\n TRACE[14.2]: rand arrive: %u, enque cust: %u",arrive_time,simctrl_ptr->enque_cust_id);
       /* check if simulation has served, max number of cust, if not continue its service */
       if(simctrl_ptr->enque_cust_id <=  START_CUST_ID + MAX_CUST - 1)
       {
          if(arrive_time == GEN_NEW_CUST)
          {
            /* new cust requesting for service, arrives at random fashion, is to be enqueued */
             enque_mode = ENQUE_REAR;
             /* cust name has NULL string, causes rest of code not executed correctly */
             /* strcpy(cust_data->cust_name,"" ,sizeof("") );
             /* cust_name for cust 1, cust 2, .. is name1, name2,.. resp */
             /* str_len = sprintf(cust_id,"%u", cust_data->cust_num);
             strcat(name, cust_id);
             str_len = strlen(name);
             memcpy(cust_data->cust_name, name, str_len);
             cust_data->cust_name[str_len] = '\0'; */
            /* if(trace_flag)
               printf("\n cust_name: %s, strlen(cust_name): %d," ,cust_data->cust_name, strlen(cust_data->cust_name)); */
	      }
       }
       else
       {
		   printf("\n WARN[14.1]: Total no. of cust %u to be served exceeds limit, using sim enque cust id: %u", \
		     MAX_CUST, simctrl_ptr->enque_cust_id);
		     return EXCEED_CUST_SERV;
	   }
    }
	/* for manually enque cust data, initial value helps to enqueue and
	   for auto only when random generate number satisfy the condition */
	if(arrive_time == GEN_NEW_CUST)
	{
		cust_data->arrive_time = simctrl_ptr->clock;
	    if(trace_flag)
	    {
	       printf("\n TRACE[14.1]: Enque Data: quedatalen: %u:: Msgtype: %u, Cust Msg datalen: %u",quedata_totlen,temp_enque->msgtype,temp_enque->datalen);
	       printf("\n TRACE[14.2]: Cust Enque Data: cust_num: %u, arrive_time: %u, cust name: %s",cust_data->cust_num,cust_data->arrive_time,cust_data->cust_name);
	    }
	   /* if only data's address in enqued, then make sure that corressponding data
	      address is not illegaly access, dont free data's address if successully enqued */
	   /* however, in our case, we follow a copy of data been enqued */
	    ret_state = Enque_Data(enque_mode, queue_megaptr, quedata_totlen, temp_data );
	    /* what ever status of enque cust info, increment next cust id to be used by 1 */
	   ++simctrl_ptr->enque_cust_id;
    }
    return ret_state;
}

/*******************************************************************
   Function Name : GetQue_Data(unsigned get_mode, queue_head *queue_megaptr, simctrl *simctrl_data)
   Description   : user level deque or retrieve queue's data
   Remarks       : returns either kind of data it possess, or failed queue oper.
   fUNC_ID       : 15
 *******************************************************************/
int GetQue_Data(unsigned get_mode, queue_head *queue_megaptr, unsigned char *quedatalen, void **deque_data )
{  /* holds starting address of deque data & quedatalen holds deque data's total length */
   int ret_state = TRUE;

   switch(get_mode)
   {
	   case DEQUE_DATA_OPER:
	     ret_state = Deque_Data(queue_megaptr, quedatalen, deque_data);
         break;
       case RETRIEVE_FRONT:
       case RETRIEVE_REAR:
         ret_state = Retrieve_QueData(get_mode, queue_megaptr, NULL, quedatalen, deque_data);
         break;
       default:
         printf("\n ERR[15.1]: Invalid Queue's Head Addr: %#X get mode: %d",queue_megaptr, get_mode);
         ret_state = FALSE;
   }
   /* deque_data has data from queue, which was either retrieved or dequed */
   if(ret_state == TRUE)
      ret_state = GetQue_MsgData(*deque_data, *quedatalen);
   return ret_state;
}

/*******************************************************************
   Function Name : Sim_Control(unsigned char oper_mode,queue_head *queue_megaptr, simctrl *simctrl_data)
   Description   : Triggers simulation modeling for the queue
   Remarks       : makes queue empty, before simulation starts
   fUNC_ID       : 16
 *******************************************************************/
int Sim_Control(unsigned oper_mode, queue_head *queue_megaptr, simctrl *simctrl_ptr)
{
	int ret_state = FALSE;
    unsigned end_time;
    char more_cust = FALSE;
    int enque_flag = TRUE;

    if(sim_status.sim_state < IDLE_SIM || sim_status.sim_state > PROCESS_SIM )
    {
		printf("\n ERR[16.1]: Invalid simulation FSM State: %u", sim_status.sim_state );
		return ret_state;
    }
    if(trace_flag)
	   printf("\n TRACE[16.1]: Sim FSM State: %u",sim_status.sim_state);
	switch(oper_mode)
	{
	   case SIMULATION_START:
	     if(sim_status.sim_state != IDLE_SIM)
	     {
	   		printf("\n ERR[16.2]: Simulation is already running, sim_state: %u",sim_status.sim_state);
	   		return ret_state;
	     }
	     printf("\n Enter end counter for simulation: ");
	     scanf("%u", &end_time);
	     /* make the queue empty, before we start simulation */
	     QueData_Range(DESTROY_QUE_OPER, queue_megaptr );
	     /* initialize a queue head with max queue's data as cust info + overhead */
	     if(Initialize_Queue(queue_megaptr,MAX_QUEUE_SIZE, sizeof(queue_data) + sizeof(cust_info) - sizeof(unsigned char)))
            return FALSE;
	     /* reset sim control parameter */
	     Initialize_SimData(simctrl_ptr, end_time);
	     /* start the queue modeling simulation */
         sim_status.sim_state = PROCESS_SIM;
         /* stop simulation only when counter has reached the end and has finished service req for all cust, which were enqueued */
          while(simctrl_ptr->clock <= simctrl_ptr->endtime || more_cust == TRUE)
         {
			 if(trace_flag)
			   printf("\n TRACE[16.2]: clock: %u, endtime: %u, morecust: %d, deque_cust_id: %u",simctrl_ptr->clock,simctrl_ptr->endtime, more_cust,simctrl_ptr->deque_cust_id);
			 /* if max no of cust to be serviced is not reached, randomly, enqueues new cust requesting for service,  */
             if(enque_flag == TRUE && (ret_state = EnQue_CustData(queue_megaptr, simctrl_ptr)) < FALSE)
             {
				 if(ret_state == EXCEED_CUST_SERV)
                /* has reached limit of max custome, been enqued, skip enque oper next time */
                   enque_flag = FALSE;
                 else if(ret_state == QUEUE_FAIL)
                   break;
		     }
             /* waits until server has completed one cust service, and if new cust exist, process it */
             if((ret_state = Server_Free(queue_megaptr, simctrl_ptr, &cust_status[CUST_STATUS_INDEX(simctrl_ptr->deque_cust_id)], &more_cust)) < FALSE)
               /* has encountered some critical problem during simulation, give up */
               break;
             /* simulates that cust is under process, and if completed updates sim status and wait for another cust */
             Service_Complete(queue_megaptr, simctrl_ptr, &cust_status[CUST_STATUS_INDEX(simctrl_ptr->deque_cust_id)], &more_cust);
             /* if queue is not empty, more cust is waiting for its service */
             if(!Empty_Queue(queue_megaptr))
                more_cust = TRUE;
             ++simctrl_ptr->clock;
             printf("\n ========================================================");
	     }
	     if(ret_state == QUEUE_FAIL)
	        printf("\n ERR[16.3]: Might faced memory shortage during simulation ");
	     else
	     {
	        if(Empty_Queue(queue_megaptr))
	          ret_state = TRUE;
	        else
	        {
	           if(ret_state <= FALSE)
	             QueData_Range(DESTROY_QUE_OPER, queue_megaptr );
	        }
	     }
	     /* simulation can be started again */
	     sim_status.sim_state = IDLE_SIM;
         break;
	   default:
	     printf("\n ERR[16.4]: Unknown Simulation operation: %d", oper_mode);
    }
    return ret_state;
}

/*******************************************************************
   Function Name : Display_Data()
   Description   : control display info for queue
   Remarks       : assume correct input
   fUNC_ID       : 17
 *******************************************************************/
int Display_Data(void)
{
	int display_mode;
    unsigned cust_id;
    int ret_state = TRUE;
    unsigned char quedatalen;
    void *deque_data = NULL;

    printf("\n Display mode in Retrieve: 1: Whole Queue, 2: Front Data, 3: Rear Data ");
    printf("\n Status: 4: Queue's Head, 5: Spec Cust, 6: Whole Cust, 7: Sim:: Enter: ");
    scanf("%d", &display_mode);
    switch(display_mode)
    {
		case MEGA_DATA_PRINT:
		  Print_Queue(display_mode, &queue_megahead);
		  break;
		case RETRIEVE_FRONT:
		case RETRIEVE_REAR:
          if((ret_state = GetQue_Data(display_mode, &queue_megahead, &quedatalen, &deque_data )) >= TRUE)
             free(deque_data);
          break;
        case RETRIEVE_QUEUE:
          if(QueData_Range(display_mode, &queue_megahead))
            ret_state = FALSE;
          break;
		case SPEC_CUST_STATUS:
		  printf("\n Enter Specific Customer's ID: ");
		  scanf("%u", &cust_id);
		  if(cust_id >= MAX_CUST)
		  {
			  printf("\n ERR[17.1]: Invalid cust id: %u, should range from %u to %u",cust_id, START_CUST_ID, START_CUST_ID + MAX_CUST - 1);
			  ret_state = FALSE;
			  break;
		  }
          Print_Queue(display_mode, &cust_id);
          break;
        case WHOLE_CUST_STATUS:
          Print_Queue(display_mode, &cust_status[CUST_STATUS_INDEX(START_CUST_ID)]);
          break;
        case SIMULATION_STATUS:
          Print_Queue(display_mode, &sim_status);
          break;
         default:
           printf("\n ERR[17.1]: Invalid display mode: %d", display_mode);
           ret_state = FALSE;
    }
    return ret_state;
}

/*******************************************************************
   Function Name : DeQue_CustData(queue_data *que_data)
   Description   : retrive customer info from dequed data
   Remarks       : que_data has info about customer.
   fUNC_ID       : 18
 *******************************************************************/
 int DeQue_CustData(queue_data *que_data)
 {
	 cust_info *deque_cust = NULL;

     if(que_data->datalen != sizeof(cust_info))
	 {  /* might be due to data corruption in queue oper */
		 printf("\n ERR[18.1]: que data len[%u] != len of cust [%u] ", que_data->datalen, sizeof(cust_info));
		 /* remember to be free dequed data, after been allocated in deque operation */
		 free(que_data);
		 return FALSE;
     }
     /* decapulation of cust info from queue_data's databuff */
     deque_cust = (cust_info *) que_data->databuff;
     if(trace_flag)
       printf("\n TRACE[18.1]: Deque Data Addr: %#X, Msg datalen: %u, Dequed cust_num: %u, cust_name: %s, cust arrival: %u",que_data, \
       que_data->datalen, deque_cust->cust_num,deque_cust->cust_name,deque_cust->arrive_time  );
     return TRUE;
 }

 /*******************************************************************
    Function Name : DeQue_SimData(queue_data *que_data)
    Description   : retrive queue simulation info from dequed data
    Remarks       : que_data has info about queue simulation data.
                    currently, simulation data is not enqueued.
    fUNC_ID       : 19
  *******************************************************************/
  int DeQue_SimData(queue_data *que_data)
  {
     return TRUE;
  }

  /*******************************************************************
    Function Name : GetQue_MsgData(queue_data *que_data, unsigned char quedatalen)
    Description   : depending on data retrived from queue,
    Remarks       : que_data has info about either customer or queue simulation data
    fUNC_ID       : 20
   *******************************************************************/
  int GetQue_MsgData(queue_data *que_data, unsigned char quedatalen)
  {
      int ret_state = FALSE;

      if(trace_flag)
         printf("\n TRACE[20.1]: Queue Data Addr: %#X, quedatalen: %u, msgtype: %u",que_data, quedatalen, que_data->msgtype);
      switch(que_data->msgtype)
      {
	     case CUST_MSG:
	      /* retrieve customers info */
	       if((ret_state = DeQue_CustData(que_data)) == TRUE)
	         ret_state = CUST_MSG;
	       break;
	     case SIM_MSG:
	       /* retrive Simulation info */
	       if((ret_state = DeQue_SimData(que_data )) == TRUE)
	          ret_state = SIM_MSG;
	       break;
	     default:
	        printf("\n ERR[20.1]: Invalid msg type %u from queue",que_data->msgtype);
	        free(que_data);
	        ret_state = FALSE;
	  }
      return ret_state;
   }

/*******************************************************************
  Function Name : QueData_Range(unsigned mode, queue_head *queue_megaptr)
  Description   : process on partial or whole operation in queue's  data
  Remarks       : que_data has info about either customer or queue simulation data
  fUNC_ID       : 21
 *******************************************************************/
 int QueData_Range(unsigned mode, queue_head *queue_megaptr)
 {
	 queue_node *curptr = NULL;         /* local temp ptr contains current node */
	 int ret_state = TRUE;
     int i = 0;
     unsigned char quedatalen;
     void *quedata = NULL;

     switch(mode)
     {
		 case RETRIEVE_QUEUE:
	        /* printf("\n Display Queue nodes from queue's front end:");
		     printf("\n ============================================");*/
		    if(Access_Queue(queue_megaptr))
		    {
				ret_state = FALSE;
		        break;
		    }
	        Control_Queue(queue_megaptr, NO_ACCESS);
    	    curptr = queue_megaptr->frontptr;
		    while(curptr)
		    {
		        ++i;
		        printf("\n\n %02d: Queue Node: %#X, Next Node: %#X",i, curptr, curptr->fore_node );
		        Control_Queue(queue_megaptr, FREE_ACCESS);
		        if((ret_state = Retrieve_QueData(mode, queue_megaptr, curptr, &quedatalen, &quedata )) <= FALSE)
		        /* unable to retrieve data, give up */
		           break;
		        Control_Queue(queue_megaptr, NO_ACCESS);
		        /* GetQue_MsgData already frees when encountered some problems */
			    if((ret_state = GetQue_MsgData(quedata, quedatalen)) >= TRUE)
			    /* no more process req on retrieve data, free it */
                   free(quedata);
		        curptr = curptr->fore_node;
	        }
	        if(ret_state >= TRUE)
	          ret_state = TRUE;
	        Control_Queue(queue_megaptr, FREE_ACCESS);
	        /* printf("\n ============================================"); */
            break;
          case DESTROY_QUE_OPER:
            if((i = Queue_Count(queue_megaptr)) <= FALSE)
              return ret_state;
            printf("\n INFO[21.1]: Before Destroy:: Queue Head's Addr: %#X, current num of nodes: %u", queue_megaptr,queue_megaptr->count);
            ret_state = Destroy_Queue(queue_megaptr);
            break;
          default:
            printf("\n ERR[21.1]: Invalid Queue Head's Addr: %#X, range_mode: %u",queue_megaptr, mode);
            ret_state = FALSE;
     }
     return ret_state;
 }

 /*******************************************************************
   Function Name : Initialize_SimData(simctrl *simctrl_ptr, unsigned endtime)
   Description   : resets sim paramters.
   Remarks       :
   fUNC_ID       : 22
 *******************************************************************/
int Initialize_SimData(simctrl *simctrl_ptr, unsigned endtime)
{
	unsigned cust_index = -1;

	/* initialize simulation status */
	sim_status.num_cust = 0;
	sim_status.totalsvctime = 0;
	sim_status.totalwaittime = 0;
	sim_status.maxqueuesize = 0;
	/* initialize all cust status */
	while(++cust_index < MAX_CUST)
	{
	   cust_status[cust_index].cust_num = START_CUST_ID + cust_index;
	   cust_status[cust_index].arrive_time = 0;
	   cust_status[cust_index].start_time = 0;
	   cust_status[cust_index].service_time = 0;
    }
	/* reseting simulation control paramters */
	simctrl_ptr->enque_cust_id = START_CUST_ID;
	simctrl_ptr->deque_cust_id = START_CUST_ID;
	simctrl_ptr->clock = 1;
	simctrl_ptr->endtime = endtime;
	sim_status.sim_state = IDLE_SIM;
	if(trace_flag)
	  printf("\n TRACE[22.1]: Initialized Sim Data: sizeof(cust status): %d, enque_cust_id: %u, deque_cust_id: %u, clock: %u, endtime: %u", \
	   sizeof(cust_status),simctrl_ptr->enque_cust_id, simctrl_ptr->deque_cust_id, simctrl_ptr->clock, simctrl_ptr->endtime);
	return TRUE;
}

/*******************************************************************
   Function Name : Server_Free(queue_head *queue_megaptr, simctrl *simctrl_data, customer_status *cust_ptr,unsigned *more_cust)
   Description   : find if server is idle, if so start serving new customer
   Remarks       : if current cust service is not complete, we can't start to service new cust.
                   cust_statusptr points to current/previous cust's status.
   fUNC_ID       : 23
 *******************************************************************/
int Server_Free(queue_head *queue_megaptr, simctrl *simctrl_ptr, customer_status *cust_statusptr, char *more_cust)
{
	int ret_state = FALSE;
    unsigned char quedatalen;
    void *deque_data = NULL;
    cust_info *deque_cust = NULL;

    /* total num of cust serviced, is less than its max  */
    if( sim_status.num_cust <= MAX_CUST && cust_statusptr - &cust_status[0] <= MAX_CUST)
    {
		if(trace_flag)
		  printf("\n TRACE[23.1]: clock: %u, cust num %u Status: cust start: %u, cust service: %u",simctrl_ptr->clock, \
		    cust_statusptr->cust_num,cust_statusptr->start_time,cust_statusptr->service_time);
		/* typecast to signed is essential in initial as start + service - 1 = (expected)-1, due to default
		   unsigned conversion on both side, it yeids (unexpected)65534 */
		if(((signed)simctrl_ptr->clock) > ((signed)(cust_statusptr->start_time + cust_statusptr->service_time - 1)))
		{
		   Queue_Count(queue_megaptr);
		  /* server is idle means that current cust service is complete, if so check for another cust exist to start its service */
		  if(!Empty_Queue(queue_megaptr))
		  {   /*  deque another cust,which is waiting in the queue to be served */
			 if((ret_state = GetQue_Data(DEQUE_DATA_OPER, queue_megaptr, &quedatalen, &deque_data )) == QUEUE_FAIL)
			 /* only on critical queue oper error, may be due no new memory for deque oper, give up */
			    return ret_state;
			 if(ret_state == CUST_MSG)
		     {
                 /* decapulation of cust info from queue_data's databuff */
                  deque_cust = (cust_info *)((queue_data *)deque_data)->databuff;
                  /* cumalitive time from start of simulation, instance before enque */
                  cust_status[CUST_STATUS_INDEX(deque_cust->cust_num)].arrive_time = deque_cust->arrive_time;
                  /* cumalitive time from start of simulation, instance at deque */
                  cust_status[CUST_STATUS_INDEX(deque_cust->cust_num)].start_time = simctrl_ptr->clock;
                  /* time req after deque cust to complete its service */
                  cust_status[CUST_STATUS_INDEX(deque_cust->cust_num)].service_time = ((unsigned) rand()) % MAX_SERVERTIME_GENNUM + 1;
                  /* simulates that current cust is under process */
                  *more_cust = TRUE;
                  simctrl_ptr->deque_cust_id = deque_cust->cust_num;
                  if(trace_flag)
                     printf("\n TRACE[23.3]: After Deque: cust num: %u status: arrive: %u, start: %u, service:%u, *more: %d", \
                      deque_cust->cust_num, cust_status[CUST_STATUS_INDEX(deque_cust->cust_num)].arrive_time,
                      cust_status[CUST_STATUS_INDEX(deque_cust->cust_num)].start_time, cust_status[CUST_STATUS_INDEX(deque_cust->cust_num)].service_time, *more_cust );
		      }
		      else
		        printf("\n ERR[23.1]: Invalid dequed data msg: %d, its datalen: %u",ret_state,quedatalen);
		      /* after utilizing cust data or valid dequeued data, free it */
              free(deque_data);
		   }
	    }
    }
    else
    {
		printf("\n WARN[23.1]: Total no. of cust %u service complete exceeds limit:- sim status: %u, cust status: %u ", \
		 MAX_CUST, sim_status.num_cust, cust_statusptr - &cust_status[0] );
		ret_state = EXCEED_CUST_SERV;
    }
    return ret_state;
}

/*******************************************************************
   Function Name : Service_Complete(queue_head *queue_megaptr, simctrl *simctrl_data,customer_status *cust_ptr,unsigned  *more_cust)
   Description   : find if current customer service is complete
   Remarks       : if current cust service is not complete, we can't start to service new cust
                   cust_statusptr points to current/previous cust's status.
   fUNC_ID       : 24
 *******************************************************************/
 int Service_Complete(queue_head *queue_megaptr, simctrl *simctrl_ptr,customer_status *cust_statusptr, char *more_cust)
 {
    int ret_state = FALSE;
    unsigned wait_time;
    int num_quenode;

    if(trace_flag)
	  printf("\n TRACE[24.1]: clock: %u, cust num %u status: cust start: %u, cust service: %u",simctrl_ptr->clock, \
	   cust_statusptr->cust_num,cust_statusptr->start_time,cust_statusptr->service_time);
    /* if current counter == cumalitive service time from start of simulation - 1 ( -1 for initial process of cust)  */
    if(((signed)simctrl_ptr->clock) == ((signed) (cust_statusptr->start_time + cust_statusptr->service_time - 1)))
    {  /* simulates that service req by current cust has completed, after deque */
       if((num_quenode = Queue_Count(queue_megaptr)) < FALSE)
         return FALSE;
       /* wait time is time cust has been wait in queuee, before its actual service starts */
        wait_time = cust_statusptr->start_time - cust_statusptr->arrive_time;
        /* update sim status */
        sim_status.num_cust += 1;
		sim_status.totalsvctime += cust_statusptr->service_time;
		sim_status.totalwaittime += wait_time;
		if(sim_status.maxqueuesize < (unsigned char)num_quenode)
	       sim_status.maxqueuesize = (unsigned char)num_quenode;
	    /* current cust's service is completely */
	    *more_cust = FALSE;
	    if(trace_flag)
	    {
	       printf("\n TRACE[24.2]: Simultion Status: no of cust: %u, max queue size: %u, *more: %d",sim_status.num_cust,sim_status.maxqueuesize, *more_cust);
	       printf("\n TRACE[24.3]: Status for cust_index: %u, cust_num: %u:: arrive time: %u, start time: %u, service time: %u",cust_statusptr - &cust_status[0],\
	        cust_statusptr->cust_num, cust_statusptr->arrive_time, cust_statusptr->start_time, cust_statusptr->service_time);
	    }
	    ret_state = TRUE;
    }
    return ret_state;
 }
