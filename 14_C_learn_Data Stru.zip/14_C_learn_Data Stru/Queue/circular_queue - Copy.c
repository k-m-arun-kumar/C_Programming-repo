/* ********************************************************************
FILE                   : circular_queue - Copy.c

PROGRAM DESCRIPTION    : circular queue using array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include <stdio.h>
#include <string.h>

#define SUCCESS         (0) 

typedef enum 
{
	NO_ERROR, ERR_NULL_PTR,ERR_FORMAT_INVALID , ERR_QUEUE_FULL, ERR_QUEUE_EMPTY, ERR_ENQUEUE_PROC, ERR_DEQUEUE_PROC, ERR_QUEUE_INSERT_FRONT_PROC, ERR_QUEUE_DELETE_REAR_PROC,
	ERR_QUEUE_RETRIEVE_INFO_PROC, ERR_DISP_QUEUE_PROC, ERR_INSERT_DATA_PROC, ERR_RETRIEVE_DATA_PROC
} system_status_t;

#define MAX_ELEMENTS_CIRC_QUEUE_ARR     (5)
 
#define ENQUEUE_OPER                          (1)
#define DEQUEUE_OPER                          (2)
#define RETRIEVE_QUEUE_OPER                   (3)
#define SEND_TO_FRONT_OF_QUEUE_OPER           (4)
#define RECEIVE_TO_REAR_OF_QUEUE_OPER         (5)
#define RESET_QUEUE_OPER                      (6)
#define EXIT_OPER                             (7)    
#define RETRIEVE_QUEUE_ELEMENT_AT_INDEX_OPER  (8)

#define RETRIEVE_QUEUE_FRONT_INDEX_OPER   (1)
#define RETRIEVE_QUEUE_REAR_INDEX_OPER    (2)
#define RETRIEVE_QUEUE_NUM_ELEMENTS_OPER  (3)
#define RETRIEVE_QUEUE_LIST_ELEMENTS_OPER (4)

#define DISP_QUEUE_LIST_ELEMENTS_OPER     (RETRIEVE_QUEUE_ELEMENT_AT_INDEX_OPER + RETRIEVE_QUEUE_LIST_ELEMENTS_OPER)

#define TRACE                    (0)
//#define CIRCULAR_QUEUE_SIMPLE  (1)

#ifndef CIRCULAR_QUEUE_SIMPLE

#define MAX_ELEMENTS_MSG_1_ARR             MAX_ELEMENTS_CIRC_QUEUE_ARR
#define MAX_ELEMENTS_MSG_2_ARR             MAX_ELEMENTS_CIRC_QUEUE_ARR
#define MAX_ELEMENTS_MSG_2_SUB_MSG_1_ARR   MAX_ELEMENTS_CIRC_QUEUE_ARR

#define ERROR_OCCURED    (1)

#define CIRCULAR_QUEUE_RESET_INDEX         (-1)

#define NULL_PTR                          ((void *) 0)
#define DATA_NA                           (0)

typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long uint64_t;

typedef char int8_t;
typedef short int int16_t;
typedef int int32_t;
typedef long int64_t;


typedef struct
{
	volatile void *associated_msg_data_ptr;
	uint16_t related_msg_type;	
} data_t;

typedef struct
{
	data_t data_arr[MAX_ELEMENTS_CIRC_QUEUE_ARR];
	uint8_t max_num_elements;
	int8_t front_index; //dequeue at front_index
	int8_t rear_index;  //enqueue at rear_index	
} circular_queue_data_t;

typedef struct
{
  uint8_t associated_msg_1_data;  	
} associated_msg_1_t;

typedef struct
{
  associated_msg_1_t associated_data_arr[MAX_ELEMENTS_MSG_1_ARR];
  int8_t associated_data_arr_front_index; 
  int8_t associated_data_arr_rear_index; 
} associated_msg_1_ctrl_arr_t;

typedef struct
{
	volatile void *associated_msg_2_data_ptr;
	uint8_t related_msg_2_sub_msg_type;
} associated_msg_2_t;

typedef struct
{
  associated_msg_2_t associated_data_arr[MAX_ELEMENTS_MSG_2_ARR];
  int8_t associated_data_arr_front_index; 
  int8_t associated_data_arr_rear_index; 	
} associated_msg_2_ctrl_arr_t;

typedef struct
{
	uint32_t associated_msg_2_sub_msg_1_data; 
} associated_msg_2_sub_msg_1_t;

typedef struct
{
	associated_msg_2_sub_msg_1_t associated_data_arr[MAX_ELEMENTS_MSG_2_SUB_MSG_1_ARR];
	int8_t associated_data_arr_front_index; 
    int8_t associated_data_arr_rear_index; 	
} associated_msg_2_sub_msg_1_ctrl_arr_t;

uint32_t system_status_flag = NO_ERROR;

volatile circular_queue_data_t comm_transmit_queue;

associated_msg_1_ctrl_arr_t associated_msg_1_datas;
associated_msg_2_ctrl_arr_t associated_msg_2_datas;
associated_msg_2_sub_msg_1_ctrl_arr_t associated_msg_2_sub_msg_1_datas;
 
uint8_t Reset_Circular_Queue(circular_queue_data_t *const circular_queue_data_ptr);
uint16_t EnQueue_Proc(circular_queue_data_t *const circular_queue_data_ptr, const data_t *const insert_data_ptr);
uint16_t DeQueue_Proc(circular_queue_data_t *const circular_queue_data_ptr, data_t *const deleted_data_ptr);
uint16_t Queue_Insert_At_Front(circular_queue_data_t *const circular_queue_data_ptr, const data_t *const insert_data_ptr);
uint16_t Queue_Delete_At_Rear(circular_queue_data_t *const circular_queue_data_ptr, data_t *const deleted_data_ptr);
uint16_t Get_Queue_Info(circular_queue_data_t *const circular_queue_data_ptr, const uint8_t queue_disp_info, void *queue_arr_index_or_num_items_ptr, void *const queue_num_elements_ptr);
uint16_t Display_Queue_Element_At_Index(circular_queue_data_t *const circular_queue_data_ptr, const void *const queue_index_ptr, data_t *const queue_disp_data_ptr);
uint16_t Disp_Retrieved_Data(const uint8_t oper_type, const data_t *const queue_retrieve_data_ptr);
uint16_t Set_Next_Pos_Msg_Data_Arr(const uint8_t oper_type, int8_t *const associated_msg_data_arr_front_index_ptr, int8_t *const associated_msg_data_arr_rear_index_ptr, const uint8_t max_elements_msg_arr);

/*------------------------------------------------------------*
FUNCTION NAME  : Error_or_Warning_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.14  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t Error_or_Warning_Proc(const char *const error_trace_str, const uint8_t warn_or_error_format, const uint32_t warning_or_error_code)
{
	printf("\n ERR: TRACE: %s, code: %u", error_trace_str, warning_or_error_code);
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Circular_Queue

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.21 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Reset_Circular_Queue(circular_queue_data_t *const circular_queue_data_ptr)
{
	uint8_t cur_arr_index;
	
	if(circular_queue_data_ptr == NULL_PTR)
	{
		system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.21.01", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	circular_queue_data_ptr->max_num_elements = sizeof(circular_queue_data_ptr->data_arr) / sizeof(data_t);
	for(cur_arr_index = 0; cur_arr_index < circular_queue_data_ptr->max_num_elements; ++cur_arr_index)
	{
		circular_queue_data_ptr->data_arr[cur_arr_index].associated_msg_data_ptr = NULL_PTR;
		circular_queue_data_ptr->data_arr[cur_arr_index].related_msg_type = DATA_NA;
	}
	circular_queue_data_ptr->front_index = CIRCULAR_QUEUE_RESET_INDEX;
	circular_queue_data_ptr->rear_index = CIRCULAR_QUEUE_RESET_INDEX;
	
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : EnQueue_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.22 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t EnQueue_Proc(circular_queue_data_t *const circular_queue_data_ptr, const data_t *const insert_data_ptr)
{
	if(circular_queue_data_ptr == NULL_PTR)
	{
		system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.22.01", ERROR_OCCURED,system_status_flag );
		return system_status_flag;
	}
	if(insert_data_ptr == NULL_PTR)
	{
		system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.22.02", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	if((circular_queue_data_ptr->front_index == 0 && circular_queue_data_ptr->rear_index == (circular_queue_data_ptr->max_num_elements - 1)) || (circular_queue_data_ptr->front_index == (circular_queue_data_ptr->rear_index + 1)))
	{
		system_status_flag = ERR_QUEUE_FULL;
		Error_or_Warning_Proc("02.22.03", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	if(circular_queue_data_ptr->front_index == CIRCULAR_QUEUE_RESET_INDEX)  
	{
		/* queue was empty */
		circular_queue_data_ptr->front_index = 0;
		circular_queue_data_ptr->rear_index = 0;
	}
	else
	{
		if(circular_queue_data_ptr->rear_index == (circular_queue_data_ptr->max_num_elements - 1))
		{
			//rear was at last position of queue			
			circular_queue_data_ptr->rear_index = 0;
		}
		else
		{
			++circular_queue_data_ptr->rear_index;
		}
	}
	memcpy(&circular_queue_data_ptr->data_arr[circular_queue_data_ptr->rear_index], insert_data_ptr, sizeof(data_t));
	#ifdef TRACE
	  printf("\n TRA: Enqueued rear: %d, msg: %u, msg_ptr: 0x%x ", circular_queue_data_ptr->rear_index, \
	    circular_queue_data_ptr->data_arr[circular_queue_data_ptr->rear_index].related_msg_type, circular_queue_data_ptr->data_arr[circular_queue_data_ptr->rear_index].associated_msg_data_ptr);
	#endif
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : DeQueue_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.23 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t DeQueue_Proc(circular_queue_data_t *const circular_queue_data_ptr, data_t *const deleted_data_ptr)
{
	if(circular_queue_data_ptr == NULL_PTR)
	{
		system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.23.01", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	if(deleted_data_ptr == NULL_PTR)
	{
		system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.23.02", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}	
	if(circular_queue_data_ptr->front_index == CIRCULAR_QUEUE_RESET_INDEX)
	{
		system_status_flag = ERR_QUEUE_EMPTY;
		Error_or_Warning_Proc("02.23.03", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	memcpy(deleted_data_ptr, &circular_queue_data_ptr->data_arr[circular_queue_data_ptr->front_index], sizeof(data_t));
	#ifdef TRACE
	  printf("\n TRA: Dequeued front: %d, msg: %u, msg_ptr: 0x%x ", circular_queue_data_ptr->front_index, \
	    deleted_data_ptr->related_msg_type, deleted_data_ptr->associated_msg_data_ptr);
	#endif
	circular_queue_data_ptr->data_arr[circular_queue_data_ptr->front_index].associated_msg_data_ptr = NULL_PTR;
	circular_queue_data_ptr->data_arr[circular_queue_data_ptr->front_index].related_msg_type = DATA_NA;	
	if(circular_queue_data_ptr->front_index == circular_queue_data_ptr->rear_index) 
	{
		/* queue had only one element */
		circular_queue_data_ptr->front_index = CIRCULAR_QUEUE_RESET_INDEX;
		circular_queue_data_ptr->rear_index = CIRCULAR_QUEUE_RESET_INDEX;
	}
	else
	{	
		if(circular_queue_data_ptr->front_index == (circular_queue_data_ptr->max_num_elements - 1))
		{
			circular_queue_data_ptr->front_index = 0;
		}
		else
		{
			++circular_queue_data_ptr->front_index;
		}
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Queue_Insert_At_Front

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.24 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Queue_Insert_At_Front(circular_queue_data_t *const circular_queue_data_ptr, const data_t *const insert_data_ptr)
{
	if(circular_queue_data_ptr == NULL_PTR)
	{
		system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.24.01", ERROR_OCCURED,system_status_flag );
		return system_status_flag;
	}
	if(insert_data_ptr == NULL_PTR)
	{
		system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.24.02", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	if((circular_queue_data_ptr->front_index == 0 && circular_queue_data_ptr->rear_index == (circular_queue_data_ptr->max_num_elements - 1)) || (circular_queue_data_ptr->front_index == (circular_queue_data_ptr->rear_index + 1)))
	{
		system_status_flag = ERR_QUEUE_FULL;
		Error_or_Warning_Proc("02.24.03", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	if(circular_queue_data_ptr->front_index == CIRCULAR_QUEUE_RESET_INDEX)  
	{
		/* queue was empty */
		circular_queue_data_ptr->front_index = 0;
		circular_queue_data_ptr->rear_index = 0;
	}
	else
	{
		if(circular_queue_data_ptr->front_index == 0)
       {
           circular_queue_data_ptr->front_index = (circular_queue_data_ptr->max_num_elements - 1);
       }
	   else
	   {
	      --circular_queue_data_ptr->front_index;
	   }
	}
	memcpy(&circular_queue_data_ptr->data_arr[circular_queue_data_ptr->front_index], insert_data_ptr, sizeof(data_t));
	#ifdef TRACE
	  printf("\n TRA: queue ins_front front: %d, msg: %u, msg_ptr: 0x%x ", circular_queue_data_ptr->front_index, \
	    circular_queue_data_ptr->data_arr[circular_queue_data_ptr->front_index].related_msg_type, circular_queue_data_ptr->data_arr[circular_queue_data_ptr->front_index].associated_msg_data_ptr);
	#endif
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Queue_Delete_At_Rear

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.25 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Queue_Delete_At_Rear(circular_queue_data_t *const circular_queue_data_ptr, data_t *const deleted_data_ptr)
{
	if(circular_queue_data_ptr == NULL_PTR)
	{
		system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.25.01", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	if(deleted_data_ptr == NULL_PTR)
	{
		system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.25.02", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}	
	if(circular_queue_data_ptr->front_index == CIRCULAR_QUEUE_RESET_INDEX)
	{
		system_status_flag = ERR_QUEUE_EMPTY;
		Error_or_Warning_Proc("02.25.03", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	memcpy(deleted_data_ptr, &circular_queue_data_ptr->data_arr[circular_queue_data_ptr->rear_index], sizeof(data_t));
	#ifdef TRACE
	  printf("\n TRA: queue del_rear rear: %d, msg: %u, msg_ptr: 0x%x ", circular_queue_data_ptr->rear_index, \
	    deleted_data_ptr->related_msg_type, deleted_data_ptr->associated_msg_data_ptr);
	#endif
	circular_queue_data_ptr->data_arr[circular_queue_data_ptr->rear_index].associated_msg_data_ptr = NULL_PTR;
	circular_queue_data_ptr->data_arr[circular_queue_data_ptr->rear_index].related_msg_type = DATA_NA;	
	if(circular_queue_data_ptr->front_index == circular_queue_data_ptr->rear_index) 
	{
		/* queue had only one element */
		circular_queue_data_ptr->front_index = CIRCULAR_QUEUE_RESET_INDEX;
		circular_queue_data_ptr->rear_index = CIRCULAR_QUEUE_RESET_INDEX;
	}
	else
	{	
		if(circular_queue_data_ptr->rear_index == 0 )
		{
			circular_queue_data_ptr->rear_index = (circular_queue_data_ptr->max_num_elements - 1);
		}
		else
		{
			--circular_queue_data_ptr->rear_index;
		}
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Get_Queue_Info

DESCRIPTION    : gets Queue elements from front_index to rear index.
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.26 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Get_Queue_Info(circular_queue_data_t *const circular_queue_data_ptr, const uint8_t queue_disp_info, void *queue_arr_index_or_num_items_ptr, void *const queue_retrieve_info_ptr)
{
	int8_t *int8_t_retrieve_data_ptr;
	data_t *data_t_retrieve_data_ptr;
    uint16_t ret_status;
	int8_t front_pos, rear_pos, num_elements = 0;
	
	if(circular_queue_data_ptr == NULL_PTR)
	{
		system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.26.01", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	if(queue_retrieve_info_ptr == NULL_PTR)
	{
		system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.26.02", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	if(circular_queue_data_ptr->front_index == CIRCULAR_QUEUE_RESET_INDEX)
    {
	    switch(queue_disp_info)
	    {
	    	case RETRIEVE_QUEUE_FRONT_INDEX_OPER:
	    	case RETRIEVE_QUEUE_REAR_INDEX_OPER:
	    	  int8_t_retrieve_data_ptr  = (int8_t *) queue_retrieve_info_ptr;
	    	  *int8_t_retrieve_data_ptr = CIRCULAR_QUEUE_RESET_INDEX;
			break;
			case RETRIEVE_QUEUE_NUM_ELEMENTS_OPER:
				int8_t_retrieve_data_ptr  = (int8_t *) queue_retrieve_info_ptr;
			    *int8_t_retrieve_data_ptr = 0;
			break; 
			case RETRIEVE_QUEUE_LIST_ELEMENTS_OPER:
				data_t_retrieve_data_ptr =  (data_t *)queue_retrieve_info_ptr;
				data_t_retrieve_data_ptr->associated_msg_data_ptr = NULL_PTR;
				data_t_retrieve_data_ptr->related_msg_type = DATA_NA;
				int8_t_retrieve_data_ptr = (int8_t *)queue_arr_index_or_num_items_ptr;
				*int8_t_retrieve_data_ptr = 0;
			break;	 
			default:
			   system_status_flag = ERR_FORMAT_INVALID;
	     	   Error_or_Warning_Proc("02.26.03", ERROR_OCCURED, system_status_flag);
		       return system_status_flag; 		 
		}
		 system_status_flag = ERR_QUEUE_EMPTY;
	     Error_or_Warning_Proc("02.26.04", ERROR_OCCURED, system_status_flag);
	     return system_status_flag;
    }	
	switch(queue_disp_info)
	{
		case RETRIEVE_QUEUE_FRONT_INDEX_OPER:
			//front_index
		   int8_t_retrieve_data_ptr  = (int8_t *) queue_retrieve_info_ptr;
		   *int8_t_retrieve_data_ptr = circular_queue_data_ptr->front_index; 
		break; 
		case RETRIEVE_QUEUE_REAR_INDEX_OPER:
		   //rear_index
		   int8_t_retrieve_data_ptr  = (int8_t *) queue_retrieve_info_ptr;
		   *int8_t_retrieve_data_ptr = circular_queue_data_ptr->rear_index;  
		 break;
		 case RETRIEVE_QUEUE_LIST_ELEMENTS_OPER:
           if(queue_arr_index_or_num_items_ptr == NULL_PTR)
		   {
			   system_status_flag = ERR_NULL_PTR;
		       Error_or_Warning_Proc("02.26.05", ERROR_OCCURED, system_status_flag);
		       return system_status_flag;
		   }
		  case RETRIEVE_QUEUE_NUM_ELEMENTS_OPER: //num_elements 		 	
		    data_t_retrieve_data_ptr =  (data_t *)queue_retrieve_info_ptr;
		    // at index 
		   front_pos = circular_queue_data_ptr->front_index;
	       rear_pos = circular_queue_data_ptr->rear_index;
	       printf("\n Queue elements from front: %u to rear: %u \n", front_pos, rear_pos);
           if(front_pos <= rear_pos )
	       {
	        	while(front_pos <= rear_pos)
	        	{
		         	//queue data is present at front_pos
		         	switch(queue_disp_info)
		         	{
		         		case RETRIEVE_QUEUE_LIST_ELEMENTS_OPER:
			             	if((ret_status = Display_Queue_Element_At_Index(circular_queue_data_ptr, &front_pos, (data_t_retrieve_data_ptr + num_elements))) != SUCCESS)
		         	        {
		         		        system_status_flag = ERR_QUEUE_RETRIEVE_INFO_PROC;
	                         	Error_or_Warning_Proc("02.26.06", ERROR_OCCURED, system_status_flag);
	                        	return system_status_flag;
				            }
						case RETRIEVE_QUEUE_NUM_ELEMENTS_OPER:
				  	       ++num_elements;	
				        break;
				    }
			       front_pos++;
		        }
	       }
        	else
        	{
	          	while(front_pos <= (circular_queue_data_ptr->max_num_elements - 1))
	        	{
		         	//queue data is present at front_pos 
		        	switch(queue_disp_info)
		         	{
		         		 case RETRIEVE_QUEUE_LIST_ELEMENTS_OPER:
			              	if((ret_status = Display_Queue_Element_At_Index(circular_queue_data_ptr, &front_pos, (data_t_retrieve_data_ptr + num_elements))) != SUCCESS)
		         	        {
		         		        system_status_flag = ERR_QUEUE_RETRIEVE_INFO_PROC;
	                         	Error_or_Warning_Proc("02.26.07", ERROR_OCCURED, system_status_flag);
	                        	return system_status_flag;
				            }
						case RETRIEVE_QUEUE_NUM_ELEMENTS_OPER:
				  	       ++num_elements;	
				        break;							
				    }
		        	front_pos++;
		        }
	         	front_pos = 0;
	         	while(front_pos <= rear_pos)
	        	{
		        	switch(queue_disp_info)
		         	{
		         		case RETRIEVE_QUEUE_LIST_ELEMENTS_OPER:
			             	if((ret_status = Display_Queue_Element_At_Index(circular_queue_data_ptr, &front_pos, (data_t_retrieve_data_ptr + num_elements))) != SUCCESS)
		         	        {
		         		        system_status_flag = ERR_QUEUE_RETRIEVE_INFO_PROC;
	                         	Error_or_Warning_Proc("02.26.08", ERROR_OCCURED, system_status_flag);
	                        	return system_status_flag;
				            }
				        case RETRIEVE_QUEUE_NUM_ELEMENTS_OPER:
				  	       ++num_elements;	
				        break; 
				    }
		        	front_pos++;
		       }
	        }
	        switch(queue_disp_info) 
		    {
				case RETRIEVE_QUEUE_NUM_ELEMENTS_OPER:
	        	  int8_t_retrieve_data_ptr  = (int8_t *) queue_retrieve_info_ptr;	        	 
                break;
                case RETRIEVE_QUEUE_LIST_ELEMENTS_OPER:
				    int8_t_retrieve_data_ptr = (int8_t *) queue_arr_index_or_num_items_ptr;
                break;   				
			}
			 *int8_t_retrieve_data_ptr = num_elements;
		 break; 
		 case RETRIEVE_QUEUE_ELEMENT_AT_INDEX_OPER:
		    //retrieve at specific queue array's index
		    if(queue_arr_index_or_num_items_ptr == NULL_PTR)
		    {
			   system_status_flag = ERR_NULL_PTR;
		       Error_or_Warning_Proc("02.26.09", ERROR_OCCURED, system_status_flag);
		       return system_status_flag;
		   }	
		   if((ret_status = Display_Queue_Element_At_Index(circular_queue_data_ptr, queue_arr_index_or_num_items_ptr, (data_t_retrieve_data_ptr + num_elements))) != SUCCESS)
		   {
		        system_status_flag = ERR_QUEUE_RETRIEVE_INFO_PROC;
	            Error_or_Warning_Proc("02.26.10", ERROR_OCCURED, system_status_flag);
	            return system_status_flag;
		   }
		 break;
		 default:
		    system_status_flag = ERR_FORMAT_INVALID;
	     	Error_or_Warning_Proc("02.26.11", ERROR_OCCURED, system_status_flag);
		    return system_status_flag;
			 
	}
	return SUCCESS;
}


/*------------------------------------------------------------*
FUNCTION NAME  : Insert_Data

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.27 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Insert_Data(const uint8_t insert_data_type)
{
	data_t insert_data_format;
	uint16_t ret_status;
    uint16_t insert_data;
    uint8_t msg_type;
	printf("\n Enter element's msg type: 1 or 2: Enter : ");
	scanf("%uh", &msg_type);
	if(msg_type > 2)
	{
		system_status_flag = ERR_FORMAT_INVALID;
	   	Error_or_Warning_Proc("02.27.01", ERROR_OCCURED, system_status_flag);
	   	return system_status_flag;
	}
    printf("\n Enter element's data to be insert : ");
    scanf("%uh", &insert_data);
	switch(msg_type)
	{
		case 1:
		   ret_status = Set_Next_Pos_Msg_Data_Arr(ENQUEUE_OPER, &associated_msg_1_datas.associated_data_arr_front_index, &associated_msg_1_datas.associated_data_arr_rear_index, MAX_ELEMENTS_MSG_1_ARR ); 
		   switch(ret_status)
		   {
		   	    case ERR_QUEUE_FULL:
		   	    	system_status_flag = ERR_QUEUE_FULL;
	             	Error_or_Warning_Proc("02.27.01", ERROR_OCCURED, system_status_flag);
	            	return system_status_flag;  		   	    
		   	   // break;
				case SUCCESS:
					associated_msg_1_datas.associated_data_arr[associated_msg_1_datas.associated_data_arr_rear_index].associated_msg_1_data = insert_data;
                    insert_data_format.associated_msg_data_ptr = &(associated_msg_1_datas.associated_data_arr[associated_msg_1_datas.associated_data_arr_rear_index]);
                    #ifdef TRACE
					   printf("\n TRA: msg type: %u inserted at rear: %d, msg_ptr: 0x%x", msg_type, associated_msg_1_datas.associated_data_arr_rear_index,  insert_data_format.associated_msg_data_ptr); 
                    #endif
				break;
				default:
				   	system_status_flag = ERR_FORMAT_INVALID;
	             	Error_or_Warning_Proc("02.27.01", ERROR_OCCURED, system_status_flag);
	            	return system_status_flag;  	
		   }		   		  
		break;
		case 2:	
		  ret_status = Set_Next_Pos_Msg_Data_Arr(ENQUEUE_OPER, &associated_msg_2_datas.associated_data_arr_front_index, &associated_msg_2_datas.associated_data_arr_rear_index, MAX_ELEMENTS_MSG_2_ARR ); 
		  switch(ret_status)
		  {
		  	  case ERR_QUEUE_FULL:
		  	  	   system_status_flag = ERR_QUEUE_FULL;
	               Error_or_Warning_Proc("02.27.01", ERROR_OCCURED, system_status_flag);
	               return system_status_flag;  		   	    
		   	   // break;
		   	  case SUCCESS:
		   	  	associated_msg_2_datas.associated_data_arr[associated_msg_2_datas.associated_data_arr_rear_index].related_msg_2_sub_msg_type = 1;
		        switch(associated_msg_2_datas.associated_data_arr[associated_msg_2_datas.associated_data_arr_rear_index].related_msg_2_sub_msg_type)
		        {
		     	   case 1:
			     	 ret_status = Set_Next_Pos_Msg_Data_Arr(ENQUEUE_OPER, &associated_msg_2_sub_msg_1_datas.associated_data_arr_front_index, &associated_msg_2_sub_msg_1_datas.associated_data_arr_rear_index, MAX_ELEMENTS_MSG_2_SUB_MSG_1_ARR );
					 switch(ret_status)
					 {
					 	 case ERR_QUEUE_FULL:
					 	     system_status_flag = ERR_QUEUE_FULL;
	                         Error_or_Warning_Proc("02.27.01", ERROR_OCCURED, system_status_flag);
	                         return system_status_flag;  		   	    
		   	             // break;
						 case SUCCESS:
						     associated_msg_2_sub_msg_1_datas.associated_data_arr[associated_msg_2_sub_msg_1_datas.associated_data_arr_rear_index].associated_msg_2_sub_msg_1_data = insert_data;
		                     associated_msg_2_datas.associated_data_arr[associated_msg_2_datas.associated_data_arr_rear_index].associated_msg_2_data_ptr = &associated_msg_2_sub_msg_1_datas.associated_data_arr[associated_msg_2_sub_msg_1_datas.associated_data_arr_rear_index];
		                     insert_data_format.associated_msg_data_ptr = &associated_msg_2_datas.associated_data_arr[associated_msg_2_datas.associated_data_arr_rear_index];
							  #ifdef TRACE
					             printf("\n TRA: inserted msg type: %u, rear: %d, msg2_ptr: 0x%x", msg_type, associated_msg_2_datas.associated_data_arr_rear_index, associated_msg_2_datas.associated_data_arr[associated_msg_2_datas.associated_data_arr_rear_index].associated_msg_2_data_ptr);
								 printf("\n TRA: sub_msg: %u, rear: %d, msg_ptr: 0x%x", associated_msg_2_datas.associated_data_arr[associated_msg_2_datas.associated_data_arr_rear_index].related_msg_2_sub_msg_type, associated_msg_2_sub_msg_1_datas.associated_data_arr_rear_index, insert_data_format.associated_msg_data_ptr);   
                              #endif			    	      	        
						 break;	
						 default:
				   	        system_status_flag = ERR_FORMAT_INVALID;
	                    	Error_or_Warning_Proc("02.27.01", ERROR_OCCURED, system_status_flag);
	                    	return system_status_flag; 
					 } 
			      break;
			      default:
			         system_status_flag = ERR_FORMAT_INVALID;
	   	             Error_or_Warning_Proc("02.27.02", ERROR_OCCURED, system_status_flag);
	                 return system_status_flag;
		        }
		      break;
			  default:
				 system_status_flag = ERR_FORMAT_INVALID;
	             Error_or_Warning_Proc("02.27.01", ERROR_OCCURED, system_status_flag);
	             return system_status_flag;  
		  }
		break;
		default:
		   system_status_flag = ERR_FORMAT_INVALID;
	       Error_or_Warning_Proc("02.27.03", ERROR_OCCURED, system_status_flag);
	       return system_status_flag;
	}
	insert_data_format.related_msg_type = msg_type;    
	switch(insert_data_type)
	{
		case ENQUEUE_OPER:
				if((ret_status = EnQueue_Proc(&comm_transmit_queue, &insert_data_format)) != SUCCESS)
		        {
		   	        system_status_flag = ERR_ENQUEUE_PROC;
	            	Error_or_Warning_Proc("02.27.04", ERROR_OCCURED, system_status_flag);
	            	return system_status_flag;
                }	 
		break;
		case SEND_TO_FRONT_OF_QUEUE_OPER:
			  	if((ret_status = Queue_Insert_At_Front(&comm_transmit_queue, &insert_data_format)) != SUCCESS)
		        {
		   	        system_status_flag = ERR_QUEUE_INSERT_FRONT_PROC;
	            	Error_or_Warning_Proc("02.27.05", ERROR_OCCURED, system_status_flag);
	            	return system_status_flag;
                }	 
		break;
		default:
		  	 system_status_flag = ERR_FORMAT_INVALID;
	         Error_or_Warning_Proc("02.27.06", ERROR_OCCURED, system_status_flag);
	         return system_status_flag;
	}
    #ifdef TRACE
       printf("\n inserted msg_type: %u, data: %u", insert_data_format.related_msg_type, insert_data);     
    #endif	
     
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Set_Next_Pos_Msg_Data_Arr

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.28 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Set_Next_Pos_Msg_Data_Arr(const uint8_t oper_type, int8_t *const associated_msg_data_arr_front_index_ptr, int8_t *const associated_msg_data_arr_rear_index_ptr, const uint8_t max_elements_msg_arr)
{
	if(associated_msg_data_arr_front_index_ptr == NULL_PTR || associated_msg_data_arr_rear_index_ptr == NULL_PTR)
	{
		system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.28.01", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	if(max_elements_msg_arr > MAX_ELEMENTS_CIRC_QUEUE_ARR)
	{
		 system_status_flag = ERR_FORMAT_INVALID;
	     Error_or_Warning_Proc("02.28.02", ERROR_OCCURED, system_status_flag);
	     return system_status_flag;
	}
	
	switch(oper_type)
	{
		case ENQUEUE_OPER:
		   if((*associated_msg_data_arr_front_index_ptr == 0 && *associated_msg_data_arr_rear_index_ptr == (max_elements_msg_arr - 1)) || (*associated_msg_data_arr_front_index_ptr == (*associated_msg_data_arr_rear_index_ptr + 1)))
	       {
		       system_status_flag = ERR_QUEUE_FULL;
		       Error_or_Warning_Proc("02.28.03", ERROR_OCCURED, system_status_flag);
		       return system_status_flag;
	       } 
		   if(*associated_msg_data_arr_front_index_ptr == CIRCULAR_QUEUE_RESET_INDEX)  
	       {
	        	/* queue was empty */
		      *associated_msg_data_arr_front_index_ptr = 0;
		      *associated_msg_data_arr_rear_index_ptr = 0;
	       }
	       else
	       {
		       if(*associated_msg_data_arr_rear_index_ptr == (max_elements_msg_arr - 1))
		       {
			       //rear is at last position of queue			
			        *associated_msg_data_arr_rear_index_ptr = 0;
		       }
		       else
		       {
			       ++*associated_msg_data_arr_rear_index_ptr;
		       }
	       }
		break;
        case DEQUEUE_OPER:
		   if(*associated_msg_data_arr_front_index_ptr == CIRCULAR_QUEUE_RESET_INDEX)
		   {
			   system_status_flag = ERR_QUEUE_EMPTY;
	           Error_or_Warning_Proc("02.28.04", ERROR_OCCURED, system_status_flag);
	           return system_status_flag;
		   }
		   if(*associated_msg_data_arr_front_index_ptr == *associated_msg_data_arr_rear_index_ptr) 
	       {
	        	/* queue had only one element */
	    	    *associated_msg_data_arr_front_index_ptr = CIRCULAR_QUEUE_RESET_INDEX;
		        *associated_msg_data_arr_rear_index_ptr = CIRCULAR_QUEUE_RESET_INDEX;
	       }
	       else
	       {	
	        	if(*associated_msg_data_arr_front_index_ptr == (max_elements_msg_arr - 1))
	        	{
		        	*associated_msg_data_arr_front_index_ptr = 0;
		        }
		        else
		        {
		        	++*associated_msg_data_arr_front_index_ptr;
		        }
	       }
        break;
        default:
           system_status_flag = ERR_FORMAT_INVALID;
	       Error_or_Warning_Proc("02.28.05", ERROR_OCCURED, system_status_flag);
	      return system_status_flag;	
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Retrieve_Data

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.29 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Retrieve_Data(const uint8_t delete_data_type, data_t *const retrieve_data_ptr)
{
	data_t retrieve_data_format, *common_retrieve_data_ptr;
	uint16_t ret_status;
    uint8_t retrieved_data;
    
    switch(delete_data_type)
	{
		case DEQUEUE_OPER:
			common_retrieve_data_ptr = &retrieve_data_format;
			if((ret_status = DeQueue_Proc(&comm_transmit_queue, common_retrieve_data_ptr)) != SUCCESS)
		    {
		   	        system_status_flag = ERR_ENQUEUE_PROC;
	            	Error_or_Warning_Proc("02.29.01", ERROR_OCCURED, system_status_flag);
	            	return system_status_flag;
            }	 
		break;
		case RECEIVE_TO_REAR_OF_QUEUE_OPER:
			common_retrieve_data_ptr = &retrieve_data_format; 
			if((ret_status = Queue_Delete_At_Rear(&comm_transmit_queue, common_retrieve_data_ptr)) != SUCCESS)
		     {
		   	        system_status_flag = ERR_QUEUE_INSERT_FRONT_PROC;
	            	Error_or_Warning_Proc("02.29.02", ERROR_OCCURED, system_status_flag);
	            	return system_status_flag;
             }	 
		break;
		case RETRIEVE_QUEUE_ELEMENT_AT_INDEX_OPER:
			//disp queue element 
			common_retrieve_data_ptr = retrieve_data_ptr;
		break;
		default:
		  	 system_status_flag = ERR_FORMAT_INVALID;
	         Error_or_Warning_Proc("02.29.03", ERROR_OCCURED, system_status_flag);
	         return system_status_flag;
	}    
    if((ret_status = Disp_Retrieved_Data(delete_data_type, common_retrieve_data_ptr)) != SUCCESS)
	{
		system_status_flag = ERR_QUEUE_RETRIEVE_INFO_PROC;
	    Error_or_Warning_Proc("02.29.04", ERROR_OCCURED, system_status_flag);
	    return system_status_flag;
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Queue_Disp_Info

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.31

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Queue_Disp_Info()
{
	const data_t *queue_start_item_ptr;
	void *queue_arr_index_or_num_elements_ptr;
	uint16_t ret_status;
	int8_t int8_t_queue_retrieve_data, queue_arr_index_or_num_elements, cur_num_elements = 0;
	int ch;
	data_t retrieved_queue_item_arr[MAX_ELEMENTS_CIRC_QUEUE_ARR];
	printf("\n Queue Disp: 1 - front, 2 - rear, 3 - num_items, 4 - items");
	printf("\n enter disp choice : ");
	scanf("%d", &ch);
	switch(ch)
	{
		case RETRIEVE_QUEUE_FRONT_INDEX_OPER:
		case RETRIEVE_QUEUE_REAR_INDEX_OPER:
		case RETRIEVE_QUEUE_NUM_ELEMENTS_OPER:
			if((ret_status = Get_Queue_Info(&comm_transmit_queue, ch, NULL_PTR, &int8_t_queue_retrieve_data)) != SUCCESS)
			{
				system_status_flag = ERR_DISP_QUEUE_PROC;
		        Error_or_Warning_Proc("02.31.01", ERROR_OCCURED, system_status_flag);
		        return system_status_flag;	
			}
			switch(ch)
			{
				case RETRIEVE_QUEUE_FRONT_INDEX_OPER:
					printf("\n Queue front : %u ", int8_t_queue_retrieve_data);
				break;
				case RETRIEVE_QUEUE_REAR_INDEX_OPER:
					 printf("\n Queue rear : %u ", int8_t_queue_retrieve_data);
				break;
				case RETRIEVE_QUEUE_NUM_ELEMENTS_OPER:
					 printf("\n queue num elements : %u", int8_t_queue_retrieve_data);
				break; 
			}
		break;
		case RETRIEVE_QUEUE_LIST_ELEMENTS_OPER:
		    queue_arr_index_or_num_elements_ptr = &queue_arr_index_or_num_elements;
	    	if((ret_status = Get_Queue_Info(&comm_transmit_queue, ch, queue_arr_index_or_num_elements_ptr, retrieved_queue_item_arr)) != SUCCESS)
			{
				system_status_flag = ERR_DISP_QUEUE_PROC;
		        Error_or_Warning_Proc("02.31.02", ERROR_OCCURED, system_status_flag);
		        return system_status_flag;	
			}
			if(queue_arr_index_or_num_elements == 0)
			{
				system_status_flag = ERR_DISP_QUEUE_PROC;
		        Error_or_Warning_Proc("02.31.03", ERROR_OCCURED, system_status_flag);
		        return system_status_flag;
			}
			#ifdef TRACE
			  printf("\n queue num elements : %u", queue_arr_index_or_num_elements);
			#endif
            for(cur_num_elements = 0; cur_num_elements < queue_arr_index_or_num_elements; ++cur_num_elements )
			{
				if((ret_status = Disp_Retrieved_Data(DISP_QUEUE_LIST_ELEMENTS_OPER, retrieved_queue_item_arr + cur_num_elements)) != SUCCESS)
				{
					system_status_flag = ERR_DISP_QUEUE_PROC;
		            Error_or_Warning_Proc("02.31.04", ERROR_OCCURED, system_status_flag);
		            return system_status_flag;
				}
			}				
		break;
		default:
		  system_status_flag = ERR_FORMAT_INVALID;
		  Error_or_Warning_Proc("02.31.05", ERROR_OCCURED, system_status_flag);
		  return system_status_flag;		
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Display_Queue_Element_At_Index

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.32 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Display_Queue_Element_At_Index(circular_queue_data_t *const circular_queue_data_ptr, const void *const queue_index_ptr, data_t *const queue_disp_data_ptr)
{
	int8_t *int8_queue_index_ptr;
	
	if(circular_queue_data_ptr == NULL_PTR)
	{
		system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.32.01", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	if(queue_index_ptr == NULL_PTR)
	{
		system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.32.02", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	if(queue_disp_data_ptr == NULL_PTR)
	{
		system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.32.03", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}	
	int8_queue_index_ptr = (int8_t *)(queue_index_ptr);
	if(*int8_queue_index_ptr >= circular_queue_data_ptr->max_num_elements)
	{
		system_status_flag = ERR_FORMAT_INVALID;
		Error_or_Warning_Proc("02.32.04", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	memcpy(queue_disp_data_ptr, &circular_queue_data_ptr->data_arr[*int8_queue_index_ptr], sizeof(data_t));
	#ifdef TRACE
	  printf("\n TRA: retrieve queue index: %d, msg_type: %u, msg_ptr: 0x%x", *int8_queue_index_ptr, queue_disp_data_ptr->related_msg_type, queue_disp_data_ptr->associated_msg_data_ptr);
	#endif
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Associate_Msg_1

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.33 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Reset_Associate_Msg_1(associated_msg_1_ctrl_arr_t *const associated_msg_1_data_ptr)
{
	if(associated_msg_1_data_ptr == NULL_PTR)
	{
	    system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.33.01", ERROR_OCCURED, system_status_flag);
		return system_status_flag;	
	}
	memset(associated_msg_1_data_ptr->associated_data_arr, '\0', sizeof(associated_msg_1_data_ptr->associated_data_arr));
	associated_msg_1_data_ptr->associated_data_arr_front_index = CIRCULAR_QUEUE_RESET_INDEX;
	associated_msg_1_data_ptr->associated_data_arr_rear_index = CIRCULAR_QUEUE_RESET_INDEX;
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Associate_Msg_2_Sub_Msg_1

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.34 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Reset_Associate_Msg_2_Sub_Msg_1(associated_msg_2_sub_msg_1_ctrl_arr_t *const associated_msg_2_sub_msg_1_data_ptr)
{
	if(associated_msg_2_sub_msg_1_data_ptr == NULL_PTR)
	{
	    system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.34.01", ERROR_OCCURED, system_status_flag);
		return system_status_flag;	
	}
	memset(associated_msg_2_sub_msg_1_data_ptr->associated_data_arr, '\0', sizeof(associated_msg_2_sub_msg_1_data_ptr->associated_data_arr));
	associated_msg_2_sub_msg_1_data_ptr->associated_data_arr_front_index = CIRCULAR_QUEUE_RESET_INDEX;
	associated_msg_2_sub_msg_1_data_ptr->associated_data_arr_rear_index = CIRCULAR_QUEUE_RESET_INDEX;
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Associate_Msg_2

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.35 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Reset_Associate_Msg_2(associated_msg_2_ctrl_arr_t *const associated_msg_2_data_ptr)
{
	if(associated_msg_2_data_ptr == NULL_PTR)
	{
	    system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.35.01", ERROR_OCCURED, system_status_flag);
		return system_status_flag;	
	}
	memset(associated_msg_2_data_ptr->associated_data_arr, '\0', sizeof(associated_msg_2_data_ptr->associated_data_arr));
	associated_msg_2_data_ptr->associated_data_arr_front_index = CIRCULAR_QUEUE_RESET_INDEX;
	associated_msg_2_data_ptr->associated_data_arr_rear_index = CIRCULAR_QUEUE_RESET_INDEX;
	Reset_Associate_Msg_2_Sub_Msg_1(&associated_msg_2_sub_msg_1_datas); 
    return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Process

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.30 

Bugs           :  
-*------------------------------------------------------------*/
void Reset_Process()
{
   Reset_Circular_Queue(&comm_transmit_queue);
   Reset_Associate_Msg_1(&associated_msg_1_datas);
   Reset_Associate_Msg_2(&associated_msg_2_datas);   
}

/*------------------------------------------------------------*
FUNCTION NAME  : Disp_Retrieved_Data

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.36 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Disp_Retrieved_Data(const uint8_t oper_type, const data_t *const queue_retrieve_data_ptr)
{
	associated_msg_2_t *retrieve_associated_msg_2_data_ptr;
	associated_msg_2_sub_msg_1_t *associated_msg_2_sub_msg_1_data_ptr;
	associated_msg_1_t *associated_msg_1_data_ptr;
	
	if(queue_retrieve_data_ptr == NULL_PTR)
	{
		system_status_flag = ERR_NULL_PTR;
		Error_or_Warning_Proc("02.36.01", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
    if(oper_type != DEQUEUE_OPER && oper_type != RECEIVE_TO_REAR_OF_QUEUE_OPER && oper_type != DISP_QUEUE_LIST_ELEMENTS_OPER && oper_type != RETRIEVE_QUEUE_ELEMENT_AT_INDEX_OPER )	
	{
		system_status_flag = ERR_FORMAT_INVALID;
		Error_or_Warning_Proc("02.36.02", ERROR_OCCURED, system_status_flag);
		return system_status_flag;
	}
	switch(queue_retrieve_data_ptr->related_msg_type)
	{
		case 1:		  
		  associated_msg_1_data_ptr = (associated_msg_1_t *)queue_retrieve_data_ptr->associated_msg_data_ptr;		  		 
          switch(oper_type) 
		  {
			  case DEQUEUE_OPER:
			  case RECEIVE_TO_REAR_OF_QUEUE_OPER:
			  	if(associated_msg_1_datas.associated_data_arr_front_index == CIRCULAR_QUEUE_RESET_INDEX)
		        {
		  	       system_status_flag = ERR_QUEUE_EMPTY;
	               Error_or_Warning_Proc("02.36.03", ERROR_OCCURED, system_status_flag);
	               return system_status_flag;
		        } 
			  	memcpy(&associated_msg_1_datas.associated_data_arr[associated_msg_1_datas.associated_data_arr_front_index], associated_msg_1_data_ptr, sizeof(associated_msg_1_t));
			    #ifdef TRACE
		          printf("\n retrieved msg_type: %u, data: %u ", queue_retrieve_data_ptr->related_msg_type, associated_msg_1_datas.associated_data_arr[associated_msg_1_datas.associated_data_arr_front_index].associated_msg_1_data);
		     	  printf("\n TRA: retrieved msg front: %d, msg_ptr : 0x%x", associated_msg_1_datas.associated_data_arr_front_index, queue_retrieve_data_ptr->associated_msg_data_ptr);
                #endif
		        Set_Next_Pos_Msg_Data_Arr(DEQUEUE_OPER, &associated_msg_1_datas.associated_data_arr_front_index, &associated_msg_1_datas.associated_data_arr_rear_index, MAX_ELEMENTS_MSG_1_ARR);
			  break;
			  case DISP_QUEUE_LIST_ELEMENTS_OPER:
			  case RETRIEVE_QUEUE_ELEMENT_AT_INDEX_OPER:	
			  	 #ifdef TRACE
		          printf("\n retrieved msg_type: %u, data: %u, msg_ptr = 0x%x ", queue_retrieve_data_ptr->related_msg_type, associated_msg_1_data_ptr->associated_msg_1_data, associated_msg_1_data_ptr);		     	 
                 #endif
			  break;	
		  }
        break;
		case 2:
		  retrieve_associated_msg_2_data_ptr = (associated_msg_2_t *)queue_retrieve_data_ptr->associated_msg_data_ptr;
		  #ifdef TRACE
		     printf("\n TRA: retrieve msg 2, msg_ptr : 0x%x", retrieve_associated_msg_2_data_ptr);
		  #endif
		  switch(retrieve_associated_msg_2_data_ptr->related_msg_2_sub_msg_type)
		  {
			  case 1:			  	 
			     associated_msg_2_sub_msg_1_data_ptr = (associated_msg_2_sub_msg_1_t *)retrieve_associated_msg_2_data_ptr->associated_msg_2_data_ptr;                 
				 switch(oper_type) 
				 {
				 	 case DEQUEUE_OPER:
				 	 case RECEIVE_TO_REAR_OF_QUEUE_OPER:
					  	if(associated_msg_2_sub_msg_1_datas.associated_data_arr_front_index == CIRCULAR_QUEUE_RESET_INDEX)
		                {
		     	            system_status_flag = ERR_QUEUE_EMPTY;
	                        Error_or_Warning_Proc("02.36.05", ERROR_OCCURED, system_status_flag);
	                        return system_status_flag;
		                }
						memcpy(&associated_msg_2_sub_msg_1_datas.associated_data_arr[associated_msg_2_sub_msg_1_datas.associated_data_arr_front_index], associated_msg_2_sub_msg_1_data_ptr, sizeof(associated_msg_2_sub_msg_1_t));				 
			        	 #ifdef TRACE
                            printf("\n retrieve related msg type: %u, sub msg type : %u, data: %u", queue_retrieve_data_ptr->related_msg_type, retrieve_associated_msg_2_data_ptr->related_msg_2_sub_msg_type, \ 
					           associated_msg_2_sub_msg_1_datas.associated_data_arr[associated_msg_2_sub_msg_1_datas.associated_data_arr_front_index].associated_msg_2_sub_msg_1_data);
				            printf("\n TRA: retrieved msg 2 front: %d, msg2_ptr: 0x%x, sub msg_front: %d", associated_msg_2_datas.associated_data_arr_front_index, associated_msg_2_sub_msg_1_data_ptr, associated_msg_2_sub_msg_1_datas.associated_data_arr_front_index );
                         #endif	
				         Set_Next_Pos_Msg_Data_Arr(DEQUEUE_OPER, &associated_msg_2_sub_msg_1_datas.associated_data_arr_front_index, &associated_msg_2_sub_msg_1_datas.associated_data_arr_rear_index, MAX_ELEMENTS_MSG_2_SUB_MSG_1_ARR); 
				     break;
					 case DISP_QUEUE_LIST_ELEMENTS_OPER:
					 case RETRIEVE_QUEUE_ELEMENT_AT_INDEX_OPER:	
					 	 printf("\n retrieve related msg type: %u, sub msg type : %u, data: %u", queue_retrieve_data_ptr->related_msg_type, retrieve_associated_msg_2_data_ptr->related_msg_2_sub_msg_type, \ 
					         associated_msg_2_sub_msg_1_data_ptr->associated_msg_2_sub_msg_1_data);
				         printf("\n TRA: retrieved msg2_ptr: 0x%x", associated_msg_2_sub_msg_1_data_ptr);
					 break;   
				 }					 
			  break;
			  default:
			    system_status_flag = ERR_FORMAT_INVALID;
		        Error_or_Warning_Proc("02.36.06", ERROR_OCCURED, system_status_flag);
		        return system_status_flag;
		  }
		  switch(oper_type) 
		  {
		  	 case DEQUEUE_OPER:
		  	 case RECEIVE_TO_REAR_OF_QUEUE_OPER:	
		      	 if(associated_msg_2_datas.associated_data_arr_front_index == CIRCULAR_QUEUE_RESET_INDEX)
		         {
		  	        system_status_flag = ERR_QUEUE_EMPTY;
	                Error_or_Warning_Proc("02.36.04", ERROR_OCCURED, system_status_flag);
	                return system_status_flag;
		         }	
		         Set_Next_Pos_Msg_Data_Arr(DEQUEUE_OPER, &associated_msg_2_datas.associated_data_arr_front_index, &associated_msg_2_datas.associated_data_arr_rear_index, MAX_ELEMENTS_MSG_2_ARR);
		     break;    
		  }
		break;
		default:
		  system_status_flag = ERR_FORMAT_INVALID;
		  Error_or_Warning_Proc("02.36.07", ERROR_OCCURED, system_status_flag);
		  return system_status_flag;
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.37

Bugs           :  
-*------------------------------------------------------------*/
int main()
{
	data_t retrieve_data;
	uint16_t ret_status;
    int ch; 
    
  	Reset_Process();
  	
    printf("\nCircular Queue operations\n");    
    while(1)
    {
    	printf("\n 1 - ins_rear, 2 - del_front, 3 - disp, 4 - ins_front, 5 - del_rear, 6 - reset, 7 - exit\n");
        printf("Enter your choice : ");
        scanf("%d",&ch);
        switch(ch)
        {
        case ENQUEUE_OPER: 
            if((ret_status = Insert_Data(ENQUEUE_OPER)) != SUCCESS)
			{
		        	
		    }		   
        break;
        case DEQUEUE_OPER: 
		   if((ret_status = Retrieve_Data(DEQUEUE_OPER, &retrieve_data)) != SUCCESS)
		   {
		   	       	
		   }
        break;
        case RETRIEVE_QUEUE_OPER:
           if((ret_status = Queue_Disp_Info()) != SUCCESS)
		   {
		   	       
		   }	
		break;		
		case SEND_TO_FRONT_OF_QUEUE_OPER:
		   if((ret_status = Insert_Data(SEND_TO_FRONT_OF_QUEUE_OPER)) != SUCCESS)
		   {
		   	   
           }
        break;
        case RECEIVE_TO_REAR_OF_QUEUE_OPER: 
		   if((ret_status = Retrieve_Data(RECEIVE_TO_REAR_OF_QUEUE_OPER, &retrieve_data)) != SUCCESS)
		   {
		   	   
		   }
        break;
        case RESET_QUEUE_OPER:
        	Reset_Process();       
        break;
        case EXIT_OPER:
		  return SUCCESS;
	//	break;
        default:
		    printf("\n Invalid option");
        }
    }
    return 0;
}


#else  
	

 // CIRCULAR_QUEUE_SIMPLE

 int front = -1, rear = -1, cqueue_arr[MAX_ELEMENTS_CIRC_QUEUE_ARR]; 
 // Begin of insert: enqueue 
unsigned int insert_rear()
{
	int insert_data;
	
	if((front == 0 && rear == (MAX_ELEMENTS_CIRC_QUEUE_ARR - 1)) || (front == (rear + 1)))
	{
		printf("Queue Overflow \n");
		return ERR_QUEUE_FULL;
	}
	printf("Enter element to be insert:");
    scanf("%d", &insert_data);
	if (front == -1)  /*If queue is empty */
	{
		front = 0;
		rear = 0;
	}
	else
	{
		if(rear == (MAX_ELEMENTS_CIRC_QUEUE_ARR - 1))	/*rear is at last position of queue */
			rear = 0;
		else
			++rear;
	}
	cqueue_arr[rear] = insert_data ;
	printf("Element inserted into queue : %d at rear: %d\n",cqueue_arr[rear], rear);
	return SUCCESS;
}
/*End of insert*/

/*Begin of del*/
unsigned int delete_front()
{
	int deleted_data;
	
	if (front == -1)
	{
		printf("Queue Underflow\n");
		 return ERR_QUEUE_EMPTY;
	}
	deleted_data = cqueue_arr[front];
	printf("Element deleted from queue : %d at front: %d\n", deleted_data, front);
	if(front == rear) /* queue has only one element */
	{
		front = -1;
		rear = -1;
	}
	else
	{	
		if(front == (MAX_ELEMENTS_CIRC_QUEUE_ARR - 1))
			front = 0;
		else
			++front;
	}
	return SUCCESS;
}
/*End of del() */

/*Begin of display*/
unsigned int display()
{
	int front_pos = front, rear_pos = rear, num_elements = 0;
	
	if(front == -1)
	{
		printf("Queue is empty\n");
	    return ERR_QUEUE_EMPTY;
	}
	printf("Queue elements from front to rear:\n");
	if( front_pos <= rear_pos )
	{
		while(front_pos <= rear_pos)
		{
			printf(" %d : %d ,", front_pos, cqueue_arr[front_pos]);
			++num_elements;
			front_pos++;
		}
	}
	else
	{
		while(front_pos <= (MAX_ELEMENTS_CIRC_QUEUE_ARR - 1))
		{
			printf(" %d : %d ,",front_pos, cqueue_arr[front_pos]);
	    	++num_elements;	
			front_pos++;
		}
		front_pos = 0;
		while(front_pos <= rear_pos)
		{
			printf(" %d : %d ,", front_pos, cqueue_arr[front_pos]);
			++num_elements;
			front_pos++;
		}
	}
	printf("\n");
	printf("num of elements : %d \n", num_elements);
	printf("element: %d at rear: %d \n", cqueue_arr[rear], rear);
	printf("element: %d at front: %d \n", cqueue_arr[front], front);	
	return SUCCESS;
}
 
unsigned int insert_front()
{
	int insert_data;
	
	if((front == 0 && rear == (MAX_ELEMENTS_CIRC_QUEUE_ARR - 1))|| (front == (rear + 1)))
	{
		printf("Queue Overflow \n");
		return ERR_QUEUE_FULL;
	}
  	printf("Enter element to be insert:");
    scanf("%d", &insert_data);
    if (front == -1)  /*If queue is empty */
	{
		front = 0;
		rear = 0;
	}
	else
	{
	   if(front == 0)
       {
           front = (MAX_ELEMENTS_CIRC_QUEUE_ARR - 1);
       }
	   else
	   {
	      --front;
	   }
    }
	cqueue_arr[front] = insert_data ;
	printf("Element inserted into queue : %d at front: %d\n",cqueue_arr[front], front);
	return SUCCESS;
}

unsigned int delete_rear()
{
	int deleted_data;
	
	if(front == -1)
	{
		printf("Queue is empty\n");
	    return ERR_QUEUE_EMPTY;
	}
	deleted_data = cqueue_arr[rear];
	printf("Element deleted from queue : %d at rear: %d\n", deleted_data, rear);
	if(front == rear) /* queue has only one element */
	{
		front = -1;
		rear = -1;
	}
	else
	{
	   if(rear == 0)
       {
           rear = (MAX_ELEMENTS_CIRC_QUEUE_ARR - 1);
       }
	   else
	   {
	      --rear;
	   }
	}
	return SUCCESS;
}


int main()
{
	unsigned int ret_status;
    int ch; 
  
    printf("\nCircular Queue operations\n");    
    while(1)
    {
    	printf("1 - ins_rear, 2 - del_front, 3 - disp, 4 - ins_front, 5 - del_rear, 6 - exit\n");
        printf("Enter your choice:");
        scanf("%d",&ch);
        switch(ch)
        {
        case 1: 
		   if((ret_status = insert_rear()) != SUCCESS)
		   {
		   	   
           }
        break;
        case 2: 
		   if((ret_status = delete_front()) != SUCCESS)
		   {
		   	  
		   }
        break;
        case 3:
           if((ret_status = display()) != SUCCESS)
		   {
		   	  
		   }	
		break;		
		case 4:
		   if((ret_status = insert_front()) != SUCCESS)
		   {
		   	   
           }
        break;
        case 5: 
		   if((ret_status = delete_rear()) != SUCCESS)
		   {
		   	  
		   }
        break;
        case 6:
		  return SUCCESS;
	//	break;
        default:
		printf("Invalid option\n");
        }
    }
    return 0;
}

#endif

