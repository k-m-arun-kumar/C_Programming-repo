/* ********************************************************************
FILE                   : dll_oper.c

PROGRAM DESCRIPTION    : ordered double linked list with operations of
                         insert, delete, display and search operations of nodes in
                         double linked list. 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
/* INSERT   */ 
#define INSERT       (1) 
/* TRAVERSE */
#define DISP         (2) 
/* SEARCH   */
#define SEARCH       (3) 
/* DELETE   */
#define DEL          (4) 
/* QUIT     */
#define QUIT         (5) 

#define FORWARD      (6)
#define BACKWARD     (7)
 
typedef struct NODE
 {
                     struct NODE *fwd;
                     struct NODE *bwd;
                     int value;
        } Node;
 
/* function declarations */
void traverse_fwd (Node *);
void traverse_bwd (Node *);
void insert_fwd ( Node *, const int);
void insert_bwd ( Node *, const int);
Node *search_fwd (Node *, const int);
Node *search_bwd (Node *, const int);
void delete_fwd (Node *, const int);
void delete_bwd ( Node *, const int);
void delete_all (Node *);

int main(void)
{
    Node root;     /* root is a Node, not a pointer to Node */
    int op = 0;
    int value = 0;
    int fbchoice = 0; /* FORWARD BACKWARD Choice */
 
    /* fwd and bwd fields of root set to NULL, fwd of root node is root for forward direction and bwd of root node is root for backward direction */
    root.fwd = 0;
    root.bwd = 0;
    root.value = 0; /* num of nodes in dll for root node */
    
    printf("\n**Program Shows different operations on Doubly Linked "
           "List.**\n");
   printf("\n User, enter 1 - INSERT, 2 - DISP, 3 - SEARCH, 4 - DEL, 5 - QUIT: "); 
    while (1)
	 {
        while (scanf("%d", &op) == 1) 
		        {
                if (op == DISP )
				{
                    printf("Whether in Forward or Backward Direction,\n");
                    printf("User, enter 6 - FORWARD, 7 - BACKWARD: ");
                    scanf("%d", &fbchoice);
 
                    if (fbchoice == FORWARD)
                       traverse_fwd(&root);
                    else if (fbchoice == BACKWARD)
                        traverse_bwd(&root);
                    else
                       	printf("Incorrect direction entered \n");
					 
                }
 
                else if (op == INSERT)
				 {
				    printf("Whether in Forward or Backward Direction,\n");
                    printf("User, enter 6 - FORWARD, 7 - BACKWARD: ");
                    scanf("%d", &fbchoice);	
                   
                   if(fbchoice == FORWARD)
                   {
                     	 printf("User, enter integer value you want to insert: ");
                         scanf("%d", &value);				   
                         insert_fwd(&root, value);
                    }
                    else if (fbchoice == BACKWARD)
                    {
                    	 printf("User, enter integer value you want to insert: ");
                         scanf("%d", &value);	
					    insert_bwd(&root, value);
					}
                     else
                     {
                     	printf("Incorrect direction entered \n");
					 }    
                    
                }
 
                else if (op == SEARCH)
				 {
				    printf("Whether in Forward or Backward Direction,\n");
                    printf("User, enter 6 - FORWARD, 7 - BACKWARD: ");
                    scanf("%d", &fbchoice);	
                    
                    if (fbchoice == FORWARD)
                    {
                    	printf("User, enter an integer value to "
                            "search in the list...: ");
                         scanf("%d", &value);
				        search_fwd(&root, value);
				    }
                    else if (fbchoice == BACKWARD)
                    {
                        printf("User, enter an integer value to "
                            "search in the list...: ");
                        scanf("%d", &value);	
					   search_bwd(&root, value);  
			     	}
				    else                 
                     {
                     	printf("Incorrect direction entered \n");
					 }
                }
 
                else if (op == DEL)
				 {
				 	printf("Whether in Forward or Backward Direction,\n");
                    printf("User, enter 6 - FORWARD, 7 - BACKWARD: ");
                    scanf("%d", &fbchoice);	
                   
                    if (fbchoice == FORWARD)
                    {
                    	 printf("User, enter a value you wish to delete: ");
                         scanf("%d", &value);
				         delete_fwd(&root, value);
				     }
                    else if (fbchoice == BACKWARD)
                    {
                        printf("User, enter a value you wish to delete: ");
                        scanf("%d", &value);	
				       delete_bwd(&root, value);
				    }
					else
                     {
                     	printf("Incorrect direction entered \n");
					 }	  
                }
                else if (op == QUIT)
				{
					delete_all(&root);
                    printf("\n Thank You!\n");
                    return 0;
                }
                else
                {
                	printf("Incorrect menu entered \n");
				}
                printf("\n User, enter 1 - INSERT, 2 - DISP, 3 - SEARCH, 4 - DEL, 5 - QUIT: ");
        }
   }
}
 
void insert_fwd(register Node *p2r, const int value)
{
    register Node *this_node = p2r;
    register Node *next;
    register Node *newnode;
 
    /* Let's confirn if value is already in the  list */
    while ((next = this_node->fwd) != NULL)
	 {
	 	 /* I ensure each value is inserted once */
            if (next->value == value)
			 {
                    printf("\aValue %d is already in the list!\n");
                    return ;
            } 
			printf("value = %d, this_node = %p, next = %p\n", this_node->value, this_node, next );           
            if (next->value > value)
                    break;                     
            this_node = next;
           
    }
 
    /* Value isn't already in the list */
    /* Let's allocate it in proper place in the list */
    /* Allocate space to newnode */
    newnode = (Node *)malloc(sizeof(Node));
 
    /* Verify if allocation successful */
    if (newnode == NULL) 
	{
        printf("Error: Memory Allocation Failed!\n");
        exit(EXIT_FAILURE);
    }
 
    /* write in value in the newnode */
    newnode->value = value;
 
    /* Insert value in the list */
    /* 
     * four pointer fields in this_node, newnode and next required
     * to be adjusted
     */
    newnode->fwd = next;
    this_node->fwd = newnode;
 
    if (this_node != p2r)
        newnode->bwd = this_node;
    else
    /* newnode is only node in dll */
        newnode->bwd = NULL;
 
    if (next != NULL)
        next->bwd = newnode;
    else
     /* newnode is end node in dll */
        p2r->bwd = newnode;
    ++p2r->value;
    printf("nos node = %d, Value %d at node %p, prev = %p, next = %p\n", p2r->value, value, newnode, newnode->bwd, newnode->fwd);
}


 void insert_bwd(register Node *p2r, const int value)
{
    register Node *this_node = p2r;
    register Node *prev;
    register Node *newnode;
 
    /* Let's confirn if value is already in the  list */
    while ((prev = this_node->bwd) != NULL)
	 {
	 	 /* I ensure each value is inserted once */
            if (prev->value == value)
			 {
                    printf("\aValue %d is already in the list!\n");
                    return ;
            } 
			printf("value = %d, this_node = %p, prev = %p\n", this_node->value, this_node, prev );           
            if (prev->value < value)
                    break;                     
            this_node = prev;
           
    }
 
    /* Value isn't already in the list */
    /* Let's allocate it in proper place in the list */
    /* Allocate space to newnode */
    newnode = (Node *)malloc(sizeof(Node));
 
    /* Verify if allocation successful */
    if (newnode == NULL) 
	{
        printf("Error: Memory Allocation Failed!\n");
        exit(EXIT_FAILURE);
    }
 
    /* write in value in the newnode */
    newnode->value = value;
 
    /* Insert value in the list */
    /* 
     * four pointer fields in this_node, newnode and next required
     * to be adjusted
     */
    newnode->bwd = prev;
    this_node->bwd = newnode;
 
    if (this_node != p2r)
        newnode->fwd = this_node;
    else
    /* newnode is only node in dll */
        newnode->fwd = NULL;
 
    if (prev != NULL)
        prev->fwd = newnode;
    else
     /* newnode is first node in dll */
        p2r->fwd = newnode;
 
    ++p2r->value;
    printf("nos node = %d, Value %d at node %p, prev = %p, next = %p\n", p2r->value, value, newnode, newnode->bwd, newnode->fwd);
}


void traverse_fwd(register Node *p2r)
{
    register Node *this_node = p2r->fwd;
    size_t nodes = 0;
	 
    /* Let's verify if list is Empty */
    if (this_node == NULL)
	 {
        printf("\n\aList is EMPTY.\n");
        return;
    }
    /* List isn't EMPTY, Traversing the list in FORWARD direction */
    
    printf("\nList is as follows: \n");
    while (this_node != NULL)
	{
	     printf("value = %d , this_node = %p, prev = %p, next = %p\n", this_node->value, this_node, this_node->bwd, this_node->fwd);
         this_node = this_node->fwd;
         ++nodes;
    }
    if(nodes == p2r->value)
       printf("nos of nodes = %d",p2r->value );
	else
	  printf("\n \a nos nodes not matched");           
}
 
void traverse_bwd(register Node *p2r)
{
    register Node *this_node = p2r->bwd;
   	size_t nodes = 0; 
   	
    /* Let's verify if list is Empty */
    if (this_node == NULL) 
	{
        printf("\n\aList is EMPTY.\n");
        return;
    }
    /* List isn't EMPTY, Traversing the list in Backward direction */
    printf("\nList is as follows: \n");
    while (this_node != NULL) 
	{
	       printf("value = %d , this_node = %p, prev = %p, next = %p\n", this_node->value, this_node, this_node->bwd, this_node->fwd); 
           this_node = this_node->bwd;
            ++nodes;
    }
    if(nodes == p2r->value)
       printf("nos of nodes = %d",p2r->value );
	else
	  printf("\n \a nos nodes not matched");    
}
 
void delete_fwd(register Node *p2r, const int value)
{
    register Node *prev = p2r;
    register Node *next;
    register Node *dnode;
    
    /* let's see if list is empty */
    if (prev->fwd == NULL)
	 {
        printf("\aList is empty.\n");      
 
        return ;
    }
         /*
         * List isn't empty. We search through the entire list for 
         * desired value and once found, we'll delete the node containing
         * the value
         */
        while ((dnode = prev->fwd) != NULL && dnode->value != value)
                prev = dnode; /* update the current node */
 
        /* now there are 2 cases, Either we've reached the end of list */
        if (dnode == NULL) 
		{
           printf("We have reached the end of the List.\n");
           printf("Value %d is NOT in the list.\n", value);
           return ;
        }
        
          /*  * set fwd to node following node to be deleted  */
          prev->fwd = dnode->fwd;
 
         next = dnode->fwd;
         if (next == NULL)
		  {
                 /* reached end of list */
                 /* 
                   * set bwd field of root node to preceding node 
                   * of deleting node
                  */
                 p2r->bwd = dnode->bwd;
           }
           else
		    {
                  /* else where in the list */
                  next->bwd = dnode->bwd;
            }
             --p2r->value; 
             printf("deleted value = %d at node %p, prev = %p, next = %p\n", value, dnode, dnode->bwd, dnode->fwd);
             printf("nos of nodes = %d \n", p2r->value);
             /* now free up the dnode */
            free(dnode);
            return ;
  
}


void delete_bwd(register Node *p2r, const int value)
{
    register Node *prev ;
    register Node *next = p2r;
    register Node *dnode;
     
    /* let's see if list is empty */
    if (next->bwd == NULL)
	 {
        printf("\aList is empty.\n");      
 
        return ;
    }
         /*
         * List isn't empty. We search through the entire list for 
         * desired value and once found, we'll delete the node containing
         * the value
         */
        while ((dnode = next->bwd) != NULL && dnode->value != value)
                next = dnode; /* update the next node */
 
        /* now there are 2 cases, Either we've reached the end of list */
        if (dnode == NULL) 
		{
           printf("We have reached the end of the List.\n");
           printf("Value %d is NOT in the list.\n", value);
           return ;
        }
        
          /*  * set bwd  to node following node to be deleted  */
          next->bwd = dnode->bwd; 
         
         prev = dnode->bwd;
         if (prev == NULL)
		  {
                 /* reached front of list */
                 /* 
                   * set fwd field of root node to preceding node 
                   * of deleting node
                  */
                 p2r->fwd = dnode->fwd;
           }
           else
		    {
                  /* else where in the list */
                  prev->fwd = dnode->fwd;
            }
             --p2r->value; 
             printf("deleted value = %d at node %p, prev = %p, next = %p\n", value, dnode, dnode->bwd, dnode->fwd);
             printf("nos of nodes = %d \n", p2r->value);
             /* now free up the dnode */
            free(dnode);
            return ;
  
} 

void delete_all(register Node *root_ptr)
{
    Node *this_node = root_ptr->bwd;
    register Node *prev;
    
    if(this_node == NULL)
    {
    	printf("\n \a List is empty\n");
    	return;
	}
	while((this_node )  != NULL)
	{
	    printf("\n value = %d, free node : %p ", this_node->value, this_node );
	   	prev = this_node->bwd;
	   	free(this_node);
	   	this_node = prev;
	}
	root_ptr->fwd = NULL;
	root_ptr->bwd = NULL;
	root_ptr->value = 0;
}


Node *search_fwd(register Node *p2r, const int value)
{
    register Node *this_node = p2r->fwd;
   
    /* Let's verify if list is Empty */
    if (this_node == NULL)
	 {
        printf("\n\aList is EMPTY.\n");
         return this_node; 
    }
    /* List isn't EMPTY, Searching value in the list */
     while ((this_node != NULL) && this_node->value != value)
          this_node = this_node->fwd;
 
            if (this_node == NULL)
			 {  /* reached end of list */
                printf("value = %d is NOT in the list.\n", value);                
            }
            else
            {
			    printf("value = %d at node %p \n", value, this_node);                
            }
            return this_node;       
  }
  
 Node *search_bwd(register Node *p2r, const int value)
{
    register Node *this_node = p2r->bwd;
     
    /* Let's verify if list is Empty */
    if (this_node == NULL)
	 {
        printf("\n\aList is EMPTY.\n");
         return this_node; 
    }
    /* List isn't EMPTY, Searching value in the list */
     while ((this_node != NULL) && this_node->value != value)
          this_node = this_node->bwd;
 
            if (this_node == NULL)
			 {  /* reached end of list */
                printf("value = %d is NOT in the list.\n", value);                
            }
            else
            {
			    printf("value = %d at node %p \n", value, this_node);                
            }
            return this_node;       
  }
  
   
