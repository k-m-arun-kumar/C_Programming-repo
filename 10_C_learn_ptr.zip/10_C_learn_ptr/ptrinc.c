/* ********************************************************************
FILE                   :  ptrinc.c

PROGRAM DESCRIPTION    : practise C coding in pointers

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
int main()
{
   static int ncol[4] = {10,20,30}, b;
   int *ptrcol = ncol, *ptrno = ncol + 3, *ptrb = &b;
   printf("\n ncol = %ux , ncol + 1 = %ux", ncol, ncol + 1);
   printf("\n ptrcol = %d, ptrcol = %ux, ptrcol = %ux , *ptrcol = %d", *ptrcol, ptrcol++, ptrcol, *ptrcol);
   /* printf("\n ptrcol = %d, ptrcol = %ux, ptrcol = %ux , *ptrcol = %d", *ptrcol, ++ptrcol, ptrcol, *ptrcol); */
   printf("\n ptrno = %d, ptrno = %ux", *ptrno, ptrno);
   printf("\n ptrno - ptrcol = %d", ptrno - ptrcol);
   printf("\n ptrno - ptrb = %d", ptrno - ptrb);
 
   return 1;
}

