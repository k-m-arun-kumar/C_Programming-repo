/* ********************************************************************
FILE                   :  ptr.c

PROGRAM DESCRIPTION    : practise C coding in pointers

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "assert.h"
#include "string.h"

#define PINT int*
typedef int* PTRINT;
int (*fptrCompute)(int,int);
int add(int n1, int n2, int n3) ;
void funcarr(char *arr);
main()
{
int a[3][4] ={1,2,3,4,5,6,7,8,9,10,11,12} ;
int i, j , k=99 ;
PINT ptr = &k, invar = 10;   /* ptr = pointer to int, invar is integer variable */
PTRINT ptr1 = &i, ptr2 =&j;  /* ptr1 and ptr2 = pointer to int */
void *vptr;
for(*ptr1 =0;*ptr1 < 3; *ptr1++)
for(*ptr2 =0;*ptr2 < 4; *ptr2++)
if(a[*ptr1][*ptr2] < k)
{ *ptr = a[*ptr1][*ptr2];
   //printf(" [%d][%d] = %d", *ptr1,*ptr2,k);
}

 ptr = malloc(2);
*ptr = 5;
printf("ptr =%d", *ptr);
/*does noting if assert() function's parameter has a non zero value
else displays error message to strerr, standard error stream */

assert(ptr != NULL); 

fptrCompute = add;
fptrCompute(2,5);

free(ptr);
ptr = NULL;
/* assert(ptr != NULL);*/ /* at run time program abort at this location, as ptr =NULL makes
 expresson ptr!= NULL as false and displays error message as EXpression: ptr!= NULL */
ptr = &k;
printf("\n *ptr = %d, invar  = %d", *ptr, invar);

int (*fptrIndirect)(const char *, ...) = printf;
fptrIndirect("Executing printf indirectly");


memset(a,99,sizeof(a));
vptr = (char *)(a[0] + 1);
printf("\n a[%d][%d] = %d, vptr = %d",0,1, a[0][1], *((char *)vptr));
}


int add(int n1, int n2, int n3) 
{
   printf("\n add(): n1 = %d, n2=%d, n3= %d ",n1, n2, n3);
   return n1+n2+n3;
}
