/* ********************************************************************
FILE                   : ptr_1.c

PURPOSE                : practise c coding in pointers 
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                       
CHANGE LOGS           : 

*****************************************************************************/


#include <stdio.h>

int main()
{
    int *pi;
    int (*pa)[3];   /* pointer to an array of 3 integers */
    int ar1[2][3] = {{1,2,3},{10,20,30}};
    int ar2[3][2];
    int **p2pi;     /* a pointer-to-pointer-to-int, a double pointer */
    const int **pp2;
    int *p1;
    const int n = 13;
 
    pp2 = &p1; /* not allowed, but suppose it were */
    *pp2 = &n; /** valid, both const, but sets p1 to point at n */
    *p1 = 10;  /* valid, but changes const n */
    
    printf("\n n = %d ", n);
    /* Then we have the following: */
    pi = &ar1[0][0];   /* both pointer-to-int */
    pi = ar1[0];       /* both pointer-to-int */
   // pi = ar1;          /* not valid because ar1 is an array of 3 integers */
 
    pa = ar1;          /* both pointer-to-int[3] */
    pa = &ar1[1];       /* pa = ptr to array of 3  int*/
    printf("\n by using pa, ar[1][2] = %d", *(*pa + 2));
   // pa = ar2;          /* not valid because ar2 is an array of 2 integers */
 
    p2pi = &pi;        /* both pointer-to-int * */
    *p2pi = ar2[0];    /* both pointer-to-int */
   // p2pi = ar2;        /* not valid */
    
    return 0;
}
