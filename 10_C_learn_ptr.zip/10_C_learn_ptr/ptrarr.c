/* ********************************************************************
FILE                   :  ptrarr.c

PROGRAM DESCRIPTION    : practise C coding in pointers

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#define ROW 3
#define COL 5
static int arr[ROW][COL] = {1,2,3,4,5,10,20,30,40,50,100,200,300,400,500};
int exarr[4][COL] = { {7,14,21,28,35}, {70,140,210,280,350}, 700,1400,2100,2800,3500, 4000,5000,6000,7000,8000 };
int main()
{
    int (*ptrarr)[COL];
	ptrarr = arr + 1;
	printf("\n arr = %ux, arr + 1 = %ux, arr[1] = %ux, *(*(ptrarr+1)+4) = %d",arr, arr + 1, arr[1],*(*(ptrarr + 1) + 4));   
    printf("\n ptrarr[1][4] = %d , *(ptrarr[1] + 4) = %d", ptrarr[1][4],*(ptrarr[1] + 4));   
	++ptrarr;
	printf("\n ++ptrarr = %ux, *ptrarr = %ux, sizeof(arr) = %d, sizeof(int (*)[COL] = %d)",ptrarr,**ptrarr, \
	   sizeof arr, sizeof(int (*)[COL]));
	   
	ptrarr = exarr + 1;
	printf("\n after ptrarr = exarr + 1 "); 
	printf("\n ==========================");
	printf("\n ptrarr[1][3] = %d , *(ptrarr[1] + 3) = %d, " 
	  "*(*(ptrarr + 1) + 3) = %d ", ptrarr[1][3], *(ptrarr[1] + 3), *(*(ptrarr + 1) + 3) );	
	return 1;
	
}
