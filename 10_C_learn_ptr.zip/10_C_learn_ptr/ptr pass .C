/* ********************************************************************
FILE                   :  ptr pass.c

PROGRAM DESCRIPTION    : practise C coding in pointers

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

struct cust
{
  int *cust_numptr;
};

int addr_pass(void *ptr);

int main()
{
   int i =0;
   struct cust cust_var[4];
   int cust_num[4];
   int intvar = 10;

   while( i < 4)
   {
      cust_num[i] = i + 5;
      cust_var[i].cust_numptr = &cust_num[i];
      printf("\n cust_num[%d]: %d, cust_numptr: %#X", i,cust_num[i], cust_var[i].cust_numptr);
      ++i;
   }
   printf("\n intvar: %d", intvar);

   addr_pass(cust_var);

   for(i= 0; i < 4; ++i)
      printf("\n cust_num[%d]: %d, cust_numptr: %#X", i,cust_num[i], cust_var[i].cust_numptr);
   printf("\n intvar: %d", intvar);

}

int addr_pass(void *ptr)
{
  struct cust *custptr, cust[4];
  int i = 0;

 /* *custptr = *ptr; */                    /* error: not allowedtype */
 /* *custptr = *(struct cust *)ptr; */     /* results garbage data */

 /* custptr = ptr; */                      /* fine, changes are global */
  cust[0] = *(struct cust *)ptr;

  for(i= 0; i < 4; ++i)
     /* printf("\n cust_num[%d]: %d", *custptr[i]->cust_numptr); */ /* error: pointer req at left side of -> */
   /* printf("\n cust_num[%d]: %d", i,*cust[i].cust_numptr); */ /* error: invalid indirection & type conversion */
   /* printf("\n cust_num[%d]: %d", i,*(cust+ i).cust_numptr); */ /* error: illegal stru oper */
   /* printf("\n cust_num[%d]: %d", i,*(*(cust+ i).cust_numptr)); */ /* error: illegal stry oper */
   printf("\n cust_num[%d]: %d", i,*(*(cust+ i).cust_numptr));
   i = 0;
   while( i < 4)
   {
      *cust[i].cust_numptr = i + 15;
       printf("\n cust_num[%d]: %d", i,*cust[i].cust_numptr);
       ++i;
   }
   return 1;
}


