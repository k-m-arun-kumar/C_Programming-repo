/* ********************************************************************
FILE                   :  Void.c

PROGRAM DESCRIPTION    : practise C coding in pointers

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "alloc.h"
#include "string.h"

int main()
{
   char name[10];
   void *temp;
  /* unsigned *num[5]; */
   int count = 0;
   void *num[5];

   do
   {
      printf("\n [%d]: Enter name: ",++count);
      scanf(" %s", name);
      if(!strcmp(name, "END"))
        break;
      temp = malloc(strlen(name) + sizeof(char));
      memcpy(temp, name, strlen(name) + sizeof(char));
      num[count - 1] = temp;
      printf("\n Entered Name: %s, Disp [%d], Alloc: %#X, Alloc: %#X: Name: %s",name, count, num[count - 1], temp, (char *)num[count - 1]);
      strcpy(name, "");
   } while(1);

   temp = malloc(strlen("END") + sizeof(char));
   strcpy(temp,"END");
   num[count - 1] = temp;

   count = 0;
   while(strcmp((char *)num[count],"END"))
   {
     printf("\n Disp [%d], Alloc: %#X: Name: %s",count + 1, num[count], (char *)num[count]);
     free((void *)num[count]);
     ++count;
   }

}
