/* ********************************************************************
FILE                   : Pointer 1.c

PROGRAM DESCRIPTION    : practise C coding in pointer

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

int check(float);
float* laugh(int);
char test(char []);
float fun(int);

int main()
{
  long s = 23, *sptr;
  float f = 23.1, *fptr;
  int i = 53, *iptr;
  char c = 320, *cptr;
  char a[] = "4rtrg";

  /* fptr = check(45.0);  */ /* warning: non portable ptr assign */
  /* a = test("123");    */  /* error: lvalue required */

  /* fptr = test("123");  */      /* warning: non portable ptr assign */
  *fptr = test("123");            /* warning: pointer use before define */
  printf("\n c = %c, i = %d, s = %ld , f = %f, a = %s", c,i,s,f,a);

}


 int check(float f)
 {
     int i = 45;
     printf("\n inside check");
     return i;
 }

float fun(int i)
{
  printf("\n inside fun");
  return 3;
}

char test(char s[])
{

    int d;
    char c, ch;
    printf("\n INSIDE test func ");

    return 'c';
}


float* laugh(int h)
{
  printf("\n inside laugh func");
  return NULL;
}


