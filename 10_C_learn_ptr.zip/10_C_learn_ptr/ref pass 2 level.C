/* ********************************************************************
FILE                   : ref pass 2 level.c

PROGRAM DESCRIPTION    : practise C coding in pointers

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "alloc.h"
#include "string.h"

typedef struct
{
   unsigned char var_datalen;
   void *var_databuff;
} var_data;

int main()
{
    var_data exist_rec[5];
    unsigned char num_targetrec;

    Get_Data(&exist_rec[0], sizeof(exist_rec)/sizeof(var_data), &num_targetrec);
    Display_Data(&exist_rec[0], &num_targetrec);
    return 1;
}

int Get_Data(var_data *get_targetrec, unsigned char max_rec, unsigned char *num_targetrec)
{
   void *alloc_ptr = NULL;
   char name[10];
   *num_targetrec = 0;

   do
   {
      printf("\n [%d]: Enter name: ",++*num_targetrec);
      scanf(" %s", name);
      if(!strcmp(name, "END") || *num_targetrec > max_rec )
      {
        printf("\n ERR[]: END or Total num matched target[%u] exceeds max [%u]",*num_targetrec,max_rec);
        --*num_targetrec;
        break;
      }
      alloc_ptr = malloc(strlen(name) + sizeof('\0'));
      memcpy(alloc_ptr, name, strlen(name) + sizeof('\0'));
      get_targetrec[*num_targetrec - 1].var_databuff = alloc_ptr;

     /* ERROR: illegal struc oper */
     /* *(get_targetrec + *num_targetrec - 1).var_datalen = strlen(name) + sizeof('\0'); */
     /* (*get_targetrec + *num_targetrec - 1).var_datalen = strlen(name) + sizeof('\0'); */
     (get_targetrec + *num_targetrec - 1)->var_datalen = strlen(name) + sizeof('\0');

      printf("\n Entered Name: %s, Disp [%d], Alloc: %#X : Name: %s, name_len: %u",name, *num_targetrec,get_targetrec[*num_targetrec - 1].var_databuff,\
       (char *)(get_targetrec + *num_targetrec - 1)->var_databuff, (get_targetrec + *num_targetrec - 1)->var_datalen - sizeof('\0'));
      strcpy(name, "");
   } while(1);

   return 1;
}

int Display_Data(void **var_dataptr, unsigned char *num_rec)
{
   unsigned char rec_count = -1;

   if(*var_dataptr)
   {
      while(++rec_count <= *num_rec - 1)
      {
         printf("\n Alloc: %#X, Name: %s, name_len: %u", (((var_data *)var_dataptr) + rec_count)->var_databuff, \
          (char *)((var_data *)var_dataptr)[rec_count].var_databuff, (((var_data *)var_dataptr) + rec_count)->var_datalen - sizeof('\0'));
         free((((var_data *)var_dataptr) + rec_count)->var_databuff);
      }
      return 1;
   }
   printf("\n ERR[25.2]: var_dataptr is NULL, to display its emp record");
   return 1;
}

