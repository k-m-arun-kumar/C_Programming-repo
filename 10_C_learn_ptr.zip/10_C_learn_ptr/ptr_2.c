/* ********************************************************************
FILE                   : ptr_2.c

PURPOSE                : practise c coding in pointers 
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                       
CHANGE LOGS           : 

*****************************************************************************/

/* 
 * diff_regptr_and_ptr2const1.c -- Program shows what happens when regular
 * pointer is assigned addresses of non-constant and constant data 
 */
#include <stdio.h>
 
int main(void)
{
    float pass_per = 60.9;        /* pass_per is non-constant float */
    const float fare = 31.35;     /* fare is constant float */
    float *fp = &pass_per;        /* fp, regular pointer to float */
 
    printf("\nIn the exp. \"float *fp = &pass_per\":\n");
    printf("fp is a regular pointer to float pass_per, value of "
               "pass_per is %f\n", *fp);
    printf("Now, we try modify pass_per using regular pointer fp...\n");
 
    *fp = 70.9;
 
    printf("O key, now, in exp. \"*fp = 70.9\", pass_per is %f\n", *fp);
    printf("\nNow, let's see what happens when fp is assigned address of"
           " some \"constant data\"\n");
 
    fp = &fare;	        /* assigned fp address of constant fare */
 
    printf("\nIn the exp. \"fp = &fare\":\n");
    printf("fp is a regular pointer to constant float \"fare\", value of"
           " fare is %f\n", *fp);
    printf("Now, we try to modify constant fare using fp...\n");
 
    *fp = 62.70;
 
    printf("O key, now, in the exp. \"*fp = 62.70\", value of constant "
           "data fare is %f\n\n", *fp);
 
    return 0;
}
