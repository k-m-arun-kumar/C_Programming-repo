/* ********************************************************************
FILE                   : ptr_arr.c

PROGRAM DESCRIPTION    : practise of using pointer to array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>
void access_multidimarr(int (*)[5], int);    /* prototype */
 
int main(void)
{
    int hawks[4][5] = {{1,2,3,4,5},
                       {6,7,8,9,10},
                       {11,12,13,14,15},
                       {16,17,18,19,20},
                      };        /* hawks's initialized */
 
     printf("Now we access \'hawks[4][5]\'...\n");
     access_multidimarr(hawks, 4);      /* called the function */
     return 0;
}
 
void access_multidimarr(int (*ptr)[5], int num)
{
    int i, j;
 
    printf("In function: accessing \'hawks\' using pointer to array.\n");
    for (i = 0; i < num; i++) {
        for (j = 0; j < 5; j++) {
            printf("hawks[%d][%d] is %d\n", i, j, *(*ptr + j));
        }
        ptr++;
    }
}
