/* ********************************************************************
FILE                   :  stru Ptr 3.c

PROGRAM DESCRIPTION    : practise C coding in pointers

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "stdlib.h"

struct cust
{
  int cust_num;
  char name[10];
  void *ptr;
};
struct time
{
  int arrive;
  char phone[15];
};
int fun_passptr(void *ptr);

int main()
{
   void *ptr;
   char *name ="hello";
   struct cust cust_var;
   struct cust cust_retrieve;
   struct time time_var;
   clrscr();

   cust_var.ptr  = &time_var;
   cust_var.cust_num = 10;
   memcpy(cust_var.name,name,10 );
   printf("\n [1.1c] before fun_pass: cust1.id: %d, cust name: %s", cust_var.cust_num, cust_var.name);
   name = "vanda";
   time_var.arrive = 250;
   memcpy(time_var.phone,name,15 );
   printf("\n [1.1c] before fun_pass: cust1: time: arrival: %d, phone %s", (*(struct time *) cust_var.ptr).arrive,((struct time *) cust_var.ptr)->phone );

   fun_passptr(&cust_var);
   printf("\n [1.1c] after fun_pass: cust1.id: %d, cust name: %s", cust_var.cust_num, cust_var.name);
   printf("\n [1.1c] after fun_pass: cust1: time: arrival: %d, phone %s", (*(struct time *) cust_var.ptr).arrive,((struct time *) cust_var.ptr)->phone ); 
   /* memset(&cust_retrieve, 0, sizeof(struct cust) );*/
   /* fun_retptr(&cust_var, &cust_retrieve,sizeof (struct cust) + sizeof (struct time)); */
     /* display 10 & hello for retrieve's arrival & phone */

   fun_retptr(&cust_var, &cust_retrieve,sizeof (struct cust));
   printf("\n [1.1c] after ret_pass: cust1.id: %d, cust name: %s", cust_var.cust_num, cust_var.name);
   printf("\n [1.1c] after ret_pass: cust1: time: arrival: %d, phone %s", (*(struct time *) cust_var.ptr).arrive,((struct time *) cust_var.ptr)->phone ); 
   printf("\n [1.2c] after ret_pass: cust2.id: %d, cust name: %s", cust_retrieve.cust_num, cust_retrieve.name);
   printf("\n [1.2c] after ret_pass: cust2: time: arrival: %d, phone %s", (*(struct time *) cust_retrieve.ptr).arrive,((struct time *) cust_retrieve.ptr)->phone );

   /* printf("\n cust2: time: arrival: %d, phone %s", cust_retrieve.(*(struct time *)ptr).arrive,cust_retrieve.((struct time *)ptr)->phone ); */
     /* error: invalid use of dot, solution below */
   
   return 1;
}

int fun_passptr(void *ptr)
{
    struct cust cust_var, *cust_ptr, *cust_acc;
    
    *cust_ptr = *(struct cust *)ptr;
    /* warning: possible use of cust_ptr before defination, anyway works fine if ptr has valid points */
    /* any change in value of its member cust_ptr, doesn't affect its value in ptr */
    cust_var = *(struct cust *)ptr;
    cust_acc = (struct cust *)ptr;
    /* any change in value of its member cust_ptr, affect its value in ptr */

    printf("\n [2.1c] cust1.id: %d, cust name: %s", (*(struct cust *)ptr).cust_num, ((struct cust *)ptr)->name);
    printf("\n [2.1c] cust1.time arrive: %d, time phone: %s", ((struct time *)(*(struct cust *)ptr).ptr)->arrive, (*(struct time *)((struct cust *)ptr)->ptr).phone);
    /* printf("\n [2.1c] cust1.time arrive: %d, time phone: %s", (*(struct cust *)ptr).((struct time *)ptr)->arrive, ((struct cust *)ptr)->(*(struct time *)ptr).phone); */
       /* error: invalid use of dot */

    printf("\n [2.1p] cust1.id: %d, cust name: %s", (*cust_ptr).cust_num, cust_ptr->name);
    printf("\n [2.1p] cust1.time arrive: %d, time phone: %s", ((struct time *)(*cust_ptr).ptr)->arrive, (*(struct time *)cust_ptr->ptr).phone);
    printf("\n [2.1v] cust1.id: %d, cust name: %s", cust_var.cust_num, (&cust_var)->name);
    printf("\n [2.1v] cust1.time arrive: %d, time phone: %s", ((struct time *)cust_var.ptr)->arrive, (*(struct time *)(&cust_var)->ptr).phone);

    cust_var.cust_num = 20;
    /* cust_acc->cust_num = 40; */
    cust_ptr->cust_num = 30;
    printf("\n [2.2p] cust1.id: %d", (*cust_ptr).cust_num);
    printf("\n [2.2a] cust1.id: %d", (*cust_acc).cust_num);
    printf("\n [2.2v] cust1.id: %d", cust_var.cust_num);
    return 1;
}

int fun_retptr(void *srcptr, void *desptr, int size)
{
    memcpy(desptr, srcptr,size );

    return 1;
}


