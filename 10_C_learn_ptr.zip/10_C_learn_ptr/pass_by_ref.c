/* ********************************************************************
FILE                   : pass_by_ref.c

PURPOSE                :  pass a data through reference
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                       
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
void Pass_By_Ref(const char * const time_str);
int main()
{
	char time_str[20] = "Hello \r";
	
	Pass_By_Ref(time_str);
}

void Pass_By_Ref(const char * const time_str)
{
	printf("Passed str = %s", time_str);
}
