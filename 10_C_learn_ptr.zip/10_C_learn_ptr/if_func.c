/* ********************************************************************
FILE                   : if_func.c

PROGRAM DESCRIPTION    : practise if using pointer

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>
 
/* function definition: function defined here */
 
int hello(void)
{
    return 1;         
}
 int hi(void)
{
    return 0;         
}
/* 
* function prototype: return-type fun_name(arguments number & their type);
*/
 
void call_fun(void);
int hi(void);
 
int main(void)
{
	
	int number;
    int *iptr;
 
    /* 
     * iptr, pointer to integer, follows the location of variable 
     * number in the memory
     */
 
    iptr = &number;   
 
    if (*iptr = 0)
        printf("used pointer in the if condition! number is %d\n", *iptr);
    else
        printf("assigned number value 0 \n");
   
    if (*iptr = 1)
        printf("used pointer in the if condition! number is %d\n", *iptr);
    else
        printf("assigned number value 0 \n"); 
		           
    if (hello())
        printf(" hello() return 1 \n");
    else
        printf("hello() returns 0 \n");
        
    if (hi())
        printf(" hi() return 1 \n");
    else
        printf("hi() returns 0 \n");   
 
    /*
     * 1. Try yourself: Analyse output of the following if-else construct
     * 2. Here, I called a function what(), whose return type is void,
     *    as if condition
     */
 
   /* if (call_fun())
        printf("function call possible as a condition in if statement!\n");
    else
        printf("call_fun() returns nothing because its return type is"
               " void, so else executed!\n"); */
               
 
    return 0;
}
void call_fun(void)
{
    printf("Inside call_fun() function!\n");
    return; 
}
