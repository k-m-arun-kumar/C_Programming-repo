/* ********************************************************************
FILE                   : const ptr.c

PROGRAM DESCRIPTION    : practise const pointers

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.

CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>

#define NUM_ROWS                  (2)
#define NUM_COLS                  (4) 

#define VAR_PTR(var_id)         var##var_id##_ptr
 
unsigned int var[NUM_ROWS][NUM_COLS] = {
                             {2,4,6,8},
                             {5,10,15, 20}
						 }; 

						 
unsigned int *const var_ptr[NUM_ROWS][NUM_COLS] = {
                                  {&var[0][0], &var[0][1], &var[0][2], &var[0][3]},
                                  {&var[1][0], &var[1][1], &var[1][2], &var[1][3]}
						 	  };
unsigned int *const var0_ptr[NUM_COLS] = { &var[0][0], &var[0][1], &var[0][2], &var[0][3]};
unsigned int *const var1_ptr[NUM_COLS] = { &var[1][0], &var[1][1], &var[1][2], &var[1][3]};							   
unsigned int *const *Var_Ptr(unsigned short var_id);
							   						 
int main()
{
	unsigned short i, j, *const *var_alloc_ptr;
	
	  for(i = 0; i < NUM_ROWS; ++i)
	  {
	  	  for(j = 0; j < NUM_COLS; ++j)
	  	  { 
	  	      printf("col : %u = %u    ", j, *var_ptr[i][j]);
		  }
		  printf("\n");
	  }
	  //var_ptr[0][0]  = &var[0][0];
	  var_alloc_ptr = Var_Ptr(0);
	  
	  printf("\n \n *var_alloc_ptr[3] = %u", *(var_alloc_ptr[3]));
	  
	return 0;
}

unsigned int *const *Var_Ptr(unsigned short var_id)
{
	switch(var_id)
	{
		case 0:
	      return VAR_PTR(0);
		break;
		case 1:
		   return VAR_PTR(1);
		break;	 
	}
	
	return NULL;
}

