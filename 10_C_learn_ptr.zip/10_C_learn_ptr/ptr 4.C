/* ********************************************************************
FILE                   :  ptr 4.c

PROGRAM DESCRIPTION    : practise C coding in pointers

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "alloc.h"

int* ret_ptr(void);
int main()
{
   int *ptr, free_ret;
   ptr = ret_ptr();
   printf("\n %d", *ptr);
  /* printf("\n %d", free(ptr)); */  /* error: not allowed type */
   free(ptr);
  /* free(ptr); */  /* run time: null ptr assign */
   return 1;
}

int* ret_ptr(void)
{
   int *ptr = NULL, *ptr1, var;            /* run time: Null ptr assign, if accessing staight way */
   ptr = malloc(sizeof(int));
  /*  ptr = &var; */
   *ptr = 10;                      /* warning: use of ptr before defination */
   printf("\n ptr1= %#x, *ptr = %d", ptr1,*ptr);
   return ptr;
}
