/* ********************************************************************
FILE                   :  ptrptr.c

PROGRAM DESCRIPTION    : practise C coding in pointers

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "stdlib.h"
#define safeFree(ptr) saferFree((void **)&ptr)
#define START_VALUE    1
#define SIZE           5
#define INCREMENT       10

void saferFree(void **pp);
void allocateArray(int **arr, int size, int value);

int main() 
{
int *ptr = NULL;
 int i = 0;

allocateArray(&ptr, SIZE, START_VALUE);
printf("\n memory allocated access from main ptr: %ux whose address &ptr :%ux \n",ptr, &ptr);
for(i=0;i < SIZE; ++i)
  printf("\n ptr[%d]: %d", i, *(ptr + i));
safeFree(ptr);
printf("\n After freeing memory: %ux",ptr);
safeFree(ptr);
return 1;
}

void saferFree(void **ptrptr) 
{
if (ptrptr != NULL && *ptrptr != NULL)
 {
    printf("\n free memory *ptrptr %ux, whose ptrptr: %ux", *ptrptr, ptrptr);
    free(*ptrptr);
   *ptrptr = NULL;
}
else
    printf("\n already memory freed");
 return;
}
/* arr contains address of local pointer variable (pi) in main, *arr refers
to contents of pointer variable( pi), which points to integer data value, 
in allocateArray(), pointer variable( pi) in main can be accessed by *arr, after
returning from allocateArray(), arr is destroyed , but now pi  in main,
 points to allocated memory SEE page 69 fig 3.7 from "understanding and using pointers */

void allocateArray(int **arr, int size, int value) 
{
   
   int i =0;
   *arr = (int*)malloc(size * sizeof(int));
   printf("\n allocate memory *arr: %ux whose arr: %ux", *arr, arr);
   if(*arr != NULL) 
    for( i= 0; i<size; ++i)
    {   
     *(*arr+i) = value +  i * INCREMENT;
	 printf("\n *(*arr + %d) = %d", i, *(*arr+i));
	 }
   return;
}
