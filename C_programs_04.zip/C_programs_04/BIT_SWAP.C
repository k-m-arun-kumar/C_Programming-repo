/* ********************************************************************
FILE                   : BIT_SWAP.c

PROGRAM DESCRIPTION    : Bit swap

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>
#include <conio.h>
int main()
{
  clrscr();
  int var1 = 10, temp = 0, temp1, mask_odd = 0xAAAA;
  int mask_even = 0x5555;
  printf("\n Enter var in hexa = ");
  scanf("%x", &var1);
  temp = (var1 & mask_even) << 1;
  temp |= (var1 & mask_odd) >> 1;
  printf("\n Bit swap data = 0x%x",temp );
  getch();
  return 1;
}
