/* ********************************************************************
FILE                   :  SWAP_PTR.c

PROGRAM DESCRIPTION    : swap data using pointers in C

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include <stdio.h>
#include <conio.h>
int main()
{
   int var1, var2, temp, to_iterate = 0;
   int *temp_ptr = NULL;
   do
   {
       clrscr();
       printf("\n Enter var1 = ");
       scanf("%d", &var1);
       printf("\n Enter var2 = ");
       scanf("%d", &var2);
       temp_ptr = &temp;
       *temp_ptr = var1;
       var1 = var2;
       var2 = *temp_ptr;
       printf("\n swapped data: var1 = %d, var2 = %d", var1, var2);
       printf("\n Do u want to continue ?");
       printf("\n enter num = 1, any other num to exit. Continue? = ");
       scanf("%d", &to_iterate);
   } while(to_iterate == 1);
   getch();
   return 1;
}
