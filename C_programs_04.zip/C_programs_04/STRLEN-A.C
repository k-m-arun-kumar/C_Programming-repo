/* ********************************************************************
FILE                   :  STRLEN-A.c

PROGRAM DESCRIPTION    : display num of chars in a string. 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include <stdio.h>
#include <conio.h>
#define MAX_STR 20
int main()
{
    char str[MAX_STR];
    size_t len, i;
    int to_iterate = 0;
    do
    {
	clrscr();
	printf("\n Enter a string. max size : %d = ", MAX_STR);
	scanf("%s", str);
	i = 0;
	while(str[i++]);
	printf("\n %s strlen = %u", str, i - 1);
	printf("\n Do u want to continue ?");
	printf("\n enter num = 1 to continue, any other num to exit. \n Continue ? = ");
	scanf("%d", &to_iterate);
    } while(to_iterate == 1);
    getch();
    return 1;
}
