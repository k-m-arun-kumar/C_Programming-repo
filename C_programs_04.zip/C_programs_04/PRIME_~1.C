/* ********************************************************************
FILE                   :PRIME_~1.c

PROGRAM DESCRIPTION    : check if a number is prime number

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "string.h"
#include "math.h"
#include "stdlib.h"

#define MAX_NUM          1000
#define MAX_PRIME_COUNT   200
#define DEBUG              00
#define  MAX_STR            10
unsigned int arr_prime[MAX_PRIME_COUNT];
size_t prime_max_count;
void Init_prime_arr();
int calc_prime(unsigned  int min_prime, unsigned  int max_prime);
int disp_prime(unsigned int min_prime, unsigned int max_prime );
void disp_arr();

void Init_prime_arr()
{
	prime_max_count = 0;
	arr_prime[prime_max_count] = 2;
	arr_prime[++prime_max_count] = 3;
}
int disp_prime(unsigned int min_prime, unsigned int max_prime )
 {
	size_t prime_count = 0, min_prime_count, count = 0;
	if(DEBUG)
	  disp_arr();
	printf("\n Displaying prime numbers in [%u,%u] \n ",min_prime, max_prime);
	for(min_prime_count = 0; min_prime_count < prime_max_count; ++min_prime_count )
	{
		if(arr_prime[min_prime_count] <= min_prime && arr_prime[min_prime_count + 1] > min_prime)
		{
		   if(arr_prime[min_prime_count] == min_prime)
		     prime_count = min_prime_count;
		   else
		     prime_count = min_prime_count + 1;
		   break;
		 }
	}
	if(DEBUG)
	  printf("\n INFO[09]: initial prime_count: %u ",  prime_count);
	for( count = 0; prime_count<prime_max_count; ++prime_count,++count )
	  printf("[%u]: %u , ",count, arr_prime[prime_count]) ;
	 printf("[%u]: %u .",count, arr_prime[prime_count]) ;
	return 0;
 }
 int calc_prime(unsigned int min_prime,unsigned int max_prime)
 {
	unsigned int prime_count=0, num = 0, max_num_prime;
	char is_prime='y';

	for(num = 5; num <= max_prime; num = num + 2 )
	{
      is_prime='y';
      max_num_prime = (unsigned int) ceil(sqrt((double) num)) ;
      if(DEBUG)
	  printf("\n INFO[02]: Number[%u] to find prime [%u]",num, max_num_prime);
       for( prime_count = 0  ;  prime_count<=prime_max_count; ++prime_count )
	  {
		if(DEBUG)
	       printf("\n INFO[03]: prime count [%u] , number [%u]",prime_count,num) ;
		 if( num % arr_prime[prime_count] == 0)
		 {
			if(DEBUG)
			  printf("\n INFO[04]: Number[%u] is divisible by first prime[%u]", num,arr_prime[prime_count]) ;
			is_prime='n';
			break;
		 }
      }
      if(is_prime=='y')
	  {
		if(DEBUG)
		    printf("\n INFO[05]: Number[%u] is a prime number ", num);
		 ++prime_max_count;
		 arr_prime[prime_max_count] = num;
	  }
	}
	return 0;
 }
int main()
{
	unsigned int min_prime, max_prime;
	char to_continue[MAX_STR], to_iterate ;

	Init_prime_arr();

	do
	{
	  printf("\n Enter min prime number : ");
	  scanf("%u", &min_prime);

	  printf("\n Enter max prime number : ");
	  scanf("%u", &max_prime);

	 if( max_prime >= min_prime)
	 {
		 if( max_prime > 3)
		    calc_prime(min_prime, max_prime);

		 disp_prime(min_prime, max_prime);
	  }
	  else
		 printf("\n ERROR[06]: max_prime[%u] < min_prime[%u]",max_prime, min_prime);
      to_iterate = 'n';
	  printf("\n Do you want to continue ? ");
	  printf("\n Press key 'y' or 'Y' to continue, any other key(s) to exit application. \n Continue ? : ");
	  gets(to_continue);
      if(!strcmp(to_continue, "y") || !strcmp(to_continue, "Y"))
	to_iterate = 'y';
    } while(to_iterate == 'y');
    getch();
    return 0;
}

void disp_arr()
{
	size_t  prime_count = 0;
	printf("\n Display prime array \n ");
	for(prime_count = 0; prime_count<prime_max_count; ++prime_count )
	  printf("[%u]: %u , ",prime_count, arr_prime[prime_count]) ;
	 printf("[%u]: %u .",prime_count, arr_prime[prime_count]) ;
}
