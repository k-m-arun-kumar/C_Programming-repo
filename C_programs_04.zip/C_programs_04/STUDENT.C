/* ********************************************************************
FILE                   :  STUDENT.c

PROGRAM DESCRIPTION    : students marks operations. 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include <stdio.h>
#include <conio.h>
#include <stdlib.h>

#define MAX_STR 20
#define MAX_REC 10

struct student_record
{
   unsigned int roll_no;
   char name[MAX_STR];
   unsigned int physics;
   unsigned int chemistry;
   unsigned int maths;
   unsigned int total;
   float average;
};
typedef struct student_record student_record;
void get_data(student_record [], unsigned int);
void disp_data(student_record [], unsigned int);
void max_field(student_record [], unsigned int, char );
void disp_char(char, int);
unsigned int highest_field[MAX_REC];
int main()
{
  student_record records[MAX_REC];
   unsigned int num_students;
   char max_mode;
   int to_iterate = 0;
   do
   {
      clrscr();
      printf("\n Enter num of students = ");
      scanf("%u", &num_students);
      get_data(records , num_students);
      disp_data(records, num_students);
      max_field(records, num_students, 't');
      max_field(records, num_students, 'p');
      max_field(records, num_students, 'c');
      max_field(records, num_students, 'm');
      max_field(records, num_students, 'a');
      printf("\n Do u want to continue ?");
      printf("\n Enter num = 1 to continue, any other num to exit. Continue ? = ");
      scanf("%d", &to_iterate);
   } while(to_iterate == 1);
   getch();
   return 1;
}
void get_data(student_record records[], unsigned int num_students)
{
   size_t i = 0;
   for(i =0; i<num_students; ++i)
   {
      printf("\n Get data for student = %d \n", i + 1);
      disp_char('=',30);
      printf("\n Roll No: " );
      scanf("%u", &records[i].roll_no);
      printf("\n Student name = ");
      scanf("%s", records[i].name);
      printf("\n Physics mark = ");
      scanf("%u",&records[i].physics);
      printf("\n Chemistry mark = ");
      scanf("%u", &records[i].chemistry);
      printf("\n Maths mark = ");
     scanf("%u", &records[i].maths);
      records[i].total = records[i].physics + records[i].chemistry + records[i].maths;
      records[i].average = records[i].total / 3;
   }
   return;
}
 void disp_char(char disp, int num)
 {
    int i = 0;
    for(i = 0; i < num; ++i)
      printf("%c",disp);
    return;
 }
 void disp_data(student_record records[], unsigned int num_students)
 {
    int i = 0;
    printf("\n Display Student records \n");
    disp_char('=',30);
    printf("\n Sl RollNo           Name  Phy Chem Max Tot Avg \n");
    disp_char('=', 50);
    for(i = 0; i < num_students; ++i)
       printf("\n %2u %6u %15s %3u %4u %3u %3u %6.2f",i +1,records[i].roll_no, records[i].name,\
	records[i].physics, records[i].chemistry, records[i].maths, records[i].total, records[i].average);
    return;
 }
void max_field(student_record records[], unsigned int num_students, char mode)
{
  unsigned int key_max = 0, i = 0;
  switch(mode)
  {
     case 'a':
      for (i = 1; i < num_students; ++i)
	key_max = (records[key_max].average < records[i].average) ? i : key_max;
	printf("\n Highest average = %6.2lf", records[key_max].average);
	for(i = 0; i < num_students; ++i)
	   if(records[key_max].average == records[i].average)
	     printf("\n Highest average having student[%d], rollno = %u, name = %s \n", i + 1, records[i].roll_no, records[i].name);
	disp_char('-',40);
	break;
     case 'p':
       for(i = 1; i < num_students; ++i)
	 key_max = (records[key_max].physics < records[i].physics) ? i : key_max;
	 printf("\n Highest Physics mark = %u", records[key_max].physics);
	 for(i = 0; i< num_students; ++i)
	   if(records[key_max].physics == records[i].physics)
	      printf("\n Highest physics mark student[%d], rollno = %u, name = %s \n", i + 1, records[i].roll_no, records[i].name);
	 disp_char('-', 40);
	 break;
     case 'm':
	for(i = 1; i < num_students; ++i)
	key_max = (records[key_max].maths < records[i].maths) ? i : key_max;
	printf("\n Highest maths mark = %u", records[key_max].maths);
	for(i = 0; i< num_students; ++i)
	  if(records[key_max].maths == records[i].maths)
	     printf("\n Highest maths mark student[%d], rollno = %u, name = %s \n", i + 1, records[i].roll_no, records[i].name);
	disp_char('-', 40);
	break;
      case 'c':
	 for(i = 1; i < num_students; ++i)
	   key_max  = (records[key_max].chemistry < records[i].chemistry) ? i : key_max;
	   printf("\n Highest chemistry mark = %u ", records[key_max].chemistry);
	 for (i = 0; i<num_students; ++i)
	   if(records[key_max].chemistry == records[i].chemistry)
	      printf("\n Highest chemistry mark, student[%d], rollno = %u, name = %s \n", i + 1, records[i].roll_no, records[i].name);
	 disp_char('-', 40);
	 break;
       case 't':
	 for(i = 1; i < num_students; ++i)
	    key_max = (records[key_max].total < records[i].total) ? i : key_max;
	 printf("\n Highest total mark = %u", records[key_max].total);
	 for(i = 0; i < num_students; ++i)
	    if(records[key_max].total == records[i].total)
	       printf("\n Highest total mark for students[%d], rollno = %u, name = %s \n", i  + 1, records[i].roll_no, records[i].name);
	 disp_char('-', 40);
	 break;
  }
  return;
}
