/* ********************************************************************
FILE                   :MUL_MAT.c

PROGRAM DESCRIPTION    : 2D matrix multiplications

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>
#include <math.h>
#include <conio.h>
#define MAX_ROW 5
#define MAX_COL 5
int main()
{
    int arr1[MAX_ROW][MAX_COL], arr2[MAX_ROW][MAX_COL], mul_arr[MAX_ROW][MAX_COL], to_iterate = 0;
	unsigned int row1, col1, row2, col2, i,j,k;
	clrscr();
	do
	{
	printf("\n Enter row for matrix 1, max = 5: ");
	scanf("%u", &row1);
	printf("\n Enter col for matrix 1, max = 5: ");
	scanf("%u", &col1);
	printf("\n Enter row for matrix 2, max = 5: ");
	scanf("%u", &row2);
	printf("\n Enter col for matrix 2, max = 5: ");
	scanf("%u", &col2);
	if((col1 == row2 ))
	{
		for(i =0; i<MAX_ROW;++i)
			for(j=0;j<MAX_COL;++j)
				mul_arr[i][j] = 0;
	printf("\n Enter MATRIX 1 values ");
	for(i = 0; i< row1; ++i)
	{
	   for(j = 0; j < col1; ++j)
	   {
	       printf("\n Enter val for row : %u, col: %u = ", i, j);
		   scanf("%d", &arr1[i][j]);
	   }
	} 
    printf("\n Enter MATRIX 2 values ");
	for(i = 0; i< row2; ++i)
	{
	   for(j = 0; j < col2; ++j)
	   {
	       printf("\n Enter val for row : %u, col: %u = ", i ,j);
		   scanf("%d", &arr2[i][j]);
	   }
	}  
	//printf("\n Mulplied Matrix values : \n ");
 	for(i = 0; i< row1; ++i)
	{
	    for(j = 0; j < col2; ++j)
	   {
		   for(k=0; k < row2; ++k)
		      mul_arr[i][j] += arr1[i][k] * arr2[k][j];
		   //printf(" %u \t",mul_arr[i][j] );
	   }
	   // printf("\n ");
	}
	}
	else
		printf("\n ERROR[01]: MATRIX mismatch");
	printf("\n Display MATRIX 1 values: \n");
    for(i = 0; i<row1; ++i)
	{
		for(j = 0;j<col1;++j)
		   printf("%u \t",arr1[i][j] );	
	    printf("\n");
	}	
    printf("\n Display MATRIX 2 values: \n");
    for(i = 0; i<row2; ++i)
	{
		for(j = 0;j<col2;++j)
		   printf("%u \t",arr2[i][j] );	
	   printf("\n");
	}
	printf("\n Display multiplied MATRIX values: \n");
    for(i = 0; i<row1; ++i)
	{
		for(j = 0;j<col2;++j)
		   printf("%u \t",mul_arr[i][j] );
	    printf("\n");
	}
	printf("\n Do u want to continue ? ");
	printf("\n Enter num = 1 to continue, any other number to exit. Continue? : ");
	scanf("%d",&to_iterate);	
   } while(to_iterate == 1);	
	getch();
	return 1;
}
