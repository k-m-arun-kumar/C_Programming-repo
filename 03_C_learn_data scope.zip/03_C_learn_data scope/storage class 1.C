/* ********************************************************************
FILE                   :  storage class 1.c

PROGRAM DESCRIPTION    : practise C coding in data scope 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

extern int check(float);
float* laugh(int);
char test(char []);
float fun(int);


extern int j;
int static k;

/* extern char ch[30]; */             /* link error: undefined ch  */
char ch[20];                          /* not assigned, '\0' is assigned */
int main()
{
  int l = 40;
  int n = 30 + l;

  /* long extern s = 23;  */          /* error: declaration syntax error   */
  /* extern int j = 9;    */          /* error: declaration syntax error  */
  int extern j;                       /* linker error: undefined j, if not defined before main */
  /* static int k = 5 + l; */         /* error: illegal initialization */
  static int k;

  clrscr();
  /* k = test("345");     */          /* error: undefined k, if define or declared before */
  fun(3);
  printf("\n ch = %s j = %d, k = %d, n = %d",ch, j,k,n);

}

/* static extern int k = 9; */     /* error: too many storage class in declaration */
/* static int k = 10 + j;   */     /* error: illegal initialization */
static int k = 10;

extern int check(float f)
 {
     int i = 45;
     printf("\n inside check");
     return i;
 }

float fun(int i)
{
  k += 40;
  j += 30;
  printf("\n inside fun: j = %d, k = %d ", j,k);
  return 3;
}

char test(char s[])
{

    int d;
    char c, ch[20];
    printf("\n INSIDE test func: ch = %s ", ch); /* ch garbage, if not assigned */

    return 'c';
}

/* int extern int j = 6; */           /* error: too many types in declaratin */
/* int extern j = 6;     */           /* error: if any id j is defined before it */
/* int extern j;         */           /* linker error: undefined j in declaration */
/* int extern j = 6 + 9 + k; */       /* error : illegal initialization */
int extern j = 6 + 9;

float* laugh(int h)
{
  printf("\n inside laugh func");
  return NULL;
}
