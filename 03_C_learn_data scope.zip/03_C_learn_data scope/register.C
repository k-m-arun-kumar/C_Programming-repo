/* ********************************************************************
FILE                   :  register.c

PROGRAM DESCRIPTION    : practise C coding in data scope 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdio.h"
#include <time.h>

int main()
{
    time_t startreg, finishreg;
    register char a[5] = "123" ;     /* fine */
    register float f = 56.8;
    register int i = 10, j = 10, *kptr;
    /* register *iptr = &i;   */   /* error: must take address of memory location */
    int k = 9,l ;

    kptr = &k;
   /* *kptr = &k; */               /* warning: non portable ptr conversion */

    clrscr();
    printf("\n enter number: ");
    /* scanf("%d", &i);  */        /* error: must take address of memory location */
    printf("\n i = %d, f = %f, a = %s, *kptr = %d", i, f, a, *kptr);

    time(&startreg);
    for(i = 0;  i < 30000; ++i )
      for(j = 0; j < 30000; ++j);
    time(&finishreg);
    printf("\n register decl. exec : %lf sec", difftime(finishreg, startreg));

    time(&startreg);
    for(k = 0; k < 30000; ++k)
      for(l = 0; l < 30000; ++l);
    time(&finishreg);
    printf("\n auto decl. exe      : %lf sec", difftime(finishreg, startreg));


}



