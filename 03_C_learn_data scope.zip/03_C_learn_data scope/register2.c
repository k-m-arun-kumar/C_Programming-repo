/* ********************************************************************
FILE                   :  register2.c

PROGRAM DESCRIPTION    : practise C coding in data scope 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

int a =5;

void process(int i)
{
   printf("\n entered number with auto: %d", i);
   return;
} 

void process_reg(register int i)
{
   printf("\n entered number with register: %d", i);
   return;
} 

void processptr(int *i)
{
   printf("\n entered number by auto ptr: %d", *i);
   return;
} 

void process_reg_ptr(register int *i)
{
   printf("\n entered number by register: %d", *i);
   return;
} 

int main()
{
   register int i = 10 ;
   int invar = 20; 
   register int *ptr = &invar;

   /* error:  &i invalid operation 
   int *reg = &i;  */

   
   /* run time error as it crashes
  /* printf("\n enter number: ");
   scanf("%d", i); */
   
   process(i); 
  process_reg(i);
  
   processptr(ptr); 
  process_reg_ptr(ptr);

   i = a;

  process(i); 
  process_reg(i);

   return 1;
}

