/* ********************************************************************
FILE                   :  XOR_SWAP.c

PROGRAM DESCRIPTION    : swap data using XOR operation

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and tested in Turbo C++
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include<stdio.h>
#include<conio.h>
int main()
{
clrscr();
int var1 = 10, var2=20;
printf("\n Enter var1 data = ");
scanf("%d", &var1);
printf("\n Enter var2 data = ");
scanf("%d", &var2);
var1 = (var1 ^ var2 ) ;
var2 = var1 ^ var2;
var1 = var1 ^ var2;
printf("\n swapped data: var1 = %d, var2 = %d", var1, var2);
getch();
return 1;
}
