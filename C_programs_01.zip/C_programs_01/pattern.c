/* ********************************************************************
FILE                   :  pattern.c

PROGRAM DESCRIPTION    : draw a pattern

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and tested in Turbo C++
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdio.h"
int main()
{
    int i = 0, j=0, k=0, l=0;
	for(i=0; i< 3; ++i)
	{ 
	     for(j =0; j < i+3; ++j)
	      printf("%d ",j + 1);
	     printf("\n"); 
	}	 
}

