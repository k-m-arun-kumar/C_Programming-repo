/* ********************************************************************
FILE                   :  ARM_ST.c

PROGRAM DESCRIPTION    : check to see if a number is armstrong number

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and tested in Turbo C++
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include <stdio.h>
#include <math.h>
#include <conio.h>
#define MAX_STR   10
#define DEBUG     01
void num_digits(unsigned int num);
unsigned int digits_arr[MAX_STR];
unsigned int digit_count = 0;
int main()
{
    unsigned int num, digits, to_iterate = 0, i = 0;
       unsigned int power =0, digit_power = 0;
	char str_num[MAX_STR];
	clrscr();
	do
	{
	power = 0;
	digit_count = 0;
	
	printf("\n Enter a  number : ");
	scanf("%u", &num);
	num_digits(num);
	 for	(i = 0; i < digit_count; ++i)
	{
		digit_power = pow(digits_arr[i],digit_count);
		power += digit_power;
		if(DEBUG)
		{
		   printf("\n [%u]: digit_power = %u, power = %u", i,digit_power,power);
		}
	}
	if(num ==  power)
	   printf("\n INFO[02]: %u is armstrong number", num);
	else
		printf("\n INFO[02]: %u is not a armstrong number", num);
	printf("\n Do you want to continue ? ");
	printf("\n Press 1 to continue, any other num to exit. Continue? : ");
	scanf("%u",&to_iterate);
	} while (to_iterate == 1);
	getch();
	return 1;

}

void num_digits(unsigned int num)
{
	unsigned int digits, temp_num = num;
	while(temp_num != 0)
	{
	digits = temp_num % 10;
	temp_num = temp_num - digits;
	temp_num /=10;

	digits_arr[digit_count] = digits;
	if(DEBUG)
	   printf("\n [%u] = %u ", digit_count, digits_arr[digit_count]);
	digit_count++;

	}
	return ;

}
