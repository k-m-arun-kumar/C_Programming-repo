/* ********************************************************************
FILE                   :  sample.c

PROGRAM DESCRIPTION    : display hello world

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and tested in Turbo C++
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdio.h"
int main()
{
	printf("\n hello world");
	return 1;
}
