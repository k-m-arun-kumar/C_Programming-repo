/* ********************************************************************
FILE                   :  ADD_MA~1.c

PROGRAM DESCRIPTION    : 2D martix addition

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and tested in Turbo C++
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include <stdio.h>
#include <math.h>
#include <conio.h>
#define MAX_ROW 5
#define MAX_COL 5
int main()
{
    int arr1[MAX_ROW][MAX_COL], arr2[MAX_ROW][MAX_COL], add_arr[MAX_ROW][MAX_COL], to_iterate = 0;
	unsigned int row, col,i,j;
	clrscr();
	do
	{
	printf("\n Enter row, max = 5: ");
	scanf("%u", &row);
	printf("\n Enter col, max = 5: ");
	scanf("%u", &col);
	printf("\n Enter MATRIX 1 values ");
	for(i = 0; i< row; ++i)
	{
	   for(j = 0; j < col; ++j)
	   {
	       printf("\n Enter val for row : %u, col: %u = ", i, j);
		   scanf("%d", &arr1[i][j]);
	   }
	} 
    printf("\n Enter MATRIX 2 values ");
	for(i = 0; i< row; ++i)
	{
	   for(j = 0; j < col; ++j)
	   {
	       printf("\n Enter val for row : %u, col: %u = ", i ,j);
		   scanf("%d", &arr2[i][j]);
	   }
	}  
	//printf("\n Added Matrix values ");
 	for(i = 0; i< row; ++i)
	{
	    for(j = 0; j < col; ++j)
	   {
	       add_arr[i][j] = arr1[i][j] + arr2[i][j] ;
		  // printf(" %u \t", add_arr[i][j] );
	   }
	   // printf("\n ");
	}
	printf("\n Display MATRIX 1 values: \n");
    for(i = 0; i<row; ++i)
	{
		for(j = 0;j<col;++j)
		   printf("%u \t",arr1[i][j] );	
	    printf("\n");
	}	
    printf("\n Display MATRIX 2 values: \n");
    for(i = 0; i<row; ++i)
	{
		for(j = 0;j<col;++j)
		   printf("%u \t",arr2[i][j] );	
	   printf("\n");
	}
	printf("\n Display Added MATRIX values: \n");
    for(i = 0; i<row; ++i)
	{
		for(j = 0;j<col;++j)
		   printf("%u \t",add_arr[i][j] );
	    printf("\n");
	}
	printf("\n Do u want to continue ? ");
	printf("\n Enter num = 1 to continue, any other number to exit. Continue? : ");
	scanf("%d",&to_iterate);	
   } while(to_iterate == 1);	
	getch();
	return 1;
}
