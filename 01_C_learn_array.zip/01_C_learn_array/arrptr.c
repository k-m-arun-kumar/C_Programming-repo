/* ********************************************************************
FILE                   : arrptr.c

PROGRAM DESCRIPTION    :  practise C coding in Array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  : Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#define ROW 5
#define COL 3
int arr[ROW][COL] = { {1,2,3},{10,20,30},{100,200,300},{ 1000,2000,3000}, {10000,20000,30000}};
int (*funcptrarr(float *fltptrarg))[COL];
int main()
{
        int *ptrarr[ROW] = {arr[0], arr[1]};
        int (*arrayptr)[COL] = arr + 2;

        int x, arr[8]={11,22,33,44,55,66,77,88};

        float flt = 9.0;
	printf("\n ptrarr[1][2] = %d, *(*(ptrarr+1)+2) = %d", ptrarr[1][2], *(*(ptrarr + 1) + 2));
	ptrarr[2]  = *arrayptr;
	printf("\n ptrarr[2][1] = %d, *(*(ptrarr+2)+1) = %d", ptrarr[2][1], *(*(ptrarr + 2) + 1));     
       
        arrayptr = funcptrarr(&flt);
        printf("\n \n just after funcptrarr call");
        printf("\n ================================");
        printf("\n arr[4][2] = %d, *(*(arrayptr + 1) + 2) = %d",arr[4][2] , *(*(arrayptr + 1) + 2));
       
        x = (arr+2)[3];
        printf("\n (arr+2)[3] = %d",x);  
        return 1;
}

/* funcptrarr is a function that takes formal argument as float pointer 
   and return a pointer to a 3 element one dimensional integer array */

int (*funcptrarr(float *fltptrarg))[COL]
{
  *fltptrarg = 18.0; 

  return(arr + 3);
}
