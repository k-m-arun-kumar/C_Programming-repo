/* ********************************************************************
FILE                   : array 1D pass.c

PROGRAM DESCRIPTION    : practise C coding in Array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdio.h"

int arr[1 + 2 + 2 < 3? 0: 2]  = { 10,20};
/* int array_fun(int [3][], int [1000], int, int, int); */
  /* cause redelaration if other than 2D array is used in its defination */

int array_fun(int [3], int [1000], int, int, int);

int main()
{
   int i = 0;
   int arr[3]  = {100,200};
   int array[4] = { 1,2,3};
  /* int array[0] = { 1,2,3,4,5}; */              /* cause corruption of data & at times crashing*/

   clrscr();
   while(i < sizeof(array)/sizeof(array[0]))
   {
      printf("\n array[%d]: %d", i, array[i]);
      ++i;
   }
   i = 0;
   while(i < sizeof(arr)/ sizeof(arr[0]))
   {
     printf("\n arr[%d]: %d", i, i[arr]);
     ++i;
   }
   arr[-2] = -500;                   /* cause data corruption due to invalid memory access */
   arr[9] = 900;

   /* arr[]  = {100,200};   */                  /* error: expr syntax*/
   /* array_fun(arr[], array, arr[-2], sizeof(arr)/ sizeof(arr[0]), sizeof(array)/sizeof(array[0]));  */
      /* error: expr syntax */

   array_fun(arr + 1, array, arr[-2], sizeof(arr)/ sizeof(arr[0]), sizeof(array)/sizeof(array[0]));
    /*passing array by pointer */
    /* run time: cause crashing of turbo C due to invalid memory access by defination array[0] */

    printf("\n after array_fun");
   i = 0;
   while(i < sizeof(array)/sizeof(array[0]))
   {
      printf("\n array[%d]: %d", i, array[i]);
      ++i;
   }
   i = 0;
   while(i < sizeof(arr)/ sizeof(arr[0]))
   {
     printf("\n arr[%d]: %d", i, i[arr]);
     ++i;
   }
   return 1;
}

/* mismatch of array paramters causes unexpected results here */
/* int array_fun(int array[2], int arr[], int var, int arrsize, int arraysize ) */
  /* error: type mismatch in redeclaration of array_fun, due to 2 D array parameter in its prototype */

int array_fun(int arr[2], int array[], int var, int arrsize, int arraysize )
{ /* some elements arr array is garbage */
  int i =0;

   printf("\n inside array_fun, size of arr[]: %d & array[]: %d, var : %d", sizeof(arr), sizeof(array),var);
   while(i < arraysize)
   {
      printf("\n array[%d]: %d", i, array[i]);
      ++i;
   }
   i = 0;
   while(i < arrsize)
   {
     printf("\n arr[%d]: %d", i, i[arr]);
     ++i;
   }
   *(array + i - 2) = 60;
   printf("\n array[%d]: %d", i - 2, array[i - 2]);
   fun_array(arr, 5);   /* cause some data corruption due to access excess array elements */
   return 1;
}

int fun_array(int arr[2], int arrsize)
{
  int i = 0;

   printf("\n inside fun_array: ");
  while (i < arrsize)
  {
    printf("\n arr[%d]: %d", i, arr[i]);
    ++i;
  }
  arr[6] = 1000;
  return 1;
}
