/* ********************************************************************
FILE                   : arrtest.c

PROGRAM DESCRIPTION    :  practise C coding in Array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  : Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#define ROW 2
#define COL 4
static int arrproc( int nrow, int ncol, int[][COL] );


int main()
{
   int i = 0, j= 0, nrow, ncol;
   static int b[][COL] = { { 10, 20 ,30}, { 3,6,9 } };
   nrow =sizeof b / COL / sizeof(int);
   ncol = sizeof b / ROW /sizeof(int);
   printf("\n nrow = %d, ncol = %d", nrow, ncol);
    printf("\n before process b array");
   for(i = 0; i < nrow; i = i + 1)
        for(j =0; j < ncol; ++j)
            printf("\n a[%d][%d] = %d", i + 1, j + 1, b[i][j]);
   arrproc(ROW, COL, b);
   printf("\n \n after process b in arrproc func");   
   for(i = 0; i < nrow; i = i + 1)
        for(j =0; j < ncol; ++j)
            printf("\n a[%d][%d] = %d", i + 1, j + 1, b[i][j]);   
       
   return 1;
}

static int arrproc(int nrow, int ncol, int c[][COL])
{
    int i = 0, j= 0;
    for(i = 0; i < nrow; i = i + 1)
        for(j =0; j < ncol; ++j)
            c[i][j] += 2;    
 return 1;                  
    
}
