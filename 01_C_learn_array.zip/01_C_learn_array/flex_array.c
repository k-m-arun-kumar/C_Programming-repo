/* ********************************************************************
FILE                   : flex_array.c

PROGRAM DESCRIPTION    : flexible size of array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

/* sizeof_3.c -- use of sizeof with flexible array member to a structure */
#include <stdio.h>
size_t flexsize(int n);
 
struct flexarray {
        char val;
        int array[];
        /* Flexible array member; must be last element of struct */
};
 
int main(void)
{
	int n = 0;
    size_t size; 
    int a = 1;
    int arr[10] = {1,2,3,4,5,6,7,8,9,10};
  /* sizeof is usually evealuted at compile time, with exception of variable length arrays where the length is specified at runtime. In such case, 
      the sizeof operator is evaluated in part at runtime to determine the storage occupied by the array. */
 /*  C says that sizeof returns a value of type size_t. This is an unsigned integer type, but not a brand-new type.
     Instead, like the portable types (int32_t and so on), it is defined in terms of the standard types.   */
    printf("\n enter nos of elements: ");
    scanf("%d", &n);
    size = flexsize(n);
    
    printf("\n size = %u", size);
    
    /* sizeof operator returns the size of the structure, including any padding, but without any storage allowed for the flexible array. */
    printf("\n sizeof(struct flexarray) = %u bytes\n",
            sizeof (struct flexarray));
            
   /*  when some expression is passed to sizeof operator, it returns the size of the type of first term in the expression and expression isn�t evaluated at all. */
    printf("size of int a and value of a in sizeof (a = 5) = %d bytes a = "
           "%d\n", sizeof (a = 5), a);
 
    printf("size of int a and value of a in sizeof (a++) = %d bytes a = %d\n",
            sizeof a++, a);
 
    printf("size of arr and  in sizeof (arr) = %d bytes & value of int arr[5] ="
           " %d\n", sizeof (arr), arr[5]);
 
    printf("size of arr and  sizeof (arr[0] = 10) = "
           "%d bytes & value of int arr[0] = %d\n", sizeof (arr[0] = 10), arr[0]);         
 
     
    return 0;
}

size_t flexsize(int n)
{
    char b[n+3];      /* Variable length array */
    return sizeof b;  /* Execution time sizeof */
}
 

