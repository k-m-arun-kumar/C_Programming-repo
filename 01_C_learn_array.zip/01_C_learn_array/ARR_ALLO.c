/* ********************************************************************
FILE                   : ARR_ALLO.c

PROGRAM DESCRIPTION    : practise string

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "string.h"
#include "conio.h"
int main()
{
   char str[] = "HELLO. I ALWAYS LOVE & TAKE CARE OF FAMILY, DO GOOD WORK WITH GOOD HEALTH, TAKE CARE OF THANKFUL PEOPLE, GOD, NATURE, LIVING THINGS, BLESS UNIVERSE TO LIVE WITH 16 SELVANGAL, GOOD KINDNESS, SPIRIT & SOUL PEOPLE, INDIA";
   unsigned int i = 0;
   clrscr();
   for (i = 0; i < strlen(str); ++i)
   {
     printf("%c", str[i]);
   }
   getch();
   return 1;
}
