/* ********************************************************************
FILE                   : arrptr2.c

PROGRAM DESCRIPTION    : practise C coding in Array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "stdio.h"
#include "malloc.h" // For memory allocation.

#define MAX_CARS 2
#define MAX_MODELS 3

int main(void);
int main()
{
   int var = {5};
   
   short  (*nPointer)[MAX_MODELS];
   int i,j;
   /* error : ch undefined
   char *cptr = &ch, ch; */
   char ch = 'a', *cptr = &ch;
   nPointer = (short (*) [MAX_MODELS]) malloc(MAX_CARS * sizeof(*nPointer));
   printf("\n nPointer = 0x%x", nPointer);
   /* NULL = (void *) 0x00 so i = (int) NULL causes  i = 0. ERROR if i = NULL */
   for (i = (int) NULL; i < MAX_CARS; i++)
   {
         
        for (j = 0; j < MAX_MODELS; j++)
        {
            nPointer[i][j] = (i * 100) + j;
        }
    }
    for (i = 0; i < MAX_CARS; i++)
    {
        for (j = 0; j < MAX_MODELS; j++)
        {
		printf("\n nPointer[%d][%d] = %d", i,j,nPointer[i][j] );
        }
    }
/* character constant occupies integer value of size in integer so, sizeof('\0') = sizeof(int) */
   printf("\n var = %d , sizeof(char) = %d, sizeof('\\0')= %d",var,  sizeof(char), sizeof('\0') );
   printf("\n sizeof(*cptr) = %d, sizeof(cptr) = %d", sizeof(*cptr),sizeof(cptr));
 /* sizeof(*nPointer) = 6 = sizeof(short) * MAX_MODELS */  
   printf("\n sizeof(short) = %d, sizeof(*nPointer) = %d, sizeof(nPointer) = %d", sizeof(short), sizeof(*nPointer), sizeof(nPointer)  );
   
   free(nPointer);   
   return 1;
}
