/* ********************************************************************
FILE                   : array & ptr.c

PROGRAM DESCRIPTION    : practise C coding in Array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "stdio.h"

int main()
{
   int arr[][4]  = {{100,200, 300},33,48,63,78,93};
   clrscr();

   printf("\n size of arr: %d, arr[0]: %d, no of arr elements: %d ", sizeof arr, sizeof arr[0], sizeof(arr)/ sizeof(arr[0][0]));
   printf("\n arr: %#X, arr[0]: %#X, arr[1]: %#X, no of col el: %d",arr, arr[0], arr[1], arr[1] - arr[0]);
   printf("\n *arr[1]: %d, arr + 1: %#X, *(arr + 1): %#X", *arr[1], arr + 1, *(arr + 1));
   printf("\n arr[6]: %#X, arr[0] +6: %#X, arr[1] + 2: %#X", arr[6],arr[0] + 6, arr[1] + 2);

   printf("\n \n &arr + 1: %#X, &arr[1]: %#X, &arr[1] + 1: %#X", &arr + 1, &arr[1], &arr[1] + 1 );
   printf("\n &(&arr[1]) + 1: %#X, &(&(&arr[1])) + 1: %#X, &(&(&arr[1])) + 10: %#X", \
     &(&arr[1]) + 1, &(&(&arr[1])) + 1, &(&(&arr[1])) + 10 );
   printf("\n arr[1]+ 2: %#X, &arr[1]+ 2: %#X, &(&arr[1]) + 2: %#X, &(&(&arr[1])) + 2: %#X",arr[1]+ 2,&arr[1]+ 2,&(&arr[1]) + 2,&(&(&arr[1])) + 2 );

   /* printf("\n &&arr[1]: %#X", &&arr[1]); */                  /* error: expr syntax */
   /* printf("\n &(&(&arr[1]) + 1): %#X", &(&(&arr[1])+1) ); */ /* error: must take memory address */
   /* printf("\n &(&(&arr[1]) + 1): %#X", &(&(&arr[1]+1)) ); */ /* error: must take memory address */
   /* printf("\n arr[0] + arr[1]: %#X", arr[0] + arr[1]); */    /* error: invalid ptr addition */

   printf("\n \n **arr: %d, *(*arr): %d, *arr: %#X", **arr,*(*arr),*arr);
   printf("\n *&arr + 2: %#X, arr + 2: %#X, *arr + 2: %#X", *&arr + 2, arr + 2, *arr + 2);
   printf("\n *(&arr + 2): %#X, *(arr + 1) + 2: %#X, *(&arr + 1) + 2: %#X", *(&arr + 2), *(arr + 1) + 2,*(&arr + 1) + 2);

   printf("\n \n &**arr: %#X, ***&arr: %d, &(&(&arr)): %#X ", &**arr, ***&arr, &(&(&arr)));
   printf("\n *(*(arr + 1) + 2): %#d, *(*arr + 1) + 2: %#d", *(*(arr + 1) + 2), *(*arr + 1) + 2);
   printf("\n *(arr[1] + 2): %#d, *(arr[1]) + 2: %d",*(arr[1] + 2), *(arr[1])+ 2);
   printf("\n *(arr + 1)[2]: %#X, 1[arr][2]: %d, (*(arr + 1))[2]: %d", *(arr + 1)[2],1[arr][2], (*(arr + 1))[2]);   

   /* printf("\n [1]arr[2]: %d ", [1]arr[2]); */  /* error: expr syntax */
   /* printf("\n [1][2]arr: %d", [1][2]arr); */   /* error: expr syntax */
   /* printf("\n 1[2][arr]: %d",1[2][arr]); */    /*error: invalid indirection */
   /* printf("\n ***arr: %d", ***arr); */         /*error: invalid indirection */
   /* printf("\n ***arr: %d", *(**arr)); */       /*error: invalid indirection */
   /* printf("\n ***arr: %d", *(*(*arr))); */     /*error: invalid indirection */
   /* printf("\n ***&*arr: %#X", ***&*arr ); */   /*error: invalid indirection */

   return 1;

}
