/* ********************************************************************
FILE                   : jaggedarr.c

PROGRAM DESCRIPTION    : practise C coding in Array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

int main()
{
  int *(arr1[3]) = { (int[]) {1, 2, 3}, (int[]) {10, 20, 30}, (int[]) {100, 200, 300} }; 
  /* error : initialize without casting and too many scalar elements */
  /* int *(arr1[]) = { {1, 2, 3}, {10, 20, 30}, {100, 200, 300} }; */
  
  /* jagged array with unequal nos of columns in each row */ 
  int *(arr2[5]) = { (int[]) {1, 2, 3, 4}, (int[]) {10, 20}, (int[]) {100, 200, 300}, (int[5]) {1000, 2000, 3000, 4000} ,(int[2]) {}}; 
  
  /* correct:  number of rows for arr2 is automatically set to 5 in this example */
  /* int *(arr2[]) = { (int[]) {1, 2, 3, 4}, (int[]) {10, 20}, (int[]) {100, 200, 300}, (int[5]) {1000, 2000, 3000, 4000} ,(int[2]) {}}; */
  
  /* error at run time due to absence of initialisation of 5th row elements (int[MAX_COL]) {} */
  /* int *(arr2[5]) = { (int[]) {1, 2, 3, 4}, (int[]) {10, 20}, (int[]) {100, 200, 300}, (int[5]) {1000, 2000, 3000, 4000} }; */
  
  /* sizecol contain 1 row of arr2 has 4 columns, 2 row has 2 columns , 3 row has 3 row, etc ie sizecol has arr2's nos of columns in each row */  
  int sizecol[] = { 4,2,3,5,2 }, i ,j, rows;
  
  for(i=0; i<3; i++) 
  {
       for( j=0; j<3; j++) 
            printf("\n arr1[%d][%d] Address: 0x%x Value: %d",i, j, &arr1[i][j], arr1[i][j]);

    printf("\n");
  }
 printf("\n sizeof arr1: %u , sizeof arr2 : %u, sizeof arr2[0] /sizeof(int) : %u", sizeof arr1, sizeof arr2, (sizeof arr2[0] / sizeof(int)) );
 
 arr2[3][4] = 5000;
 arr2[4][0] = 10000;
 
 /* rows variable contains number of rows in arr2 */
 rows = sizeof arr2 / sizeof(int *);
 for (i =0; i <  rows ; i++)
 {
   for (j = 0 ;j < sizecol[i] ; j++)
     /* array notation as arr2[i][j] can also be used to access each element */ 
      printf("\n arr2[%d][%d] Address: 0x%x Value: %d",i, j, &arr2[i][j], *(*(arr2 + i) + j));

    printf("\n");
  }
 return 1;
}
