/* ********************************************************************
FILE                   : arrptr1.c

PROGRAM DESCRIPTION    :  practise C coding in Array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  : Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

void display2DArrayUnknownSize(int *arr, int rows, int cols) 
{
for(int i=0; i<rows; i++) 
{
  for(int j=0; j<cols; j++) 
    printf(" row %d, col %d: %d", i,j,*(arr + (i*cols) + j));
  printf("\n");
}
return; 
}

int main()
{
int matrix[2][4] = { {1, 2, 3, 4}, {10, 20, 30, 40} };
   display2DArrayUnknownSize(&matrix[0][0], 2, 4);
   
}
