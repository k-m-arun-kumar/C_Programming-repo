/* ********************************************************************
FILE                   : array 2D Pass.c

PROGRAM DESCRIPTION    :  practise C coding in Array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  : Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "stdio.h"

int array_fun(int [4], int [1000], int, int );
/* int fun_array(int [][4], int ); */
  /* error: type mismatch if due  2D */
int fun_array(int [10][5], int);
int fun_array(int [0][5], int);

int main()
{
   int i = 0, j= 0;
   int array[4] = { 1,2,3};
   int arr[][4]  = {{100,200, 300},33,48,63,78,93};
   clrscr();

   printf("\n size of arr: %d, arr[0]: %d, no of arr elements: %d, arr: %#X", sizeof arr, sizeof arr[0], sizeof(arr)/ sizeof(arr[0][0]),arr);
   printf("\n");
   while(i < sizeof(array)/sizeof(array[0]))
   {
      printf(" array[%d]: %d", i, array[i]);
      ++i;
   }
   i = 0;
   printf("\n");
   while(i < sizeof(arr)/ sizeof(arr[0]))
   {
     j = 0;
     while (j < sizeof(arr[0])/sizeof(arr[0][0]))
     {
        printf(" arr[%d][%d]: %d", i, j, i[arr][j]);
        ++j;
     }
     printf("\n");
     ++i;
   }
   array_fun(arr[0] + 3, array, sizeof(arr)/ sizeof(arr[0][0]), sizeof(array)/sizeof(array));
     /* warning: suspicous ptr conv */

   printf("\n after array_fun");
   i = 0;
   printf("\n");
   while(i < sizeof(array)/sizeof(array[0]))
   {
      printf(" array[%d]: %d", i, array[i]);
      ++i;
   }

   i = 0;
   printf("\n\n");
   while(i < sizeof(arr)/ sizeof(arr[0]))
   {
     j = 0;
     while (j < sizeof(arr[0])/sizeof(arr[0][0]))
     {
        printf(" arr[%d][%d]: %d", i, j, i[arr][j]);
        ++j;
     }
     printf("\n");
     ++i;
   }
   return 1;
}


int array_fun(int arr[2], int array[], int arrsize, int arraysize )
{
  int i =0;

   printf("\n inside array_fun, arrsize: %d, arraysize: %d \n",arrsize, arraysize);
   while(i < arraysize)
   {
      printf(" array[%d]: %d", i, array[i]);
      ++i;
   }
   i = 0;
   printf("\n");
   while(i < arrsize)
   {
     printf(" arr[%d]: %d", i, i[arr]);
     ++i;
   }
   *(array + i - 2) = 60;
   printf("\n array[%d]: %d", i - 2, array[i - 2]);
   fun_array(arr, arrsize);
    /* warning: sucpicous ptr conv */
   return 1;
}

int fun_array(int arr[0][5], int arrsize)
{
  int i = 0,j = 0;

   printf("\n \n inside fun_array: sizeof(arr): %d, sizeof(arr[0]): %d",sizeof(arr), sizeof(arr[2]));

   printf("\n");
   while(i < arrsize/(sizeof(arr[0])/sizeof(arr[0][0])))
   {
     j = 0;
     while (j < sizeof(arr[0])/sizeof(arr[0][0]))
     {
        printf(" arr[%d][%d]: %d", i, j, i[arr][j]);
        ++j;
     }
     printf("\n");
     ++i;
   }
   arr[0][8] = 25;
  return 1;
}

