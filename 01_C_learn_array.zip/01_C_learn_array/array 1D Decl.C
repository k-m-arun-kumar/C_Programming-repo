/* ********************************************************************
FILE                   : array 1D Decl.c

PROGRAM DESCRIPTION    :  practise C coding in Array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  : Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "stdio.h"
int array_fun(int []);

int size = 10;

/* int arr[1 + 2 + 2 < 3? 0: 2] = { 10,20,30}; */
  /* error: too many initialization */

int arr[1 + 2 + 2 < 3? 0: 2]  = { 10,20};

int main()
{
  /* int arr[size] = { 1,2,3,4}; */   /* error: const expr req */
  /* int arr[3] = {{1,2,3}} ;  */     /* initialisation & declaration error */
  /* int arr[3] = {1,2,3,4}; */       /* error: too many initialization*/

   int i = 0;
   int array[1 + 2 + 2 > 3? 0: 2]  = { 1,2,3,4,5,6,7,8,9,10};
    /* no of elements depends on its initialisation */
    /* cause some data corruption due to access excess array elements */
  
   /* int arr1[1] = {100,200};*/  /* fine */
   int arr[4]  = {100,200};

   printf("\n sizeof array[]: %d", sizeof(array) );
   while(i < sizeof(array)/sizeof(array[0]))
   {
      printf("\n array[%d]: %d", i, array[i]);
      ++i;
   }
   i = 0;
   while(i < sizeof(arr)/ sizeof(arr[0]))
   {
     printf("\n arr[%d]: %d", i, i[arr]);
     ++i;
   }
   arr[-2] = -500;      /* cause some data corruption due to access invalid array elements */
   arr[9] = 900;
   printf("\n arr[-2]: %d, arr[9]: %d", arr[-2], arr[9]);
     /* fine */
   return 1;
}


