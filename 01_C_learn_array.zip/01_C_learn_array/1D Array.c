/* ********************************************************************
FILE                   : 1D Array.c

PROGRAM DESCRIPTION    : practise C coding in Array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "stdarg.h"
#include "stdlib.h"
#include "alloc.h"

int main()
{
   var_input("start",3, 4, -1);
}

int var_input(char *msg, ...)
{
   va_list argptr;
   int num, arr[10], count = 0, disp_count = -1;

   clrscr();
   memset(arr, 0 , sizeof(arr));
   va_start(argptr, msg);
   num = va_arg(argptr, int);
   while(num >= 0)
   {
	 *(arr + count++) = num;
     num = va_arg(argptr, int);
   }
   while(++disp_count < count)
     printf("\n arr[%d] = %d", disp_count, arr[disp_count]);
   va_end(argptr);
   return 1;
}
