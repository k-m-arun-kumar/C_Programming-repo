/* ********************************************************************
FILE                   : array 2D Decl.c

PROGRAM DESCRIPTION    : practise C coding in Array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
int array_fun(int []);

int size = 10;

int main()
{

   /* int array[3][] = {{100,200,300},1,2,3,4}; */    /* error: struc size unknown */
   /* int array[][4] = {100,200,300,{1,2,3}};  */     /* error: illegal initialization */
   /* int array[][3] = {{100,200,300,400},1,2,3}; */  /* error: too many initillization */
   /* int array[1][4] = {{ 100,200,300},1,2,3,4,5}; */ /* error: too many initillization */

   int arr[][4]  = {{100,200, 300},33,48,63,78,93};
   int i =0, j =0;

   clrscr();
   printf("\n sizeof arr: %d, arr[0]: %d ", sizeof(arr),sizeof(arr[0]) );

   printf("\n");
   while(i < sizeof(arr)/sizeof(arr[0]))
   {
      printf(" arr[%d]: %d", i, arr[i]);
      ++i;
   }

   i = 0;
   j = 0;
   printf("\n \n");
   while (j < sizeof(arr)/sizeof(arr[0][0]))
   {
       printf(" arr[%d][%d]: %d", i, j, i[arr][j]);
       ++j;
   }

   i = 0;
   printf("\n \n");
   while(i < sizeof(arr)/ sizeof(arr[0]))
   {
     j = 0;
     while (j < sizeof(arr[0])/sizeof(arr[0][0]))
     {
        printf(" arr[%d][%d]: %d", i, j, arr[i][j]);
        ++j;
     }
     printf("\n");
     ++i;
   }

   return 1;
}


