/* ********************************************************************
FILE                   : 1D Array & 1D Dynamic.c

PROGRAM DESCRIPTION    : practise C coding in Array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdio.h"
#include "stdlib.h"
#include "string.h"

typedef struct
{
  unsigned char var_datalen;
  void *var_databuff;
} var_data;

int main()
{
   Process_Data1();
   Process_Data2();
}

int Process_Data1()
{
    var_data exist_rec[5], *start_rec = &exist_rec[0];
    unsigned char num_targetrec;

    printf("\n Inside Process Data1 Func ");
    Insert_Data1(start_rec, sizeof(exist_rec)/sizeof(var_data), &num_targetrec);
    Delete_Data(&start_rec, &num_targetrec);
}

int Insert_Data1(var_data *get_targetrec, unsigned char max_rec, unsigned char *num_targetrec)
{
   void *alloc_ptr = NULL;
   char name[10];
   *num_targetrec = 0;

   do
   {
      printf("\n [%d]: Enter name: ",++*num_targetrec);
      scanf(" %s", name);
      if(!strcmp(name, "END") || *num_targetrec > max_rec )
      {
        printf("\n ERR[]: END or Total num matched target[%u] exceeds max [%u]", --*num_targetrec,max_rec);
        break;
      }
      alloc_ptr = malloc(strlen(name) + sizeof('\0'));
      memcpy(alloc_ptr, name, strlen(name) + sizeof('\0'));
      get_targetrec[*num_targetrec - 1].var_databuff = alloc_ptr;
      (get_targetrec + *num_targetrec - 1)->var_datalen = strlen(name) + sizeof('\0');

      printf("\n Entered Name: %s, Disp [%d], Alloc: %#X : Name: %s, name_len: %u",name, *num_targetrec,get_targetrec[*num_targetrec - 1].var_databuff,\
       (char *)(get_targetrec + *num_targetrec - 1)->var_databuff, (get_targetrec + *num_targetrec - 1)->var_datalen - sizeof('\0'));
      strcpy(name, "");
   } while(1);

   return 1;
}

int Delete_Data(void **var_dataptr, unsigned char *num_rec)
{
   unsigned char rec_count = -1;

   if(*var_dataptr)
   {
      while(++rec_count < *num_rec )
      {
         printf("\n Alloc: %#X, Name: %s, name_len: %u", (((var_data *)*var_dataptr) + rec_count)->var_databuff, \
          (char *)((var_data *)*var_dataptr)[rec_count].var_databuff, (((var_data *)*var_dataptr) + rec_count)->var_datalen - sizeof('\0'));
         free((((var_data *)*var_dataptr) + rec_count)->var_databuff);
      }
      return 1;
   }
   printf("\n ERR[25.2]: var_dataptr is NULL, to display its emp record");
   return 1;
}

int Process_Data2()
{
    var_data *rec = NULL;
    unsigned char num_rec =0;

    printf("\n Inside Process Data2 Func ");
    Insert_Data2(&rec, &num_rec);
    Delete_Data((void **)&rec, &num_rec);
    free(rec);
    return 1;
}

int Insert_Data2(void **rec, unsigned char *num_rec)
{
   unsigned char max_rec = 5;

   *rec = calloc(max_rec, sizeof(var_data));
   Add_Data2(*rec, num_rec, max_rec);
   return 1;
}

int Add_Data2(void *rec, unsigned char *num_rec, unsigned char max_rec)
{
   void *alloc_ptr = NULL;
   char name[10];
   *num_rec = 0;

   do
   {
      printf("\n [%d]: Enter name: ",++*num_rec);
      scanf(" %s", name);
      if(!strcmp(name, "END") || *num_rec > max_rec )
      {
        printf("\n ERR[]: END or Total num matched target[%u] exceeds max [%u]", --*num_rec, max_rec);
        break;
      }
      alloc_ptr = malloc(strlen(name) + sizeof('\0'));
      memcpy(alloc_ptr, name, strlen(name) + sizeof('\0'));
      (((var_data *)rec) + *num_rec - 1)->var_databuff = alloc_ptr;
      ((var_data *)rec)[*num_rec - 1].var_datalen = strlen(name) + sizeof('\0');
      printf("\n Entered Name: %s, Disp [%d], Alloc: %#X : Name: %s, name_len: %u",name, *num_rec, ((var_data *)rec)[*num_rec - 1].var_databuff,\
       (char *)((var_data *)rec + *num_rec - 1)->var_databuff, ((var_data *)rec + *num_rec - 1)->var_datalen - sizeof('\0'));
      strcpy(name, "");
   } while(1);
   return 1;
}
