/* ********************************************************************
FILE                   :const.c

PROGRAM DESCRIPTION    : practise C constants

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
int process_int(const int *ptr);
/* no error or warning even if process_const() prototype is declared,but not defined */

/* error: if *const ptr is the formal arg of process_const() */
int process_const( const void *const ptr);

int invar = 10, invar1 = 100, invar2  = 5, *ptrcon = &invar2;
int *const inptr = &invar;
const int *const constptr = &invar1;
int *const *varptr = &inptr;

int main()
{
    /* error: inptr cannot be assigned to other pointer or same initialized pointer 
	   as it as declared as int *const inptr = &invar 
	   
	inptr = &invar; */
	
	*inptr = 50;
	
	/* error: constptr cannot be assigned to other or same initialized pointer,
	   or cannot use be indrection operator on left side of assignment as below 
	   
	 *constptr = 500;
	constptr = &invar; */
	
	
	process_int(inptr);
	printf("\n after process_int() *inptr: %d", *inptr);
	process_const(ptrcon);
	printf("\n after process_const() *ptrcon: %d", *ptrcon);
	
	/* error: invalid operation of **invar1
	
	 printf("\n *constptr = %d", **invar1 ); */
	 
	 printf("\n *constptr = %d", *constptr );
 
	/* error: *varptr is read only location as it declared as  int *const 
	

	*varptr = ptrcon; */
	
	printf("\n **varptr = %d", **varptr );
 		
	 varptr = &inptr;
	
	
	**varptr = 300; 
	
	
	printf("\n inptr by varptr: %d, *inptr= %d, invar = %d", **varptr, *inptr, invar);
}

int process_int(const int *ptr)
{
   ptr = &invar1;
   printf("\n invar1 by ptr = %d", *ptr);
   
   /* error: cannot modify ptr as object is a const int if const int *ptr is declared
   
  *ptr = 1000; */
  
   return 1;
}

int process_const(const void *const ptr)
{
  /* error: ptr cannot be assigned to other pointer or same initialized pointer 
	 as it as declared as const void *const ptr = ptcon
  
  ptr = &invar; */

 
  *(int *)ptr = 5000;
  return 1;
}

