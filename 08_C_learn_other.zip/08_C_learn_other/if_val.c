/* ********************************************************************
FILE                   : if_val.c

PROGRAM DESCRIPTION    : practise of if statement 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

/*
 * mix_bool_int.c -- program displays ints being tested as boolean values
 */
#include <stdio.h>
#define TRUE 1
#define FALSE 0
 _Bool new_count();
int main(void) 
{
    int flag;
    _Bool okey;
    int count = 0;
 
    printf("\n User, type in some intger value...\n");
    scanf("%d", &flag);
 
    if (flag == FALSE)    /* if flag is zero or false */
    {
	     flag = (!flag);  /* set  flag = 1 */      
	     printf("\n flag = false");
	}
 
    if (flag == TRUE)     /* if flag is 10 or true */
    {
	    printf("\n flag = true");
	 }
     while ((okey = new_count()) == TRUE)
	 {
        printf("No of Iteration Count is %d\n", ++count);
     }
    return 0;
}

_Bool new_count()
{
    _Bool new;
    int a, b;
 
    printf("\n enter two intgers...\n");
    scanf("%d %d", &a, &b);
 
    if (a == b)
        return new = 1;
    else
        return new = 0;
}
