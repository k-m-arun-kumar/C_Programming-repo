/* ********************************************************************
FILE                   :enumoper.c

PROGRAM DESCRIPTION    : practise C enumerations

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdio.h"

int exvar = 4;

/* error: enum value for blue should be integer constant expression 
  
 enum flags { red, green, blue = exvar, yellow, orange, violet} enumvar = violet; */
 
enum flags { red, green, blue = 5, yellow, orange, violet} enumvar = violet, *enumptr = &enumvar;
int main()
{
    printf("\n enumvar :%d",enumvar );
    printf("\n enter two digit no: ");
	scanf("%d", &enumvar);
	
        /* enum data type occupies memory size of sizeof(int) */   
	printf("\n sizeof(enumvar): %d, enumvar after input = %d", sizeof(enumvar), enumvar);
	printf("\n enumvar after arithmetic = %d", (++enumvar % 10));
	
	*enumptr = exvar;
	printf("\n *enumptr = %d, enumvar = %d",*enumptr, enumvar);
	
    return 1;
}
