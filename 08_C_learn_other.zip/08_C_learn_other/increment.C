/* ********************************************************************
FILE                   :increment.c

PROGRAM DESCRIPTION    : practise C increment operator

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdio.h"
void funcarr(char *arr);

int main()
{
 int unsigned b = 32888;
 short s = 23;
 float f = 23.1;
 int i=1, k=1;
 char ch = 320;
 char a[] = "4rtrg";

 i = ++i;
 s = printf("\n b = %d, b = %ux, i = %d, i = %d, i = %d",\
     b, b, ++i, i ,i++  );

k = 1;
printf("\n k++ = %d k++ = %d k++ = %d", k++, k++, k++);

 printf("\ns = %d, f = %f, ch = %d", s, ++f, ++ch);
 for( f < 23.1 ;i <= 6; scanf("%d", &s))
 {
  printf("\n i = %d",i);

  i++;

 }
 for( ;;0);
   {
     int f = 27;

     printf("\n f = %d",f);
  }
   funcarr(&a);
}

void funcarr(char *arr)
{
  printf("\n funcarr: *arr = ", *arr);
  printf("\n *arr++ = %d", *arr++);
  printf("\n *arr++ = %d", *arr);
  printf("\n *arr++ = %d", *++arr);
}
