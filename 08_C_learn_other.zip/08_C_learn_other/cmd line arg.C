/* ********************************************************************
FILE                   :cmd line arg.c

PROGRAM DESCRIPTION    : practise C coding in command line arguments

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

/* int main(long a, char *argv[]) */      /* result not fine */
/* int main(char a, char *argv[]) */      /* fine */

/* int main(char *d[], char *b[], int c, int a) */  /* d has garbage  */

/* int main(int a, int c, char *b[]) */   /* b[] has garbage values */
/* int main(float a, char *b[], int c) */ /* run time: floating point error, terminate */

/* int main(char a, char *b, int c) */
 /* b[0]: program name b[1] = , b[2] = red, b[3] = , b[4] = yell, b[5] = , b[6] = arrow

/* int main(char a, char *b[], int c = 32)*/ /* run time: undefined main */
/* int main(char a, char b[3][2], int c)  */ /* b[], garbage */
/* int main(char a, char b[3][], int c)  */  /* error: size of array not known */
/* int main(char a, char *b[3], int c)  */   /* fine,a = 6 even for b[5] */
/* int main(char a, char b[3][10], int c) */ /* garbage */
/* int main(int a, char b[10][10], int c) */ /* garbage */
/* int main(char a, char *b[], int c) */
int main(int a, char *b[], int c)
{
  int count = 0;

  clrscr();
  printf("\n a = %d", a);

  /* for(count = 0; count < 10; ++count) */
     /* if a =6, then till b[5] is fine, b[6] = null, b[7]... = garbage  */

  for(count = 0; count < a; ++count)
    printf("\n argv[%d]: %s",count, b[count]);

  a = 2;
  c = 45;

  printf("\n a = %d, c = %d", a, c);

}

/* NOTE: assume cmd line arg: red yell arrow blue green dell */
/* if cmd line arg, red yell arrow "blue green" dell , then "blue green "
   is consiered as one parameter */  
