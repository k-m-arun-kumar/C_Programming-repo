/* ********************************************************************
FILE                   : comma.c

PROGRAM DESCRIPTION    : practise of comma operator

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>
int disp_b(int b);
int get_b(int *b_ptr);

int main()
{
     int a = 10, b = 20, c = 30;
    int x, y, z;
 
    printf("Value of exp. \"x = a + b, b + c, c + a;\" is %d\n", (x = a + b, b + c, c + a));
     /* value of x is value of rightmost sub-exp. c + a */
	 
	 printf("Value of exp. \"x = a + b, b + c, c + a;\" is %d\n", 
             x = a + b, b + c, c + a);
     /* value of x is value of leftmost sub-exp. a + b */
	 
	 x = a + b, y = b + c, z = c + a;
 
    printf("In x = a + b, y = b + c, z = c + a; x is %d y is %d"
           " and z is %d", x, y, z);
    /* above statement is same as x = a + b; y = b + c; z = c + a; */ 
	
	printf("The value of entire expression a + b, b + c, c + a" 
             " is %d\n", (a + b, b + c, c + a));
    printf("Value of the entire exp. a, a++, a++; is %d\n",
             (a, a++, a++));  
     /* exit loop by b < 0 or b > 100 */
	 while(get_b(&b) , disp_b(b),  b >= 0  && b <= 100 )
     {
     	 
	 }
        return 1;
}
int get_b(int *b_ptr)
{
	printf("\n enter num : ");
	scanf("%d", b_ptr);
	return 1;
}
int disp_b(int b)
{
	printf("\n entered : %d", b);
	return 1; 
}
