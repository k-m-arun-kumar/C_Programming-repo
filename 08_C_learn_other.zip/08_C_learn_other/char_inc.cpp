/* ********************************************************************
FILE                   : char_inc.c

PROGRAM DESCRIPTION    : 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.  
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>

int main()
{
	unsigned char num = 9;
	
	++num;
	printf("\n num = %u", num);
	return 0;
 } 
