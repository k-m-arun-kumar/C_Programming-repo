/* ********************************************************************
FILE                   :cmdline.c

PROGRAM DESCRIPTION    : practise C coding in  command line arguments

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "stdio.h"
#include "string.h"


/* when cmdline is executed as cmdline.exe "" "hello" world "india today",
  argg = 5, argf[0] = cmdline.exe, argf[1] =  , argf[2] = hello, argf[3] = world
  argf[4] = india today  */
   
 /* when cmdline is executed as cmdline.exe \"hello\" world, argg = 3, argf[0] = cmdline.exe, 
 argf[1] = "hello" , argf[2] = world */
 
/* when cmdline is executed as cmdline.exe h"ell"o, argg = 2, argf[0] = cmdline.exe, 
 argf[1] = hello */ 
  
int main(int argg, char *argf[])
{
   int i =0;
   char charr[20], *chptr;
   
    for(i = 0 ;i< argg; ++i)
	 printf("\n argf[%d]: %s", i, argf[i] );
	 
	strcpy(charr,argf[0] );
    printf("\n charr: %s",charr );
	
	chptr = argf[1];
	 printf("\n chptr: %s",chptr ); 
	
	 
    return 1;
}
