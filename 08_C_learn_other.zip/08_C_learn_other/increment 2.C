/* ********************************************************************
FILE                   :increment 2.c

PROGRAM DESCRIPTION    : practise C increment operator

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

int main()
{
 int unsigned b = 32888;
 short s = 23;
 float f = 23.1;
 int i=1;
 char ch = 320;
 char array[] = "12345";
void funcarr(char *);

 int x= 3, z, y
 ;

/* z= x----1; */ /* error, lvalue */
 z = x-- -1;
 printf("\n x = %d, z = %d", x,z);

 x = 3;
 z = ++x + x++;
 printf("\n x = %d, z = %d", x,z);

 x = 3;
 y = 6;
 z = 9;
 z -= -x-- - --y;
 /* z = x+++++x; */ /* error, lvalue */
 printf("\n x = %d, y = %d, z = %d", x,y,z);

 x = y = z =-1;
 x = ++x || ++y && ++z;
 printf("\n x= %d, y = %d, z= %d", x,y,z);

 x= 3;
 y = 4;
 z= 5;
 y= ++x - 4 || z - 5  && ++z;
 printf("\n x = %d, y = %d, z = %d", x,y,z);


funcarr(array);
}

void funcarr(char *arr)
{
  printf("\n funcarr: *arr = %c", *arr);
  printf("\n *arr++ = %c", *arr++);
  printf("\n *arr = %c", *arr);
  printf("\n *++arr = %c", *++arr);
  printf("\n *arr = %c", *arr);
}
             
