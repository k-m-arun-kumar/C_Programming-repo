/* ********************************************************************
FILE                   :enum.c

PROGRAM DESCRIPTION    : practise C enumerations

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

/* enum sample { yellow, green, green}; */  /* error: redecalration of green  */

int i = 40;
/* enum sample {yellow = -9 + 6, green, red = i, brown }; */  /* error: constant expr req */

enum sample { yellow = -9 + 6, green, red = 16, brown, blue} back = 4;

/* enum sample foreground = pick; */        /* error: pick undefined & illegal initialization */
/* sample foreground;   */                  /* error: dclaration syntax */
/* int yellow; */                           /* error: redecla yellow */
/* enum sample yellow; */                   /* error: redeclaration yellow */
/* enum sample foreground = green + i; */   /* error: illegal initialization */

enum sample foreground = green + red;
enum sample a = 32768;
enum sample *eptr = &a;
enum sample earr[3];

typedef struct
{
    int k;
    enum sample b;
}  stype;


int main()
{
   int yellow = 8;
   stype c = {2, brown};

   foreground = yellow;


   clrscr();
   /* printf("\n sample bytes: %d", sizeof enum sample); */ /* error: expression syntax */

   printf("\n sample; %d bytes, a = %d, yellow = %d, fore = %d, back = %d", \
      sizeof(enum sample), a, yellow, foreground, back);

   printf("\n enter number: ");
   scanf("%d", &back);

   /* scanf("%d", &green); */                    /* error: must take address of memory location */
   /* printf("\n stype: %d", sizeof stype); */   /* error: improper use of typedef */

   printf("\n stype: %d byte, c.b = %d, back = %d, back = %d", \
     sizeof(stype), c.b, back+= 250, back);

   back = check(eptr);
   printf("\n back = %d, a = %d", back, a);

   earr[0] = red;
   earr[1] = brown;
   earr[2] = yellow;
   printf("\n earr[0]: %d, earr[1]: %d, earr[2]: %d",\
    earr[0], earr[1], earr[2]);


}

int check(int *h)
{
   *h  = red;
   printf("\n *h = %d", *h);
   return blue;
}
