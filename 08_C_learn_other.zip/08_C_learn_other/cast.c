/* ********************************************************************
FILE                   : cast.c

PROGRAM DESCRIPTION    : data casting

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.


In any operation involving two types, both values are converted to the higher ranking of the two types.
The ranking of types, from highest to lowest, is long double, double, float, unsigned long long, long long, unsigned long, long, unsigned int, and int.
 One possible exception is when long and int are the same size, in which case unsigned int outranks long. 
 The short and char types dont appear in this list because they would have been already promoted to int or perhaps unsigned int. 
 
 Remember that any nonzero value in C is considered TRUE while 0 is considered FALSE. Since single bit storage is sufficient to store 1 or 0, 
 so new type _Bool can be used to store either TRUTH Value.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
typedef union _conversion 
	{
     float fNum;
     unsigned int uiNum;
    } Conversion;
	
int isPositive1(float number) ;	
double vector1[] = {1.1, 2.2, 3.3, 4.4};
double vector2[] = {1.1, 2.2, 3.3, 4.4};
double *vector3 = vector1;
void add(int size, double * restrict arr1, const double * restrict arr2);
main()
{
    int num, *pi;
	
    pi = &num;
    printf("\n Before: pi =  %p",pi);
	
    int tmp = (int)pi;
    pi = (int*)tmp;
    printf("\n After: pi = %p",pi);
	
	printf("\n ispostive()  =%d, %d", isPositive1(-3.7f), isPositive1(3.7f));
	add(4,vector1,vector2);
	

	add(4,vector1,vector3);
    add(4,vector1,vector1); 
for (int i = 0; i < sizeof(vector1)/ sizeof(double); i++) 
{
    printf("\n vector1[%d] = %lf", i, vector1[i]);
}
}
int isPositive1(float number) 
{
Conversion conversion = { .fNum = number};
return (conversion.uiNum & 0x80000000) == 0;
}
void add(int size, double * restrict arr1, const double * restrict arr2)
 {
for (int i = 0; i < size; i++) 
{
    arr1[i] += arr2[i];
	printf("\n arr1[%d] = %lf", i, arr1[i]);
}
}
