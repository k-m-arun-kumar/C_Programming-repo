/* ********************************************************************
FILE                   :  typedef.c

PROGRAM DESCRIPTION    : practise C in typedef operation

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
typedef int arr[3];
int process(float ft);
typedef int (*fptr)(float);
fptr funcprocess(fptr fptr);


int main()
{
   /* error: if arr is used as datatype without defination by typedef outside main() */
  /* typedef int arr[3]; */
   arr arr;
   
   /* ERROR: static and external storage class varible need to be intialised by constant expression */
  /* static int a = process(1.0); */
  
   arr[1]  = 20;
   int b = process(1.0), c;
   
   fptr ptr1 = funcprocess(process);
   ptr1(2.0);
   c = ptr1(3.0);
   printf("\n sizeof(arr) = %d, b = %d,arr[1] = %d", sizeof(arr),b,arr[1]);
   
  
   return 1;
}

int process(float ft)
{ 
    arr i;
	
	 printf("\n sizeof(arr) = %d, ft = %f", sizeof(arr), ft);
    return 1;
}

fptr funcprocess(fptr fptr)
{
   return fptr;
}
