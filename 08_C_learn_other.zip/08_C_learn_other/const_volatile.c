/* ********************************************************************
FILE                   : const_volatile.c

PROGRAM DESCRIPTION    : practise volatile data in C

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


int main(void) 
{ 
    volatile int local = 10; 
    int *ptr = (int*) &local; 
  
    printf("Initial value of local : %d \n", local); 
    local = 200;
    printf("Modified value of local directly: %d \n", local); 
    *ptr = 100; 
    printf("Modified value of local indirectly: %d \n", local); 
   
  
    return 0; 
} 
