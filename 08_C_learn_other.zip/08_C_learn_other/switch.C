/* ********************************************************************
FILE                   :  switch.c

PROGRAM DESCRIPTION    : practise C in switch operation

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

int main()
{
 int unsigned b = 32888;
 short s = 23;
 float f = 23.1;
 int i=1;
 char ch = 320;
 char a[] = "4rtrg";

/* break; */       /* error, due to misplaced break */
/* continue; */    /* error, due to misplaced continue */
 printf("\n switch experiment begins ");

/* 2 ==3 ? i= 2: i= 3; */  /* error, Lvalue req */

 switch(0)
 {
   i = i+1;
   printf("\n i = %d", i);

  case 0:

     printf("\n case 0");
     i++;
     break;
     printf("\n i = %d",i);
   case 1:
     printf("\n case 1");
   default:
     printf("\n switch:1, default 1");

  }
  switch(4.0)
  {
   /* case s = 2*2: */    /* error, requires constant expression */
     case 0==1 ||( 1< 2) + 3 :
      printf("\n switch 2: case 4:1");
      break;
      break;
  }

  switch('A')

    case 'A':
    
    printf("\n switch 3: case 7");
    printf("\n switch 3: i = %d", i);
    /*case 'B': */                         /* Error, case outside switch */
    printf("\n switch 3: case A");
   

 switch("1234")            /* warning: pointer no conversion */
  {
    case 4:
      printf("\n switch 4: case 4:1");
      break;
      printf("\n switch 2: case 4:2"); /* warning: will not be executed */
  }

  switch(7)
   case 8:
    printf("\n switch 3: case 7");
    printf("\n switch 3: i = %d", i);

switch('A')
{
    case 'A':
    
    printf("\n switch 3: case 7");
    printf("\n switch 3: i = %d", i);
    /* case '65': */                         /* Error, duplicate case */
    printf("\n switch 3: case A");
}
}
