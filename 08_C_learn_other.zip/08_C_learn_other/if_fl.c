/* ********************************************************************
FILE                   : if_fl.c

PROGRAM DESCRIPTION    : practise of if with floating point data

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>
int main(void)
{
     float x = 00.556678;
    int y;
	
    if (0.1)       /* floating point constant */
        printf("\n 0.1 ");
	if(0.0)
	    printf("\n 0.0 ");
	
 
    /* floating point val x is explicitly promoted to integer */
 
    if (y = (int)x)       
        printf("\n y = x ");
 
    printf("\n the values: x is %f and y is %d\n", x,y);	
    return 0;
}
