/* ********************************************************************
FILE                   :  sll_std.c

PROGRAM DESCRIPTION    : single linked list library
                              

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    NOT COMPLETED

NOTE                  :  
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "stdio.h"
#include "string.h"
#include "math.h"
#include "time.h"
#include "stdlib.h"
#include "sll.h"

/* ==============================================================

   Function Name : Map_HeadLinks(int, void* )
   Description   : Maps with head ptr of different linked lists
   Parameter     : gets input as headptr of linked list
   Remarks       : Currently, only Emp Head ptr is mapped with it
   Func_ID       : 2
================================================================= */

int Map_HeadLinks(int head_mode, void *headptr)
{
   switch(head_mode)
   {
      case EMP_HEAD:
	links_head[EMP_HEAD] = (struct megadata *) headptr;
	printf("\n TRACE[2.1]: links_head[%d]: %#x", EMP_HEAD, links_head[EMP_HEAD]);
        break;

      default:
        printf("\n ERR[2.1]: Invalid head mode = %d", head_mode);
        return 0;
   }
   return 1;
}


/* ==================================================================

   Function Name : Get_HeadLink(int head_mode, void *headptr)
   Description   : Gets head ptr
   Parameter     : provides headptr of linked list
   Remarks       : Currently, only Emp Head ptr is mapped with it
   Func_ID       : 3

=================================================================== */

int Get_HeadLink(int head_mode, void *headptr)
{
   switch(head_mode)
   {
       case EMP_HEAD:
          (struct megadata *)headptr = (struct megadata *) links_head[EMP_HEAD];
          break;

       default:
          printf("\n ERR[3.1]: Invalid head mode = %d", head_mode);
          return 0;
   }
   return 1;
}


/* ==================================================================

   Function Name : Create_List(int head_mode)
   Description   : creates a empty linked list
   Remarks       :
   Func_ID       : 4

=================================================================== */

int Create_List(int head_mode, void *ptr )
{
   int i = 0;
   struct megadata *megaptr;

   megaptr = ptr;

    /* Empty Linked list */

   megaptr->count = 0;
   megaptr->headptr = NULL;


   /* DISPLAY(trace_flag,("\n TRACE[4.1]: A single Linked List Initialised") ) */
   printf("\n TRACE[4.1A]: A SLL Initialised: Addr = %#x", megaptr);
   return 1;

}


/* ==================================================================

   Function Name : Trace_flag
   Description   : control trace flow 
   Remarks       : 
   fUNC_ID       : 7 

=================================================================== */

int Trace_flag(void)
{
   printf("\n 1: Use to Enable Global Trace : ");
   scanf("%d", &trace_flag);
   return 1;
}


/* ==================================================================

   Function Name : Validate_Data(int data_type, int min, int max, void *check_data)
   Description   : validates various data type, if data is valid, provided at return,
                   if invalid returns NULL.  
   Remarks       : min & max value must be used: indata_size is reserved for future use 
   fUNC_ID       : 8 

=================================================================== */

void* Validate_Data(int indata_type, int indata_size, int min, int max, int outdata_type, void *check_data)
{
   char temp_indata[OPER_SIZE];
   int temp_int;
   long int temp_lint;
   char check_data[OPER_SIZE];
   void *outdata = NULL;

   switch(indata_type)
   {
       case STRING_TYPE: 
          switch(outdata_type)
          {          
             case INT_TYPE:
                temp_indata = check_data;

                /*  rectify: if input starts with non numeric, it returns 0, confusion with numeric 0 */
                temp_int = atoi(temp_indata);   

                /* convert decimal to string */
                sprintf(check_data,"%d",temp_int );         
    
                /* check for numeric string such as "123" */
                if(!strcmp(check_data, temp_indata))
                {  
                    if( temp_int < min || get_ctrl > max )  
                    {
                       printf("\n ERR[8.1]: out of range numeric input: %d (min: %d, max: %d)", \
                          temp_int, min, max);                       
                    }     
                 } 
                 else
                 { 
                     printf("\n ERR[8.2]: Invalid input with non numeric: check_data[%s], temp_indata[%s]",check_data, temp_indata);                     
                 }
                 outdata = &temp_int;
                 break;

              case LINT_TYPE:
                temp_indata = check_data;

                /*  rectify: if input starts with non numeric, it returns 0, confusion with numeric 0 */
                temp_lint = atol(temp_indata);   

                /* convert long decimal to string */
                sprintf(check_data,"%ld",temp_lint );         
    
                /* check for numeric string such as "123" */
                if(!strcmp(check_data, temp_indata))
                {  
                    if( temp_int < min || get_ctrl > max )  
                    {
                       printf("\n ERR[8.3]: out of range numeric input: %d (min: %d, max: %d)", \
                          temp_lint, min, max);                         
                    }     
                 } 
                 else
                 { 
                     printf("\n ERR[8.4]: Invalid input with non numeric: check_data[%s], temp_indata[%s]",check_data, temp_indata);                     
                 }
                 outdata = &temp_lint;
                 break;

               default:
                 printf("\n ERR[8.5]: Invalid out data type: %d",outdata_type );
                 
           } 
          break; 
 
          default:
             printf("\n ERR[8.6]: Invalid in data type: %d",indata_type);             
               
   }
   return outdata;
 }
