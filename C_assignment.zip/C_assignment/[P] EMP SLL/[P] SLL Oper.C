/* ********************************************************************
FILE                   : SLL_Oper.c

PROGRAM DESCRIPTION    : Maintaining Employee's Record using Single Linked List.
                         ascending ordered based on unique value single linked list with 
                         operations of insert, delete, search, display and modify node of 
                         single linked list.
                         Emp id: 1 to 5 in one link, 6 to 10 in other link, etc till 20 
                              

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    NOT COMPLETED

NOTE                  :  
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "stdio.h"
#include "string.h"
#include "math.h"
#include "time.h"
#include "stdlib.h"

#define SIZE          100
#define NAME_SIZE      15
#define PHONE_SIZE     20
#define LINKS_SIZE     10
#define MEGADATA_SIZE  04 
#define EMP_HEAD       00
#define EMP_FIRST      00
#define MAX_EMP_ID    999
#define MIN_EMP_ID    001

#define MAX_OPER       04  /* add, delete, print, quit */
#define OPER_SIZE      20
#define QUIT_OPER      00
#define ADD_OPER       01
#define DELETE_OPER    02
#define PRINT_OPER     03

#define CHAR_TYPE      00
#define UCHAR_TYPE     01
#define INT_TYPE       02
#define UINT_TYPE      03
#define LINT_TYPE      04
#define ULINT_TYPE     05
#define FLOAT_TYPE     06
#define UFLOAT_TYPE    07
#define DOUBLE_TYPE    08
#define UDOUBLE_TYPE   09
#define LDOUBLE_TYPE   10
#define ULDOUBLE_TYPE  11
#define STRING_TYPE    12 

/* tracing execution flow */

#define TRACE_ON      1
int trace_flag = TRACE_ON;
#define DISPLAY(i,x)  if(i == TRACE_ON )  printf(x);

extern int Trace_flag(void);

struct megadata                            /* link control */
{
  int count;
  void *headptr;
};

struct employee
{
  long int emp_id;                        /* Emp Id as the key for emp linked list  */
  char emp_name[NAME_SIZE];
  char emp_phone[PHONE_SIZE];
};

struct employee_list                      /* data struct */
{
  struct employee emp_data;
  struct employee_list *nextptr;
};

typedef struct employee_list emp_record;

struct megadata mega_head[MEGADATA_SIZE];  /* contains head link for emp linked list */
void *links_head[LINKS_SIZE];              /* 0 points to emp's head link, rest is reserved */

/* function declaration */
extern int Create_EmpList(int head_mode );
extern int Create_List(int head_mode, void *ptr );
extern int Link_Menu(int head_mode);

extern int Add_EmpNode(int head_mode, struct employee );
extern int Delete_EmpNode(int head_mode, struct employee *);
extern int Print_EmpList(int head_mode );
extern int Destroy_List(int head_mode);

extern int Map_HeadLinks(int head_mode, void *headptr);
extern int Get_HeadLink(int head_mode, void *headptr);
extern int Search_List(int head_mode, void *target_key, void *preptr, void *curptr);

extern struct employee Get_EmpData(void);
extern void* Validate_Data(int indata_type,int indata_size,int min,int max,int outdata_type,void *check_data);

/* =========================================================

   Function name : main
   Description   : operation on Single Linked list
   Remarks       : None
   Func ID       : 1

=========================================================== */

int main()
{
  char control ;
  struct employee temp_emp;        /* Temp Emp data before processing */

  clrscr();

  /* initialise the head link for employees record */

  if(!Create_EmpList(EMP_HEAD))
  {
      printf("\n ERR[1.1]: Unable to create a list");
      exit(1);
  }

   /* Some Basic operation on Emp Single Linked list */
  do
  {

    control = Link_Menu(EMP_HEAD);

    Trace_flag();

    /*
    switch( control)
    {
      case ADD_OPER:
	temp_emp = Get_EmpData();
	if(!Add_EmpNode(EMP_HEAD, temp_emp))
	{
	    printf("\n ERR[1.3]: Unable to add Employee Data ");
	    continue;
	}
	break;

      case DELETE_OPER:
	 printf("\n Enter Emp Id (key) to be deleted : ");
         scanf("%D",&temp_emp.emp_id);

	 if(!Delete_EmpNode(EMP_HEAD, &temp_emp))
	 {
	     printf("\n ERR[1.5]: Unable to Delete Emp Node");
	     continue;
	 }
	 break;

      case PRINT_OPER:
	 if(!Print_EmpList(EMP_HEAD)
	 {
	     printf("\n ERR[1.6]: Unable to print Emp List");
	     continue;
	 }
	 break;


      case QUIT_OPER:
	 if(!Destroy_EmpList(EMP_HEAD)
	 {
	    printf("\n ERR[1.7]: Unable to Destroy Emp List");
	 }
	 break;

      default:
	 printf("\n ERR[1.2]: Illegal Linked list operation: %d", control);
     }
       */

  } while(control != QUIT_OPER );


 return 1;

}

/* ==============================================================

   Function Name : Map_HeadLinks(int, void* )
   Description   : Maps with head ptr of different linked lists
   Parameter     : gets input as headptr of linked list
   Remarks       : Currently, only Emp Head ptr is mapped with it
   Func_ID       : 2
================================================================= */

int Map_HeadLinks(int head_mode, void *headptr)
{
   switch(head_mode)
   {
      case EMP_HEAD:
	links_head[EMP_HEAD] = (struct megadata *) headptr;
	printf("\n TRACE[2.1]: links_head[%d]: %#x", EMP_HEAD, links_head[EMP_HEAD]);
        break;

      default:
        printf("\n ERR[2.1]: Invalid head mode = %d", head_mode);
        return 0;
   }
   return 1;
}


/* ==================================================================

   Function Name : Get_HeadLink(int head_mode, void *headptr)
   Description   : Gets head ptr
   Parameter     : provides headptr of linked list
   Remarks       : Currently, only Emp Head ptr is mapped with it
   Func_ID       : 3

=================================================================== */

int Get_HeadLink(int head_mode, void *headptr)
{
   switch(head_mode)
   {
       case EMP_HEAD:
          (struct megadata *)headptr = (struct megadata *) links_head[EMP_HEAD];
          break;

       default:
          printf("\n ERR[3.1]: Invalid head mode = %d", head_mode);
          return 0;
   }
   return 1;
}


/* ==================================================================

   Function Name : Create_List(int head_mode)
   Description   : creates a empty linked list
   Remarks       :
   Func_ID       : 4

=================================================================== */

int Create_List(int head_mode, void *ptr )
{
   int i = 0;
   struct megadata *megaptr;

   megaptr = ptr;

    /* Empty Linked list */

   megaptr->count = 0;
   megaptr->headptr = NULL;


   /* DISPLAY(trace_flag,("\n TRACE[4.1]: A single Linked List Initialised") ) */
   printf("\n TRACE[4.1A]: A SLL Initialised: Addr = %#x", megaptr);
   return 1;

}


/* ==================================================================

   Function Name : Create_EmpList(int head_mode)
   Description   : creates a empty linked list for emp mega mode
   Remarks       :
   Func_ID       : 5

=================================================================== */

int Create_EmpList(int head_mode)
{
   int i = 0;

   /* map links_head[0] to address of megadata node */
   if(!Map_HeadLinks(head_mode, &mega_head[EMP_FIRST] ))
   {
         /* error state in mapping */
          return 0;
   }

   while(i < MEGADATA_SIZE)
   {
        if(!Create_List(head_mode, (&mega_head[EMP_FIRST] + i) ))
        {
           /* error state in creating list */
           return 0;
	}
	printf("\n TRACE[5.1A]: Emp Mega HLL Initialise: Addr = %#x", &mega_head[EMP_FIRST] + i);
        ++i;
   }
  /* DISPLAY(trace_flag,("\n TRACE[5.1]: Emp Mega Head Linked List Initialised: %d", i ) ) */
   return 1;
}


/* ==================================================================

   Function Name : Link_Menu(int head_mode)
   Description   : get & valid input code for single linked list operation
   Remarks       :
   fUNC_ID       : 6

=================================================================== */

int Link_Menu(int head_mode)
{
  char get_oper[OPER_SIZE];
  char check_oper[OPER_SIZE];
  int *get_ctrl;


  printf("\n MENU for Single Linked List Operation in Emp record :- ");
  printf("\n 1: Add a Emp record  \n 2: Delete a Emp record \n 3: Display Emp records \n 0: Quit");

  printf("\n \n Enter your chioce: ");
  scanf(" %s",get_oper);

  if((get_ctrl = (int *) Validate_Data(STRING_TYPE, OPER_SIZE, 0, MAX_OPER - 1, INT_TYPE, get_oper )) != NULL)
     return *get_ctrl;
  else
     /* invalid input data */
     return -1;
}


/* ==================================================================

   Function Name : Trace_flag
   Description   : control trace flow 
   Remarks       : 
   fUNC_ID       : 7 

=================================================================== */

int Trace_flag(void)
{
   printf("\n 1: Use to Enable Global Trace : ");
   scanf("%d", &trace_flag);
   return 1;
}


/* ==================================================================

   Function Name : Validate_Data(int data_type, int min, int max, void *check_data)
   Description   : validates various data type, if data is valid, provided at return,
                   if invalid returns NULL.  
   Remarks       : min & max value must be used: indata_size is reserved for future use 
   fUNC_ID       : 8 

=================================================================== */

void* Validate_Data(int indata_type, int indata_size, int min, int max, int outdata_type, void *check_data)
{
   char temp_indata[OPER_SIZE];
   int temp_int;
   long int temp_lint;
   char check_data[OPER_SIZE];
   void *outdata = NULL;

   switch(indata_type)
   {
       case STRING_TYPE: 
          switch(outdata_type)
          {          
             case INT_TYPE:
                temp_indata = check_data;

                /*  rectify: if input starts with non numeric, it returns 0, confusion with numeric 0 */
                temp_int = atoi(temp_indata);   

                /* convert decimal to string */
                sprintf(check_data,"%d",temp_int );         
    
                /* check for numeric string such as "123" */
                if(!strcmp(check_data, temp_indata))
                {  
                    if( temp_int < min || get_ctrl > max )  
                    {
                       printf("\n ERR[8.1]: out of range numeric input: %d (min: %d, max: %d)", \
                          temp_int, min, max);                       
                    }     
                 } 
                 else
                 { 
                     printf("\n ERR[8.2]: Invalid input with non numeric: check_data[%s], temp_indata[%s]",check_data, temp_indata);                     
                 }
                 outdata = &temp_int;
                 break;

              case LINT_TYPE:
                temp_indata = check_data;

                /*  rectify: if input starts with non numeric, it returns 0, confusion with numeric 0 */
                temp_lint = atol(temp_indata);   

                /* convert long decimal to string */
                sprintf(check_data,"%ld",temp_lint );         
    
                /* check for numeric string such as "123" */
                if(!strcmp(check_data, temp_indata))
                {  
                    if( temp_int < min || get_ctrl > max )  
                    {
                       printf("\n ERR[8.3]: out of range numeric input: %d (min: %d, max: %d)", \
                          temp_lint, min, max);                         
                    }     
                 } 
                 else
                 { 
                     printf("\n ERR[8.4]: Invalid input with non numeric: check_data[%s], temp_indata[%s]",check_data, temp_indata);                     
                 }
                 outdata = &temp_lint;
                 break;

               default:
                 printf("\n ERR[8.5]: Invalid out data type: %d",outdata_type );
                 
           } 
          break; 
 
          default:
             printf("\n ERR[8.6]: Invalid in data type: %d",indata_type);             
               
   }
   return outdata;
 }
   
/* ==================================================================

   Function Name : Get_EmpData(void)
   Description   : get emp id & emp name 
   Remarks       : 
   fUNC_ID       : 9 

=================================================================== */

struct employee Get_EmpData(void)
{
   struct employee get_empdata;
   char get_empid[OPER_SIZE];
   long int *emp_id;
   char check_oper[OPER_SIZE];

   printf("\n Enter Employee's ID : ");
   scanf(" %s", &get_data);
    
   if((emp_id = (long int *) Validate_Data(STRING_TYPE, OPER_SIZE, MIN_EMP_ID, MAX_EMP_ID, LINT_TYPE, get_empid )) != NULL)
   {
      printf("\n Enter Employee's name having emp_id: %d", *emp_id);
      scanf(" %s", get_empdata.emp_name);
      get_empdata.emp_id = *emp_id;
   }
   else
   {
     /* invalid input data */
     return -1;
   }
   return get_empdata;
}
