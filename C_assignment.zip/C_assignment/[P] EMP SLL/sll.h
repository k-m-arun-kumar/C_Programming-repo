/* ********************************************************************
FILE                   : sll.h

PROGRAM DESCRIPTION    : single linked list header                              

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :   

NOTE                  :  
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "stdio.h"
#include "string.h"
#include "math.h"
#include "time.h"
#include "stdlib.h"

#define SIZE          100
#define NAME_SIZE      15
#define PHONE_SIZE     20
#define LINKS_SIZE     10
#define MEGADATA_SIZE  04 
#define EMP_HEAD       00
#define EMP_FIRST      00

#define MAX_OPER       04  /* add, delete, print, quit */
#define OPER_SIZE      20
#define QUIT_OPER      00
#define ADD_OPER       01
#define DELETE_OPER    02
#define PRINT_OPER     03

#define CHAR_TYPE      00
#define UCHAR_TYPE     01
#define INT_TYPE       02
#define UINT_TYPE      03
#define LINT_TYPE      04
#define ULINT_TYPE     05
#define FLOAT_TYPE     06
#define UFLOAT_TYPE    07
#define DOUBLE_TYPE    08
#define UDOUBLE_TYPE   09
#define LDOUBLE_TYPE   10
#define ULDOUBLE_TYPE  11
#define STRING_TYPE    12 

/* tracing execution flow */

#define TRACE_ON      1
#define DISPLAY(i,x)  if(i == TRACE_ON )  printf(x);


struct megadata                            /* link control */
{
  int count;
  void *headptr;
};

struct employee
{
  long int emp_id;                        /* Emp Id as the key for emp linked list  */
  char emp_name[NAME_SIZE];
  char emp_phone[PHONE_SIZE];
};

struct employee_list                      /* data struct */
{
  struct employee emp_data;
  struct employee_list *nextptr;
};

typedef struct employee_list emp_record;


/* extern variable declaration */
extern int trace_flag;
extern struct megadata mega_head[MEGADATA_SIZE];  /* contains head link for emp linked list */
extern void *links_head[LINKS_SIZE];              /* 0 points to emp's head link, rest is reserved */


/* function declaration */
extern int Create_EmpList(int head_mode );
extern int Create_List(int head_mode, void *ptr );
extern int Link_Menu(int head_mode);

extern int Add_EmpNode(int head_mode, struct employee );
extern int Delete_EmpNode(int head_mode, struct employee *);
extern int Print_EmpList(int head_mode );
extern int Destroy_List(int head_mode);

extern int Map_HeadLinks(int head_mode, void *headptr);
extern int Get_HeadLink(int head_mode, void *headptr);
extern int Search_List(int head_mode, void *target_key, void *preptr, void *curptr);

extern struct employee Get_EmpData(void);
extern void* Validate_Data(int indata_type,int indata_size,int min,int max,int outdata_type,void *check_data);

extern int Trace_flag(void);

