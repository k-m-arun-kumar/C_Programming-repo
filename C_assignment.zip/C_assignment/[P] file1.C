/* ********************************************************************
FILE                   : file 1.c

PROGRAM DESCRIPTION    : practise C coding in functions

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    NOT COMPLETED. 

NOTE                  :  
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "file2.C"

int l;
extern int test(void);

int main()
{
  int l = 56;

  printf("\n inside main \n l = %d",l );
  l = test();

}

static int k;

int test(void)
{
   printf("\n inside test fun \ n k = %d", k);
   return 34;

}


