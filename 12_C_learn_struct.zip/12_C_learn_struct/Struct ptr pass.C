/* ********************************************************************
FILE                   :  Struct ptr pass.c

PROGRAM DESCRIPTION    : practise C coding in structure

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#define CONTINUE 2
#define QUIT     1
typedef struct
{
   int num;
   char ch;
} data;

unsigned menu1(void);
unsigned char menu2(void);

int main()
{
   data st_data;
   int int_data;
   unsigned oper1;
   unsigned char oper2;

   initialize(&st_data, &int_data);
   printf("\n after initial func: &st_data: %#X, st_data.num: %d, st_data.ch: %c, &int_data: %#X, int_data: %d", \
     &st_data,st_data.num,st_data.ch, &int_data, int_data);
   do
   {
	   oper1 = menu1();
	   switch(oper1)
	   {
		   case CONTINUE:
		     process(&st_data, &int_data);
		     printf("\n inside sw 1: &st_data: %#X, st_data.num: %d, st_data.ch: %c, &int_data: %#X, int_data: %d", \
               &st_data,st_data.num,st_data.ch, &int_data, int_data);
			 break;
           case QUIT:
             printf("\n Quit switch 1");
             break;
	   }
   }while (oper1 != QUIT);

   initialize(&st_data, &int_data);
   printf("\n after initial func: &st_data: %#X, st_data.num: %d, st_data.ch: %c, &int_data: %#X, int_data: %d", \
     &st_data,st_data.num,st_data.ch, &int_data, int_data);

  /* do
   {
   	   oper2 = menu2();
   	   switch(oper2)
   	   {
   		   case CONTINUE:
   		     /* &st_data, &int_data given to process is garbage and even outside
   		        switch 2, &st_data, &int_data is garbage //
   		     process(&st_data, &int_data);
   			 printf("\n inside sw 2: &st_data: %#X, st_data.num: %d, st_data.ch: %c, &int_data: %#X, int_data: %d", \
              &st_data,st_data.num,st_data.ch, &int_data, int_data);
             break;
            case QUIT:
             printf("\n Quit switch 2");
             oper2 = QUIT;
             break;
   	   }
   }while (oper2 != QUIT);*/  /* cause infinite loop, even if quit is given. assign QUIT in case QUIT, helps to come out of while loop */

   /* do
   {
	   oper1 = menu1();
	   if(oper1 == CONTINUE)
	   {
		   process(&st_data, &int_data);
		     printf("\n inside if 1: &st_data: %#X, st_data.num: %d, st_data.ch: %c, &int_data: %#X, int_data: %d", \
               &st_data,st_data.num,st_data.ch, &int_data, int_data);
       }
       else if(oper1 == QUIT)
             printf("\n Quit if 1 based ");
   } while (oper1 != QUIT);*/

   /* do
      {
   	   oper2 = menu2();
   	   if(oper2 == CONTINUE)
   	   {  /* &st_data, &int_data given to process is garbage and even outside
   		   switch 2, &st_data, &int_data is garbage //
   		   process(&st_data, &int_data);
   		     printf("\n inside if 2: &st_data: %#X, st_data.num: %d, st_data.ch: %c, &int_data: %#X, int_data: %d", \
                  &st_data,st_data.num,st_data.ch, &int_data, int_data);
          }
          else if(oper2 == QUIT)
                printf("\n Quit if 2 based ");
   } while (oper2 != QUIT); */
   /* same case with unsigned char in switch, except that even if
      continue is given comes out of loop & quit works fine */

  /* oper2 = menu2();
   switch(oper2)
   {
      case CONTINUE:
   	    /* &st_data, &int_data given to process is garbage and even outside
   		        switch 2, &st_data, &int_data is garbage //
   	    process(&st_data, &int_data);
   	    printf("\n inside sw 2: &st_data: %#X, st_data.num: %d, st_data.ch: %c, &int_data: %#X, int_data: %d", \
        &st_data,st_data.num,st_data.ch, &int_data, int_data);
        break;
   } */

   /* oper2 = menu2();
   if(oper2 == CONTINUE)
   {   /* &st_data, &int_data given to process is garbage and even outside
   		   switch 2, &st_data, &int_data is garbage //
      process(&st_data, &int_data);
      printf("\n inside if 2: &st_data: %#X, st_data.num: %d, st_data.ch: %c, &int_data: %#X, int_data: %d", \
        &st_data,st_data.num,st_data.ch, &int_data, int_data);
   } */

   initialize(&st_data, &int_data);
   printf("\n after initial func: &st_data: %#X, st_data.num: %d, st_data.ch: %c, &int_data: %#X, int_data: %d", \
     &st_data,st_data.num,st_data.ch, &int_data, int_data);

   return 1;
}

int initialize(data *st_ptr, int *int_ptr)
{
  st_ptr->num = 30;
  st_ptr->ch  = 'B';
  *int_ptr = 25;
  printf("\n inside initialize: st_ptr: %#X, st_ptr->num: %d, st_ptr->ch: %c, int_ptr: %#X, *int_ptr: %d", \
    st_ptr,st_ptr->num,st_ptr->ch,int_ptr,*int_ptr);
  return 1;
}

int process(data *st_ptr, int *int_ptr)
{
	int num;

	printf("\n before process: st_ptr: %#X, st_ptr->num: %d, st_ptr->ch: %c, int_ptr: %#X, *int_ptr: %d", \
    st_ptr,st_ptr->num,st_ptr->ch,int_ptr,*int_ptr);
    ++st_ptr->ch;
    num = st_ptr->num;
    *int_ptr = 101;
    printf("\n after process: st_ptr: %#X, st_ptr->num: %d, st_ptr->ch: %c, int_ptr: %#X, *int_ptr: %d, num = %d", \
    st_ptr,st_ptr->num,st_ptr->ch,int_ptr,*int_ptr, num);
    return 1;
}

unsigned menu1(void)
{
	unsigned oper;

	printf("\n CONTINUE: 2, QUIT: 1: Enter: ");
	scanf("%u", &oper);
	return oper;
}

unsigned char menu2(void)
{
	unsigned char oper;

	printf("\n CONTINUE: 2, QUIT: 1: Enter: ");
	scanf("%u", &oper);
	return oper;
}

