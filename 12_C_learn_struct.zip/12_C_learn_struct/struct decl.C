/* ********************************************************************
FILE                   :  struct decl.c

PROGRAM DESCRIPTION    : practise C coding in structure

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

/* #include " stdio.h" */   /* error: unable to open stdio.h */

#include "stdio.h"
#include "stdio.h"

/* extern struct tag */     /* fine */
static struct tag
{
 int a;
 float b;
 char name[10];
};

typedef struct tag tag;
/* struct tag tag; */                /* error: redecl of tag */

struct test
{
  int a;
  char name [15];
  tag tag;
} sttest[] = {23, "india", 45, 25.6,"jai hind", 24  }, *sptr;

struct tag stvar[] = { { 57, 78}, {45}, 89, 35,"hello", 102, 34.5,"wel" };

/* struct tag stvar[] = { {{ 57, 78}, {45}, 89, 35,"hello", 102, 34.5,"wel" }}; */
  /* error: initailizer syntax & decla syntax */

typedef short SHORT[3];

int main()
{
   extern struct sample
   {
      int a;
      tag tag;
   } stauto /* = {23, 45, 67.9, "jai hind" } */ ;
       /* Error: decla syntax, due to initialize of auto class struct */

    struct test       /* overrides struct test define above */
    {
      int a;
    } ;

    struct test st;

    int a = 107;
    SHORT b;
    struct tag tag[2];           /* overrides tag as datatype, being treated as array */

   /* extern struct sample sample; */      /* Linker error: undefined sample */

  /* typedef struct sample sample; */      /* error: cause redecl of sample, below */
   struct sample sample;

  /* typedef struct sample sample; */      /* error: redecl of sample */

  /* printf("\n enter a number: ");
   scanf("%d", &sample.a); */

   /* scanf("%d". &sample.b); */           /* warning: b not a part of struct */

   printf("\n a = %d, sizeof sttest : %d, sample members: a = %d",\
     a, sizeof sttest, sample.a);     /* sample.a: garbage */

   for(a = 0; a < 3; ++a )
   {
     b[a] = a + 3;
     printf("\n b[%d] = %d",a, b[a]);
   }

  /* for (a = 0; a < sizeof(stvar)/sizeof(tag); ++a )
      printf("\n stvar[%d].a : %d, stvar[%d].b = %f, stvar[%d].name = %s", \
     a, stvar[a].a, a, stvar[a].b, a, stvar[a].name);  */
       /* tag, in this case is treated as a array rather a datatype */

  for (a = 0; a < sizeof(stvar)/sizeof(struct tag); ++a )
      printf("\n stvar[%d].a : %d, stvar[%d].b = %f, stvar[%d].name = %s", \
     a, stvar[a].a, a, stvar[a].b, a, stvar[a].name);

   /* sample = {24, 28, 34.7, "india" }; */  /* error: expr syntax */

   /* printf("\n sample: a = %d, tag.a : %d, tag.b: %f,\
     tag: %s", test.a, sample.tag.a, sample.tag.b, sample.tag.name); */

   /* printf("\n test: %d, name: %s ", st.a, st.name); */
     /* error: ambigous name*/

}

/* int check(struct sample) */   /* error: undefined sample */
/* { */                          /* error: decl syntax error */

int check(struct tag tag)
{

}

