/* ********************************************************************
FILE                   :  struct2.c

PROGRAM DESCRIPTION    : practise C coding in structure

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

typedef struct { char name[5];} name;

union uni 
{
    int invar;
	char ch;
	struct
	{  
	    float ftvar;
	} stvar;
};	


int main()
{
 name name = {"This"},  *ptr = &name ;

 union uni unvar = {65};
 char arg[25]= "\n unvar.invar = %d";

/* ERROR = invalid initalzation 
	  union uni unvar = 25; */

printf("\n *(ptr->name + 2) = %c, *((*ptr).name + 2) = %c,(*ptr).name[2] = %c, ",*(ptr->name + 2), *((*ptr).name + 2), (*ptr).name[2] );

/* ERROR: ptr can access to member of structure not a address within the member's address 
printf("\n *(ptr->(name + 2)) = %c",*(ptr->(name + 2)) ); */

   printf(arg, unvar.invar ); 
   printf("\n unvar.ch = %c, unvar.stvar.ftvar = %f", unvar.ch, unvar.stvar.ftvar); 
	
return 1;
}
