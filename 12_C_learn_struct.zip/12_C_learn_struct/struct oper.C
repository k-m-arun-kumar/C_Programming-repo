/* ********************************************************************
FILE                   :  struct oper.c

PROGRAM DESCRIPTION    : practise C coding in structure

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  : Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "string.h"

struct tag
{
 char c;
 int a;
 char name[10];
}

;

typedef struct tag tag;

struct test
{
  int i;
  char name [15];
  tag tag;
  float f;
} sttest[] = {23, "india", 45, 29.7,"jai hind", 24, 35 }, *sptr = &sttest;
    /* warning: suspecious ptr conv, avoid if assign with &sttest[0] */


int check(struct test );
struct test test(struct test *);
int i(void);                      /* not define, no problem unless called */

int main()
{
  tag tag, *tagptr;
  int i = 10;
  float *fptr;

  clrscr();

  printf("\n sttest[0].tag.a : %d, sttest.tag.name: %s", \
  ++sttest[i - 10].tag.a, sttest[0].tag.name);

  sttest[1].tag.a = check(sttest[0]);
  printf("\n sttest[1].tag.a: %d", sttest[1].tag.a);

  tagptr = &sttest[1].tag;
 /* tagptr.c = 65.8; */          /* error: illegal struc oper */
 /* tag->c = 65.8;   */          /* error: ptr req at left side of -> */

  tagptr->c = 65.8;
  tagptr->a = 10;

  /* *(float) ++tagptr = 55.0; */
   /* error: incompatible type conver & illegal use of float pt */

   fptr = (float *) ++tagptr;
   *fptr = 19.89f;
   printf("\n *fptr: %f, sttest[1].f : %f", *fptr, sttest[1].f );

   printf("\n sttest[1].tag: %d, sttest[1].tag.a: %d, sttest[1].f : %f",\
   sttest[1].tag.c, sttest[1].tag.a, sttest[1].f);

  printf("\n sptr->i :%d, (*sptr).tag.a: %d", sptr->i, (*sptr).tag.a);

/*  printf("\n : %d", *sptr.i); */           /* error: illegal stru oper */

/* printf("\n : %c", *sttest.name + 2)  */
   /* error: illegal stru oper, solu use sttest[0] */

/* printf("\n : %c", sptr->(name + 2)); */    /* error: illegal use of arrow */

/* printf("\n : %c", *(*(sttest + 0).name + 2));  */
	 /* error: illegal stru oper */

/* printf("\n %c", *((*sttest + 0).name + 2));    */
	/* error: illegal stru oper */

  printf("\n sttest[0] name: %s, name: %s", sttest[0].name, (*sptr).name);

  printf("\n sttest[0].name[2] : %c, %c, %c, %c, %c, %c, %c, %c",sttest[0].name[2],\
   sptr->name[2], (*sptr).name[2],*(sttest[0].name + 2), *(sptr->name + 2),\
    *((*sptr).name + 2), *((sttest + 0)->name + 2), *((*(sttest + 0)).name + 2)  );

  printf("\n ++sptr->i : %d", ++sptr->i);
  printf("\n (++sptr)->i : %d", (++sptr)->i);

  sttest[1] = test(&sttest[0]);
  printf("\n sttest[1].i: %d, sttest.tag.name: %s", sttest[1].i, sttest[1].tag.name);
  printf("\n sttest[0].i: %d, sttest.tag.name: %s", sttest[0].i, sttest[0].tag. name);

  sptr =  &tag;       /* warning: suspicious ptr conversion, result fine */
  sptr->c = 'c';
  sptr->a = 123;
  printf("\n sptr->c : %c, sptr->a : %d", sptr->c, sptr->a);
    /* warning: c & a not part of stru    */

}

int check(struct test sttest)
{
   struct test *stptr = &sttest;
   stptr->tag.a = sttest.i + 10;
   printf("\n check: tag.a = %d",stptr->tag.a);
   return stptr->i;

}

/* struct test test(struct test *test )
{
   test->i = 115;
   strcpy(test->tag.name, "vanda");

}  */    /* return value garbage, tries to convert to struct test */

struct test test(struct test *test)
{
  test->i = 115;
  strcpy(test->tag.name, "vanda");
 return *test;
}
