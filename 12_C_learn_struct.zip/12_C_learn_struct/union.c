/* ********************************************************************
FILE                   : union.c

PROGRAM DESCRIPTION    : practise of union 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>

typedef union {
               int a;
               float b;
               char c;
    } A_union;

int main(void)
{
    /* initializing only one member 'x' */
    A_union x = {23.34};    /* first member a = implict cast to 23 */
 
    printf("Memory allocated to \'x\' of A_union is: %d bytes.\n",
            sizeof(x));
    puts("");
 
    printf("x.a is an integer: %d\n", x.a);
    printf("x.b is a float: %.2f\n", x.b);
     printf("x.a is a integer: %d\n", x.a);
    return 0;
}
