/* ********************************************************************
FILE                   :  struptr.c

PROGRAM DESCRIPTION    : practise C coding in structure

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
 
/* maintain your own list of allocated structures. When a user no longer needs an instance of a structure, 
it is returned to the pool. When an instance is needed, it obtains the object from the pool. 
If there are no elements available in the pool, a new instance is dynamically memory allocated. 
This approach effectively maintains a pool of structures that can be used and reused as needed. */ 

#include "stdio.h"
#include "stdlib.h"
#include "string.h"


#define LIST_SIZE 2
#define NUM_PERSONS 4

typedef struct person
 {
char* firstName;
char* lastName;
char* title;
unsigned int age;
} Person;

typedef struct _alternatePerson 
{
char* firstName;
char* lastName;
char* title;
short age;
} AlternatePerson;


Person *list[LIST_SIZE];

void initializeList();
Person *getPerson(); 
void initializePerson(Person *ptrperson, const char* fn, const char* ln, const char* title, unsigned int age);
void displayPerson(Person *ptrPerson);
void deallocatePerson(Person *ptrperson);
Person *returnPerson(Person *ptrperson);
void freemem();

int main()
{
   Person person, *ptrPerson[NUM_PERSONS];
   int i =0;
   unsigned int age = 30;
 
   printf("\n sizeof(char *) = %d, sizeof(short) = %d", sizeof(char *), sizeof(short));
   printf("\n sizeof(Person) = %d, sizeof(AlternatePerson) = %d",sizeof(Person),sizeof(AlternatePerson)); 
   
   initializeList();
   
   for ( i =0; i< NUM_PERSONS; i++)
   {
      ptrPerson[i] = getPerson();
      initializePerson(ptrPerson[i],"arun","kumar","Mr.",age += 5);
      displayPerson(ptrPerson[i]);
      
   }
   
   for ( i =0; i< 3; i++)
      returnPerson(ptrPerson[i]);
   i =0;
   ptrPerson[i] = getPerson();
   returnPerson(ptrPerson[i]);

   returnPerson(ptrPerson[3]); /* free */
   freemem();
}

/* initialize the memory pool, which is used to minimize overhead of dynamic memory allocation.
   memory pool (list), is inilized to NULL, meaning is when a new pointer of Person data type structure,
   it has to be allocated from dynamic memory allocation method, rather than from memory pool */
 void initializeList() 
{
   for(int i=0; i<LIST_SIZE; i++) 
     list[i] = NULL;
  return; 
}

/* if a pool list is has pointer address, which was been dynamically memory allocated and that memory 
   was been no longer required, is returned to the pool list, so pool list[i] != NULL. when a instance of object
   requires a memory then ptr = list[i] is used, then list[i] = NULL is used to indicate that it has no  free dynamically
   allocated memory
   if list[i] == NULL, then instance of object, which requires a memory, is dynammcally allocated  */

Person *getPerson() 
{
   for(int i=0; i<LIST_SIZE; i++) 
   {
       if(list[i] != NULL) 
	   {
	      Person *ptr = list[i];
		  printf("\n getPerson(), obtain from pool, list[%d]: addr = %#X", i, ptr );
		  list[i] = NULL;
		  return ptr;
       }
   }
   Person *ptrperson = (Person*)malloc(sizeof(Person));
   printf("\n getPerson(): pool is empty, malloc Addr : %#X", ptrperson);
   return ptrperson;
}

void initializePerson(Person *ptrperson, const char* fn, const char* ln, const char* title, unsigned int age) 
{
     ptrperson->firstName = (char*) malloc(strlen(fn) + 1);
     strcpy(ptrperson->firstName, fn);
     ptrperson->lastName = (char*) malloc(strlen(ln) + 1);
     strcpy(ptrperson->lastName, ln);
     ptrperson->title = (char*) malloc(strlen(title) + 1);
     strcpy(ptrperson->title, title);
     ptrperson->age = age;
	 return;
}

void displayPerson(Person *ptrPerson)
{
   printf("\n DisplayPerson(), ptrPerson = %#X", ptrPerson);
   printf("\n firstname = %s, lastName = %s, title= %s, age = %u", ptrPerson->firstName, ptrPerson->lastName, ptrPerson->title, ptrPerson->age ); 
   return;
}

void deallocatePerson(Person *ptrperson)
{
    free(ptrperson->firstName);
    free(ptrperson->lastName);
    free(ptrperson->title);
	return;
}
/* if a list[i] == NULL, meaning that then it does not have any free dynamic memory address 
   so list[i] = ptr , which means that list[i] now has address of the address of dynamic memory,
   which s no longer free */
Person *returnPerson(Person *ptrperson)
{
    for(int i=0; i<LIST_SIZE; i++) 
	{
        if(list[i] == NULL) 
		{
             list[i] = ptrperson;
			 printf("\n returnperson(), returned to list[%d]: addr = %#X", i, list[i]);
            return ptrperson;
       }
    }
	/* If the memory pool is full, then the pointers within person are freed using the deallocatePerson function,
	   person is freed */
	   
    deallocatePerson(ptrperson);
	printf("\n returnperson(), free addr = %#X", ptrperson);
    free(ptrperson);
    return NULL;
}

/* forcely free pool list to avoid memory leak, when this program closes */
void freemem()
{
    for(int i=0; i<LIST_SIZE; i++)
    {
	    if(list[i])
		{
		   Person *ptrperson = list[i];
		   deallocatePerson(ptrperson);
		   printf("\n forcely free memory = %#X",ptrperson);
		   free(ptrperson);
		   list[i] = NULL;
		}
    }
	return;
 }
