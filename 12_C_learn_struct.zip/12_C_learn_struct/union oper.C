/* ********************************************************************
FILE                   :  union oper.c

PROGRAM DESCRIPTION    : practise C coding in union

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

 #include "stdio.h"
#include "string.h"

/* union tag
{
 char c;
 int a;
 char name[10];
}  untag = {'c', 45, "india"}; */  /* error: initialization error, decl error */

/* union tag
{ char c;
  int a;
  char name[10];
}  untag = {"india"}; */    /* error: illegal initializtion */

/* union tag
{
  char c;
  int a;
  float b;
  char name[10];
} untag[] = {'a', 65, "india", 54}; */
   /* error: illegal initialize at 54
      NOTE: initialize to first member of union */


union tag
{
   char c;
   int a;
   char id[5];
   float b;
   struct
   {
     int a;
     float c;
   } st;
   union
   {
      float a;
      long c;
   } un;
   enum {red = 4, green, blue} envar;
   char name[4];

} untag[] = { 56, 65, 54 };

typedef union tag tag;

/* struct test
{
  int i;
  char name [15];
  tag tag;
  float f;

} sttest[] = {23, "india", 97, 29.7, "55", 54, 65, 97, 55, 0, 99 }; */
    /* warning: non portable ptr conv, not taking data from "55",
      if a "hi" comes after "55", then fine, except "55" */

 struct test
 {
    int i;
    char name [15];
    tag tag;
    float f;
   /* enum {red, green= -9, blue} envar; */ /* error: redecl of red, green, blue */
   enum { black, yellow} envar;
 }  sttest[] = {101, "india", 97, 65.5, 67, -10,"hellow", 'a'};

 union tag untage(union tag *);

int i =9;

int main()
{
  tag tag, *tagptr;
  int i = 10;

  clrscr();
  for(i = 0; i < sizeof(sttest)/sizeof(struct test); ++i)
  {
      printf("\n sttest[%d] i = %d, name = %s, tag.c = %c,\
	tag.a = %d ,tag.name = %s, f = %f, envar = %d", i, sttest[i].i,
	sttest[i].name, sttest[i].tag.c, sttest[i].tag.a, \
	sttest[i].tag.name, sttest[i].f, sttest[i].envar );
  }
  printf("\n size: union tag : %d, size id: %d", sizeof(union tag), sizeof(sttest[0].i));

  /* printf("\n size: untag.id: %d", sizeof(untag.id)); */
     /* error: illegal stru oper */

  for(i = 0; i < sizeof(untag)/sizeof(union tag ); ++i)
    printf("\n untag[%d]: c = %d, a = %d, b= %f, id = %s, name = %s,\
    st.a = %d, st.c = %f, un.a = %f, un.c = %d, envar = %d",i, untag[i].c,\
    untag[i].a, untag[i].b, untag[i].id, untag[i].name, untag[i].st.a, \
    untag[i].st.c, untag[i].un.a, untag[i].un.c, untag[i].envar );

    tagptr = untag;
    /* untag[1] = check(untag[0]); */  /* error: illegal stru oper */
    untag[1].a = check(untag[0]);

    printf("\n untag[1].a : %d, untag[0].a : %d", untag[1].a, untag[0].a);
    (++tagptr)->a = 0xfe46;

    printf("\n untag[1].a : %#x, untag[1].c : %#x", tagptr->a, tagptr->c);

    untag[0]  = untage(tagptr);

    i = 0;
     printf("\n untag[%d]: c = %d, a = %d, b= %f, id = %s, name = %s,\
    st.a = %d, st.c = %f, un.a = %f, un.c = %d, envar = %d",i, untag[i].c,\
    untag[i].a, untag[i].b, untag[i].id, untag[i].name, untag[i].st.a, \
    untag[i].st.c, untag[i].un.a, untag[i].un.c, untag[i].envar );


    i = 1;
    printf("\n untag[%d]: c = %d, a = %d, b= %f, id = %s, name = %s,\
    st.a = %d, st.c = %f, un.a = %f, un.c = %d, envar = %d",i, untag[i].c,\
    untag[i].a, untag[i].b, untag[i].id, untag[i].name, untag[i].st.a, \
    untag[i].st.c, untag[i].un.a, untag[i].un.c, untag[i].envar );


    i = 2;
    /* untag[i].name = 102; */     /* error: lvalue req */
    untag[i].b = 75.7;
    untag[i].envar = green;          /* enum varible, envar garbage */


    printf("\n untag[%d]: c = %d, a = %d, b= %f, id = %s, name = %s,\
    st.a = %d, st.c = %f, un.a = %f, un.c = %d, envar = %d",i, untag[i].c,\
    untag[i].a, untag[i].b, untag[i].id, untag[i].name, untag[i].st.a, \
    untag[i].st.c, untag[i].un.a, untag[i].un.c, untag[i].envar );

}

/* int check(union test sttest) */  /* error: redecl of test */
int check(union tag untag)
{
   union tag *unptr = &untag;
   unptr->a = untag.i + 10;
    /* warning: i not a member of stru, if z is used, then error, undefined z */

   strcpy(untag.name, "bellow");
     /* integer members of union, are garbage */

  /* unptr->b = 23.5; */

   printf("\n check: tag.a = %d, untag.name = %s, id = %s", \
    unptr->a, unptr->name, unptr->id);
   return unptr->i;

}



/* union tag untag(union tag *untag) */    /* error: redecl of untag */
union tag untage(union tag *tag)
{
  tag->a = 115;
  strcpy(tag->name, "vanda");
  tag->st.a = 100;
  tag->st.c = 72;
  return *tag;
}


/*int i(void)
{
} */
/* error: redecl of i as i is as extern var */
