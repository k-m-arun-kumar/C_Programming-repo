/* ********************************************************************
FILE                   : ARIT_PTR.c

PROGRAM DESCRIPTION    : do arthimetic operation of addition, subtraction, multiplication and division using function array pointer

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include<stdio.h>
#include<conio.h>
typedef long int (*func_operators)(int, int );
long int add(int, int);
long int sub(int, int);
long int mul(int, int);
long int div(int, int);
func_operators func_oper[] = {add, sub, mul, div};
int main()
{
  int oper, operand1, operand2, to_continue;
  long int result;

  clrscr();
  do
  {

  printf("add - 0, sub - 1, mul - 2, div - 3");
  printf("\n enter arith oper : ");
  scanf("%d",&oper);
  if(oper > 3 || oper < 0)
  {
    printf("\n ERR: invalid oper ");
  }
  else
  {
    printf("\n enter operand 1: ");
    scanf("%d",&operand1);
    printf("\n enter operand 2: ");
    scanf("%d", &operand2);
    result = func_oper[oper](operand1, operand2);
    printf("result = %ld", result);
  }
  printf("\n press 1 to continue, any other to exit");
  printf("\n enter : ");
  scanf("%d", &to_continue);
  }while(to_continue == 1);
  return 0;
}

long int add(int operand1, int operand2)
{
   return (long int)(func_oper[3](operand1, operand2) + operand2);
}

long int sub(int operand1, int operand2)
{
   return (long int)(operand1 - operand2);
}

long int mul(int operand1, int operand2)
{
  return (long int)(operand1 * operand2);
}
long int div(int operand1, int operand2)
{
   return (long int)(operand1/operand2);
}

