/* ********************************************************************
FILE                   : io_lib.c

PURPOSE                : 2D Array initialisation 
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                       
CHANGE LOGS           : 

*****************************************************************************/
#include <stdio.h>

/* ---------------------- macro defination ------------------------------------------------ */
#define PIN_SIG_UNKNOWN       (0)
#define PIN_SIG_DIGITAL       (1)
#define PIN_SIG_ANALOG        (2)

#define IO_DIR_INPUT           (0)                  
#define IO_DIR_OUTPUT          (1)

#define IO_FUNC_GPIO           (0)
#define IO_FUNC_SPI            (1)                   
#define IO_FUNC_I2C            (2)
#define IO_FUNC_UART           (3)
#define IO_FUNC_ADC            (4)
#define IO_FUNC_DAC            (5)
#define IO_FUNC_PWM            (6)
#define IO_FUNC_TIMER          (7)
#define IO_FUNC_EXTR_INTP      (8)
#define IO_FUNC_CAPTURE        (9)
#define IO_FUNC_COMP          (10)
#define IO_FUNC_DEBUG         (11)
#define IO_FUNC_TRACE         (12)
#define IO_FUNC_RESERVE       (13)
#define IO_FUNC_SAME          (14)
#define IO_FUNC_UNUSED        (15) 
#define IO_FUNC_INVALID       (16)

#define IO_FUNC_MODE_00       (0)
#define IO_FUNC_MODE_01       (1)
#define IO_FUNC_MODE_02       (2)
#define IO_FUNC_MODE_03       (3) 

#define NULL_PTR                                      ((void *)0)
#define STATE_LOW                                 (0U) 
#define STATE_HIGH                                (1U)
#define STATE_UNKNOWN                             (2U)
#define STATE_INVALID                             (3U)
#define STATE_VALID                               (4U)

#define SUCCESS               (0)
#define FAILURE               (1)


/* ---------------------- data type defination -------------------------------------------- */

typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long uint64_t;

typedef char int8_t;
typedef short int int16_t;
typedef int int32_t;
typedef long int64_t;
typedef struct
{
	uint8_t io_pin        : 6;        // IO pin [0:63]
	uint8_t signal        : 2;        // analog, digital     
	uint8_t dir           : 1;        // input or output 
	uint8_t state         : 2;        // initial output state 
	uint8_t func          : 4;        // pin function type ie GPIO, ADC, DAC, Timer, SPI, or I2C, etc 
} io_config_t;

typedef enum
{
    PORT_CH_00, PORT_CH_01, NUM_PORT_CHS	
} port_ch_t;

typedef struct
{
	  uint8_t port;
	  uint8_t port_pin;
} io_port_t;

typedef enum 
{ 
  PIN_00, PIN_01, PIN_02, PIN_03, PIN_04, PIN_05, PIN_06, PIN_07, 
  PIN_08, PIN_09, PIN_10, PIN_11, PIN_12, PIN_13, PIN_14, PIN_15,
  PIN_16, PIN_17, PIN_18, PIN_19, PIN_20, PIN_21, PIN_22, PIN_23,
  PIN_24, PIN_25, PIN_26, PIN_27, PIN_28, PIN_29, PIN_30, PIN_31,
  NUM_PINS_PER_PORT   
} io_pin_t;

typedef enum 
{
  IO_CH_00, IO_CH_01, IO_CH_02, IO_CH_03, IO_CH_04, IO_CH_05, IO_CH_06, IO_CH_07, 
  IO_CH_08, IO_CH_09, IO_CH_10, IO_CH_11, IO_CH_12, IO_CH_13, IO_CH_14, IO_CH_15,
  IO_CH_16, IO_CH_17, IO_CH_18, IO_CH_19, IO_CH_20, IO_CH_21, IO_CH_22, IO_CH_23,
  IO_CH_24, IO_CH_25, IO_CH_26, IO_CH_27, IO_CH_28, IO_CH_29, IO_CH_30, IO_CH_31,
	IO_CH_48 = 48, IO_CH_49, IO_CH_50, IO_CH_51, IO_CH_52, IO_CH_53, IO_CH_54, IO_CH_55, 
  IO_CH_56, IO_CH_57, IO_CH_58, IO_CH_59, IO_CH_60, IO_CH_61, IO_CH_62, IO_CH_63, NUM_IO_CHS = 48
} io_ch_t;

/* -------------------- public variable declaration --------------------------------------- */
  
/* -------------------- public function declaration --------------------------------------- */
uint8_t IO_Channel_Init(const io_config_t *const );
uint8_t IO_Channel_Read(const uint8_t io_ch);
void Reset_Ports(void);
uint8_t Config_Port_Pins(const uint8_t io_channel, const void *const data_ptr);
uint8_t IO_Channel_Write(const uint8_t io_channel, const uint8_t data);
uint8_t IO_Ch_Validate(const uint8_t io_ch);

/* ----------------------------- global variable defination --------------------- */

uint32_t PINSEL0, PINSEL1, PINSEL2;
uint32_t IO0DIR, IO1DIR;
uint32_t IO0SET, IO1SET;
uint32_t IO0CLR, IO1CLR;
uint32_t IO0PIN, IO1PIN;

static uint32_t  *io_port_func_ptr[NUM_PORT_CHS + 1] = {(uint32_t *) &PINSEL0,(uint32_t *) &PINSEL1, (uint32_t *) &PINSEL2 };
static uint32_t  *io_port_dir_ptr[NUM_PORT_CHS] = { (uint32_t *) &IO0DIR, (uint32_t *) &IO1DIR };
static uint32_t  *io_port_set_ptr[NUM_PORT_CHS] = {(uint32_t *)&IO0SET, (uint32_t *) &IO1SET};
static uint32_t  *io_port_clr_ptr[NUM_PORT_CHS] = {(uint32_t *) &IO0CLR, (uint32_t *) &IO1CLR};
static uint32_t  *io_port_ptr [NUM_PORT_CHS] = {(uint32_t *) &IO0PIN, (uint32_t *) &IO1PIN};

#define IO_CH_LED1                      (IO_CH_02)
#define IO_CH_SW1                       (IO_CH_48) 

const io_config_t io_config[] = {
																		     { IO_CH_00, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED}, //IO_CH_00
                                                                             { IO_CH_01, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_LED1, PIN_SIG_DIGITAL, IO_DIR_OUTPUT, STATE_LOW,  IO_FUNC_GPIO },
                                                                             { IO_CH_03, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_04, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_05, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},	
                                                                             { IO_CH_06, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_07, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_08, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_09, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_10, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_11, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_12, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_13, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_14, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_15, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},	
                                                                             { IO_CH_16, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED}, //IO_CH_16
                                                                             { IO_CH_17, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_18, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_19, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_20, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_21, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_22, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_23, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_24, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},
                                                                             { IO_CH_25, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_26, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},	
                                                                             { IO_CH_27, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_28, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_29, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_30, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { IO_CH_31, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},  //IO_CH_31
																		 
																		     { IO_CH_48, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_INVALID, IO_FUNC_UNUSED },  //IO_CH_48
                                                                             { IO_CH_49, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { IO_CH_50, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { IO_CH_51, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { IO_CH_52, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { IO_CH_53, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { IO_CH_54, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { IO_CH_55, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { IO_CH_56, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},	
                                                                             { IO_CH_57, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { IO_CH_58, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_GPIO},
                                                                             { IO_CH_59, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_DEBUG},
                                                                             { IO_CH_60, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_DEBUG},
                                                                             { IO_CH_61, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_DEBUG},
																			 { IO_CH_62, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_DEBUG},
                                                                             { IO_CH_63, PIN_SIG_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_DEBUG},  //IO_CH_63
																	  }	;							

/* ----------------------------- global variable declaration -------------------- */


/* ----------------------------- global function declaration -------------------- */
static uint8_t GPIO_Func_Init(const io_config_t *const io_config_ptr, const uint8_t io_config_index);
static uint8_t Debug_IO_Func_Init_Check(const io_config_t *const io_config_ptr, uint8_t *const io_config_index);
static uint8_t Trace_IO_Func_Init_Check(const io_config_t *const io_config_ptr, uint8_t *const io_config_index);
static uint8_t IO_Conf_Index_Mapto_IO_Ch(uint8_t *const io_ch, const uint8_t io_config_index);
static uint8_t IO_Ch_Mapto_IO_Conf_Index( uint8_t *const io_config_index, const io_port_t *const io_port_ptr);

void View_Val(void);

int main()
 {
 	 uint8_t i, j, ret_status = SUCCESS;
 	 
 	 printf("\n sizeof(io_conf) = %u", sizeof(io_config));
     if((ret_status = IO_Channel_Init(io_config)) != SUCCESS)
     {
     	 return 1;
	 }
     View_Val();	
    return 0;
 }  
 
 
void View_Val(void)
{
	uint8_t i;
	
    for(i = 0; i < NUM_PORT_CHS + 1; ++i)
	 {
	    printf ("\n PINSEL:%d = 0x%x", i, *io_port_func_ptr[i] );
	 }
	 for(i = 0; i < NUM_PORT_CHS; ++i)
	 {
	 	 printf("\n IODIR%d = 0x%x, IOPIN%d = 0x%x", i, *io_port_dir_ptr[i], i, *io_port_ptr[i] );
		 printf(" IOSET%d = 0x%x, IOCLR%d = 0x%x", i, *io_port_set_ptr[i],i, *io_port_clr_ptr[i]);
		  		  
	 }
}
/*------------------------------------------------------------*
FUNCTION NAME  : IO_Channel_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.01  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t IO_Channel_Init(const io_config_t * const io_config_ptr)
{
	 uint8_t io_config_index, port, port_pin, io_ch, ret_status = SUCCESS;
	
	 if(io_config_ptr == NULL_PTR)
	 {
	 	 printf("\n ERR[03:01:01]: NULL_PTR");
		  return FAILURE; 
	 }
	 Reset_Ports();	
	  
	 for(io_config_index = 0; io_config_index < NUM_IO_CHS; ++io_config_index)
	 {
		  if((ret_status = IO_Conf_Index_Mapto_IO_Ch(&io_ch, io_config_index)) != SUCCESS)
			{
				printf("\n ERR[03:01:02]: io_config_index  :%u, io_ch = %u",io_config_index,io_ch );
				 break;
			}
			if((ret_status = IO_Ch_Validate(io_ch)) != SUCCESS)
      {
      	        	printf("\n ERR[03:01:03]: " );
				   goto IO_INIT_FAILURE;
			 	   break;
			}				 
	   // common to all IO pin's function process 
	  	switch((io_config_ptr + io_config_index)->func)
	  	{
		     case IO_FUNC_GPIO:
		        if((ret_status = GPIO_Func_Init(io_config_ptr, io_config_index)) != SUCCESS)
		        {
		        	printf("\n ERR[03:01:04]:");
			         goto IO_INIT_FAILURE;
			 	       break;
		        }
						continue;
			    break; 
			    case IO_FUNC_SAME:
					  continue;
			    break;
			    case IO_FUNC_UNUSED:
			    case IO_FUNC_RESERVE:
			       continue;
					break;
		  }
		 	 port  = io_ch / NUM_PINS_PER_PORT;
		   port_pin = io_ch % NUM_PINS_PER_PORT;
	    switch(port)
		  {			 
		     case	PORT_CH_00:
				     switch(port_pin)
				     {
				    	 case PIN_00:
					 	     switch((io_config_ptr + io_config_index)->func)
		             {
                    case IO_FUNC_UART:
			              break;
			              case IO_FUNC_PWM:
			              break;
							    	default:
							    		printf("\n ERR[03:01:05]: io_ch = %u, invalid func = %u", io_ch, (io_config_ptr + io_config_index)->func );
							    		ret_status = FAILURE;
							      	goto IO_INIT_FAILURE;
						 	    	break;
						     }
					     break;
				   }
       break;
       case PORT_CH_01:
				 switch(port_pin)
				 {
					   case PIN_16:
							  switch((io_config_ptr + io_config_index)->func)
	  	          {
		               case IO_FUNC_TRACE:
										 if((ret_status = Trace_IO_Func_Init_Check(io_config_ptr, &io_config_index)) != SUCCESS)
										 {
										 	printf("\n ERR[03:01:06]: trace invalid: io_config_index = %u", io_config_index);
											  goto IO_INIT_FAILURE;
						 	        	break; 
										 }
										 *io_port_func_ptr[2] |= (IO_FUNC_MODE_01 << 3);
                   break;
									 default:
									 		printf("\n ERR[03:01:07]: port1 & pin16, func = %u", (io_config_ptr + io_config_index)->func);
										 ret_status = FAILURE;
							       goto IO_INIT_FAILURE;
						 	    	break;
						    }
							    							
						 break;
             case PIN_26:
							  switch((io_config_ptr + io_config_index)->func)
	  	          {
		               case IO_FUNC_DEBUG:
										 if((ret_status = Debug_IO_Func_Init_Check(io_config_ptr, &io_config_index)) != SUCCESS)
										 {
										 		printf("\n ERR[03:01:08]: debug invalid: io_config_index = %u", io_config_index);
											  goto IO_INIT_FAILURE;
						 	        	break; 
										 }
										 *io_port_func_ptr[2] |= (IO_FUNC_MODE_01 << 2);
                   break;
									 default:
									 	printf("\n ERR[03:01:09]: port1 & pin26, func = %u", (io_config_ptr + io_config_index)->func);
										 ret_status = FAILURE;
							       goto IO_INIT_FAILURE;
						 	    	break;
						    }         							
						 break;	
			default:
				printf("\n ERR[03:01:10]: unmatched func port 1 pin : %u", port_pin);
                 ret_status = FAILURE;
					       goto IO_INIT_FAILURE;
					   break;					 
				 }
				 
        break;
        default:
        	printf("\n ERR[03.01.11]: port = %u", port);
			ret_status = FAILURE; 
			break;
		  }			 
   }	 
IO_INIT_FAILURE:  
   if(ret_status == FAILURE)
    {				
        Reset_Ports();	
	  }		
	   return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : IO_Channel_Write

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.03  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t IO_Channel_Write(const uint8_t io_channel, const uint8_t data)
{
	 uint8_t port, port_pin;
    
     port = io_channel / NUM_PINS_PER_PORT;
	 port_pin = io_channel % NUM_PINS_PER_PORT;
	 
	 if(data & STATE_HIGH)
	 {
		 *io_port_set_ptr[port] = 1 << port_pin;
	 }
	 else
	 {
	    *io_port_clr_ptr[port] = 1 << port_pin;			
	 }
	 return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Ports

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.04  

BUGS           :              
-*------------------------------------------------------------*/
void Reset_Ports(void)
{
	uint8_t i;
	
    for(i = 0; i < NUM_PORT_CHS + 1; ++i)
	 {
	    *io_port_func_ptr[0] = IO_FUNC_GPIO;
	 }
	 for(i = 0; i < NUM_PORT_CHS; ++i)
	 {
		 *io_port_dir_ptr[i] = 0;
		 *io_port_ptr[i] = 0;
		 *io_port_set_ptr[i] = 0;
		 *io_port_clr_ptr[i] = 0;
	 }
}

/*------------------------------------------------------------*
FUNCTION NAME  : IO_Channel_Read

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.05  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t IO_Channel_Read(const uint8_t io_ch)
{
	 uint8_t port, port_pin;
    
     port = io_ch / NUM_PINS_PER_PORT;
	 port_pin = io_ch % NUM_PINS_PER_PORT;
	 if(*io_port_ptr[port] & (1 << port_pin))
	 {
		 return STATE_HIGH;
	 }
	 return STATE_LOW;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Common_IO_Ch_Func_Init

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.06  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t GPIO_Func_Init(const io_config_t * const io_config_ptr, const uint8_t io_config_index)
{
	  uint8_t port, port_pin, io_ch, ret_status = SUCCESS ;
	
	  if((ret_status = IO_Conf_Index_Mapto_IO_Ch(&io_ch, io_config_index)) != SUCCESS)
	  {
	  	   printf("\n ERR[03.06.01]");
				 return FAILURE;
	  }
	  printf("\n INFO[03.06.02]: io_config_index = %u -> io_ch = %u", io_config_index, io_ch);
	  port = io_ch / NUM_PINS_PER_PORT;
	  port_pin = io_ch % NUM_PINS_PER_PORT;
	  switch(port)
		{			 
		     case	PORT_CH_00:
					  if(port_pin <= PIN_15)
            {
		            *io_port_func_ptr[0] |= (IO_FUNC_MODE_00 << (port_pin * 2));
		    }
            else
		        {
                if( port_pin <= PIN_31)
			          {
			             	*io_port_func_ptr[1] |= (IO_FUNC_MODE_00 << (port_pin * 2));
			          }
			        	 else
			          {
				            // invalid port 0 pin > 31 
				             printf("\n ERR[03.06.03]: port 0, pin = %u > 31", port_pin);
				         	  ret_status = FAILURE;
				            goto GPIO_INIT_FAILURE;
				    	     
				        }
			      }
						switch((io_config_ptr + io_config_index)->signal)
						{
									   case PIN_SIG_DIGITAL:
									  	 switch((io_config_ptr + io_config_index)->dir)
										   {
										  	  case IO_DIR_INPUT:
													  switch((io_config_ptr + io_config_index)->state)
														{
															  case STATE_UNKNOWN:
																case STATE_INVALID:	
																break;
																default:
															    printf("\n ERR[03.06.04]: invalid input state = %u, io_config_index: %u,  ", (io_config_ptr + io_config_index)->state, io_config_index );		
                                   ret_status = FAILURE;
							                     goto GPIO_INIT_FAILURE;
							                  break;																	
														}
														*io_port_dir_ptr[port] |= (IO_DIR_INPUT << port_pin);
                          break;		
											  	case IO_DIR_OUTPUT:
														switch((io_config_ptr + io_config_index)->state)
														{
															  case STATE_LOW:
																	*io_port_clr_ptr[port] |= 1 << port_pin;
																break;
																case STATE_HIGH:
																	*io_port_set_ptr[port] |= 1 << port_pin;
																break;
                                default:
                                	  printf("\n ERR[03.06.05]: invalid output state = %u, io_config_index: %u", (io_config_ptr + io_config_index)->state, io_config_index );		
                                   ret_status = FAILURE;
							                     goto GPIO_INIT_FAILURE;
							                  break;																	
														}
														*io_port_dir_ptr[port] |= (IO_DIR_OUTPUT << port_pin);
                          break;													
										   }
									   break;
									   default: 
									     printf("\n ERR[03.06.06]: invalid signal = %u, io_config_index: %u", (io_config_ptr + io_config_index)->signal, io_config_index );		
                       ret_status = FAILURE;
							         goto GPIO_INIT_FAILURE;
						 	    	 break;										 
							 }
						break;
					  case PORT_CH_01:
							if(port_pin >= PIN_26 && port_pin <= PIN_31)
							{
								 
						    *io_port_func_ptr[2] |= (IO_FUNC_MODE_00 << 2);
							}
							else
							{
								 if(port_pin >= PIN_16 && port_pin <= PIN_25)
								 {
									  *io_port_func_ptr[2] |= (IO_FUNC_MODE_00 << 3);
								 }
								 else
								 {
								 	 printf("\n ERR[03.06.07]: invalid port1's pin = %u", port_pin );	
									 // invalid port 1 pin [0,15] or [32, +infinity ] 
									  ret_status = FAILURE;
							      goto GPIO_INIT_FAILURE;
								 }
							}
			      break;
            default:
            	printf("\n ERR[03.06.08]: invalid port = %u", port );
              ret_status = FAILURE;
						break;
			}						
	 GPIO_INIT_FAILURE: 
      return ret_status; 								 
}

/*------------------------------------------------------------*
FUNCTION NAME  : IO_Ch_Validate 

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for lpc2138 io channel 

Func ID        : 03.07  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t IO_Ch_Validate(const uint8_t io_ch)
{
	  uint8_t port, port_pin, ret_status = SUCCESS ;
	
	  port  = io_ch / NUM_PINS_PER_PORT;
	  port_pin = io_ch % NUM_PINS_PER_PORT; 
	  
	  switch(port)
		{
			  case PORT_CH_00:
					if( port_pin > PIN_31)
					{
						  ret_status = FAILURE;
					}
        break;
				case PORT_CH_01:
					if(port_pin <= PIN_15 || port_pin > PIN_31)
					{
						 ret_status = FAILURE;
					}
        break;
        default:
					ret_status = FAILURE;
				break;
		}					
		return ret_status; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : Debug_IO_Func_Init_Check

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for lpc2138 io channel 

Func ID        : 03.08  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t Debug_IO_Func_Init_Check(const io_config_t *const io_config_ptr, uint8_t *const io_config_index_ptr)
{
	  uint8_t ret_status = SUCCESS, next_io_config_index = *io_config_index_ptr, req_io_config_index ;
	  io_port_t req_io_port;
	
	  req_io_port.port = PORT_CH_01;
	  req_io_port.port_pin = PIN_31;
	
	  if((ret_status = IO_Ch_Mapto_IO_Conf_Index( &req_io_config_index, &req_io_port)) != SUCCESS)
		{
			  printf("\n ERR[03.08.01] " );
			  return FAILURE;
		}
		do
		{
	   	++next_io_config_index;	  	 
	  } while(next_io_config_index <= req_io_config_index && (io_config_ptr + next_io_config_index)->func == IO_FUNC_DEBUG);
		if(next_io_config_index > req_io_config_index)
		{
			 *io_config_index_ptr = req_io_config_index;
			  printf("\n INFO[03.08.02]: debug proper: io_config_index = %u", *io_config_index_ptr);
		}
		else
		{
			 printf("\n ERR[03.08.03]: debug not proper config: io_config_index = %u, last func = %u", next_io_config_index, (io_config_ptr + next_io_config_index)->func );
			 ret_status = FAILURE;
		}
		return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Trace_IO_Func_Init_Check

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for lpc2138 io channel 

Func ID        : 03.09  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t Trace_IO_Func_Init_Check(const io_config_t *const io_config_ptr, uint8_t *const io_config_index_ptr)
{
	  uint8_t ret_status = SUCCESS, next_io_config_index = *io_config_index_ptr, req_io_config_index ;
	  io_port_t req_io_port;
	
	  req_io_port.port = PORT_CH_01;
	  req_io_port.port_pin = PIN_25;
	
	  if((ret_status = IO_Ch_Mapto_IO_Conf_Index( &req_io_config_index, &req_io_port)) != SUCCESS)
		{
			  printf("\n ERR[03.09.01] " );
			  return FAILURE;
		}
		do
		{
	   	  ++next_io_config_index;	  	 
	  } while(next_io_config_index <= req_io_config_index && (io_config_ptr + next_io_config_index)->func == IO_FUNC_TRACE);
		if(next_io_config_index > req_io_config_index)
		{
			 *io_config_index_ptr = req_io_config_index;
			 printf("\n INFO[03.09.02]: trace proper: io_config_index = %u", *io_config_index_ptr);
		}
		else
		{
			 printf("\n ERR[03.09.03]: trace not proper config:  io_config_index = %u, last func = %u", next_io_config_index, (io_config_ptr + next_io_config_index)->func );
			 ret_status = FAILURE;
		}
		return ret_status;  
}
/*------------------------------------------------------------*
FUNCTION NAME  : IO_Conf_Index_Mapto_IO_Ch

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for lpc2138 io channel 

Func ID        : 03.10  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t IO_Conf_Index_Mapto_IO_Ch(uint8_t *const io_ch, const uint8_t io_config_index)
{
	    uint8_t ret_status = SUCCESS;
	
	    if(io_ch == NULL_PTR)
			{
				 printf("\n ERR[03.10.01]: NULL PTR");
				  return FAILURE;
			}
	    if(io_config_index <= IO_CH_31)
		  {
			   *io_ch = io_config_index;
		  }
		  else
		  {
			 // i = [32, 47] map io_ch = [48, 63] as in lpc2138 port 1 pin[0,15] are reserved
	   	  if(io_config_index < IO_CH_48)
		    {
		        *io_ch = io_config_index + 16;
		    }
				else
				{
					printf("\n ERR[03.10.02]: io_config_index = %u > 48 ", io_config_index);
					 ret_status = FAILURE;					
				}
		  }
			return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : IO_Ch_Mapto_IO_Conf_Index

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for lpc2138 io channel 

Func ID        : 03.11  

BUGS           :              
-*------------------------------------------------------------*/
static uint8_t IO_Ch_Mapto_IO_Conf_Index( uint8_t *const io_config_index, const io_port_t *const io_port_ptr)
{
	    uint8_t ret_status = SUCCESS;
	
	    if(io_config_index == NULL_PTR || io_port_ptr == NULL_PTR)
			{
				  printf("\n ERR[03.11.01]: NULL PTR");
				  return FAILURE;
			}
			switch(io_port_ptr->port)
			{
				  case PORT_CH_00:
						 *io_config_index = NUM_PINS_PER_PORT * io_port_ptr->port +  io_port_ptr->port_pin;
					break;
					case PORT_CH_01:
						 *io_config_index = NUM_PINS_PER_PORT * io_port_ptr->port +  io_port_ptr->port_pin - 16;
					break;
          default:
          	 printf("\n ERR[03.11.02]: port ch = %u > 1", io_port_ptr->port);
             ret_status = FAILURE;						
			}
	   	return ret_status;
}
/*------------------------------------------------------------------*-
  ------------------------ END OF FILE ------------------------------
-*------------------------------------------------------------------*/
