/* ********************************************************************
FILE                   : num_to_str.c

PURPOSE                :  convert a number to string. 
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                       
CHANGE LOGS           : 

*****************************************************************************/


#include <stdio.h>
#include "conio.h"
int Num_to_Str(const int num_to_conv_str, const unsigned int num_digits_in_str, const unsigned int num_format, const char disp_sign_flag, char *num_in_str);
int main()
{
   int num_to_conv_str, rcvd_status;
   unsigned int min_digits_in_str, num_format ;   
   char disp_sign_flag, num_in_str[7] ;
   clrscr();
   printf("\n for num_format : 1 - decimal, 2 - hexa. Enter : ");
   scanf("%u", &num_format); 
   switch(num_format)
   {
	   case 1:
	     printf("\n for num to conv str in decimal. Enter : ");
         scanf("%d", &num_to_conv_str);
	   break;
	   case 2:
	     printf("\n for num to conv str in hexa. Enter : ");
         scanf("%x", &num_to_conv_str);
	   break;
	   
   }
   
   printf("\n for min digits in str conv . Enter : ");
   scanf("%u", &min_digits_in_str);
   printf("\n for disp_sign : 'y' - yes, 'n' - no. Enter: ");
   disp_sign_flag = getch();
   putchar(disp_sign_flag);
   
   if((rcvd_status =  Num_to_Str(num_to_conv_str, min_digits_in_str, num_format, disp_sign_flag, num_in_str)) == 0)
   {
	   printf("\n num in str = %s", num_in_str);
   }
   else
   {
	   printf("\n Error: num in str conv ");
   }
   getch();
   return 0;
}

int Num_to_Str(const int num_to_conv_str, const unsigned int min_digits_in_str, const unsigned int num_format, const char disp_sign_flag, char *num_in_str)
{
	char num_data[] ={'0','1','2','3','4','5','6','7','8','9'};  
	char hex_data[] ={'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'}; 
	char sign_flag, first_non_zero_digit_flag = 'n';
	unsigned int cur_digit, place_val, cur_num_digits_left, num_in_str_index = 1;
    int num = num_to_conv_str;
	
	switch(num_format)
	{
		case 1:
		  place_val = 10000U;
		  cur_num_digits_left = 5; 
		  while(cur_num_digits_left > 0 )
		  {
			   cur_digit = (num / place_val);
			   if(cur_num_digits_left <= min_digits_in_str)
			   {   
		          num_in_str[num_in_str_index] = (num_data[cur_digit]); 				  
				  ++num_in_str_index;
			   }
			   else
			   {
				  if(first_non_zero_digit_flag == 'n' && cur_digit != 0 )
			      {
				     first_non_zero_digit_flag = 'y';					 
			      }	
                  if(first_non_zero_digit_flag == 'y')
				  {		
                      num_in_str[num_in_str_index] = (num_data[cur_digit]);
					   ++num_in_str_index;
				  }
			   }			  
			  --cur_num_digits_left;
			  num = num_to_conv_str % place_val;
			  place_val /= 10;
		  }			  
		break;
		case 2:
		  place_val = 16 * 16 * 16;
		  cur_num_digits_left = 4; 
		  while(cur_num_digits_left > 0 )
	      {
	          cur_digit = (num / place_val);
	          if(cur_num_digits_left <= min_digits_in_str)
			  {
				  num_in_str[ num_in_str_index] = (hex_data[cur_digit]); 
				  ++num_in_str_index;
			  }
	          else
	          {
		          if(first_non_zero_digit_flag == 'n' && cur_digit != 0 )
			      {
					 first_non_zero_digit_flag = 'y';
			      }	
                  if(first_non_zero_digit_flag == 'y')
				  {					  
				      num_in_str[ num_in_str_index] = (hex_data[cur_digit]); 
					  ++num_in_str_index;
				  }
			  }			  
			  --cur_num_digits_left;
			  num = num_to_conv_str % place_val;
			  place_val /= 16;
		  }	
		break;
		default:
		  return 1;
	}
	switch(disp_sign_flag)
	{
		case 'y':
		  if(num_to_conv_str > 0)
			num_in_str[0] = '+';
		 else if (num_to_conv_str < 0) 
            num_in_str[0] = '-';
         else // 0
           num_in_str[0] = ' '; 
          		   
		break;
		case 'n':
		  num_in_str[0] = ' ';
		break;
		default:
		  return 1;		
	}
	num_in_str[num_in_str_index] = '\0';
	
	return 0;
}
