/* ********************************************************************
FILE                   : staircase.c

PROGRAM DESCRIPTION    : Write a program that prints a staircase of size n.

Consider a staircase of size :

   #
  ##
 ###
####

Observe that its base and height are both equal to n, and the image is drawn using # symbols and spaces. The last line is not preceded by any spaces.

Input Format           :  A single integer,n , denoting the size of the staircase.

Output Format          :  Print a staircase of size  using # symbols and spaces.

Note: The last line must have  spaces in it.

Sample Input           : 6 

Sample Output          :

     #
    ##
   ###
  ####
 #####
######

Explanation           :  The staircase is right-aligned, composed of # symbols and spaces, and has a height and width of n = 6

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>
#include <limits.h>
#include <stdbool.h>

void staircase(int n) {
    // Complete this function
    int i = 0, j = 0, k = 1, l ;
    for(i = 0; i < n; ++i)
    {
       for(j = 0; j < n -i - 1 ; ++j)
            printf(" ");
       for(l = 0; l < k; ++l)
       {
           printf("#"); 
       }
        ++k;
       printf("\n");     
    }
}

int main() {
    int n; 
    scanf("%i", &n);
    staircase(n);
    return 0;
}
