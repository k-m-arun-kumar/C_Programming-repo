/* ********************************************************************
FILE                   : circular_shift.c

PROGRAM DESCRIPTION    : implementation od circular left or right shift

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include <stdio.h>
#include <conio.h>
typedef struct 
{
	unsigned char to_continue: 1;
	unsigned char circular_shift_oper: 1;	
} conf_types;
conf_types conf; 
void  Circular_Shift();

int main()
{
   
   unsigned char temp_conf;    
   do 
   {
	   printf("\n circular shift : left - l, right - r");
	   printf("\n Enter a circular shift oper : ");
	   temp_conf = getch();
	   putch(temp_conf);
	   switch(temp_conf)
	   {  
	       case  'l':
           case  'L':
               conf.circular_shift_oper = 1;
			   Circular_Shift();			  
           break;
		   case  'r':
           case  'R':
              conf.circular_shift_oper = 0; 
			  Circular_Shift();
           break;
           default:
              printf("\n ERR: invalid oper ");		   
	   } 
	   printf("\n press y continue, any other to exit");
	   printf("\n Enter to continue : ");
	   temp_conf = getch();
	   putch(temp_conf);
       switch(temp_conf)
	   {
          case 'y':
          case 'Y':
            conf.to_continue = 1;
          break;
          default:
            conf.to_continue = 0;
	   }			
   } while(conf.to_continue == 1 );
   
   return 1;
}

void Circular_Shift()
{
	unsigned int num_to_shift, num_bits_to_shift, num_shifted;
	
	printf("\n Enter a number to shift : 0x");
	scanf("%x", &num_to_shift);
	printf("\n Enter nos of bits to be shifted : ");
	scanf("%u", &num_bits_to_shift);
	
	switch( conf.circular_shift_oper)
	{
		case 1: //circular left shift
		  num_shifted =  num_to_shift << num_bits_to_shift | num_to_shift >> (sizeof(unsigned int) * 8 - num_bits_to_shift);		  
		break;
		case 0: //circular right shift
		    num_shifted =  num_to_shift >> num_bits_to_shift | num_to_shift << (sizeof(unsigned int) * 8 - num_bits_to_shift);		
		break;
	}
	printf("\n shifted Number - 0x%x", num_shifted);
}
