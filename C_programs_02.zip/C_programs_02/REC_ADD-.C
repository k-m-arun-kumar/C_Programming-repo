/* ********************************************************************
FILE                   : REC_ADD-.c

PROGRAM DESCRIPTION    : calc and display factorial of a number and also fibo series 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>
#include <conio.h>

int rec_add(int);
long int rec_fac(int);
void rec_fibo(int);
void rec_disp(int);
int disp_num, fib1 = 0, fib2 = 1, temp;
int main()
{
  int to_iterate = 0, num;
  long int fact = 1;
  do
  {
    clrscr();
    printf("\n Enter num of terms for AP = ");
    scanf("%d", &num);
    printf("\n sum of terms[%d] = %d", num, rec_add(num));
    printf("\n Enter for terms for factorial = ");
    scanf("%d", &num);
    fact = rec_fac(num);
    printf("\n factorial for terms[%d] = %ld", num, fact);
    printf("\n Enter cycle for fibo series = ");
    scanf("%d", &num);
    fib1 = 0;
    fib2 = 1;
    switch(num)
    {
    case 1:
       printf("%u", 0);
       break;
    case 2:
	printf("%u %u", 0, 1);
	break;
    default:
      rec_fibo(num);
   }
   printf("\n Enter numbers to display = ");
   scanf("%d", &disp_num);
   rec_disp(disp_num);

  printf("\n Do u want to continue ? ");
  printf("\n Enter num = 1 to continue, any other num to exit. Continue? = ");
  scanf("%d", &to_iterate);
  }while(to_iterate == 1);

  getch();
  return 1;
}
int rec_add(int num)
{
  if(num == 1)
     return 1;
  return (num + rec_add(num -1));
 }
 long int rec_fac(int num)
 {
 if (num ==1)
    return 1;
 return (num * rec_fac(num - 1));
 }


 void rec_fibo(int num)
 {
    if(num <= 0)
      return;
    printf(" %u ", fib1);
    temp = fib1 + fib2;
    fib1 = fib2;
    fib2 = temp;
    rec_fibo(num - 1);
 }
 void rec_disp(int num)
 {
    if(num <= 0)
      return;
    printf("%d ",disp_num - num + 1);
    rec_disp(num - 1);
 }
