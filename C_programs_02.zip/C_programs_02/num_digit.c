/* ********************************************************************
FILE                   : num_digit.c

PURPOSE                : calc and display number of digits of a number
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                       
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main()
{
	char num_str[6];
	int num = 0, temp_num, base = 10000;
	int num_digits, cur_digit, i;
	
	printf("\n Enter number = ");
	scanf("%d", &num);	
	itoa(num,num_str,10);
	 	
	num_digits = strlen(num_str);
	printf("\n num = %s, num_digits = %u ", num_str, num_digits );
	for(i = num_digits - 1; i >=0; --i)
	{
		cur_digit = num_str[i] - '0';
		printf("\n pos = %d, digit = %d ", i + 1, cur_digit);
	}
	
	temp_num = num;
	
	for(i = 5; i> 0; --i, base /= 10 )
	{
		cur_digit = temp_num /base;
		printf("\n pos = %d, digit = %d ", i, cur_digit);
		temp_num %= base;
	}
}

