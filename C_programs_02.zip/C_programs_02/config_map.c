/* ********************************************************************
FILE                   : config_map.c

PROGRAM DESCRIPTION    : practise 2D constant array

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>

#define PIN_TYPE_UNKNOWN       (0)
#define PIN_TYPE_DIGITAL       (1)
#define PIN_TYPE_ANALOG        (2)

#define IO_DIR_INPUT           (0)                  
#define IO_DIR_OUTPUT          (1)

#define STATE_LOW              (0)
#define STATE_HIGH             (1)  

#define IO_FUNC_GPIO           (0)
#define IO_FUNC_SPI            (1)                   
#define IO_FUNC_I2C            (2)
#define IO_FUNC_UART           (3)
#define IO_FUNC_ADC            (4)
#define IO_FUNC_DAC            (5)
#define IO_FUNC_PWM            (6)
#define IO_FUNC_TIMER          (7)
#define IO_FUNC_EXTR_INTP      (8)
#define IO_FUNC_CAPTURE        (9)
#define IO_FUNC_COMP          (10)
#define IO_FUNC_DEBUG         (11)
#define IO_FUNC_TRACE         (12)
#define IO_FUNC_RESERVE       (13)
#define IO_FUNC_SAME          (14)
#define IO_FUNC_UNUSED        (15)  

 typedef unsigned char uint_8;
typedef unsigned short int uint_16;
typedef unsigned int uint_32;
typedef unsigned long uint_64;

typedef char int_8;
typedef short int int_16;
typedef int int_32;
typedef long int_64;

typedef struct
{
	uint_8 io_pin;                   // IO pin
    uint_8 signal        : 2;        //analog, digital     
	uint_8 dir           : 1;        // input or output 
	uint_8 state         : 1;        // state 
	uint_8 func          : 4;        // pin function type ie GPIO, ADC, DAC, Timer, SPI, or I2C, etc     
} io_config_type;

typedef enum
{
    PORT_CHANNEL_00, PORT_CHANNEL_01, NUM_PORT_CHANNELS	
} port_channel_type;

typedef enum 
{ 
  PIN_00, PIN_01, PIN_02, PIN_03, PIN_04, PIN_05, PIN_06, PIN_07, 
  PIN_08, PIN_09, PIN_10, PIN_11, PIN_12, PIN_13, PIN_14, PIN_15,
  PIN_16, PIN_17, PIN_18, PIN_19, PIN_20, PIN_21, PIN_22, PIN_23,
  PIN_24, PIN_25, PIN_26, PIN_27, PIN_28, PIN_29, PIN_30, PIN_31,
  NUM_PINS_PER_PORT   
} io_channel_type;

#define  LED1_PORT0_POS     (PIN_10)

const io_config_type io_config[NUM_PORT_CHANNELS][NUM_PINS_PER_PORT] = {
                                                                          {
																		     { PIN_00, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_01, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_02, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_03, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_04, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_05, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_06, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_07, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
																    		 { PIN_08, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_09, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             {LED1_PORT0_POS, PIN_TYPE_DIGITAL, IO_DIR_OUTPUT, STATE_LOW, IO_FUNC_GPIO},
                                                                             { PIN_11, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_12, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_13, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_14, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_15, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},	
                                                                             { PIN_16, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_17, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_18, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_19, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_20, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_21, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_22, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_23, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_24, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_25, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_26, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},	
                                                                             { PIN_27, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_28, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_29, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_30, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED},
                                                                             { PIN_31, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_UNUSED}
																		 },
                                                                         {
																			 { PIN_00, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},
                                                                             { PIN_01, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},
                                                                             { PIN_02, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},
                                                                             { PIN_03, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},
                                                                             { PIN_04, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},
                                                                             { PIN_05, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},
                                                                             { PIN_06, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},
                                                                             { PIN_07, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},
																			 { PIN_08, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},
                                                                             { PIN_09, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},
                                                                             { PIN_10, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},
                                                                             { PIN_11, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},
                                                                             { PIN_12, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},
                                                                             { PIN_13, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},
                                                                             { PIN_14, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},
                                                                             { PIN_15, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_LOW,  IO_FUNC_RESERVE},	
                                                                             { PIN_16, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { PIN_17, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { PIN_18, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { PIN_19, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { PIN_20, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { PIN_21, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { PIN_22, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { PIN_23, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { PIN_24, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { PIN_25, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { PIN_26, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},	
                                                                             { PIN_27, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { PIN_28, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { PIN_29, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { PIN_30, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED},
                                                                             { PIN_31, PIN_TYPE_DIGITAL, IO_DIR_INPUT, STATE_HIGH,  IO_FUNC_UNUSED}
																	      }
																	  }	;																													 
  

 int main()
 {
 	 uint_8 i, j;
 	 
 	 printf("\n sizeof(io_conf) = %u", sizeof(io_config));
 	 for(i = 0; i < NUM_PORT_CHANNELS; ++i)
	  {
	  	 printf("\n PORT Num : %u ", i);
	  	 for (j = 0; j < NUM_PINS_PER_PORT; ++j)
	  	 {
	  	 	printf("\n Port: %u, Pin: %u, io: %u, signal: %u, dir: %u, state: %u, func = %u", i,j, io_config[i][j].io_pin, io_config[i][j].signal, io_config[i][j].dir, io_config[i][j].state, io_config[i][j].func );
		 }
		 printf("\n");
	  }
    	
    return 0;
 }  
