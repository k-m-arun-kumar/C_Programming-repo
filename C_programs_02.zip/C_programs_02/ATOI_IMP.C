/* ********************************************************************
FILE                   : ATOI_IMP.c

PROGRAM DESCRIPTION    : IMPLEMENTATION OF ATOI function 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include <stdio.h>
#include <conio.h>
unsigned int char_to_digit(const char ch);
unsigned int str_len(const char *);
int main ()
{
   char num_str[6];
   unsigned int num=0,cur_unit, cur_digit= 0, place = 1, ten = 10, num_chars = 0,pos = 0 ;
   clrscr();

   printf("\n enter a num in string = ");
   scanf(" %s", num_str);
   num_chars = str_len(num_str);
   place = 1;
   pos = num_chars - 1;
   cur_unit = char_to_digit(num_str[pos]);
   num = place * cur_unit;
   printf("\n cur_digit[%u], pos[%u], cur_unit = %u, num = %u",\
    cur_digit, pos, cur_unit, num);
   for(cur_digit = 1; cur_digit < num_chars; ++cur_digit)
   {
     place =  place * ten;
     pos = num_chars - 1 - cur_digit;
     cur_unit = char_to_digit(num_str[pos]);
     num += (cur_unit * place);
     printf("\n cur_digit[%u], pos[%u], num = %u, face = %u, place = %u", \
      cur_digit,pos, num, cur_unit, place);
   }
   printf("\n num = %u for string=%s", num, num_str);
   getch();
   return 0;
}
unsigned int str_len(const char *str)
{
    unsigned int num_chars = 0;
    while(*(str + num_chars++));
    printf("\n num chars = %u for string=%s", num_chars - 1, str);
    return num_chars - 1;
}
unsigned int char_to_digit(const char ch)
{
  unsigned int digit = 0;
   switch(ch)
   {
      case '0':
	digit = 0;
	break;
      case '1':
	digit = 1;
	break;
      case '2':
       digit = 2;
       break;
     case '3':
       digit = 3;
       break;
     case '4':
      digit = 4;
      break;
     case '5':
      digit = 5;
      break;
    case '6':
      digit = 6;
      break;
    case '7':
      digit = 7;
      break;
    case '8':
     digit = 8;
     break;
    case '9':
     digit = 9;
     break;
   }
   return digit;
}

