/* ********************************************************************
FILE                   : retrieve.c

PROGRAM DESCRIPTION    : divide a long integer into parts of short integer

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>
#define MAX_NUM_CHARS_INPUT_DATA         (8u)
#define EIGHT_DIGIT                      (8U)
#define FOUR_DIGIT                       (4U) 
#define TWO_PARTS                        (2U)
/* enter num are in integer format, to save eeprom data memory, every 2 digits of num occupies 1 byte with num in hexadecimal format
and store nums in EEPROM with hexadecimal format */
#if ((MAX_NUM_CHARS_INPUT_DATA % EIGHT_DIGIT) == 0) 
	#define MAX_ELEMENTS_EEPROM_NUM_IN_4DIGITS     (MAX_NUM_CHARS_INPUT_DATA / EIGHT_DIGIT)
#else 
	#define MAX_ELEMENTS_EEPROM_NUM_IN_4DIGITS     ((MAX_NUM_CHARS_INPUT_DATA / EIGHT_DIGIT) + 1)
#endif
/* retrieved num from EEPROM are in hexadecimal format, every 4 digits of num occupies 1 word with num in intefger format */
#if ((MAX_NUM_CHARS_INPUT_DATA % FOUR_DIGIT) == 0) 
	#define MAX_ELEMENTS_CUR_NUM_IN_8DIGITS     (MAX_NUM_CHARS_INPUT_DATA / FOUR_DIGIT)
#else
	#define MAX_ELEMENTS_CUR_NUM_IN_8DIGITS     ((MAX_NUM_CHARS_INPUT_DATA / FOUR_DIGIT) + 1)
#endif

unsigned int eeprom_num_digits_entered, ram_num_8digit_cur_index = 0, eeprom_num_2digits_cur_index = 0;
unsigned short int read_eeprom[MAX_NUM_CHARS_INPUT_DATA], eeprom_num_in_mul_4digit[MAX_ELEMENTS_EEPROM_NUM_IN_4DIGITS];


unsigned long int ram_num_in_mul_8digits[MAX_ELEMENTS_CUR_NUM_IN_8DIGITS];

union num_alignment
{
	unsigned long int ram_num_in_single_8digits;
	unsigned short int eeprom_num_in_two_4digits[TWO_PARTS];
};
union num_alignment num_8digit_4digit_conv;

union num_alignment *const ptr_conv_cur_index = &num_8digit_4digit_conv;

void Retrieve_Datas();
int main()
{
	unsigned int i = 0, max_eeprom_num_in_mul_4digit = 0;
   
   printf("\n Enter size in parts of 4digits: ");
   scanf("%u", &eeprom_num_digits_entered);
   for(i = 0 ; i < eeprom_num_digits_entered; ++i)
   {
	   printf("\n [%d] num part of 4 digits : ", i + 1);
	   scanf("%hu", &read_eeprom[i]);	 
   }
   Retrieve_Datas();
   if(eeprom_num_digits_entered % 2)
   {
	 max_eeprom_num_in_mul_4digit =  (eeprom_num_digits_entered / 2) + 1;
   }
   else
   {
	   max_eeprom_num_in_mul_4digit =(eeprom_num_digits_entered / 2);
   }

  for(i = 0;i < max_eeprom_num_in_mul_4digit; ++i)
   {
   	 
	   printf("\n 8de[%u] = %lu", i, ram_num_in_mul_8digits[i]);
   }
    getch();
   return 0;
}
void Retrieve_Datas()
{

	unsigned int whole_num_four_digit_index = 0, parts_index=0, max_eeprom_num_in_mul_4digit = 0;
	unsigned int whole_num_eight_digit_index  = 0,i = 0;

    if(eeprom_num_digits_entered % 2)
	{
		max_eeprom_num_in_mul_4digit = (eeprom_num_digits_entered / 2) + 1;
	}
    else
	{
		max_eeprom_num_in_mul_4digit = (eeprom_num_digits_entered / 2);
	}
	printf("\n max_eeprom_num_in_mul_4digit = %u ", max_eeprom_num_in_mul_4digit);
	for( whole_num_four_digit_index = 0; whole_num_four_digit_index < max_eeprom_num_in_mul_4digit * 2; ++whole_num_four_digit_index)
	{
	   eeprom_num_in_mul_4digit[whole_num_four_digit_index] = read_eeprom[whole_num_four_digit_index];
	   ptr_conv_cur_index->eeprom_num_in_two_4digits[parts_index] = eeprom_num_in_mul_4digit[whole_num_four_digit_index];
	   printf("\n 4d[%u]: %hu",whole_num_four_digit_index , ptr_conv_cur_index->eeprom_num_in_two_4digits[parts_index]);
	   if(whole_num_four_digit_index % TWO_PARTS)
	   {
		  ram_num_in_mul_8digits[whole_num_eight_digit_index] =  ptr_conv_cur_index->ram_num_in_single_8digits;
		  printf("\n ==========================="); 
		  printf("\n 4dh : %hu, 4dl: %hu, 8d[%u]: %lu", ptr_conv_cur_index->eeprom_num_in_two_4digits[1],  ptr_conv_cur_index->eeprom_num_in_two_4digits[0],\
		    whole_num_eight_digit_index, ram_num_in_mul_8digits[whole_num_eight_digit_index] );
		  printf("\n ===========================");
		  ++whole_num_eight_digit_index;
		  i = 0;
		  while(i < whole_num_eight_digit_index )
		  {
		  	printf("\n 8dc[%u]: %lu", i, ram_num_in_mul_8digits[i] );
		  	++i;
		  }
		  parts_index = 0;
       }
       else
	   {
		   ++parts_index;
		   ptr_conv_cur_index->eeprom_num_in_two_4digits[parts_index] = 0;		   		  
	   }
	}
	whole_num_eight_digit_index = 0;
}
