/* ********************************************************************
FILE                   : consucc_bits.c

PROGRAM DESCRIPTION    : a integer data bit SET, Clear and Toggle operation

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>

#define SET_CONSUCC_BIT    (1)
#define CLEAR_CONSUCC_BIT  (2)
#define TOGGLE_CONSUCC_BIT (3)

#define SUCCESS            (0)
#define FAILURE            (1)
  
typedef unsigned int uint_32;
typedef unsigned char uint_8;

typedef struct 
{
	uint_32 consucc_val;
	uint_8 start_bit_pos;
	uint_8 bits_len;
} consucc_bit_type;

uint_8 Config_Consucc_Bits(void *data_ptr, uint_8 consucc_bit_flag);

int main()
{
	consucc_bit_type consucc_bit_data;
	uint_32 temp_data;
	uint_8 to_continue, config_consucc_bit_flag ;
	
	do
	{
		printf("\n Enter start pos - ");
		scanf("%u", &temp_data);
		consucc_bit_data.start_bit_pos  =  temp_data;
		printf("\n Enter bits len - ");
		scanf("%u", &temp_data);
		consucc_bit_data.bits_len  =  temp_data;
		printf("\n Enter data - ");
		scanf("%u", &consucc_bit_data.consucc_val);
		printf("\n Enter MODE - 1: SET, 2:CLEAR, 3: TOGGLE -  ");
		scanf("%u", &temp_data);
		config_consucc_bit_flag = temp_data;
		Config_Consucc_Bits((void *) &consucc_bit_data, config_consucc_bit_flag );
		printf("\n RESULT: mode %u", config_consucc_bit_flag);
		printf("\n Start_bit_pos: %u, bits_len; %u, consucc_val: %u", consucc_bit_data.start_bit_pos, consucc_bit_data.bits_len, consucc_bit_data.consucc_val );		
		printf("\n Do u want to continue: press Y or y - ");
		to_continue = getch();		
	} while(to_continue == 'Y' || to_continue == 'y');
    return 0;    
}

uint_8 Config_Consucc_Bits(void *data_ptr, uint_8 consucc_bit_flag)
{
	uint_8 i, ret_status = SUCCESS;
    uint_32 pos0_consucc_bits = 0;	
	consucc_bit_type *consucc_bit_ptr = (consucc_bit_type *)data_ptr;
	
	if(consucc_bit_ptr == NULL || consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len > 32)
	{
		return  FAILURE;
	}
	for(i = 0; i < consucc_bit_ptr->bits_len; ++i)
	{
	  	pos0_consucc_bits |= 1 << i;			
	}
	switch(consucc_bit_flag)
	{
         case SET_CONSUCC_BIT:
		    consucc_bit_ptr->consucc_val |=  pos0_consucc_bits << consucc_bit_ptr->start_bit_pos;
	     break;		
	     case CLEAR_CONSUCC_BIT:
		    consucc_bit_ptr->consucc_val &= ~(pos0_consucc_bits << consucc_bit_ptr->start_bit_pos);
	     break;
		 case TOGGLE_CONSUCC_BIT:
		    consucc_bit_ptr->consucc_val ^= (pos0_consucc_bits << consucc_bit_ptr->start_bit_pos);
		 break;
		 default:
		    ret_status = FAILURE;
	}
	return ret_status;
}
