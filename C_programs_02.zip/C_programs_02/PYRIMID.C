/* ********************************************************************
FILE                   : PYRIMID.c

PROGRAM DESCRIPTION    : DISPLAY A PYRIMID pattern

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>

int main()
{
   int inc = 5, j, k = 0, inc_cnt = inc;

   while(k < inc)
   {
         for(j = 1; j <= inc_cnt; ++j)
	     {
		 printf("%u", j);
	     }
	     for(j = 1; j <= k * 2 ; ++j)
	     {
		 printf("%c",'-');
	     }
	     for(j = inc_cnt; j > 0; --j)
	     {
	       printf("%u", j);
	     }
	     printf("\n");
      ++k;
      --inc_cnt;
   }
   return 0;
}
