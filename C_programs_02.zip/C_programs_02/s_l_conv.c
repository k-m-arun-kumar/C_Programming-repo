/* ********************************************************************
FILE                   : s_l_conv.c

PROGRAM DESCRIPTION    : 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include <stdio.h>

union num_alignment
{
	unsigned long int ram_num_in_single_4digits;
	unsigned short eeprom_num_in_two_2digits[2];
};
union num_alignment num_4digit_2digit_conv;

union num_alignment *const ptr_conv_cur_index = &num_4digit_2digit_conv;

int main()
{
   unsigned short lower_short, higher_short;
   unsigned long int num_word; 
   printf("\n size long : %u, size short: %u, size int : %u", sizeof(unsigned long), sizeof(unsigned short), sizeof(unsigned int)) ;
   printf("\n Enter lower short : ");
   scanf("%hu", &lower_short);
   printf("\n Enter higher short : ");
   scanf("%hu", &higher_short);
   ptr_conv_cur_index->eeprom_num_in_two_2digits[0] = lower_short;
   ptr_conv_cur_index->eeprom_num_in_two_2digits[1] = higher_short;
   num_word = ptr_conv_cur_index->ram_num_in_single_4digits;
   printf("\n higher_short: %hu, lower_short: %hu, WORD : %lu",higher_short,lower_short, num_word);
   return 1;
}
