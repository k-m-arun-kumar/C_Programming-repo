/* ********************************************************************
FILE                   : POWER_SE.c

PURPOSE                : check if a number is power of 2.
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                       
CHANGE LOGS           : 

*****************************************************************************/


#include "stdio.h"
#include "conio.h"
#include "stdlib.h"

typedef struct 
{
	int arr_unique_element;
	int arr_unique_element_result;
} result_data;

result_data  *Is_Power(int , int *, int *);
int main()
{
   int *input_arr, i = 0, to_continue = 1;
   int input_arr_size, num, result_arr_size;
   result_data *result_arr;
   
   do
   {
   printf("\n Enter num_size : enter - ");
   scanf("%d",&input_arr_size);
   input_arr = (int *) malloc(sizeof(int) * input_arr_size);
   printf("\n Enter input arr elements : ");
   for(i = 0; i < input_arr_size; ++i)
   {
       printf("\n %d element - enter : ", i);
       scanf("%d", input_arr + i);
       printf("\n %d - %d\n", i, input_arr[i]);
   }
   result_arr  = Is_Power(input_arr_size, input_arr, &result_arr_size );
   printf("\n Result ");
   for(i = 0; i <result_arr_size ; ++i)
   {
       printf("\n %d: %d -  %d",i ,result_arr[i].arr_unique_element,  result_arr[i].arr_unique_element_result);
   }
   free(input_arr);
   free(result_arr);
   printf("\n Do u want to continue (1/0) - Enter - ");
   scanf("%d", &to_continue);
   }   
   while(to_continue == 1); 
   getch();
   return 0;
 }
 result_data* Is_Power(int input_arr_size, int *input_arr, int *result_arr_size)
 {
  int power, i = 0, arr_result_size = 0, j = 0;
  result_data *arr_result;
  
   arr_result =( result_data*) malloc(sizeof(result_data) * input_arr_size);
      
   for(i = 0 ; i < input_arr_size; ++i)
   {
   	  for(j =0 ; j < arr_result_size ; ++j)
   	  {
   	  	 if(arr_result[j].arr_unique_element == input_arr[i])
   	  	 {
   	  	 	printf("\n MATCH FOR previous result, input_arr_element = %d arr_result_index : %d, input_arr_index = %d", input_arr[i],j, i);
   	  	    break;
   	     }
   	  }
   	  if(arr_result_size == j)
	  {    
		     arr_result[arr_result_size].arr_unique_element = input_arr[i];
             for(power = 1; power <= input_arr[i] ; power = power * 2);
             if((power / 2) % input_arr[i] == 0 )
             {    
			     printf("\n %d - %d num power of 2", i, input_arr[i]);
                 arr_result[arr_result_size].arr_unique_element_result = 0;
             }
             else
             {
                printf("\n %d - %d num not power of 2", i, input_arr[i]);
                arr_result[arr_result_size].arr_unique_element_result = 1;
            }
            
            ++arr_result_size;
        }
    }
    arr_result = (result_data *) realloc(arr_result, sizeof(result_data) * arr_result_size);
    *result_arr_size = arr_result_size;
     return arr_result;
}
