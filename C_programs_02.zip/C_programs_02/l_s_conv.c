/* ********************************************************************
FILE                   : l_s_conv.c

PURPOSE                : long integer data into integer parts
                     									 	 
AUTHOR                : K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            : 

NOTE                  : Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                       
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>
#define MAX_NUM_CHARS_INPUT_DATA          (8) 
#define NUM_CONV_IN_TWO_PARTS             (2U)
#define FOUR_DIGIT                        (4U)
#define EIGHT_DIGIT                       (8U) 
/* enter num are in integer format, to save eeprom data memory, every 2 digits of num occupies 1 byte with num in hexadecimal format
and store nums in EEPROM with hexadecimal format */
#if ((MAX_NUM_CHARS_INPUT_DATA % FOUR_DIGIT) == 0) 
	#define MAX_ELEMENTS_EEPROM_NUM_IN_4DIGITS     (MAX_NUM_CHARS_INPUT_DATA / FOUR_DIGIT)
#else 
	#define MAX_ELEMENTS_EEPROM_NUM_IN_4DIGITS     ((MAX_NUM_CHARS_INPUT_DATA / FOUR_DIGIT) + 1)
#endif
/* retrieved num from EEPROM are in hexadecimal format, every 4 digits of num occupies 1 word with num in intefger format */
#if ((MAX_NUM_CHARS_INPUT_DATA % EIGHT_DIGIT) == 0) 
	#define MAX_ELEMENTS_CUR_NUM_IN_8DIGITS     (MAX_NUM_CHARS_INPUT_DATA / EIGHT_DIGIT)
#else 
	#define MAX_ELEMENTS_CUR_NUM_IN_8DIGITS     ((MAX_NUM_CHARS_INPUT_DATA / EIGHT_DIGIT) + 1)
#endif

union num_alignment
{
	unsigned long int ram_num_in_single_8digits;
	unsigned short eeprom_num_in_two_4digits[NUM_CONV_IN_TWO_PARTS];	
};
union num_alignment num_8digit_4digit_conv, *const ptr_conv_cur_index = &num_8digit_4digit_conv;
unsigned int ram_num_8digit_cur_index,eeprom_num_4digits_cur_index, num_digits_entered_cur_data;
unsigned long int ram_num_in_mul_8digits;
unsigned short int save_num_in_two_4digits;

int main()
{
	printf("\n Enter num digits : ");
	scanf("%u", &num_digits_entered_cur_data);
	printf("\n Enter num to convert lower parts : ");
	scanf("%lu", &ram_num_in_mul_8digits);
	
    eeprom_num_4digits_cur_index =  num_digits_entered_cur_data % (EIGHT_DIGIT / FOUR_DIGIT); 
    ptr_conv_cur_index->ram_num_in_single_8digits =  ram_num_in_mul_8digits;       
	save_num_in_two_4digits = ptr_conv_cur_index->eeprom_num_in_two_4digits[eeprom_num_4digits_cur_index];
	
	printf("\n part_index: %u: word: %lu in req short: %hu ", eeprom_num_4digits_cur_index, ram_num_in_mul_8digits, save_num_in_two_4digits);
	printf("\n word: %lu in higher short: %hu, lower short: %hu", ram_num_in_mul_8digits, ptr_conv_cur_index->eeprom_num_in_two_4digits[1], \
	    ptr_conv_cur_index->eeprom_num_in_two_4digits[0]);
	return 1;
}
