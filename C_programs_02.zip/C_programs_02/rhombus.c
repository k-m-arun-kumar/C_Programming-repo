/* ********************************************************************
FILE                   : rhombus.c

PROGRAM DESCRIPTION    : display a rhombus pattern

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>


int main()
{
   unsigned int rh_size = 4, i = 0, j = 0, min_col = rh_size, col_len = 1;
   
   for(i = 1;  i < (rh_size) ; ++i )
   {
       for(j = 1; j < min_col; ++j)
	   {
	       printf("%c", ' ');
	   }
	   for(j = min_col; j < min_col + col_len; ++j )
	   {
	      printf("%c", '*');
	   }
	   min_col -= 1;
	   col_len += 2;
	   printf("\n");
   }
   for(i = rh_size ; i <= rh_size * 2 - 1; ++i)
   {
       for(j = 1; j < min_col; ++j)
	   {
	       printf("%c", ' ');
	   }
	   for(j = min_col; j < min_col + col_len; ++j )
	   {
	      printf("%c", '*');
	   }	
	   min_col += 1;
	   col_len -= 2;
	   printf("\n");
   }
   return 0;
}
