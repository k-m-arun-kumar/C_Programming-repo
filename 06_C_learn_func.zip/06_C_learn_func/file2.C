/* ********************************************************************
FILE                   : file2.c

PROGRAM DESCRIPTION    : practise C coding in functions

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

int l;
static int k;

static void fun(void);

int main()
{

  int test(void);
  clrscr();
  printf("\n inside main");
  test();
}


int test(void)
{
   printf("\n inside test fun \n k = %d", k);
   fun();
   return 34;

}

void fun(void)
{

  int check(int);

  printf("\n inside fun");
  k = check(5);
}


static int check(int n)
{
    k += n;
    printf("\n inside check: k = %d, l = %d", k, l);
    return 23;
}

