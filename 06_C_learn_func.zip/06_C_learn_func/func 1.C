/* ********************************************************************
FILE                   : func 1.c

PROGRAM DESCRIPTION    : practise C coding in functions

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

/* int check(int); */ 
/* if func undeclared, then assumes returns int type  */

ptret(int i)
{
  int *pt = &i;

  return pt;            /*  warning: non portable pointer conversion */
}

int main()
{


 int unsigned b = 32888;
 short s = 23;
 float f = 23.1;
 int i = 53;
 char ch = 320;
 char a[] = "4rtrg";

 int x= 3, z, *y = &x;

 /* check(int); */      /* error: expression syntax */
 /* i = check(3,8,9)*/  /* error: extra parameter */
 i = check(9.9);
 printf("\n i = %d", i);

 y = ptret(i);         /* warning: non portable pointer conversion*/
 printf("\n *y = %d, *y = %d ", *y, *y + 110); /*  garbage */



 }

/* float check(int ch) */ /* error: redecl of check, if undeclared before */
 check(int ch)
 {
   /* ch >= 54 ? return(3): return(4); */ /* error: expersion syntax */
   return (float) (ch + 2 + 5.5);
 }

