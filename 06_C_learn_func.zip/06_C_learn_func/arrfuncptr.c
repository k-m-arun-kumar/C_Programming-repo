/* ********************************************************************
FILE                   : arrfuncptr.c

PROGRAM DESCRIPTION    : practise C coding in functions

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

#define ROW 3
int (*hostarrfunc[ROW])(char *);
int guestfunc1(char *);
int guestfunc2(char *);
int guestfunc3(char *);

int main()
{
    int in;
	 hostarrfunc[0] = guestfunc1; 
	 printf("\n *(hostarrfunc[0]) = %d", (*hostarrfunc[0])("1st func"));
	// hostarrfunc + 1 = &guestfunc2; error 
	 hostarrfunc[1] = guestfunc2;
	 hostarrfunc[2] = hostarrfunc[1];
	 printf("\n *(hostarrfunc[2]) = %d", (*hostarrfunc[2])("2st func"));
    return 1;
}

int guestfunc1(char *str1)
{
   printf("\n inside guestfunc1, str1= %s", str1);
   return 10;  
}

int guestfunc2(char *str2)
{
   printf("\n inside guestfunc2, str2= %s", str2);
   return 20;  
}
int guestfunc3(char *str3)
{
   printf("\n inside guestfunc3, str3= %s", str3);
   return 30;  
}
