/* ********************************************************************
FILE                   : func 3.c

PROGRAM DESCRIPTION    : practise C coding in functions

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

int check(float);
int* laugh(int);
void test(char []);
int fun(int, float, char, char []);

int i = 23;
/* int j = i; */         /* error: illegal initialization */

int main()
{

 
 long s = 23;
 float f = 23.1;
 int i = 53;
 char ch = 320;
 char a[] = "4rtrg";
/* static int k = i; */      /* error: illegal initialization */

 int x= 3, z, *y = &x;

  /* a =  fun(23,45.4, 'a', "234"); */ /* error: lvalue required */
  /* y = fun(23, 45.4,'s', "567");  */ /* warning: non portable assign */
  s = fun(23,45.6,'d', "789");
  printf("\n x = %d, ", x);

  /* test(ch);        */        /* warning: non portable ptr conversion, run time: divide error */
  /* test("123");     */

  /* x = check(23.4); */        /* x is garbage */
 /* x	= laugh(56); */	        /* warning: non portable ptr assign, x = garbage */

  printf("\n x = %d \n Main end");
 }




 int check(float f)
 {
     int *pt, i = 45;
     pt = &i;
     printf("\n inside check");
     return pt;                  /* warning: non portable ptr conversion */
 }

int fun(int i, float f, char c, char ch[])
{
  printf("\n inside fun");
  printf("\n i = %d, f = %f, c = %c, ch = %s",i,f,c,ch);
  return 3;
}

void test(char s[])
{

    int d;
    char c, ch;
    printf("\n inside test \n printf returns: %d \n get a number :", printf("\n s = %s", s));
   /* printf("\n after getting no: %d : get a character :", scanf("%d", &d) ); */
    fflush(stdin);
    scanf("%d %c", &d, &c);       /* if data given is c 4 g, then d, c are not taken, ch = c */
   /* fflush(stdin); */
    scanf("%c", &ch);

    /* scanf(" %c", &c); */
    printf("\n d = %d, c = %c, ch = %c",d , c, ch);
    printf("\n test func end");

}


int* laugh(int h)
{
  printf("\n inside laugh func");
  return 1;                    /* warning: non portable ptr conversion */
}


