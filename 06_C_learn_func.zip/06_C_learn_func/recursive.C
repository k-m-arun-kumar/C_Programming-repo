/* ********************************************************************
FILE                   : recursive.c

PROGRAM DESCRIPTION    : practise C coding in recursive functions

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

/* recursive func for 1+ (2 * 2) + ..........+ (num * num) */
#include "stdio.h"

int display_data(int num);

int main()
{
   long int sumsquare = 1;
   int num = 0;

   clrscr();
   printf("\n Enter number for sum square: ");
   scanf("%d", &num);
   if(num > 0)
   {
     sumsquare += exec_sumsquare(num);
     printf("\n sums square: %ld", sumsquare);

   }
   display_data(num);
   return 1;
}

int exec_sumsquare(int num)
{
  if(num == 1)
   return 1;                                   /* base code for sumsquare's recursive */
  else
   return num*num + exec_sumsquare(num - 1);   /* general code of sumsquare's recursive */
}

int display_data(int num)
{
   if(num == 0)                                /* base code for display_data's recursive */
      return 0; 
   display_data(num - 1);                      /* general code of display_data's recursive */ 
   printf("\n Num display: %d", num);

   /* if (num == 0)
     return 0; */  
   /* if it is only base code for display_data's recursive, infinte loop */                            

   return 1; 
}
