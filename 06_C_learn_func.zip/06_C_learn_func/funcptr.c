/* ********************************************************************
FILE                   : funcptr.c

PROGRAM DESCRIPTION    : practise C coding in functions

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
float funchost(int (*)(int, float), char ch);
int funcguest1(int, float);
int funcguest2(int, float);
int main()
{
      
	printf("\n flt  =%f after funcguest1", funchost(funcguest1, 'a'));
       /* assign func pointer funcptr = funcguest1 is same as funcptr = & funcguest1 as compiler
        ignores & if identifier is as function. As with array names, when
          name of a function is used, it returns the function�s address */
	printf("\n flt  =%f after funcguest2", funchost(&funcguest2, 'z'));

	return 1;
}

float funchost(int (*funcptr)(int intarg, float fltarg), char ch )
{    
     int guest_int_arg; 
	 float guest_flt_arg;
	 
     switch(ch)
	 {
	 case 'a':
	   guest_int_arg = 10 ;
	   guest_flt_arg = 100.0;
	   break;
	 case 'z':
	   guest_int_arg  = 50;
	   guest_flt_arg  = 500.0;
	   break;
	 default:
       printf("\n ERROR: host function has received invalid ch = %c", ch);
	   return 0.0;
     }  
  
     printf("\n ch = %c in host function , return of guest function = %d", ch, funcptr(guest_int_arg, guest_flt_arg) );
    /*  (*funcptr)(guest_int_arg, guest_flt_arg) same as calling guest func as funcptr(guest_int_arg, guest_flt_arg) */
       printf("\n ch = %c in host function , return of guest function = %d", ch, (*funcptr)(guest_int_arg, guest_flt_arg) );   
	 if(funcptr == funcguest1)
	    return 7.0;
	 else if(funcptr == funcguest2) 
        return 14.0;
	 else 
           printf("\n host function has called different function");

 
        return 0.0;
		
}

int funcguest1(int inarg1, float fltarg1)
{
    printf("\n in guest function 1 : int_arg = %d, flt_arg =%f", inarg1, fltarg1);
	return 1;
}

int funcguest2(int inarg1, float fltarg1)
{
    printf("\n in guest function 2 : int_arg = %d, flt_arg =%f", inarg1, fltarg1);
	return 2;
}




