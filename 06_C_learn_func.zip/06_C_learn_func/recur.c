/* ********************************************************************
FILE                   : recur-.c

PROGRAM DESCRIPTION    : practise of recursive function in C

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>
#include <ctype.h>
 
/* function prototype: function returns Integer */
 
int recursive_display(int);     
 
int main(void)
{	
    int char_dec_val,ret;
 
    if (ret = recursive_display(char_dec_val = getchar()))
        printf("\nrecursive fun. implemented successfully!\n");
    else
        printf("recursive fun. returns 0, so else executed!\n");
 
    printf("recursive_display() returns %d\n", ret);
    return 0;
}
int recursive_display(int counter)
{	
    if (counter == 1) {
        printf("Recursion Count is %d\n", counter);
        return 1;
    }
    else {
        printf("Recursion Count is %d\n", counter--);
        return recursive_display(counter);
    }
}
