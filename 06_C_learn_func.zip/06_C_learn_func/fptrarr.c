/* ********************************************************************
FILE                   : fptrarr.c

PROGRAM DESCRIPTION    : practise C coding in functions

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
/* operations is a array of  function pointers of size 4, whose function takes 2 integers a argument and return an integer */
typedef int (*fptrOperation)(int , int);

int add(int num1, int num2);
int subtract(int num1, int num2);
int operInit();
int evaluateArray(int opcode, int num1, int num2);

int (*operations[4])(int, int) = {NULL};
int main()
{
   operInit();
   
   printf("\n additon using array of func ptr: %d", evaluateArray(0, 5, 6));
   printf("\n subtraction using array of func ptr: %d", evaluateArray(1, 5, 6));
   return 1;
}

int operInit()
{
   operations[0]= add;
   operations[1]= subtract;
   return 1;
}

int evaluateArray(int opcode, int num1, int num2)
 {
    fptrOperation operation;
	if(operations[opcode] != NULL)
	{
      operation = operations[opcode];
      return operation(num1, num2);
	}
	else
	 printf("\n func pointer of arr [%d] IS null", opcode);
	return 0; 
}

int add(int num1, int num2)
{
 return (num1 + num2);
 }
 
int subtract(int num1, int num2)
{
 return (num1 - num2);
}
