/* ********************************************************************
FILE                   : fptr_ret.c

PROGRAM DESCRIPTION    : practise C coding in functions

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
/* funcptr is a user defined data type which is function pointer
that takes a integer a argument and returns integer */ 
typedef int (*funcptr)(int);

/* fptrOperation is a user defined data type which is function pointer
that takes a 2 integers a argument and returns integer */ 
typedef int (*fptrOperation)(int,int);

int (*fptr1)(int);
int square(int);

int add(int num1, int num2);
int subtract(int num1, int num2);
int compute(fptrOperation operation, int num1, int num2) ;

fptrOperation select(char opcode);
int evaluate(char opcode, int num1, int num2);

int main()
{
   int n = 5;
   funcptr fptr2;
   fptr1 = square;
   printf("\n %d squared is %d",n, fptr1(n));
   n = 10;
   fptr2 = square;
   printf("\n %d squared is %d",n, fptr2(n));
   
   printf("\n addition using funcptr as arg: %d",compute(add,5,6));
   printf("\n subtraction using funcptr as arg: %d",compute(subtract,5,6));
   
   printf("\n addition using funcptr as return:%d",evaluate('+', 5, 6));
   printf("\n subtraction using funcptr as return:%d",evaluate('-', 5, 6));
    return 1;   
  }


int square(int num) 
{
   return ((float) (num*num));
}

int add(int num1, int num2)
 {
return num1 + num2;
}
int subtract(int num1, int num2)
 {
return num1 - num2;
}

int compute(fptrOperation operation, int num1, int num2) 
{
  return operation(num1, num2);
}

fptrOperation select(char opcode) 
{
switch(opcode) 
{
case '+':
 return add;
case '-': 
 return subtract;  
 default:
  printf("\n illegel arthimetic operation ");
  return NULL;
 }
}  
int evaluate(char opcode, int num1, int num2) 
{
    fptrOperation operation = select(opcode);
    return operation(num1, num2);
}
