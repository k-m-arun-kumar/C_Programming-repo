/* ********************************************************************
FILE                   : vararg.c

PROGRAM DESCRIPTION    : practise C coding in functions

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "stdarg.h"

#define NUM_SIM_FSM              2     /* Number of SIM FSM state: idle & process */
#define IDLE_SIM_FSM             0     /* Simulation is yet to start */
#define PROCESS_SIM_FSM          1     /* Simulation is under process */

int SimFSM_Idle();
int SimFSM_Process();

sim_state = IDLE_SIM_FSM;

typedef struct
{
	int (*sim_fsm)();
} sim_fsm_func;

sim_fsm_func sim_fsm_table[NUM_SIM_FSM] =
{
    {SimFSM_Idle},      /* Simulation is idle */
    {SimFSM_Process}    /* Simulation is under process */
};

int main()
{

}
