/* ********************************************************************
FILE                   : func ptr 1.c

PROGRAM DESCRIPTION    : practise C coding in functions

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "stdlib.h"

#define MODE_1  1
#define MODE_2  2

struct employee
{
	int empid;
	char name[15];
};

int fun1(void *);
int fun2(void *);
void *Mode1_Input(int);
int Mode1_Output(int);
void Mode2_Init(void);
void *Mode2_Input(int);
int Mode2_Output(int);

static struct
{
    unsigned int mode;
    void (*Init) ();
    void *(*Input) ();
    int (*Print) ();
    char *name;
}
modetbl[] =
{
    {
       MODE_1,NULL, Mode1_Input, Mode1_Output, "MODE1"
    }
    ,
    {
		MODE_2, Mode2_Init, Mode2_Input, Mode2_Output, "MODE2"
    }
};

#define NO_MODES    (sizeof(modetbl)/sizeof(modetbl[0]))

int (*funptr[]) () =  {fun1, fun2};

int num;
struct employee emp_data[5];

int main()
{
   char name[] = "hello";
   int i;
   int mode;

   printf("\n sizeof empdata: %d & name: %d, addr: %#x, addr: %#x", sizeof(emp_data), sizeof(name), emp_data, emp_data + 1 );
   for(i = 0 ;i < NO_MODES ; ++i)
   {
	   /* if below is not checked then run time abnormal program terminate */
	   if(modetbl[i].Init != NULL)
	      (*modetbl[i].Init)();
	(*modetbl[i].Input)(i);
	(*modetbl[i].Print)(i);
   }
   return 1;
}

int fun1(void *emp_data)
{
    char name[] = "vanda mataram";

    (++(struct employee *)emp_data)->empid = 25;
    memcpy(((struct employee *)emp_data)->name,name, sizeof(name));
    return 1;
}

int fun2(void *emp_data)
{
	int i;
    for(i = 0; i <5; ++i)
      printf("\n [%d] empid: %d, emp name: %s", i, ((struct employee *) emp_data+ i)->empid, ((struct employee *)emp_data + i)->name);
    return 1;
}

void Mode2_Init()
{
	int i = 0;

    memset(&emp_data[0], 0, sizeof(emp_data));
    for(i = 0; i <5; ++i)
      printf("\n [%d] empid: %d, emp name: %s", i, emp_data[i].empid, emp_data[i].name);

  /* *funptr[0](temp_emp)) */          /* Error: calling non function */
    return ;
}

void* Mode1_Input(int a)
{
	printf("\n Enter a number: ");
	scanf("%d", &num);
	return &num;
}

void* Mode2_Input(int a)
{
	char name[] = "vanda mataram";
    char dest_name[20];
    memcpy(dest_name, name, sizeof(name));
	printf("\n Enter emp id: & name :");
	scanf("%d %[^\n]", &emp_data[0].empid, emp_data[0].name );
    (*funptr[0])(emp_data);
    (*funptr[1])(emp_data);
    printf("\n dest_name: %s", dest_name);
	return emp_data;
}

int Mode1_Output(int a)
{
	printf("\n a = %d, name: %s, enterned data: %d ", a,modetbl[a].name, num );
	return 1;
}

int Mode2_Output(int a)
{
	printf("\n a = %d, name: %s, enterned data: %d, name: %s ", a,modetbl[a].name, emp_data[0].empid,emp_data[0].name );
	return 1;
}
