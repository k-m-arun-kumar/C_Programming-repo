/* ********************************************************************
FILE                   : func 2.c

PROGRAM DESCRIPTION    : practise C coding in functions

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

int check(float);
int laugh(int);
void test(float);
int fun(int, float, char, char []);

int main()
{


 long s = 23;
 float f = 23.1;
 int i = 53;
 char ch = 320;
 char a[] = "4rtrg";

 int x= 3, z, *y = &x;

/* x =  test(2.5); */                  /* error: expression type not allowed */
 x = check(3);                         /* x will have garbage value */
 x = (float) fun(23,45.4, 'a', "234");
/* x = fun(23, 45.4, "234", "123"); */ /* error: type mismatch in para 3 */
/* x = fun(23,"a",'a', "123");  */     /* error: type mismatch in para 2 */
/* x = fun(23,45.6,'a', 'a');   */     /* warning: non portable ptr conversion, var ch[] garbage */
 x = fun(23, 'c','a', "23");
/* x = fun(23,45,'s',4);        */     /* warning: non portable ptr conversion, var ch[] garbage */
/* x = fun(2, 4.5);             */     /* error: too few parameters to call */

 printf("\n x = %d", x);

 }




 /* float check(float f) */ /* error: type redeclaration mismatch */
 int check(float f)
 {
     printf("\n inside check");
     return;
 }

int fun(int i, float f, char c, char ch[])
{
  printf("\n inside fun");
  printf("\n i = %d, f = %f, c = %c, ch = %s",i,f,c,ch);
  return 3,6.789;
}

/* void test(float) */ /* error: arg 1 missing */
void test(float f)
{
    /* int check(int);*/  /* error: type mismatch redeclaration */
    int check (float);
    printf("\n inside test");
    return 1;             /* warning: void func may not return */
}




