/* ********************************************************************
FILE                   : fptrcast.c

PROGRAM DESCRIPTION    : practise C coding in functions

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "stdio.h"
typedef int (*fptrToSingleInt)(int);
typedef int (*fptrToTwoInts)(int,int);
typedef void (*fptrBase)();

int add(int, int);
void arrpass(int *, int);
int main()
{
/* error arr undefined as = has associativity from L->R
  int *iptr =  arr , arr[4] = {10,20,30,40},i ; */
   int arr[4] = {10, 20, 30, 40}, *iptr =  arr, i ;
   int size = sizeof arr/ sizeof(int);
   	  
  fptrToTwoInts fptrFirst = add;
  fptrBase basePointer;
  
  arrpass(arr, size);
   
   for(i=0; i<size; i++) 
      printf("\n (arr + %d) = %ux ,arr[%d] = %d",i, (arr + i), i, arr[i] );
	  
	  
  fptrToSingleInt fptrSecond = (fptrToSingleInt)fptrFirst;
  fptrFirst = (fptrToTwoInts)fptrSecond;
  printf("\n addition using casting of func pointers: %d",fptrFirst(5,6));  
  

fptrFirst = add;
basePointer = (fptrBase)fptrFirst;
fptrFirst = (fptrToTwoInts)basePointer;
printf("\n addition using casting func pointers via void %d\n",fptrFirst(5,6));
}

int add(int num1, int num2)
{
   return (num1 + num2);
}

void arrpass(int *iptr, int size)
{
   int i=0, value  = 3;
   for(i=0; i<size; i++) 
   {
      *iptr++ *= value;
    /*  printf("\n iptr = %ux, *iptr = %d", iptr, *iptr); */
     
   }
   return;
}
