/* ********************************************************************
FILE                   : ptr_char.c

PROGRAM DESCRIPTION    : practise of c coding in string

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>
/* structure declaration */
typedef struct A {                     /* typedef creates new type */
                  char surname[15];
                  int roll_no;
                  char initial[5];
                  float marks;
        }New;
int main()
{
	int i = 0;
	char *str[] = {"hello", "world", "hi", "bye"}; 

    New x = {"smith", 34, "J", 67.38}; /* x is a variable of New */
    New y[10];                         /* 'y' an array of 10 New elements */
    New *pstruct = &x;                 /* 'pstruct' is a pointer to 'x' */
 
    //x = {"john", 40, "k", 60.50};
	
	for(; i < sizeof(str)/sizeof(char *); ++i)
	{
		printf("\n %d: str = %s", i + 1, *(str+ i));
		
	}
	
	return 0;
}
