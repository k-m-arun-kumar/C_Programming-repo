/* ********************************************************************
FILE                   : string2.c

PROGRAM DESCRIPTION    : practise C coding in string operation

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "string.h"
#include "stdlib.h"

size_t stringLength(char *); 
char* staticFormat(const char* name, size_t quantity, size_t weight);
int main()
{
   char strarr[] = "simple";
   char *chptr = strarr;
   
   char (*charr)[7] = &strarr;
   
   char* part1 = staticFormat("Axle",25,45);
   char* part2 = staticFormat("Piston",55,5);
   
   /* Returning a pointer to a static variable used for multiple purposes, causes staticFormat() method used the same static buffer
      for both calls, the last call overwrote the first call�s results. 
   
       instead of static array, if auto storage array, is returned by staticFormat(), then it cause unpredicatible results, 
	   due to auto variables got deallocated after the staticFormat(), so address returned by auto storage array no longer exist */
   
   printf("%s\n",part1);
   printf("%s\n",part2);
   
   
   printf("\n 1st strarr\'s len = %d",stringLength(strarr));
   
   /* warning: &strarr returns strarr's address = strarr */
   
  /* printf("\n 2nd strarr\'s len = %d",stringLength(&strarr)); */
  
   printf("\n 3rd strarr\'s len = %d",stringLength(&strarr[0])); 
   printf("\n 4rd charr\'s len = %d",stringLength(chptr)); 
  
   printf("\n chptr\'s addr = %#X, chptr = %s", chptr, chptr);
   printf("\n sizeof(*charr) = %d, charr = %#X, charr + 1 = %#X", sizeof(*charr),charr,charr + 1 );
   
  
   
   return 1;
}

size_t stringLength(char *string) 
{
   size_t length = 0;
   
   while(*string++)
    {
       length++;
    }
    return length;
}

char* staticFormat(const char* name, size_t quantity, size_t weight) 
{
static char buffer[64]; 
sprintf(buffer, "Item: %s Quantity: %u Weight: %u", name, quantity, weight);
return buffer;
}
