/* ********************************************************************
FILE                   : string1.c

PROGRAM DESCRIPTION    : practise C coding in string operation

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "stdlib.h"
#include "string.h"

int main()
{
    /* error: cannot mix char constant with a string
    char str1[] = {'T'"his world "'.'}; */
	char strarr[] = {"This" " world"}; 
	char arrst[] = {"This \0 world"};
	char chstr[] = {'T', 'h', 'i', 's', '\0',  'w', 'o','r','l','d' };	
	char charr[20], *chptr;

	printf("\n strarr = %s, sizeof(strarr) = %d, sizeof(*strarr) = %d", strarr,sizeof(strarr), sizeof(*strarr) );
	/* arrst = This, sizeof(arrst) = 13 */
	printf("\n arrst = %s, sizeof(arrst) = %d", arrst, sizeof(arrst));
	/* chstr = This, sizeof(charr) = 10 */ 
	printf("\n chstr = %s, sizeof(charr) = %d", chstr, sizeof(chstr));

        printf("\n Enter a string: ");
        gets(charr);
        printf("\n entered string: ");
        puts(charr);
		
	strcpy(ch, "india today");
  
	printf("\n strlen(charr) = %d, sizeof(charr) = %d, charr = %s, charr \'s address: %#X ",strlen(charr), sizeof(charr), charr, charr);

/* error: address where string literal ("welcome") allocated cannot be assigned to char array 
charr = "welcome"; */

/* "welcome" string returns address where string literal is allocated */
chptr = "welcome";	
printf("\n chptr = %s, string's addr : %#X, chptr \'s addr = %#X, strlen(chptr) = %s", chptr, "welcome", chptr, strlen(chptr));
	return 1;
}
