/* ********************************************************************
FILE                   : gets.c

PROGRAM DESCRIPTION    : practise C coding in gets function

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>

int main ()
 {
   char str[50];
     
   printf("Enter a string : ");
   gets(str);
   
   printf("You entered: %s", str);

   return(0);
}
