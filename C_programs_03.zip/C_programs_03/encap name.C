/* ********************************************************************
FILE                   : encap name.c

PROGRAM DESCRIPTION    : encapulation 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "stdio.h"
#include "stdlib.h"
#include "alloc.h"
#include "string.h"

typedef struct queuenode
{
   unsigned char msgtype;      /* differentiate kind of data in queue */
   unsigned char datalen;      /* variable data's length */
   char *quedatabuff;          /* contains address of data */
} queue_node;

typedef struct
{
   unsigned emp_id;              /* Employee ID, used as key */
   unsigned char name_len;       /* Total length of Emp's Name */
   char *emp_name;               /* variable Employee Name */
} emp_info;

int main()
{
   Encap_Empdata();
   return 1;
}

int Encap_Empdata()
{
   emp_info *emp_data = NULL;
   queue_node *temp_enque = NULL;
   char name[20], *emp_name = NULL;
   unsigned char quedata_totlen;
   char temp_data[30];
   unsigned emp_id, name_len;

   printf("\n Enter Emp ID & its name: ");
   scanf(" %u %[^\n]", &emp_id, name);
   name_len = strlen(name) + 1;
   /* entered name is terminated with '\0' */
   quedata_totlen = sizeof(queue_node) - sizeof(char *) + sizeof(emp_info) + name_len;
   memset(temp_data,0, 30);
   temp_enque = (queue_node *)temp_data;
   temp_enque->msgtype = 1;
   temp_enque->datalen = sizeof(emp_info) + name_len;
   /* encapulation of employee info into queue_data's databuff */
   /* using address allocated for quedatabuff, though it not good programming, used to get more ideas */
   emp_data = (emp_info *)&temp_enque->quedatabuff;
   emp_data->emp_id = emp_id;
   emp_data->name_len = name_len;

    /* emp_name garbage */
    /* memcpy(&emp_data->emp_name, name, name_len);*/
    /* emp_name is NULL */
    /* memcpy(emp_data->emp_name, name, name_len); */

    /* emp_name points to its address */
    /* emp_data->emp_name = (char *)&emp_data->emp_name;
      memcpy(emp_data->emp_name, name, name_len); */

    /* emp_name = (char *)&emp_data->emp_name;
     memcpy(emp_name, name, name_len); */
    /* emp_data->emp_name = (char *)&emp_data->emp_name;
     memcpy(*emp_data->emp_name, name, name_len); */

    /* emp_data->emp_name = (char *)&emp_data->emp_name + 1;
    memcpy(emp_data->emp_name, name, name_len); */

    /* fine: points to next address from its allocated address */
    /* emp_data->emp_name = (char *)&emp_data->emp_name + 2;
       memcpy(emp_data->emp_name, name, name_len); */

    /* fine: points to next address from its allocated address */
    emp_data->emp_name = (char *)temp_data + sizeof(queue_node) - sizeof(char *) + sizeof(emp_info);
    memcpy(emp_data->emp_name, name, name_len);

    printf("\n TRACE : entered name: %s, temp_data: %#X, emp_data: %#X, emp_name: %#X",name, temp_data, emp_data,emp_data->emp_name );
    printf("\n TRACE[29.1]: Enque Data: quedatalen: %u:: Msgtype: %u, Emp Msg datalen: %u",quedata_totlen,temp_enque->msgtype,temp_enque->datalen);
    printf("\n TRACE[29.2]: Emp Enque Data: emp_id: %u, name_len: %u, emp name: %s",emp_data->emp_id,emp_data->name_len,emp_data->emp_name);

    Decap(temp_data);
    return 1;
}

int Decap(void *que_data)
{
	emp_info *emp_data = NULL;
	queue_node *deque_data = NULL;

	deque_data = (queue_node *)que_data;
	printf("\n Decap: deque_data:%#X:: Msg:%u, datalen:%u, quedatabuff:%#X",deque_data,deque_data->msgtype,deque_data->datalen, deque_data->quedatabuff);
	emp_data = (emp_info *) &deque_data->quedatabuff;
	printf("\n Decap Emp: emp_data:%#X:- Empid:%u, namelen:%u, name:%s, name Ptr:%#X",emp_data,emp_data->emp_id, emp_data->name_len, emp_data->emp_name, emp_data->emp_name);
    return 1;
}
