/* ********************************************************************
FILE                   : Print_Simple.c

PROGRAM DESCRIPTION    : implementation of printf function

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.

CHANGE LOGS           : 

*****************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
/* prints a lot of information about floating-point numbers */
#include <math.h>

#define NULL_PTR                                      ((void *)0)
#define NULL_CHAR                                           ('\0')
#define EOF                                                  (-1)
#define SUCCESS                                               (0)
#define FAILURE                                               (1)
#define NUM_CONVERT_BUFFER_LEN                               (33)

#define STATE_NO                                 (0)
#define STATE_YES                                (1)
#define STATE_NA                                 (2)


#define CHARBITS               (8)
#define FLOATBITS              (sizeof(float) * CHARBITS)
/* endianness testing */
const int EndianTest = 0x04030201;

#define LITTLE_ENDIAN() (*((const char *) &EndianTest) == 0x01) 

/* extract nth LSB from object stored in lvalue x */
#define GET_BIT(float_num, float_bit_index) ((((const char *) &float_num)[LITTLE_ENDIAN() ? (float_bit_index) / CHARBITS : sizeof(float_num) - (float_bit_index) / CHARBITS - 1] >> ((float_bit_index) % CHARBITS)) & 0x01)

#define PUT_BIT(float_disp, float_num, float_bit_index) ((GET_BIT((float_num), (float_bit_index)) ? (float_disp.ieee_754_format |= (1 << float_bit_index)) : (float_disp.ieee_754_format &= ~(1 << float_bit_index)) ))
#define PAD_RIGHT                     (1)
#define PAD_ZERO                      (2)
/* the following should be enough for 32 bit int */
#define PRINT_BUF_LEN                (12)

#define ASCII_CODE_BACKSLASH          (92)
#define MAX_PRINT_WIDTH_SPECIFIER     (15)          
#define REQ_PRINT_WIDTH_ARR_SIZE      (3)

typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long uint64_t;

typedef char int8_t;
typedef short int  int16_t;
typedef int int32_t;
typedef long int64_t;

typedef struct 
{
	float float_num;
	struct
	{
		uint32_t mantissa   : 24;
		uint32_t exponient  :  7;
		uint32_t float_sign :  1;	
	    
	} raw_ieee_754; 	
	uint32_t ieee_754_format;	
} float_ieee_754_format_t;	

typedef enum 
{
	NUM_CONV_BIG_ALPHA, NUM_CONV_SMALL_ALPHA, NUM_CONV_ALPHA_NA
} num_conv_alpha_t;

typedef enum 
{
	GET_NUM_DIGITS, GET_POWER_OF_CUR_NUM_DIGITS, GET_POWER_OF_NEXT_NUM_DIGITS  
} get_num_digits_type_t;

typedef enum
{
	FORMAL_SPEC_c, FORMAL_SPEC_s, FORMAL_SPEC_d, FORMAL_SPEC_u, FORMAL_SPEC_b, FORMAL_SPEC_o, FORMAL_SPEC_x, FORMAL_SPEC_X, FORMAL_SPEC_h, FORMAL_SPEC_hu
} format_spec_t;

typedef enum
{
	BASE_02 = 2, BASE_08 = 8, BASE_10 = 10, BASE_16 = 16
} base_t;

char Put_Char(const char to_disp_char);
int16_t Print(const char* const format_str,...) ;
int16_t Put_Str(const char *const to_disp_str);
uint8_t Str_Len(const char *const str);
char *Num_Convert(const int32_t num_to_convert, const uint8_t base, const uint8_t alpha_flag, const uint8_t conv_till_conf_size );
uint16_t Print_Float_Bits(const float float_num);
uint32_t Power_Of(const uint8_t base, const uint8_t power );
uint16_t Get_Num_Digits_Based_Data(const uint32_t num, int32_t *const num_digits_data_ptr, const uint8_t base, const uint8_t get_num_digits_type);
uint16_t Reverse_Str(const char *const str_to_reverse_ptr, char *const reversed_str_ptr, const uint8_t conf_str_to_reverse_start_pos, const uint8_t conf_str_to_reverse_len);
char* Num_To_Str_Conv(const int32_t num, char *const num_in_str, const uint8_t base);
uint8_t Str_to_Num_Conv(int32_t *const num_conv_from_str, const char *const num_in_str);
int16_t Print_Str(const char *const to_disp_str, const uint8_t width_spec_len);
int16_t Print_Format_Spec(const va_list *print_va_list_ptr, const char *const got_width_spec_ptr, const uint8_t format_spec_type, const uint8_t print_ctrl_flag) ; 
/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.01 

Bugs           :  
-*------------------------------------------------------------*/
int main(void)
{
	uint32_t uint32_num = 30;
	int32_t int32_num = -40;
	uint16_t num_chars_printed = 0;
	int16_t int16_num = -20;
	uint8_t uint8_num = 97;
	float float_num = -2.3;
	
    num_chars_printed = printf("printf: int32_num = %d, ", int32_num);
	printf("num_chars: %0u \n", num_chars_printed);
    num_chars_printed = Print("Print: int16_num = %4h, ", int16_num);
	Print("uint32_num : %4u, %% hello\n", uint32_num); 
	
	printf("Enter float num: ");
	 while(scanf("%f", &float_num) == 1) 
	 {
        printf("%10g = %24.17g = ", float_num, float_num);
        Print_Float_Bits(float_num);
        putchar('\n');
		printf("Enter float num: ");
    }
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Print

DESCRIPTION    : Print() operation is similar to printf()
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 10.18 

Bugs           :  
-*------------------------------------------------------------*/
int16_t Print(const char* const format_str,...) 
{ 
	const char *traverse_ptr; 
	char got_width_spec_str[REQ_PRINT_WIDTH_ARR_SIZE]; 
	va_list arg;
	int16_t ret_status;
	int16_t num_chars_printed = 0;
	uint8_t cur_num_digits = 0, print_ctrl_flag = 0; 
		
    if(format_str == NULL_PTR)
    {
        return EOF; 
    }  
    memset(got_width_spec_str, NULL_CHAR, REQ_PRINT_WIDTH_ARR_SIZE);
    //Module 1: Initializing Print's arguments 	 
	va_start(arg, format_str); 
	traverse_ptr = format_str;	
    while(*traverse_ptr != NULL_CHAR) 
	{ 	    
		if(print_ctrl_flag == 0) 
		{
			if(*traverse_ptr != '%')
			{
			    switch(*traverse_ptr) 
			    {
			       case '\\':	
				      if((ret_status = Put_Char('\\')) == NULL_CHAR)
			          {
			   	         va_end(arg); 
                         return num_chars_printed;
			          }
			          ++num_chars_printed;  
				   break;
				   case '\'':	
				      if((ret_status = Put_Char('\'')) == NULL_CHAR)
			          {
			   	         va_end(arg); 
                         return num_chars_printed;
			          }
			          ++num_chars_printed;  
			       break;
			       case '\"':	
				       if((ret_status = Put_Char('\"')) == NULL_CHAR)
			           {
			   	          va_end(arg); 
                          return num_chars_printed;
			           }
			           ++num_chars_printed;  
			    	break;
				    case '\n':
				      if((ret_status = Put_Char('\n')) == NULL_CHAR)
			          {
			   	         va_end(arg); 
                         return num_chars_printed;
			          }
			          ++num_chars_printed;
				    break;
			        case '\r':
				      if((ret_status = Put_Char('\r')) == NULL_CHAR)
			          {
			   	          va_end(arg); 
                          return num_chars_printed;
			          }
				      ++num_chars_printed;  			      
				     break;
				     default:
				        if((ret_status = Put_Char(*traverse_ptr)) == NULL_CHAR)
			            {
			              va_end(arg); 
                          return num_chars_printed;	
			            }
				        ++num_chars_printed;
			    }
		    	++traverse_ptr;
		     	continue;
    	    }
    	    else
    	    {
    	    	//% 
                ++traverse_ptr; 
				print_ctrl_flag = (1 << 0);	        	 
			}
        }
		//Module 2: Fetching and executing arguments
		switch(*traverse_ptr) 
		{ 
			case 'c' : 
			   if((ret_status = Print_Format_Spec(&arg, got_width_spec_str, FORMAL_SPEC_c, print_ctrl_flag )) == EOF)
				{
					va_end(arg); 
                    return num_chars_printed;
				}				 
				num_chars_printed += ret_status;
			    print_ctrl_flag = 0;
			    cur_num_digits = 0;			  
			break; 	
			case 's': 
			   if((ret_status = Print_Format_Spec(&arg,  got_width_spec_str, FORMAL_SPEC_s, print_ctrl_flag )) == EOF)
				{
					va_end(arg); 
                    return num_chars_printed;
				}
			    num_chars_printed += ret_status;
		    	print_ctrl_flag = 0;
				cur_num_digits = 0;					   
			break; 
			//binary format
            case 'b':
			    if((ret_status = Print_Format_Spec(&arg,  got_width_spec_str, FORMAL_SPEC_b, print_ctrl_flag )) == EOF)
				{
					va_end(arg); 
                    return num_chars_printed;
				}
			    num_chars_printed += ret_status;
		    	print_ctrl_flag = 0;
				cur_num_digits = 0;			  
            break; 			
			case 'd' : 
			   if((ret_status = Print_Format_Spec(&arg,  got_width_spec_str, FORMAL_SPEC_d, print_ctrl_flag )) == EOF)
				{
					va_end(arg); 
                    return num_chars_printed;
				}
			    num_chars_printed += ret_status;
		    	print_ctrl_flag = 0;
				cur_num_digits = 0;				   		
			break; 
			case 'u':
			    if((ret_status = Print_Format_Spec(&arg, got_width_spec_str, FORMAL_SPEC_u, print_ctrl_flag )) == 0)
				{
					va_end(arg); 
                    return num_chars_printed;
				}				 
				num_chars_printed += ret_status;
			    print_ctrl_flag = 0;
			    cur_num_digits = 0;
			break; 
			case 'h' :
			    ++traverse_ptr;
			    switch(*traverse_ptr)
			    {
			        case 'u':
					   if((ret_status = Print_Format_Spec(&arg, got_width_spec_str, FORMAL_SPEC_hu, print_ctrl_flag )) == EOF)
				       {
				 	       va_end(arg); 
                           return num_chars_printed;
			           }
					break;
					default:
				       if((ret_status = Print_Format_Spec(&arg, got_width_spec_str, FORMAL_SPEC_h, print_ctrl_flag )) == EOF)
				       {
				 	       va_end(arg); 
                           return num_chars_printed;
			           }
			           --traverse_ptr;
				}
				num_chars_printed += ret_status;
				print_ctrl_flag = 0;  
				cur_num_digits = 0;
			break;   
			case 'o': 
			   if((ret_status = Print_Format_Spec(&arg, got_width_spec_str, FORMAL_SPEC_o, print_ctrl_flag  )) == EOF)
			   {
				    va_end(arg); 
                    return num_chars_printed;
			   }
			   num_chars_printed += ret_status;
			   print_ctrl_flag = 0;
			   cur_num_digits = 0;
			break;	
			case 'x':
    		   if((ret_status = Print_Format_Spec(&arg, got_width_spec_str, FORMAL_SPEC_x, print_ctrl_flag )) == EOF)
			   {
				    va_end(arg); 
                    return num_chars_printed;
			   }
			    num_chars_printed += ret_status;
				print_ctrl_flag = 0;
				cur_num_digits = 0;				
			break;
			case 'X':
    		   if((ret_status = Print_Format_Spec(&arg, got_width_spec_str, FORMAL_SPEC_X, print_ctrl_flag )) == EOF)
			   {
				    va_end(arg); 
                    return num_chars_printed;
			   }
			   	num_chars_printed += ret_status;
				print_ctrl_flag = 0; 
				cur_num_digits = 0;	  					
			break;
			case '%':
			   if((ret_status = Put_Char('%')) == NULL_CHAR)
			   {
			   	    va_end(arg); 
                    return num_chars_printed;
			   }
			   ++num_chars_printed;
			   print_ctrl_flag = 0; 	
			break;			
		    case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
			  do 
			  {
				  if(cur_num_digits >= REQ_PRINT_WIDTH_ARR_SIZE)
			      {
			         va_end(arg);                    
                     return num_chars_printed;
			      }	
			      got_width_spec_str[cur_num_digits++] = *traverse_ptr;
				  ++traverse_ptr;	
		      } while(*traverse_ptr >= '0' && *traverse_ptr <= '9');
		      --traverse_ptr;
		       got_width_spec_str[cur_num_digits] = NULL_CHAR;
		       print_ctrl_flag = (1 << 1);
			break;	
            default:
                va_end(arg);                    
                return num_chars_printed;			
		}
		++traverse_ptr;	
	} 
	//Module 3: Closing argument list to necessary clean-up
	va_end(arg); 
	return num_chars_printed;
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Print_Format_Spec

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 10.19 

Bugs           :  
-*------------------------------------------------------------*/
int16_t Print_Format_Spec(const va_list *print_va_list_ptr, const char *const got_width_spec_ptr, const uint8_t format_spec_type, const uint8_t print_ctrl_flag) 
{
	char actual_width_spec_str[REQ_PRINT_WIDTH_ARR_SIZE], *num_conv_in_str_ptr, *print_str;
    uint32_t uint32_print_data; 
	int32_t int32_print_data, width_specifier = 0; 
	uint16_t uint16_print_data; 
	int16_t int16_print_data;	
    uint8_t uint8_print_data, cur_num_digits = 0; 
	int8_t int8_print_data;
	int16_t ret_status = 0, num_chars_displayed = 0;
	
	if(print_va_list_ptr == NULL_PTR)
	{
		return EOF;
	}
	if(print_ctrl_flag & (1 << 1))
	{
		//width specifier
		if(got_width_spec_ptr == NULL_PTR)
		{
			return EOF;	
		}
		memset(actual_width_spec_str, NULL_CHAR, REQ_PRINT_WIDTH_ARR_SIZE);
	   if((Reverse_Str(got_width_spec_ptr, actual_width_spec_str, 0, 0)) != SUCCESS)
	   {
	   	    printf("ERR: rev_str \n");
	   	   	return 0;			
       }
       if((Str_to_Num_Conv(&width_specifier, actual_width_spec_str)) != SUCCESS)
	   {
	   	    printf("ERR: str_to_num \n");
	     	return EOF;
       }
       if(width_specifier > MAX_PRINT_WIDTH_SPECIFIER)
       {
       	    printf("ERR: width exceed \n");
	   	   return EOF;
	   }
   }
   switch(format_spec_type)
   { 
      case FORMAL_SPEC_c:
	     int8_print_data = (int8_t)va_arg(*print_va_list_ptr , int32_t );		
		 if((ret_status = Put_Char(int8_print_data)) == NULL_CHAR)
		 {
		  	  return EOF;
	     }
	  break;
	  case FORMAL_SPEC_s:
	     print_str = va_arg(*print_va_list_ptr, char *); 		//Fetch string
		 if((ret_status = Print_Str(print_str, 0)) == EOF)
		 {
		 	 return EOF;		  
		 }
	  break;
   	  case FORMAL_SPEC_u:   	  	
   	  	 uint32_print_data = va_arg(*print_va_list_ptr, uint32_t );	
         if((num_conv_in_str_ptr = Num_Convert(uint32_print_data, BASE_10, NUM_CONV_ALPHA_NA, width_specifier)) == NULL_PTR)
         {
	        return EOF;
	     }
	  break;
	  case FORMAL_SPEC_d:
	  	 int32_print_data = va_arg(*print_va_list_ptr, int32_t ); 	
		 if((num_conv_in_str_ptr = Num_Convert(int32_print_data, BASE_10, NUM_CONV_ALPHA_NA, width_specifier)) == NULL_PTR)
         {
	        return EOF;
	     }
	  break;
	  case FORMAL_SPEC_b:
	   	uint32_print_data = va_arg(*print_va_list_ptr, uint32_t ); 
	    if((num_conv_in_str_ptr = Num_Convert(uint32_print_data, BASE_02, NUM_CONV_ALPHA_NA, width_specifier )) == NULL_PTR)
		{
			 return EOF;   
		}
	  break;
	  case FORMAL_SPEC_h:
	   	   int16_print_data = (int16_t)va_arg(*print_va_list_ptr, int32_t ); 		
	   	   if((num_conv_in_str_ptr = Num_Convert(int16_print_data, BASE_10, NUM_CONV_ALPHA_NA, width_specifier)) == NULL_PTR)
		   {
			   	return EOF;            
		   }           
	   break; 
	   case FORMAL_SPEC_hu:
	   	  uint16_print_data = (uint16_t)va_arg(*print_va_list_ptr, uint32_t ); 
		  if((num_conv_in_str_ptr = Num_Convert(uint16_print_data, BASE_10, NUM_CONV_ALPHA_NA, width_specifier)) == NULL_PTR)
		  {
		 	    return EOF;     
		  }
	   break;
	   
	   case FORMAL_SPEC_o:
	       uint32_print_data = va_arg(*print_va_list_ptr, uint32_t); //Fetch Octal representation
		   if((num_conv_in_str_ptr = Num_Convert(uint32_print_data, BASE_08, NUM_CONV_ALPHA_NA, width_specifier)) == NULL_PTR)
		   {
			    return EOF;    
		   }
		break;
		case FORMAL_SPEC_x:
			uint32_print_data = va_arg(*print_va_list_ptr, uint32_t); //Fetch Hexadecimal representation
			if((num_conv_in_str_ptr = Num_Convert(uint32_print_data, BASE_16, NUM_CONV_SMALL_ALPHA, width_specifier)) == NULL_PTR)
			{
			     return EOF; 
			}		    
		break;
		case FORMAL_SPEC_X:
			uint32_print_data = va_arg(*print_va_list_ptr, uint32_t); //Fetch Hexadecimal representation
			if((num_conv_in_str_ptr = Num_Convert(uint32_print_data, BASE_16, NUM_CONV_BIG_ALPHA, width_specifier)) == NULL_PTR)
			{
			     return EOF; 
			}	 		    
		break;
		default:
		  	 return EOF;    	  
   } 	    
	if((ret_status = Print_Str(num_conv_in_str_ptr, width_specifier)) == EOF)
	{
	    return EOF;
	}
	if(print_ctrl_flag & (1 << 1))
	{
		memset((void *)got_width_spec_ptr, NULL_CHAR, REQ_PRINT_WIDTH_ARR_SIZE);
    }
    num_chars_displayed += ret_status;
	return num_chars_displayed;
}
			    
/*------------------------------------------------------------*
FUNCTION NAME  : Put_Char

DESCRIPTION    : Put_Char() operation is similar to putchar()
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 10.19 

Bugs           :  
-*------------------------------------------------------------*/
char Put_Char(const char to_disp_char)
{
    char displayed_char;
	displayed_char = putchar(to_disp_char);
	return displayed_char;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Put_Str

DESCRIPTION    : Put_Str() operation is similar to puts()
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 10.20 

Bugs           :  
-*------------------------------------------------------------*/
int16_t Put_Str(const char *const to_disp_str)
{
	uint8_t num_chars_displayed = 0, str_len;
	uint8_t ret_status;
	
	if(to_disp_str == NULL_PTR)
	{
		return EOF;
	}
	if((str_len = Str_Len(to_disp_str)) == 0)
	{
		return EOF;
	}
	while(*(to_disp_str + num_chars_displayed) != NULL_CHAR)
	{
		if((ret_status = Put_Char(*(to_disp_str + num_chars_displayed))) == NULL_CHAR)
		{
			return EOF;
		}
		++num_chars_displayed;
	}
	return num_chars_displayed;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Print_Str

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 10.20 

Bugs           :  
-*------------------------------------------------------------*/
int16_t Print_Str(const char *const to_disp_str, const uint8_t width_spec_len)
{
	uint16_t ret_status;
	uint8_t num_chars_displayed = 0, str_len, disp_str_len, proc_bit_field = 0;	
	char disp_char;
	
	if(to_disp_str == NULL_PTR)
	{
		return EOF;
	}
	if((str_len = Str_Len(to_disp_str)) == 0)
	{
		return EOF;
	}
	disp_str_len = (str_len > width_spec_len) ? str_len : width_spec_len;
	while( (disp_char = *(to_disp_str + num_chars_displayed)) != NULL_CHAR)
	{
		if(disp_char == '-')
		{
		    proc_bit_field |= (1 << 1);
		    ++num_chars_displayed;
		    continue;
		}
		else
			if(disp_char == '0')
		    {
			   if((proc_bit_field & (1 << 0)) == 0)
			   {
				   disp_char = ' ';
			   }
			}
			else
	    	{
	    		if(proc_bit_field & (1 << 1)) 
	    		{
	    		    if((ret_status = Put_Char('-')) == NULL_CHAR)
	             	{
		            	return EOF;
	            	}
					proc_bit_field &= ~(1 << 1);
				}
		    	proc_bit_field |= (1 << 0);
		    }
				
		if((ret_status = Put_Char(disp_char)) == NULL_CHAR)
		{
			return EOF;
		}
		++num_chars_displayed;
	}
	return num_chars_displayed;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Str_Len

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.05  

BUGS           :  
-*------------------------------------------------------------*/
uint8_t Str_Len(const char *const str)
{
    uint8_t num_chars = 0;
	
	  if(str == NULL_PTR)
	  {
		  return 0;
	  }
    while(*(str + num_chars))
	{
		++num_chars;
	}
    return num_chars;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Num_Convert

DESCRIPTION    : Convert integer number into octal, hex, etc.
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.19 

Bugs           :  
-*------------------------------------------------------------*/
char *Num_Convert(const int32_t num_to_convert, const uint8_t base, const uint8_t alpha_flag, const uint8_t conv_till_conf_size ) 
{ 
    const char hexa_char_num_arr[]= "0123456789";
	const char hexa_char_big_alpha_arr[] = "ABCDEF";
	const char hexa_char_small_alpha_arr[] = "abcdef";
	static char buffer[NUM_CONVERT_BUFFER_LEN];
	const char *hexa_char_alpha_ptr;
	char *num_in_str_ptr;  
	int32_t cur_num_to_convert = num_to_convert;
	int32_t num_to_convert_num_digits; 
	uint8_t char_index, conv_cur_size = 0, conv_till_size;	
	
	if(base > BASE_16)
	{
		return NULL_PTR;
	}
	if(base <= BASE_10)
	{
		if(alpha_flag != NUM_CONV_ALPHA_NA)
		{
			return NULL_PTR;
		}
	}
	else
	{
	    switch(alpha_flag)
	    {
		   case NUM_CONV_BIG_ALPHA:
		     hexa_char_alpha_ptr = hexa_char_big_alpha_arr;
		   break;  
		   case NUM_CONV_SMALL_ALPHA:
		     hexa_char_alpha_ptr = hexa_char_small_alpha_arr;
		   break;
		   default:
		      return NULL_PTR;
		}
	}
	memset(buffer, NULL_CHAR, NUM_CONVERT_BUFFER_LEN);
    num_in_str_ptr = &buffer[NUM_CONVERT_BUFFER_LEN - 1];
	*num_in_str_ptr = NULL_CHAR;	
	if(conv_till_conf_size == 0)
	{
		if(cur_num_to_convert < 0)
		{
			cur_num_to_convert = -cur_num_to_convert;
		}
	   	do 
    	{ 
	        char_index = cur_num_to_convert % base;
	    	if(char_index >= 0 && char_index <= 9)
		    {
		    	*--num_in_str_ptr = hexa_char_num_arr[char_index]; 
	    	}
	    	else
	    	{			
		        *--num_in_str_ptr = hexa_char_alpha_ptr[char_index - 10]; 
		    }
	    	cur_num_to_convert /= base; 
	     }	 
    	while(cur_num_to_convert != 0); 
    	if(num_to_convert  < 0)
    	{
    		*--num_in_str_ptr = '-';
		}
	}
	else
	{
	 	if(conv_till_conf_size >= NUM_CONVERT_BUFFER_LEN)
	    {
	    	return NULL_PTR;
	    }
		if(cur_num_to_convert < 0)
		{
			cur_num_to_convert = -cur_num_to_convert;
			//adjust 
			conv_cur_size = 1;
		}
	    if((Get_Num_Digits_Based_Data(cur_num_to_convert, &num_to_convert_num_digits, base, GET_NUM_DIGITS )) != SUCCESS)
	    {
	     	return NULL_PTR;
		}
		conv_till_size = (num_to_convert_num_digits > conv_till_conf_size - conv_cur_size) ? num_to_convert_num_digits: (conv_till_conf_size - conv_cur_size) ;		
		for(conv_cur_size = 0; conv_cur_size < conv_till_size; ++conv_cur_size) 
		{
		      char_index = cur_num_to_convert % base;
	          if(char_index >= 0 && char_index <= 9)
		      {
		      	   *--num_in_str_ptr = hexa_char_num_arr[char_index]; 
	          }
	    	  else
	          {			
		           *--num_in_str_ptr = hexa_char_alpha_ptr[char_index - 10]; 
		      }
	    	  cur_num_to_convert /= base; 
	    }
		if(num_to_convert  < 0)
    	{
    		*--num_in_str_ptr = '-';
		}	 
    	   
	}
	return(num_in_str_ptr); 
}

/*------------------------------------------------------------*
FUNCTION NAME  : Print_Float_Bits

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.01 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Print_Float_Bits(const float float_num)
{
	float_ieee_754_format_t float_disp;	
    int8_t float_bit_index;

    float_disp.ieee_754_format = 0;
    float_bit_index = FLOATBITS - 1;
	//sign_bit part
    PUT_BIT(float_disp, float_num, float_bit_index);
   
   // exponient part
    for(float_bit_index--; float_bit_index >= 23; float_bit_index--)
	{
        PUT_BIT(float_disp, float_num, float_bit_index);
    }
	//mantissa part
    for(; float_bit_index  >= 0; float_bit_index--)
	{
        PUT_BIT(float_disp, float_num, float_bit_index);
    }
	printf("\n float in IEEE 754 format: 0x%X ", float_disp.ieee_754_format);
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Get_Num_Digits_Based_Data

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.05  

BUGS           :  
-*------------------------------------------------------------*/
uint16_t Get_Num_Digits_Based_Data(const uint32_t num, int32_t *const num_digits_data_ptr, const uint8_t base, const uint8_t get_num_digits_type)
{
	uint32_t power_base_cur_digit;
    int32_t max_num_digits, cur_num_digits; 
	
	*num_digits_data_ptr = 0;
	if(num_digits_data_ptr == NULL_PTR)
	{
		  return FAILURE;
	}
	if(base > BASE_16)
	{
		return FAILURE;
	}
	switch(get_num_digits_type)
	{
		case GET_NUM_DIGITS:
		case GET_POWER_OF_CUR_NUM_DIGITS:
		case GET_POWER_OF_NEXT_NUM_DIGITS:
		break;
		default:
		  return FAILURE;
	}
	max_num_digits = sizeof(uint32_t) * 8;
	switch(base)
	{
		case BASE_08:
		   max_num_digits = ((sizeof(uint32_t) * 8) / 3) + 1;
		break;
        case BASE_16:
            max_num_digits = ((sizeof(uint32_t) * 8) / 4);
		break;
        case BASE_10: 
           max_num_digits = (sizeof(uint32_t) * 3);
        break; 
	}
	for(cur_num_digits = max_num_digits; cur_num_digits >= 0; --cur_num_digits )
	{
		power_base_cur_digit = Power_Of(base, (uint8_t)cur_num_digits);
		if((num / power_base_cur_digit) != 0)
		{
			switch(get_num_digits_type)
			{
				case GET_NUM_DIGITS:
				  *num_digits_data_ptr = cur_num_digits + 1; 
				break;
                case GET_POWER_OF_CUR_NUM_DIGITS:
				  *num_digits_data_ptr = power_base_cur_digit;
                break;	
                case GET_POWER_OF_NEXT_NUM_DIGITS:
				    *num_digits_data_ptr = power_base_cur_digit * base;
                break;                               				
			}
			return SUCCESS;
		}
	}
    return FAILURE;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Power_Of

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.10 

Bugs           :   
-*------------------------------------------------------------*/
uint32_t Power_Of(const uint8_t base, const uint8_t power )
{
    uint32_t power_val = 1;
    uint8_t i = 0;
  
    if(power == 0)
    {
       return 1;
    }
    for(i = 1; i <= power; ++i)
    {
      power_val *= base;
    }
    return power_val;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reverse_Str

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : reversed_str must be memory allocated with size >= str_len_to_reverse

Func ID        : 02.10 

Bugs           :   
-*------------------------------------------------------------*/
uint16_t Reverse_Str(const char *const str_to_reverse_ptr, char *const reversed_str_ptr, const uint8_t conf_str_to_reverse_start_pos, const uint8_t conf_str_to_reverse_len)
{
	uint8_t str_to_reverse_start_index, str_to_reverse_end_index, str_len_to_reverse, str_len_for_reverse;
	int8_t cur_len = 0; 
	
	if(str_to_reverse_ptr == NULL_PTR || reversed_str_ptr == NULL_PTR)
	{
		return FAILURE;
	}
	if((str_len_for_reverse = Str_Len(str_to_reverse_ptr)) == 0)
	{
	    return FAILURE;
	}
	if(conf_str_to_reverse_len != 0)
	{
	   if(conf_str_to_reverse_len > str_len_for_reverse)
       {
		   return FAILURE;
       }	    
	   str_len_to_reverse = conf_str_to_reverse_len;
	}
	else
	{
    	str_len_to_reverse = str_len_for_reverse - conf_str_to_reverse_start_pos;
	}
    str_to_reverse_start_index = conf_str_to_reverse_start_pos;
	str_to_reverse_end_index = str_to_reverse_start_index + str_len_to_reverse - 1;	 	  
	if(str_to_reverse_start_index >= str_len_for_reverse || str_to_reverse_end_index >= str_len_for_reverse)
	{
		printf("ERR: reverse index invalid: start : %u, end: %u \n", str_to_reverse_start_index, str_to_reverse_end_index);
	    return FAILURE; 
	}	
	memset(reversed_str_ptr, NULL_CHAR, str_len_to_reverse);	
	for(cur_len = 0 ; cur_len < str_len_to_reverse; ++cur_len)
	{
    	reversed_str_ptr[cur_len] = str_to_reverse_ptr[str_to_reverse_end_index - cur_len];
	}
    return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Num_To_Str_Conv

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : this function is simliar to itoa

Func ID        : 02.10 

Bugs           :   
-*------------------------------------------------------------*/
char* Num_To_Str_Conv(const int32_t num_to_str, char *const num_in_str, const uint8_t base) 
{ 
    int32_t num = num_to_str; 
    uint8_t is_num_negative_flag = STATE_NO, num_in_str_len = 0; 
    int8_t reverse_start_index = 0, reverse_end_index;
	char temp;
	
    if(num_in_str == NULL_PTR)
	{
		return NULL_PTR;
	}
    if(base > BASE_16)
	{
		return NULL_PTR;
	}
    /* Handle 0 explicitely, otherwise empty string is printed for 0 */
    if (num == 0) 
    { 
        num_in_str[num_in_str_len++] = '0'; 
        num_in_str[num_in_str_len] = NULL_CHAR; 
        return num_in_str; 
    } 
  
    // In standard itoa(), negative numbers are handled only with base 10. 
    if (num < 0)  
    { 
        if( base != BASE_10)
        {
        	return NULL_PTR;	
        }
        is_num_negative_flag = STATE_YES; 
        num = -num; 
    } 
    // Process individual digits 
    while (num != 0) 
    { 
        int rem = num % base; 
        num_in_str[num_in_str_len++] = (rem > 9) ? (rem - 10) + 'A' : rem + '0'; 
        num = num/base; 
    }  
    // If number is negative, append '-' 
    if (is_num_negative_flag == STATE_YES) 
	{
        num_in_str[num_in_str_len++] = '-'; 
	}  
    num_in_str[num_in_str_len] = NULL_CHAR; // Append string terminator   
    // Reverse the string 
	reverse_start_index = 0; 
    reverse_end_index = num_in_str_len - 1;
    	
    while (reverse_start_index < reverse_end_index) 
    { 
        //swap 
        temp = *(num_in_str + reverse_start_index );
		*(num_in_str + reverse_start_index ) = *(num_in_str + reverse_end_index );
		*(num_in_str + reverse_end_index ) = temp;
        ++reverse_start_index;
        --reverse_end_index; 
    } 	
    return num_in_str; 
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Str_to_Num_Conv

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : digits are extracted from left to right format from digit in num_in_str

Func ID        : 02.04  

BUGS           :  
-*------------------------------------------------------------*/
uint8_t Str_to_Num_Conv(int32_t *const num_conv_from_str, const char *const num_in_str  )
{	
	 int32_t num = 0;
	 uint32_t place;
	 int16_t cur_unit;
	 uint8_t num_chars = 0, base = BASE_10, pos = 0, start_num_pos = 0 ;
	
	 if(num_conv_from_str == NULL_PTR || num_in_str == NULL_PTR )
	 {
		 return FAILURE;
	 }
	 if(num_in_str[0] == '+' || num_in_str[0] == '-')
	 {
		 start_num_pos = 1;
	 }
	 else if(num_in_str[0] >= '0' && num_in_str[0] <= '9')
	 {
		  start_num_pos = 0;
	 }
	 else
	 {
		 *num_conv_from_str = 0;
		 printf("ERR: NON digit \n");
         return FAILURE;
	 }		 
	 num_chars = Str_Len(num_in_str + start_num_pos);
	 if(num_chars == 0)
	 {
		 *num_conv_from_str = 0;
		  printf("ERR: 0 len \n");
		 return FAILURE;
	 }
	 pos = start_num_pos; 	     
     for( place = Power_Of(base, num_chars - 1); place >= 1; place /= base, ++pos )
     {
     	 cur_unit = num_in_str[pos] - '0';
    	 if(cur_unit < 0 ||  cur_unit > 9 )
    	 {
	    	 *num_conv_from_str = 0;
	    	  printf("ERR: len \n");
             return FAILURE;
	     }		 
         num += (cur_unit * place);		      
     }
	 if(num_in_str[0] == '-')
	 {
		 *num_conv_from_str = -num;  
	 }
	 else
	 {
	     *num_conv_from_str = num; 
	 }
     return SUCCESS;
}
