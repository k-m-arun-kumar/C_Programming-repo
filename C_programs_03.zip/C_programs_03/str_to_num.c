/* ********************************************************************
FILE                   : str_to_num.c

PROGRAM DESCRIPTION    : string to number conversion in C

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>

#define NULL_PTR                              ((void *)0)
#define NUM_0_CHAR                            ('0')

#define SUCCESS                                 (0)
#define ERR_STR_TO_NUM_PARA                     (1)
#define FAILURE                                 (2)
#define ERR_STR_PTR_NULL                        (3)

typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long uint64_t;

typedef char int8_t;
typedef short int int16_t;
typedef int int32_t;
typedef long int64_t;

uint8_t Str_to_Num_Conv(int32_t *const num_conv_from_str, const char *const num_in_str  );
uint8_t Str_Len(const char *const str);
uint32_t Power_Of(const uint8_t base,  const uint8_t power );
uint8_t error_flag = 0;

int main()
{
	char num_in_str[10] = "+2589";
	int32_t num_conv_from_str;
	uint8_t ret_status;
	
	if((ret_status = Str_to_Num_Conv(&num_conv_from_str, num_in_str))!= SUCCESS)
	{
		printf("\n ERR: Str to num");
	}
	else
	{
		printf("\n INFO: num in str = %s, num = %d", num_in_str, num_conv_from_str );
	}
	return SUCCESS;
}

#ifdef STR_TO_NUM_FROM_RIGHT_TO_LEFT
/*------------------------------------------------------------*
FUNCTION NAME  : Str_to_Num_Conv

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : digits are extracted from right to left format from least digit in num_in_str
                 and no sign symbol is present at num_in_str[0] 

Func ID        : 02.04  

BUGS           :  
-*------------------------------------------------------------*/
uint8_t Str_to_Num_Conv(int32_t *const num_conv_from_str, const char *const num_in_str  )
{	
	 int32_t num = 0;
	 uint32_t place = 1;
	 int8_t cur_unit;
	 uint8_t num_chars = 0, cur_digit= 0, base = 10, pos = 0 ;
	
	 if(num_conv_from_str == NULL_PTR || num_in_str == NULL_PTR )
	 {
	 	printf("\n ERR: null_ptr");
		 error_flag = ERR_STR_TO_NUM_PARA;
		 return error_flag;
	 }
	 num_chars = Str_Len(num_in_str);
	 printf("\n INFO: num_chars : %d", num_chars);	
     place = 1;
     pos = num_chars - 1;
     cur_unit = num_in_str[pos] - NUM_0_CHAR;
	 if(cur_unit < 0 ||  cur_unit > 9 )
	 {
	     printf("\n ERR: char: %c at unit place: ", num_in_str[pos]);
		 *num_conv_from_str = 0;
         error_flag = ERR_STR_TO_NUM_PARA;		 
		 return error_flag;
	 }	
     num = place * cur_unit;
     printf("\n INFO: digit = %c at pos =  %d, num = %d", num_in_str[pos] , pos, num );  
     for(cur_digit = 1; cur_digit < (num_chars ); ++cur_digit)
     {
         place =  place * base;
         pos = num_chars - 1 - cur_digit;
         cur_unit = num_in_str[pos] - NUM_0_CHAR;       
	     if(cur_unit < 0 ||  cur_unit > 9 )
	     {
			 printf("\n ERR: char = %c at pos =  %d", num_in_str[pos], pos );
			  *num_conv_from_str = 0;
			 error_flag = ERR_STR_TO_NUM_PARA; 
			 return error_flag;
		 }			 
         num += (cur_unit * place); 
		 printf("\n INFO: digit = %c at pos =  %d, num = %d", num_in_str[pos] , pos, num );   
     }
	 *num_conv_from_str = num; 
	 printf("\n INFO: num = %d", num );  	 
     return SUCCESS;
}
#else
/*------------------------------------------------------------*
FUNCTION NAME  : Str_to_Num_Conv

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : digits are extracted from left to right format from digit in num_in_str

Func ID        : 02.04  

BUGS           :  
-*------------------------------------------------------------*/
uint8_t Str_to_Num_Conv(int32_t *const num_conv_from_str, const char *const num_in_str  )
{	
	 int32_t num = 0;
	 uint32_t place;
	 int8_t cur_unit;
	 uint8_t num_chars = 0, base = 10, pos = 0, start_num_pos = 0 ;
	
	 if(num_conv_from_str == NULL_PTR || num_in_str == NULL_PTR )
	 {
		 error_flag = ERR_STR_TO_NUM_PARA;
		 return error_flag;
	 }
	 if(num_in_str[0] == '+' || num_in_str[0] == '-')
	 {
		 start_num_pos = 1;
	 }
	 else if(num_in_str[0] >= '0' && num_in_str[0] <= '9')
	 {
		  start_num_pos = 0;
	 }
	 else
	 {
		 *num_conv_from_str = 0;
         error_flag = ERR_STR_TO_NUM_PARA;		 
		 return error_flag; 
	 }		 
	 num_chars = Str_Len(num_in_str + start_num_pos);
	 printf("\n INFO: num_chars : %d", num_chars);	
	 pos = start_num_pos; 	     
     for( place = Power_Of(base, num_chars - 1); place >= 1; place /= base, ++pos )
     {
     	 cur_unit = num_in_str[pos] - NUM_0_CHAR;
    	 if(cur_unit < 0 ||  cur_unit > 9 )
    	 {
	    	 printf("\n ERR: char = %c at pos =  %d", num_in_str[pos], pos );
		     *num_conv_from_str = 0;
             error_flag = ERR_STR_TO_NUM_PARA;		 
		     return error_flag;
	     }		 
         num += (cur_unit * place);
		 printf("\n INFO: digit = %c at pos =  %d, num = %d", num_in_str[pos] , pos, num );      
     }
	 if(num_in_str[0] == '-')
	 {
		 *num_conv_from_str = -num;  
	 }
	 else
	 {
	     *num_conv_from_str = num; 
	 }
     return SUCCESS;
}
#endif

/*------------------------------------------------------------*
FUNCTION NAME  : Str_Len

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.05  

BUGS           :  
-*------------------------------------------------------------*/
uint8_t Str_Len(const char *const str)
{
    uint8_t num_chars = 0;
	
	  if(str == NULL_PTR)
		{
			 error_flag = ERR_STR_PTR_NULL;	
			 return 0;
		}
    while(*(str + num_chars))
    {
    	++num_chars;
	}
	return num_chars ;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Power_Of

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.10 

Bugs           :   
-*------------------------------------------------------------*/
uint32_t Power_Of(const uint8_t base, const uint8_t power )
{
    uint32_t power_val = 1;
    uint8_t i = 0;
  
    if(power == 0)
    {
       return power_val;
    }
    for(i = 1; i <= power; ++i)
    {
      power_val *= base;
    }
    return power_val;
}
