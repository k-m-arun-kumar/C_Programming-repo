/* ********************************************************************
FILE                   : selective_one_nofsm.c

PROGRAM DESCRIPTION    : elevator control is based on two basic principles.
  1: Continue to travel in the current elevator movement direction(up or down) while there are still remaining requests in that same elevator movement direction.
  2: If there are no further requests in that direction, then stop and become idle, or change direction if there are requests in the opposite direction.
  elevator's in cabin floor call for each floor and only one hall floor call for each floor are considered. 
  So when either in cabin floor call or hall floor call is active, then floor call for that floor is active.
  We simulate, floor call as request for that floor and implemented elevator control principles 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>
#define SUCCESS         (0) 

typedef enum 
{
	NO_ERROR, ERR_NULL_PTR,ERR_FORMAT_INVALID , ERR_QUEUE_FULL, ERR_QUEUE_EMPTY, ERR_ENQUEUE_PROC, ERR_DEQUEUE_PROC, ERR_QUEUE_INSERT_FRONT_PROC, ERR_QUEUE_DELETE_REAR_PROC,
	ERR_QUEUE_RETRIEVE_INFO_PROC, ERR_DISP_QUEUE_PROC, ERR_INSERT_DATA_PROC, ERR_RETRIEVE_DATA_PROC, NUM_SYS_STATUS
} system_status_t;


typedef enum
 {
	ERR_UART_NOT_DATA_SRC = NUM_SYS_STATUS, ERR_FLOOR_INVALID, ERR_ELEVATOR_CH_ID_EXCEEDS, WARN_FLOOR_CALL_ALREADY_SELECT, ERR_NEXT_STOP_FLOOR_REACH_BUT_NOT_IN_STOP_LIST,
	ERR_MAX_STOP_FLOOR_REACH_BUT_NOT_IN_STOP_LIST, ERR_MIN_STOP_FLOOR_REACH_BUT_NOT_IN_STOP_LIST, ERR_NEXT_STOP_MORE_THAN_MAX_STOP_FLOOR, ERR_NEXT_STOP_LESS_THAN_MIN_STOP_FLOOR, 
	ERR_COMPUTE_NEXT_FLOOR_STOP_PROC, ERR_ELEVATOR_NOT_STATIONARY, ERR_MIN_STOP_FLOOR_INVALID, ERR_MIN_STOP_FLOOR_NOT_IN_STOP_LIST, ERR_MAX_STOP_FLOOR_INVALID, NUM_APPL_STATUS
 } appl_status_t;
 
#define ERROR_OCCURED    (1)
#define NULL_PTR                          ((void *) 0)
#define DATA_NA                           (0)

typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long uint64_t;

typedef char int8_t;
typedef short int int16_t;
typedef int int32_t;
typedef long int64_t;

uint32_t system_status_flag = NO_ERROR;
uint32_t appl_status_flag = NO_ERROR;

typedef enum
{
	RESET_WHOLE, RESET_DATA_IDS_AND_APPL, RESET_APPL
} reset_status_t;

uint8_t Error_or_Warning_Proc(const char *const error_trace_str, const uint8_t warn_or_error_format, const uint32_t warning_or_error_code);
uint16_t Appl_Reset(const uint8_t reset_type);
uint16_t Appl_Reset_Proc(const uint8_t cur_ctrl_elevator_ch_id);
uint16_t Validate_Floor(const uint8_t floor);
uint16_t Compute_Next_Floor_Stop(const uint8_t cur_ctrl_elevator_ch_id, uint8_t *const elevator_next_fsm_state_ptr);

#define MAX_NUM_FLOORS          (5)
#define FLOOR_ID_INVALID        (MAX_NUM_FLOORS  + 1)
#define DEFAULT_FLOOR           (0)
#define MAX_NUM_ELEVATORS       (1)
#define CTRL_ELEVATOR_CH_ID     (0)

typedef enum 
{
	STATIONARY, MOVE_UP, MOVE_DOWN, STARTUP_STATIONARY, STARTUP_MOVE_UP, STARTUP_MOVE_DOWN,  ELEVATOR_ERROR, STATUS_NA,  NO_PENDING_FLOOR_CALLS, 
	TRIGGER_MOVE_UP_NO_DIR_CHANGE, TRIGGER_MOVE_UP_DIR_CHANGE, TRIGGER_MOVE_DOWN_NO_DIR_CHANGE, TRIGGER_MOVE_DOWN_DIR_CHANGE
} elevator_status_t;

typedef struct
{
   uint8_t cur_max_floor_call;
   uint8_t cur_min_floor_call;
   uint8_t cur_floor;
   uint8_t elevator_status;
   uint8_t elevator_movement;
   uint8_t pending_floor_call_bit_field;
   uint8_t next_stop_floor;
} elevator_ctrl_and_status_t;

elevator_ctrl_and_status_t elevator_ctr_and_status[MAX_NUM_ELEVATORS];

typedef enum
{
	CUR_FLOOR_OPER = 1, FLOOR_CALL_OPER, DISP_OPER, RESET_OPER, EXIT_OPER
} choice_oper_t;

/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.13  

BUGS           :              
-*------------------------------------------------------------*/
int main()
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	uint8_t floor_call, temp_data, cur_floor, next_state;
	int8_t choice; 
	
	cur_elevator_ptr = elevator_ctr_and_status + CTRL_ELEVATOR_CH_ID;
	Appl_Reset(RESET_APPL);
	
	while(1)
	{
		printf("\n 1 - cur floor, 2 - floor call, 3 - disp, 4 - reset, 5 - exit ");
		printf("\n Enter choice : ");
		scanf("%d", &choice);
		switch(choice)
		{
			case CUR_FLOOR_OPER:
			  printf("\n Enter current floor:  ");			  
			  scanf("%d", &temp_data);
			  if((ret_status = Validate_Floor(temp_data)) != SUCCESS)
			  {
				  printf("\n ERR: INVALID FLOOR: RANGE[0, %u] ", MAX_NUM_FLOORS - 1 );
				  break;				  
			  }
			  cur_elevator_ptr->cur_floor = temp_data;			 
			  switch(cur_elevator_ptr->elevator_movement) 
			  {
				  case STATUS_NA:
			  	   	cur_elevator_ptr->next_stop_floor = DEFAULT_FLOOR;
			  	   	if(cur_elevator_ptr->cur_floor == cur_elevator_ptr->next_stop_floor)
			  	   	{
			  	   		 cur_elevator_ptr->elevator_status = STARTUP_STATIONARY;
						 printf("\n Stationary: cur_floor : %d", cur_elevator_ptr->cur_floor);
					}
					else
					{
						if(cur_elevator_ptr->cur_floor < cur_elevator_ptr->next_stop_floor) 
				        {
				        	//trigger to move up at start up
				        	 cur_elevator_ptr->elevator_status = MOVE_UP;
							 cur_elevator_ptr->elevator_movement = STARTUP_MOVE_UP;
                             printf("\n Moving Up - cur_floor : %d", cur_elevator_ptr->cur_floor);							 
				        }
				        else
				        {	
						  // trigger to move down at start up					 	
				            cur_elevator_ptr->elevator_status = MOVE_DOWN;
							cur_elevator_ptr->elevator_movement = STARTUP_MOVE_DOWN;
				            printf("\n Moving Down - cur_floor : %d", cur_elevator_ptr->cur_floor);
				        }	
					}
                  break; 					
			      case MOVE_UP:
				  case MOVE_DOWN:
				    if(cur_elevator_ptr->cur_floor == cur_elevator_ptr->next_stop_floor)
			  	    {
			  	    	 cur_elevator_ptr->elevator_status = STATIONARY;
			  	 	     if((cur_elevator_ptr->pending_floor_call_bit_field & (1 << cur_elevator_ptr->next_stop_floor)) == 0)
			  	 	     {
			  	 	 	    printf("\n ERR:  next stop floor: %d reached but not in stop list", cur_elevator_ptr->next_stop_floor);
			    		    appl_status_flag = ERR_NEXT_STOP_FLOOR_REACH_BUT_NOT_IN_STOP_LIST;
			    		    Error_or_Warning_Proc("02.13.02", ERROR_OCCURED, appl_status_flag);
                            return appl_status_flag;						 
				         }
                         cur_elevator_ptr->pending_floor_call_bit_field &= ~(1 << cur_elevator_ptr->cur_floor);				         
                         if((ret_status = Compute_Next_Floor_Stop(CTRL_ELEVATOR_CH_ID, &next_state)) != SUCCESS)
					     {
					    	 appl_status_flag = ERR_COMPUTE_NEXT_FLOOR_STOP_PROC;
			    	         Error_or_Warning_Proc("02.13.03", ERROR_OCCURED, appl_status_flag);
					    	return appl_status_flag;
					     }   
							
                         switch(next_state)
						 {	
                           case NO_PENDING_FLOOR_CALLS:
						      cur_elevator_ptr->elevator_movement = STATIONARY;
							  printf("\n No pending floor calls");
						   break;                                  						
                           case TRIGGER_MOVE_UP_NO_DIR_CHANGE:						
					          //trigger car to move up
							  cur_elevator_ptr->elevator_movement = MOVE_UP;
				              printf("\n TRA: No dir change to move up to next stop floor: %d",cur_elevator_ptr->next_stop_floor);
                           break;
						    case TRIGGER_MOVE_UP_DIR_CHANGE:
							  //trigger car to move up
							   cur_elevator_ptr->elevator_movement = MOVE_UP;
				              printf("\n TRA: Dir change move up to next stop floor: %d",cur_elevator_ptr->next_stop_floor);
						   break;	
						   case TRIGGER_MOVE_DOWN_NO_DIR_CHANGE:						
					          //trigger car to move down
							  cur_elevator_ptr->elevator_movement = MOVE_DOWN;
				              printf("\n TRA: No dir change to move down to next stop floor: %d",cur_elevator_ptr->next_stop_floor);
                           break;
						   case TRIGGER_MOVE_DOWN_DIR_CHANGE:
						      //trigger car to move down
							  cur_elevator_ptr->elevator_movement = MOVE_DOWN;
				              printf("\n TRA: dir change to move down to next stop floor: %d",cur_elevator_ptr->next_stop_floor);
						   break;
                           default:	
                               appl_status_flag = ERR_FORMAT_INVALID;
		                       Error_or_Warning_Proc("02.13.04", ERROR_OCCURED, appl_status_flag);
		                      return appl_status_flag;						   
			            }
			         }
				     else
				     {
					    switch(cur_elevator_ptr->elevator_movement)
					    {
						   case MOVE_UP:
						     printf("\n TRA: Moving up non stop, cur_floor : %d and next_stop_floor: %d", cur_elevator_ptr->cur_floor, cur_elevator_ptr->next_stop_floor);
					       break;                           
						   case MOVE_DOWN:
						     printf("\n TRA: Moving Down non stop, cur_floor : %d and next_stop_floor: %d", cur_elevator_ptr->cur_floor, cur_elevator_ptr->next_stop_floor);
					       break;						   
					    }
				     }
				      printf("\n TRA: pending floor calls : 0x%x", cur_elevator_ptr->pending_floor_call_bit_field); 
				   break;
				   case STARTUP_MOVE_UP:
				   	    
						if(cur_elevator_ptr->cur_floor == cur_elevator_ptr->next_stop_floor)
			  	     	{
			  	   		   cur_elevator_ptr->elevator_status = STARTUP_STATIONARY;
						    printf("\n Stationary: cur_floor : %d", cur_elevator_ptr->cur_floor);
					   }
					   else
					   {
						   printf("\n Moving up - cur_floor : %d", cur_elevator_ptr->cur_floor);
					   }
				   break;
				   case STARTUP_MOVE_DOWN:
				        if(cur_elevator_ptr->cur_floor == cur_elevator_ptr->next_stop_floor)
			  	     	{
			  	   		    cur_elevator_ptr->elevator_status = STARTUP_STATIONARY;
						    printf("\n Stationary: cur_floor : %d", cur_elevator_ptr->cur_floor);
					    }
						else
					    {
				   	      printf("\n Moving Down - cur_floor : %d", cur_elevator_ptr->cur_floor);
						}
				   break;
				   case STARTUP_STATIONARY:
                      printf("\n Floor calls are allowed ");					  
				   break;
				   default:
				       appl_status_flag = ERR_FORMAT_INVALID;
		               Error_or_Warning_Proc("02.13.04", ERROR_OCCURED, appl_status_flag);
		               return appl_status_flag;
			  }
			break;
			case FLOOR_CALL_OPER:
			    printf("\n Enter floor call:  ");
			    scanf("%d", &temp_data);
				if((ret_status = Validate_Floor(temp_data)) != SUCCESS)
			    {
				   printf("\n ERR: INVALID FLOOR: RANGE[0, %u] ", MAX_NUM_FLOORS - 1 );
				   break;
			    }
			    floor_call = temp_data;
			    if(floor_call == cur_elevator_ptr->cur_floor)
			    {
					printf("\n WARN: floor call: %d == cur_floor", floor_call);					
					break;
				}
				else
				{					
			    	if((cur_elevator_ptr->pending_floor_call_bit_field & (1 << floor_call)) != 0)
			    	{
			    		printf("\n WARN: floor call: %d was already be selected", floor_call);
			    		appl_status_flag = WARN_FLOOR_CALL_ALREADY_SELECT;
			    		Error_or_Warning_Proc("02.13.05", ERROR_OCCURED, appl_status_flag);
			    		break;
					}
					else
					{
						 cur_elevator_ptr->pending_floor_call_bit_field |= (1 << floor_call);
						 if(cur_elevator_ptr->cur_max_floor_call == FLOOR_ID_INVALID)
						 {
						 	 cur_elevator_ptr->cur_max_floor_call = floor_call;
						 	 cur_elevator_ptr->cur_min_floor_call = floor_call;
						 	 cur_elevator_ptr->next_stop_floor = floor_call;
							 printf("\r TRA: first pending floor call : %d",floor_call );
						 	 if(cur_elevator_ptr->cur_floor < floor_call) 
					    	 {
						    	 cur_elevator_ptr->elevator_status = MOVE_UP;
								 cur_elevator_ptr->elevator_movement = MOVE_UP;
                                 printf("\n TRA: move up to floor call: %d", floor_call);								 
						     }
						     else
						     {						 	
						        cur_elevator_ptr->elevator_status = MOVE_DOWN;
						        cur_elevator_ptr->elevator_movement = MOVE_DOWN;
								 printf("\n TRA: move down to floor call: %d", floor_call);	
						     }
							
						 }
						 else
						 {
						 	 if(cur_elevator_ptr->cur_max_floor_call < floor_call)
						 	 {
						 	 	cur_elevator_ptr->cur_max_floor_call = floor_call;
							 }
							 if(cur_elevator_ptr->cur_min_floor_call > floor_call)
						 	 {
						 	 	cur_elevator_ptr->cur_min_floor_call = floor_call;
							 }
							 printf("\n TRA: pending floor call range[%d , %d]", cur_elevator_ptr->cur_min_floor_call, cur_elevator_ptr->cur_max_floor_call);
						 }
						 printf("\n TRA: pending floor calls : 0x%x", cur_elevator_ptr->pending_floor_call_bit_field);
					}
				}
			break;
			case DISP_OPER:
				printf("cur_floor                     : %u\n", cur_elevator_ptr->cur_floor);
	            printf("next_stop_floor               : %u\n", cur_elevator_ptr->next_stop_floor);
            	printf("min_stop_floor                : %u\n", cur_elevator_ptr->cur_min_floor_call);
            	printf("max_stop_floor                : %u\n", cur_elevator_ptr->cur_max_floor_call);
            	printf("status                        : %u\n", cur_elevator_ptr->elevator_status);
            	printf("movement                      : %u\n", cur_elevator_ptr->elevator_movement);
             	printf("pending floor calls           : 0x%X\n", cur_elevator_ptr->pending_floor_call_bit_field);	
            break; 	
			case RESET_OPER:
			  Appl_Reset(RESET_APPL);
			break;
			case EXIT_OPER:
			  return SUCCESS;
			//break;
			default:
			  printf("\n Invalid oper ");
		}
	}
    return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Reset_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.11

BUGS           :    
-*------------------------------------------------------------*/ 
uint16_t Appl_Reset_Proc(const uint8_t cur_ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
		
	if(cur_ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("11.11.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    } 
    cur_elevator_ptr = elevator_ctr_and_status + cur_ctrl_elevator_ch_id;
    cur_elevator_ptr->cur_max_floor_call = FLOOR_ID_INVALID;
    cur_elevator_ptr->cur_min_floor_call = FLOOR_ID_INVALID;
    cur_elevator_ptr->elevator_status = STATIONARY;
    cur_elevator_ptr->elevator_movement = STATUS_NA;
	cur_elevator_ptr->pending_floor_call_bit_field = 0; 
	cur_elevator_ptr->next_stop_floor = FLOOR_ID_INVALID;  
	return SUCCESS;
}	


/*------------------------------------------------------------*
FUNCTION NAME  : Validate_Floor

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.12  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Validate_Floor(const uint8_t floor)
{
	if(floor < 0 || floor >=  MAX_NUM_FLOORS)
	{
		appl_status_flag = ERR_FLOOR_INVALID;
		Error_or_Warning_Proc("11.12.01", ERROR_OCCURED, appl_status_flag);
		return appl_status_flag;
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Compute_Next_Floor_Stop

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.13  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Compute_Next_Floor_Stop(const uint8_t cur_ctrl_elevator_ch_id, uint8_t *const elevator_next_fsm_state_ptr)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	int8_t cur_floor;
	
	if(elevator_next_fsm_state_ptr == NULL_PTR)
	{
		appl_status_flag = ERR_NULL_PTR;
	    Error_or_Warning_Proc("11.13.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
	}
    if(cur_ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("11.13.03", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    } 
    cur_elevator_ptr = elevator_ctr_and_status + cur_ctrl_elevator_ch_id;
	if(cur_elevator_ptr->elevator_status != STATIONARY)
	{
		appl_status_flag = ERR_ELEVATOR_NOT_STATIONARY;
	    Error_or_Warning_Proc("11.13.04", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
	}
	if(cur_elevator_ptr->next_stop_floor == cur_elevator_ptr->cur_min_floor_call && cur_elevator_ptr->next_stop_floor == cur_elevator_ptr->cur_max_floor_call)
	{
		//no more floor calls 
		 cur_elevator_ptr->next_stop_floor = FLOOR_ID_INVALID;
		 cur_elevator_ptr->cur_min_floor_call = FLOOR_ID_INVALID;
		 cur_elevator_ptr->cur_max_floor_call = FLOOR_ID_INVALID;
		 *elevator_next_fsm_state_ptr = NO_PENDING_FLOOR_CALLS;
		 return SUCCESS;
	}
    switch(cur_elevator_ptr->elevator_movement )
    { 
      	case MOVE_UP:
			if(cur_elevator_ptr->next_stop_floor > cur_elevator_ptr->cur_max_floor_call)
			{
			 	 printf("\n ERR:  next stop floor: %d > max_floor_call : %d", cur_elevator_ptr->next_stop_floor, cur_elevator_ptr->cur_max_floor_call);
			   	 appl_status_flag = ERR_NEXT_STOP_MORE_THAN_MAX_STOP_FLOOR;
			   	 Error_or_Warning_Proc("11.13.05", ERROR_OCCURED, appl_status_flag);
			   	 return appl_status_flag;
			}
		    if(cur_elevator_ptr->next_stop_floor < cur_elevator_ptr->cur_max_floor_call)
			{
			  	 for(cur_floor = cur_elevator_ptr->next_stop_floor + 1; cur_floor <= cur_elevator_ptr->cur_max_floor_call; ++cur_floor)
			     {
			    	 if((cur_elevator_ptr->pending_floor_call_bit_field & (1 << cur_floor)) != 0)
			    	 {
			    	     if(cur_elevator_ptr->cur_min_floor_call == cur_elevator_ptr->next_stop_floor)
			    	     {
			    	     	 cur_elevator_ptr->cur_min_floor_call = cur_floor;
						 }			    	     
			 	    	 cur_elevator_ptr->next_stop_floor = cur_floor;
					   	 break;
			   	     }
			     }				 
			     if(cur_floor > cur_elevator_ptr->cur_max_floor_call)
			     {
			    	 printf("\n ERR: max stop floor: %d but not in stop list", cur_elevator_ptr->cur_max_floor_call);
			         appl_status_flag = ERR_MAX_STOP_FLOOR_REACH_BUT_NOT_IN_STOP_LIST;
			         Error_or_Warning_Proc("11.13.06", ERROR_OCCURED, appl_status_flag);
				 	return appl_status_flag;	 
			     }
				 printf("\n TRA: cur_floor: %d, next stop floor : %u, min floor call : %d, max_floor_call: %d", 
				  cur_elevator_ptr->cur_floor, cur_elevator_ptr->next_stop_floor, cur_elevator_ptr->cur_min_floor_call, cur_elevator_ptr->cur_max_floor_call);
				 *elevator_next_fsm_state_ptr = TRIGGER_MOVE_UP_NO_DIR_CHANGE;
				 return SUCCESS;				 
		    }
		    // cur_elevator_ptr->next_stop_floor == cur_elevator_ptr->cur_max_floor_call
			if(cur_elevator_ptr->next_stop_floor < cur_elevator_ptr->cur_min_floor_call)
		    {
		         printf("\n ERR:  next stop floor: %d < min_floor_call : %d", cur_elevator_ptr->next_stop_floor, cur_elevator_ptr->cur_min_floor_call);
		      	 appl_status_flag = ERR_NEXT_STOP_LESS_THAN_MIN_STOP_FLOOR;
		      	 Error_or_Warning_Proc("11.13.07", ERROR_OCCURED, appl_status_flag);
			   	 return appl_status_flag;                    	
			}
			// action to move down      
			//cur_elevator_ptr->next_stop_floor > cur_elevator_ptr->cur_min_floor_call 
			for(cur_floor = cur_elevator_ptr->next_stop_floor - 1; cur_floor >= cur_elevator_ptr->cur_min_floor_call; --cur_floor)
			{
			  	 if((cur_elevator_ptr->pending_floor_call_bit_field & (1 << cur_floor)) != 0)
			   	 {
			   	 	if(cur_elevator_ptr->cur_max_floor_call == cur_elevator_ptr->next_stop_floor)
					{
						cur_elevator_ptr->cur_max_floor_call = cur_floor;
					}	
			    	cur_elevator_ptr->next_stop_floor = cur_floor;			    					 				
			     	break;
			     }
			}
			if(cur_floor < cur_elevator_ptr->cur_min_floor_call)
			{
				appl_status_flag = ERR_MIN_STOP_FLOOR_INVALID;
		        Error_or_Warning_Proc("11.13.08", ERROR_OCCURED, appl_status_flag);
			    return appl_status_flag;
			}
			printf("\n TRA: cur_floor: %d, next stop floor : %u, min floor call : %d, max_floor_call: %d", 
				  cur_elevator_ptr->cur_floor, cur_elevator_ptr->next_stop_floor, cur_elevator_ptr->cur_min_floor_call, cur_elevator_ptr->cur_max_floor_call); 
			*elevator_next_fsm_state_ptr = TRIGGER_MOVE_DOWN_DIR_CHANGE;
			return SUCCESS;			
		//break;
		case MOVE_DOWN:
		    if(cur_elevator_ptr->next_stop_floor < cur_elevator_ptr->cur_min_floor_call)
			{
			 	 printf("\n ERR:  next stop floor: %d < min_floor_call : %d", cur_elevator_ptr->next_stop_floor, cur_elevator_ptr->cur_min_floor_call);
			   	 appl_status_flag = ERR_NEXT_STOP_LESS_THAN_MIN_STOP_FLOOR;
			   	 Error_or_Warning_Proc("11.13.09", ERROR_OCCURED, appl_status_flag);
			   	 return appl_status_flag;
			}
		    if(cur_elevator_ptr->next_stop_floor > cur_elevator_ptr->cur_min_floor_call)
			{
			  	 for(cur_floor = cur_elevator_ptr->next_stop_floor - 1; cur_floor >= cur_elevator_ptr->cur_min_floor_call; --cur_floor)
			     {
			    	 if((cur_elevator_ptr->pending_floor_call_bit_field & (1 << cur_floor)) != 0)
			    	 {
			    	  	if(cur_elevator_ptr->cur_max_floor_call == cur_elevator_ptr->next_stop_floor)
					    {
					    	cur_elevator_ptr->cur_max_floor_call = cur_floor;
					    }
			 	    	 cur_elevator_ptr->next_stop_floor = cur_floor;
						 break;
			   	     }
			     }				 
			     if(cur_floor < cur_elevator_ptr->cur_max_floor_call)
			     {
			    	 printf("\n ERR: MiN floor call: %d but not in stop list", cur_elevator_ptr->cur_min_floor_call);
			         appl_status_flag = ERR_MIN_STOP_FLOOR_REACH_BUT_NOT_IN_STOP_LIST;
			         Error_or_Warning_Proc("11.13.10", ERROR_OCCURED, appl_status_flag);
				 	return appl_status_flag;	
				 }					
			     printf("\n TRA: cur_floor: %d, next stop floor : %u, min floor call : %d, max_floor_call: %d", 
				 cur_elevator_ptr->cur_floor, cur_elevator_ptr->next_stop_floor, cur_elevator_ptr->cur_min_floor_call, cur_elevator_ptr->cur_max_floor_call);
				 *elevator_next_fsm_state_ptr = TRIGGER_MOVE_DOWN_NO_DIR_CHANGE;
				 return SUCCESS;				 
		    }
			if(cur_elevator_ptr->next_stop_floor > cur_elevator_ptr->cur_max_floor_call)
		    {
		         printf("\n ERR:  next stop floor: %d > max_floor_call : %d", cur_elevator_ptr->next_stop_floor, cur_elevator_ptr->cur_max_floor_call);
		      	 appl_status_flag = ERR_NEXT_STOP_MORE_THAN_MAX_STOP_FLOOR;
		      	 Error_or_Warning_Proc("11.13.11", ERROR_OCCURED, appl_status_flag);
			   	 return appl_status_flag;                    	
			}
			// action to move up     
			//cur_elevator_ptr->next_stop_floor < cur_elevator_ptr->cur_max_floor_call 
			for(cur_floor = cur_elevator_ptr->next_stop_floor + 1; cur_floor <= cur_elevator_ptr->cur_max_floor_call; ++cur_floor)
			{
			  	 if((cur_elevator_ptr->pending_floor_call_bit_field & (1 << cur_floor)) != 0)
			   	 {
			   	 	 if(cur_elevator_ptr->cur_min_floor_call == cur_elevator_ptr->next_stop_floor)
			    	 {
			    	   	 cur_elevator_ptr->cur_min_floor_call = cur_floor;
					 }	
					 cur_elevator_ptr->next_stop_floor = cur_floor;
					 break;
			     }
			}
			if(cur_floor > cur_elevator_ptr->cur_max_floor_call)
			{
				appl_status_flag = ERR_MAX_STOP_FLOOR_INVALID;
		        Error_or_Warning_Proc("11.13.12", ERROR_OCCURED, appl_status_flag);
			    return appl_status_flag;
			}
			printf("\n TRA: cur_floor: %d, next stop floor : %u, min floor call : %d, max_floor_call: %d", 
				  cur_elevator_ptr->cur_floor, cur_elevator_ptr->next_stop_floor, cur_elevator_ptr->cur_min_floor_call, cur_elevator_ptr->cur_max_floor_call);
			*elevator_next_fsm_state_ptr = TRIGGER_MOVE_UP_DIR_CHANGE;
			return SUCCESS;			
	//	break;				        
		default:
		   printf("\n ERR:  invalid last movement" );
		   appl_status_flag = ERR_FORMAT_INVALID;
		   Error_or_Warning_Proc("11.13.13", ERROR_OCCURED, appl_status_flag);
		   return appl_status_flag;	
	 }
	 return SUCCESS;
}				     

/*------------------------------------------------------------*
FUNCTION NAME  : Error_or_Warning_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.14  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t Error_or_Warning_Proc(const char *const error_trace_str, const uint8_t warn_or_error_format, const uint32_t warning_or_error_code)
{
	printf("\n ERR: TRACE: %s, code: %u", error_trace_str, warning_or_error_code);
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Reset

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.01

BUGS           :    
-*------------------------------------------------------------*/
 uint16_t Appl_Reset(const uint8_t reset_type)
{
	uint16_t ret_status;
	
	switch(reset_type)
	{
		case RESET_APPL:	
           appl_status_flag = NO_ERROR;
           Appl_Reset_Proc(CTRL_ELEVATOR_CH_ID);	   
		break;
		default:
		   appl_status_flag = ERR_FORMAT_INVALID;
		   Error_or_Warning_Proc("11.01.04", ERROR_OCCURED, appl_status_flag);
		   return appl_status_flag;
	}
	return SUCCESS;
}


