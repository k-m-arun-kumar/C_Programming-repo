/* ********************************************************************
FILE                   : port_conf.c

PROGRAM DESCRIPTION    : 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>

#define FLAG_CONSUCC_BITS_1         (1)
#define FLAG_CONSUCC_BITS_0         (2)
#define FLAG_CONSUCC_BITS_TOGGLE    (3)
#define TEST_OK_1_CONSUCC_BITS      (4)
#define TEST_FAIL_1_CONSUCC_BITS    (5)
#define TEST_OK_0_CONSUCC_BITS      (6)
#define TEST_FAIL_0_CONSUCC_BITS    (7)

#define SUCCESS            (0)
#define FAILURE            (1)

#define NULL_PTR            ((void *) 0)
#define INT_BIT_SIZE         (32) 
 
typedef unsigned int uint32_t;
typedef unsigned char uint8_t;

typedef enum 
{
	NO_ERROR, ERR_IO_CONFIG_NULL_PTR, ERR_CONFIG_PORT_NULL_PTR_OR_END_PIN_VAL, ERR_CONFIG_PORT_BIT_VAL, ERR_IO_CH_WRITE_DATA,
	ERR_IO_CONFIG_INDEX_INVALID, ERR_IO_CH_INVALID, ERR_CONFIG_IO_CH_MATCH_INVALID, ERR_GPIO_FUNC_SET,  ERR_IO_CH_00_FUNC_SET, 
	ERR_TRACE_FUNC_SET, ERR_IO_CH_48_FUNC_SET, ERR_IO_CH_58_FUNC_SET, ERR_PORT1_PIN_FUNC_SET, ERR_PORT_INVALID,
  ERR_CONFIG_PORT_INIT_VAL, ERR_IO_CH_GPIO_FUNC_SET, ERR_SW_CH_GPIO_FUNC_SET, ERR_GPIO_INPUT_FUNC_STATE, ERR_PIN_SIGNAL,
	ERR_PORT0_IO_PIN, ERR_PORT1_IO_PIN,  ERR_GPIO_CH_SET_PORT, ERR_IO_PIN_RANGE,  ERR_IO_CH_24_PIN, ERR_IO_CH_32_TO_47,
	ERR_CONF_INDEX_IO_CH_NULL_PTR, ERR_PORT_TO_IO_CONF_NULL_PTR, ERR_MAX_SW_CH_EXCEEDS, ERR_CONSUCC_PARA, ERR_STR_TO_NUM_PARA,
	ERR_STR_PTR_NULL, ERR_GPIO_OUTPUT_DATA, ERR_INVALID_PORT, ERR_IO_CH_READ_DATA, ERR_IO_CH_TO_SW_CH,
	ERR_IO_CH_RESERVE_PIN_FUNC_SET, ERR_GPIO_OUTPUT_FUNC_STATE, ERR_SW_CH_NOT_MATCH_IO_CH, ERR_CONFIG_PIN_RANGE, 
	ERR_CONFIG_DEBUG_FUNC_SET, ERR_CONFIG_TRACE_FUNC_SET, ERR_IO_CONFIG_TABLE_LARGE, NUM_SYS_ERR 
} system_error_flags_t;

 typedef enum
{
    PORT_CH_00, PORT_CH_01, NUM_PORT_CHS	
} port_ch_t;

typedef struct
{
	  uint8_t port;
	  uint8_t port_pin;
} io_port_t;

typedef enum 
{ 
  PIN_00, PIN_01, PIN_02, PIN_03, PIN_04, PIN_05, PIN_06, PIN_07, 
  PIN_08, PIN_09, PIN_10, PIN_11, PIN_12, PIN_13, PIN_14, PIN_15,
  PIN_16, PIN_17, PIN_18, PIN_19, PIN_20, PIN_21, PIN_22, PIN_23,
  PIN_24, PIN_25, PIN_26, PIN_27, PIN_28, PIN_29, PIN_30, PIN_31,
  NUM_PINS_PER_PORT   
} io_pin_t;

typedef enum 
{
  IO_CH_00, IO_CH_01, IO_CH_02, IO_CH_03, IO_CH_04, IO_CH_05, IO_CH_06, IO_CH_07, 
  IO_CH_08, IO_CH_09, IO_CH_10, IO_CH_11, IO_CH_12, IO_CH_13, IO_CH_14, IO_CH_15,
  IO_CH_16, IO_CH_17, IO_CH_18, IO_CH_19, IO_CH_20, IO_CH_21, IO_CH_22, IO_CH_23,
  IO_CH_24, IO_CH_25, IO_CH_26, IO_CH_27, IO_CH_28, IO_CH_29, IO_CH_30, IO_CH_31,
	IO_CH_48 = 48, IO_CH_49, IO_CH_50, IO_CH_51, IO_CH_52, IO_CH_53, IO_CH_54, IO_CH_55, 
  IO_CH_56, IO_CH_57, IO_CH_58, IO_CH_59, IO_CH_60, IO_CH_61, IO_CH_62, IO_CH_63, NUM_IO_CHS = 48
} io_ch_t;  
   
static uint32_t IO0PIN, IO1PIN, *const io_port_ptr [NUM_PORT_CHS] = {(uint32_t *) &IO0PIN, (uint32_t *) &IO1PIN}, error_flag = NO_ERROR;

typedef struct 
{
	uint32_t consucc_val;
	uint8_t start_bit_pos;
	uint8_t bits_len;
} consucc_bit_t;

uint8_t Config_Consucc_Bits( const uint8_t flag_consucc_bit, void *const data_ptr);
uint8_t Config_Port_Pins(const uint8_t io_channel, const void *const data_ptr);
uint8_t IO_Ch_Validate(const uint8_t io_ch, const uint8_t bit_len);

int main()
{
	consucc_bit_t consucc_bit_data;
	uint32_t temp_data;
	uint8_t to_continue, io_ch, port, port_pin ;
	
	do
	{
		printf("\n Enter start pos - ");
		scanf("%u", &temp_data);
		consucc_bit_data.start_bit_pos  =  temp_data;
		printf("\n Enter bits len - ");
		scanf("%u", &temp_data);
		consucc_bit_data.bits_len  =  temp_data;
		printf("\n Enter set data - 0x");
		scanf("%x", &temp_data);
		consucc_bit_data.consucc_val =  temp_data;
		printf("\n Enter cur port0 data - 0x");
		scanf("%x", io_port_ptr[PORT_CH_00]);
		printf("\n Enter IO ch - ");
		scanf("%u", &io_ch);	
		Config_Port_Pins(io_ch, &consucc_bit_data);	
		printf("\n Start_bit_pos: %u, bits_len; %u, set_data: 0x%x, io_ch: %u", \
		    consucc_bit_data.start_bit_pos, consucc_bit_data.bits_len, consucc_bit_data.consucc_val, io_ch );
		printf("\n Result -  port0 data: 0x%x", *io_port_ptr[PORT_CH_00]);		
		printf("\n Do u want to continue: press Y or y - ");
		to_continue = getch();		
	} while(to_continue == 'Y' || to_continue == 'y');
    return 0;    
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Config_Consucc_Bits

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.02 

BUGS           :
-*------------------------------------------------------------*/
uint8_t Config_Consucc_Bits( const uint8_t flag_consucc_bit, void *const data_ptr)
{
	uint32_t from_bit0_consucc_bits = 0;	
	consucc_bit_t *consucc_bit_ptr = (consucc_bit_t *)data_ptr;
	uint8_t i, ret_status = SUCCESS, end_bit_pos;     
	
	end_bit_pos = consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len - 1;
	if(consucc_bit_ptr == NULL_PTR || end_bit_pos >= INT_BIT_SIZE)
	{
		printf("\n ");
		return  error_flag;
	}
	for(i = 0; i < consucc_bit_ptr->bits_len; ++i)
	{
	  	from_bit0_consucc_bits |= 1 << i;			
	}
	switch(flag_consucc_bit)
	{
         case FLAG_CONSUCC_BITS_1:
		    consucc_bit_ptr->consucc_val |=  from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos;
	     break;		
	     case FLAG_CONSUCC_BITS_0:
		    consucc_bit_ptr->consucc_val &= ~(from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
	     break;
		 case FLAG_CONSUCC_BITS_TOGGLE:
		    consucc_bit_ptr->consucc_val ^= (from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
		 break;
		 default:
		    error_flag = ERR_CONSUCC_PARA;
		    ret_status = error_flag;
	}
	return ret_status;
}


/*------------------------------------------------------------*
FUNCTION NAME  : Config_Port_Pins

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 03.02  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t Config_Port_Pins(const uint8_t io_channel, const void *const data_ptr)
{
	 consucc_bit_t *consucc_bit_ptr = (consucc_bit_t *)data_ptr, consucc_bits_1;
	 uint8_t port, port_pin, ret_status = SUCCESS, end_port_pin;
 	 
	 end_port_pin = consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len - 1;
	 if(consucc_bit_ptr == NULL_PTR || end_port_pin >= NUM_PINS_PER_PORT)
	 {
		 error_flag = ERR_CONFIG_PORT_NULL_PTR_OR_END_PIN_VAL;
		   return error_flag;
	 } 
	 if((ret_status = IO_Ch_Validate(io_channel, consucc_bit_ptr->bits_len)) != SUCCESS)
	 {
	     error_flag  = ERR_IO_CH_INVALID;
	     return error_flag;
	 }
	 consucc_bits_1.start_bit_pos = consucc_bit_ptr->start_bit_pos;
	 consucc_bits_1.bits_len = consucc_bit_ptr->bits_len;
	 consucc_bits_1.consucc_val = 0;
    if((ret_status = Config_Consucc_Bits(FLAG_CONSUCC_BITS_1, &consucc_bits_1)) != SUCCESS )
	 {
		 error_flag = ERR_CONFIG_PORT_INIT_VAL;
		 return error_flag;
	 }
     port = io_channel / NUM_PINS_PER_PORT;
	 port_pin = io_channel % NUM_PINS_PER_PORT;	 
	 if(consucc_bit_ptr->start_bit_pos != port_pin || consucc_bits_1.consucc_val != (consucc_bits_1.consucc_val | consucc_bit_ptr->consucc_val << consucc_bit_ptr->start_bit_pos))
	 {
		  error_flag = ERR_CONFIG_PORT_BIT_VAL;
		 // to set data in port not within valid range for a bit len  ie for bit len - 3, then valid value range is [0,7] 
		 return error_flag;
	 }
		
	 *io_port_ptr[port] = ( *io_port_ptr[port] & ~consucc_bits_1.consucc_val ) | (consucc_bit_ptr->consucc_val << consucc_bit_ptr->start_bit_pos);
	 return ret_status;
}


/*------------------------------------------------------------*
FUNCTION NAME  : IO_Ch_Validate 

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : for lpc2138 io channel 

Func ID        : 03.07  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t IO_Ch_Validate(const uint8_t io_ch, const uint8_t bit_len)
{
	  uint8_t port, port_pin, ret_status = SUCCESS, end_port_pin ;
	
	  port  = io_ch / NUM_PINS_PER_PORT;
	  port_pin = io_ch % NUM_PINS_PER_PORT; 
	  end_port_pin = port_pin + bit_len - 1;
	  if(port_pin >= NUM_PINS_PER_PORT || end_port_pin >= NUM_PINS_PER_PORT)
	  {
		  error_flag = ERR_IO_PIN_RANGE;
			return FAILURE;
	  }
	  switch(port)
	  {
			  case PORT_CH_00:
					if( (port_pin <= PIN_24 && end_port_pin >= PIN_24))
					{
					  	// PORT0's pin 24 is reserved
						  error_flag = ERR_IO_CH_24_PIN;
						  ret_status = error_flag;
					}
					
        break;
				case PORT_CH_01:
					if(port_pin <= PIN_15 || end_port_pin <= PIN_15)
					{
						// port1's pin [0,15] are reserved
						 error_flag = ERR_IO_CH_32_TO_47;
						 ret_status = error_flag;
					}
					
        break;
        default:
		    error_flag = ERR_INVALID_PORT;
					ret_status = error_flag;
				break;
		}					
		return ret_status; 
}


