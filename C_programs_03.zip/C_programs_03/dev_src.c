/* ********************************************************************
FILE                   : dev_src.c

PROGRAM DESCRIPTION    : 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include <stdio.h>


#define MAX_DATA_INPUT_DEVS                 (2)
#define MAX_DATA_OUTPUT_DEVS                (3)

#define  DATA_ID_INVALID               (100)
#define  DEV_ID_BIT_SIZE               (4)
#define  DEV_CH_ID_BIT_SIZE            (4)
#define INT_BIT_SIZE                   (32)

#define NUM_INPUT_DEV_ID_UART_CHS            (1)
#define NUM_INPUT_DEV_ID_I2C_CHS             (1)
#define NUM_INPUT_DEV_ID_SPI_CHS             (1)
#define NUM_INPUT_DEV_ID_MISC_CHS            (1)          
#define NUM_INPUT_DEV_ID_ADC_CHS             (1) 
#define NUM_INPUT_DEV_ID_KEYBOARD_CHS        (2)
#define NUM_INPUT_DEV_ID_SW_CHS              (3)             

#define NUM_OUTPUT_DEV_ID_UART_CHS           (1)
#define NUM_OUTPUT_DEV_ID_I2C_CHS            (1)
#define NUM_OUTPUT_DEV_ID_SPI_CHS            (1)  
#define NUM_OUTPUT_DEV_ID_MISC_CHS           (1)
#define NUM_OUTPUT_DEV_ID_DAC_CHS            (1)
#define NUM_OUTPUT_DEV_ID_PWM_CHS            (1)
#define NUM_OUTPUT_DEV_ID_LCD_CHS            (1)
#define NUM_OUTPUT_DEV_ID_SEG7_CHS           (2)

#define NULL_PTR                                      ((void *)0)

#define SUCCESS                                 (0)
#define FAILURE                                 (1)

#define STATE_YES                                (0)
#define STATE_NO                                 (1)
#define FLAG_CONSUCC_BITS_1         (1)
#define FLAG_CONSUCC_BITS_0         (2)
#define FLAG_CONSUCC_BITS_TOGGLE    (3)
#define TEST_OK_1_CONSUCC_BITS      (4)
#define TEST_FAIL_1_CONSUCC_BITS    (5)
#define TEST_OK_0_CONSUCC_BITS      (6)
#define TEST_FAIL_0_CONSUCC_BITS    (7)

 /* Bit Operation macros */
     /* Set bit pos  in byte data   */
#define Set_Bit_in_Data(data , bit_pos)                         ((*(data)) |=   (1<<(bit_pos)))     
      /* Clear bit pos in byte data */ 
#define Clear_Bit_in_Data(data ,bit_pos)                         ((*(data)) &= (~(1<<(bit_pos))))      
    /* flip bit pos in byte data  */ 
#define Toggle_Bit_in_Data(data , bit_pos)                       ((*(data)) ^=   (1<<(bit_pos)))        
    /* Test if bit pos in byte data  is set   */
#define Test_Bit_Is_Set_in_Data(data ,bit_pos)                    ((*(data)) & (1<<bit_pos))       
   /* Test if bit pos in byte data is clear */  
#define Test_Bit_Is_Clear_in_Data(data ,bit_pos)                  (!((*(data)) & (1<<bit_pos))) 

//REQ_DATA_INPUT_DEVS_CONF =  ((NUM_INPUT_DEVS /(INT_BIT_SIZE/ (DEV_CH_ID_BIT_SIZE + 1))) + 1)
#define  REQ_DATA_INPUT_DEVS_CONF      (2) 
#define  REQ_DATA_OUTPUT_DEVS_CONF     (2) 
#define DATA_MAX_NUM_CHARS             (10)

typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned int uint32_t;

typedef enum 
{
  DATA_ID_SEG7, NUM_DATA_IDS    	
} cur_data_id_t;

typedef enum
{
  INPUT_DEV_ID_UART, INPUT_DEV_ID_I2C, INPUT_DEV_ID_SPI, INPUT_DEV_ID_MISC, INPUT_DEV_ID_ADC, 
	INPUT_DEV_ID_KEYBOARD, INPUT_DEV_ID_SW, NUM_INPUT_DEVS, INPUT_DEV_ID_INVALID 	
} input_dev_id_t; 

typedef enum
{
	OUTPUT_DEV_ID_UART, OUTPUT_DEV_ID_I2C, OUTPUT_DEV_ID_SPI, OUTPUT_DEV_ID_MISC, OUTPUT_DEV_ID_DAC, 
	OUTPUT_DEV_ID_PWM, OUTPUT_DEV_ID_LCD, OUTPUT_DEV_ID_SEG7,  NUM_OUTPUT_DEVS, OUTPUT_DEV_ID_INVALID 
} output_dev_id_t;

typedef enum 
{
	 CH_ID_00, CH_ID_01, CH_ID_02, CH_ID_03, CH_ID_04, CH_ID_05, CH_ID_06, CH_ID_07, 
	 CH_ID_08, CH_ID_09, CH_ID_10, CH_ID_11, CH_ID_12, CH_ID_13, CH_ID_14, CH_ID_15, 
	 NUM_CHS, CH_ID_INVALID
} ch_id_t; 

typedef struct
{
	uint8_t  dev_id    : DEV_ID_BIT_SIZE;
	uint8_t  dev_ch_id : DEV_CH_ID_BIT_SIZE;
} dev_id_t;

typedef struct
{
     uint8_t data_id;
     dev_id_t data_input_dev_ids[MAX_DATA_INPUT_DEVS];
	 dev_id_t data_output_dev_ids[MAX_DATA_OUTPUT_DEVS];
} data_id_dev_src_t;

typedef struct 
{
	uint32_t consucc_val;
	uint8_t start_bit_pos;
	uint8_t bits_len;
} consucc_bit_t;
 

typedef struct 
{
	 uint32_t data_input_devs_conf[REQ_DATA_INPUT_DEVS_CONF];
	 uint32_t data_output_devs_conf[REQ_DATA_OUTPUT_DEVS_CONF];
	 uint8_t data_id;
	 uint8_t max_allocated_data_len;
	 uint8_t data_str_len;
	 char data_str[DATA_MAX_NUM_CHARS];	  
	 uint8_t data_input_num_try;
	 uint8_t valid_input_terminator_flag          : 1;
    uint8_t reach_max_alloc_input_chars_flag     : 1;
    uint8_t data_input_mode                      : 1;
	uint8_t                                      : 5;		 
} data_id_status_para_t;

typedef enum 
{
	NO_ERROR, ERR_IO_CONFIG_NULL_PTR, ERR_PORT_WRITE_VAL, ERR_PORT_WRITE_INIT_VAL, ERR_IO_CH_WRITE_DATA,
	ERR_IO_CONFIG_INDEX_INVALID, ERR_IO_CH_INVALID, ERR_CONFIG_IO_CH_MATCH_INVALID, ERR_GPIO_FUNC_SET,  ERR_IO_CH_00_FUNC_SET, 
	ERR_TRACE_FUNC_SET, ERR_IO_CH_48_FUNC_SET, ERR_IO_CH_58_FUNC_SET, ERR_PORT1_PIN_FUNC_SET, ERR_PORT_INVALID,
    ERR_CONFIG_PORT_INIT_VAL, ERR_IO_CH_GPIO_FUNC_SET, ERR_SW_CH_GPIO_FUNC_SET, ERR_GPIO_INPUT_FUNC_STATE, ERR_PIN_SIGNAL,
	ERR_PORT0_IO_PIN, ERR_PORT1_IO_PIN,  ERR_GPIO_CH_SET_PORT, ERR_IO_PIN_RANGE,  ERR_IO_CH_24_PIN, ERR_IO_CH_32_TO_47,
	ERR_CONF_INDEX_IO_CH_NULL_PTR, ERR_PORT_TO_IO_CONF_NULL_PTR, ERR_MAX_SW_CH_EXCEEDS, ERR_CONSUCC_PARA, ERR_STR_TO_NUM_PARA,
	ERR_STR_PTR_NULL, ERR_GPIO_OUTPUT_DATA, ERR_INVALID_PORT, ERR_IO_CH_READ_DATA, ERR_IO_CH_TO_SW_CH,
	ERR_IO_CH_RESERVE_PIN_FUNC_SET, ERR_GPIO_OUTPUT_FUNC_STATE, ERR_SW_CH_NOT_MATCH_IO_CH, ERR_CONFIG_PIN_RANGE, 
	ERR_CONFIG_DEBUG_FUNC_SET, ERR_CONFIG_TRACE_FUNC_SET, ERR_IO_CONFIG_TABLE_LARGE, ERR_TEST_FAIL_1_CONSUCC_BITS, ERR_TEST_FAIL_0_CONSUCC_BITS,
	ERR_KEYPAD_NO_ACCESS, ERR_KEYPAD_ROW_WRITE, ERR_KEYPAD_INVALID_ROW, ERR_KEYPAD_COL_READ, ERR_KEYPAD_NO_ACCESS_COL,
	ERR_KEYPAD_EXCEEDS_CHARS, ERR_SW_NO_READ, ERR_SW_NO_ACCESS, ERR_READ_PORT_VAL, ERR_SEG7_NO_WRITE,
	ERR_SW_NOT_PRESSED, KEYPAD_DATA_READY, KEYPAD_REACH_MAX_CHARS_WAIT_TERMINATOR_KEY, KEYPAD_PRESSED_KEY_DETECT, ERR_KEYPAD_NO_ACCESS_NON_NUM_PRESSED, 
	ERR_KEYBOARD_PROC, ERR_WRITE_NON_OUTPUT, ERR_PORT_WRITE_BIT_VAL, ERR_EXCEED_DATA_ID, ERR_NULL_PTR,
	ERR_INVALID_FORMAT, ERR_EXCEEDS_DATA_NUM_CHARS, ERR_DEV_SRC_ID_INVALID, ERR_ALREADY_MEM_ALLOC ,ERR_DATA_ID_CONF,
	ERR_DEV_CH_ID_EXCEEDS, ERR_DEV_CH_ID_OR_DATA_ID_INVALID, ERR_DEV_CH_ID_NO_ACCESS, ERR_PREV_AND_CUR_DATA_MATCH, 
	ERR_SEG7_NO_ACCESS, NUM_SYS_ERR 
} system_error_flags_t;


static uint8_t Data_ID_Input_Src_Set(const uint8_t data_id, const data_id_dev_src_t *const cur_data_id_dev_src_conf_ptr);
static uint8_t Data_ID_Output_Src_Set(const uint8_t data_id, const data_id_dev_src_t * const cur_data_id_dev_src_conf_ptr);
uint8_t Data_IDs_Set_Para(void);
uint8_t Config_Consucc_Bits( const uint8_t flag_consucc_bit, void *const data_ptr);
uint8_t Seg7_Proc(const uint8_t seg7_ch_id, const uint32_t  seg7_rcv_disp_num);
uint8_t Keyboard_Proc(const uint8_t keyboard_ch_id, uint8_t *const pressed_key);
uint8_t Data_ID_Devs_Src_Set(const data_id_dev_src_t * const data_id_dev_src_conf_ptr, const uint8_t num_conf_size);
data_id_status_para_t data_id_status_para[NUM_DATA_IDS] ;
uint32_t error_flag;
uint8_t cur_data_id;
const data_id_dev_src_t  data_ids_dev_srcs[] = {
	                                             {DATA_ID_SEG7, {INPUT_DEV_ID_KEYBOARD, CH_ID_01, INPUT_DEV_ID_INVALID }, {OUTPUT_DEV_ID_SEG7, CH_ID_01, OUTPUT_DEV_ID_INVALID}}
                                             };	

int main()
{
    data_id_status_para_t *cur_data_id_status_para_ptr = NULL_PTR;
    consucc_bit_t mask_dev_ch_id;
    uint8_t ret_status = SUCCESS, error_status_flag = STATE_NO, dev_src_index, dev_src_arr_index, dev_src_arr_bit, cur_dev_id, dev_ch_id, pressed_key;
	uint32_t seg7_rcv_disp_num; 
	
	cur_data_id = DATA_ID_SEG7;	
    if((ret_status = Data_IDs_Set_Para()) != SUCCESS)
  	{
 		return FAILURE;
    }
    
    if((ret_status = Keyboard_Proc(CH_ID_01, &pressed_key)) != SUCCESS)
    {
    	return FAILURE;
	} 
    
    if((ret_status = Seg7_Proc(CH_ID_01, seg7_rcv_disp_num)) != SUCCESS)
    {
    	return FAILURE;
	}
	printf("\n Data ID: %u src ch id of keyboard and seg7 are allowed to accessed", cur_data_id);
	return SUCCESS;   
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Config_Consucc_Bits

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.02 

BUGS           :
-*------------------------------------------------------------*/
uint8_t Config_Consucc_Bits( const uint8_t flag_consucc_bit, void *const data_ptr)
{
	uint32_t from_bit0_consucc_bits = 0;	
	consucc_bit_t *consucc_bit_ptr = (consucc_bit_t *)data_ptr;
	uint8_t i, ret_status = SUCCESS, end_bit_pos;     
	
	end_bit_pos = consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len - 1;
	if(consucc_bit_ptr == NULL_PTR || end_bit_pos >= INT_BIT_SIZE)
	{
		error_flag = ERR_CONSUCC_PARA;
		return  error_flag;
	}
	for(i = 0; i < consucc_bit_ptr->bits_len; ++i)
	{
	  	from_bit0_consucc_bits |= 1 << i;			
	}
	switch(flag_consucc_bit)
	{
         case FLAG_CONSUCC_BITS_1:
		    consucc_bit_ptr->consucc_val |=  from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos;
	     break;		
	     case FLAG_CONSUCC_BITS_0:
		    consucc_bit_ptr->consucc_val &= ~(from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
	     break;
		 case FLAG_CONSUCC_BITS_TOGGLE:
		    consucc_bit_ptr->consucc_val ^= (from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
		 break;
		 default:
		    error_flag = ERR_CONSUCC_PARA;
		    ret_status = error_flag;
	}
	return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Data_IDs_Set_Para

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.10 

Bugs           :   
-*------------------------------------------------------------*/
uint8_t Data_IDs_Set_Para(void)
{
	uint8_t data_id = 0, ret_status = SUCCESS;
	
	if((ret_status =  Data_ID_Devs_Src_Set(data_ids_dev_srcs, sizeof(data_ids_dev_srcs)/sizeof(data_id_dev_src_t))) != SUCCESS)
	{
		error_flag = ERR_DEV_SRC_ID_INVALID;
		return ret_status;
	}
    return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Data_ID_Devs_Src_Set

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.07 

Bugs           :   
-*------------------------------------------------------------*/
uint8_t Data_ID_Devs_Src_Set(const data_id_dev_src_t * const data_id_dev_src_conf_ptr, const uint8_t num_conf_size)
{
	const data_id_dev_src_t *cur_data_id_dev_src_conf_ptr = NULL_PTR;
	uint8_t data_id, ret_status = SUCCESS;
	
	if(data_id_dev_src_conf_ptr == NULL_PTR || num_conf_size <= 0)
	{
		error_flag = ERR_NULL_PTR;
		return error_flag;
	}
	for(data_id = 0; data_id < num_conf_size; ++data_id)
	{
		cur_data_id_dev_src_conf_ptr =  data_id_dev_src_conf_ptr + data_id;
		if((ret_status = Data_ID_Input_Src_Set(data_id, cur_data_id_dev_src_conf_ptr)) != SUCCESS)
		{
			break;
		}
		if((ret_status = Data_ID_Output_Src_Set(data_id, cur_data_id_dev_src_conf_ptr)) != SUCCESS)
		{
			break;
		}
	}
	if(ret_status != SUCCESS)
	{
     //	Reset_Data_IDs_Status();
	}
	return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Data_ID_Input_Src_Set

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.08 

Bugs           :   
-*------------------------------------------------------------*/
static uint8_t Data_ID_Input_Src_Set(const uint8_t data_id, const data_id_dev_src_t *const cur_data_id_dev_src_conf_ptr)
{
      uint8_t ret_status = SUCCESS, dev_src_index, dev_src_arr_index, dev_src_arr_bit, cur_dev_id, dev_ch_id;

      if(cur_data_id_dev_src_conf_ptr == NULL_PTR || data_id >= NUM_DATA_IDS)
	  {
		  error_flag = ERR_NULL_PTR;
		  return error_flag;
	  }	  
      dev_src_index = 0; 
		
		cur_dev_id = cur_data_id_dev_src_conf_ptr->data_input_dev_ids[dev_src_index].dev_id;
		while(cur_dev_id < NUM_INPUT_DEVS )
		{
			dev_src_arr_index = cur_dev_id / (INT_BIT_SIZE / (DEV_CH_ID_BIT_SIZE + 1));
			dev_src_arr_bit = ((((cur_dev_id * (DEV_CH_ID_BIT_SIZE + 1)) % INT_BIT_SIZE ) + 1) % INT_BIT_SIZE);
			dev_ch_id = cur_data_id_dev_src_conf_ptr->data_input_dev_ids[dev_src_index].dev_ch_id;
			switch(cur_dev_id)
			{
				case INPUT_DEV_ID_UART:
				  if(dev_ch_id >= NUM_INPUT_DEV_ID_UART_CHS)
				  {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;  
				case INPUT_DEV_ID_I2C:
				  if(dev_ch_id >= NUM_INPUT_DEV_ID_I2C_CHS)
				  {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case INPUT_DEV_ID_SPI:
				  if(dev_ch_id >= NUM_INPUT_DEV_ID_SPI_CHS)
				  {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case INPUT_DEV_ID_MISC:
				  if(dev_ch_id >= NUM_INPUT_DEV_ID_MISC_CHS)
				  {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case INPUT_DEV_ID_ADC:
				  if(dev_ch_id >= NUM_INPUT_DEV_ID_ADC_CHS)
				  {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case INPUT_DEV_ID_KEYBOARD:
				  if(dev_ch_id >= NUM_INPUT_DEV_ID_KEYBOARD_CHS)
				  {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case INPUT_DEV_ID_SW:
				  if(dev_ch_id >= NUM_INPUT_DEV_ID_SW_CHS)
				  {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				default:
				  error_flag = ERR_DATA_ID_CONF;
				  return error_flag;
			}
			dev_ch_id = (dev_ch_id << 1) | 0x01;			
			data_id_status_para[data_id].data_input_devs_conf[dev_src_arr_index] |= (dev_ch_id << dev_src_arr_bit);
		   	++dev_src_index;
		    cur_dev_id = cur_data_id_dev_src_conf_ptr->data_input_dev_ids[dev_src_index].dev_id;
		}
		return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Data_ID_Output_Src_Set

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.09 

Bugs           :   
-*------------------------------------------------------------*/
static uint8_t Data_ID_Output_Src_Set(const uint8_t data_id, const data_id_dev_src_t * const cur_data_id_dev_src_conf_ptr)
{
      uint8_t ret_status = SUCCESS, dev_src_index, dev_src_arr_index, dev_src_arr_bit, cur_dev_id, dev_ch_id;

      if(cur_data_id_dev_src_conf_ptr == NULL_PTR || data_id >= NUM_DATA_IDS)
	  {
		  error_flag = ERR_NULL_PTR;
		  return error_flag;
	  }	  
       dev_src_index = 0; 
		cur_dev_id = cur_data_id_dev_src_conf_ptr->data_output_dev_ids[dev_src_index].dev_id;
		while(cur_dev_id < NUM_OUTPUT_DEVS )
		{
			dev_src_arr_index = cur_dev_id / (INT_BIT_SIZE / (DEV_CH_ID_BIT_SIZE + 1));
			dev_src_arr_bit = ((((cur_dev_id * (DEV_CH_ID_BIT_SIZE + 1)) % INT_BIT_SIZE ) + 1) % INT_BIT_SIZE);
			dev_ch_id = cur_data_id_dev_src_conf_ptr->data_output_dev_ids[dev_src_index].dev_ch_id;
			switch(cur_dev_id)
			{
				case OUTPUT_DEV_ID_UART:
				   if(dev_ch_id >= NUM_OUTPUT_DEV_ID_UART_CHS)
				   {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break; 
				case OUTPUT_DEV_ID_I2C:
				if(dev_ch_id >= NUM_OUTPUT_DEV_ID_I2C_CHS)
				   {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break; 
				case OUTPUT_DEV_ID_SPI:
				if(dev_ch_id >= NUM_OUTPUT_DEV_ID_SPI_CHS)
				   {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case OUTPUT_DEV_ID_MISC:
				if(dev_ch_id >= NUM_OUTPUT_DEV_ID_MISC_CHS)
				   {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case OUTPUT_DEV_ID_DAC:
				if(dev_ch_id >= NUM_OUTPUT_DEV_ID_DAC_CHS)
				   {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case OUTPUT_DEV_ID_PWM:
				if(dev_ch_id >= NUM_OUTPUT_DEV_ID_PWM_CHS)
				   {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case OUTPUT_DEV_ID_LCD:
				if(dev_ch_id >= NUM_OUTPUT_DEV_ID_LCD_CHS)
				   {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				case OUTPUT_DEV_ID_SEG7:
				if(dev_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS)
				   {
					  error_flag = ERR_DEV_CH_ID_EXCEEDS;
					  return error_flag;
				  }
				break;
				default:
				  error_flag = ERR_DATA_ID_CONF;
				  return error_flag;
			}
			dev_ch_id = (dev_ch_id << 1) | 0x01;			
			data_id_status_para[data_id].data_output_devs_conf[dev_src_arr_index] |= (dev_ch_id << dev_src_arr_bit);
		   	++dev_src_index;
		    cur_dev_id = cur_data_id_dev_src_conf_ptr->data_output_dev_ids[dev_src_index].dev_id;
		}
       return ret_status;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Keyboard_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           :

Func ID        : 04.01  

BUGS           :     
-*------------------------------------------------------------*/
uint8_t Keyboard_Proc(const uint8_t keyboard_ch_id, uint8_t *const pressed_key)
{
	   data_id_status_para_t *cur_data_id_status_para_ptr = NULL_PTR;
	 //  keyboard_ctrl_t *cur_keyboard_ctrl_ptr = NULL_PTR;
     consucc_bit_t mask_dev_ch_id;
	   
	   uint8_t ret_status = SUCCESS, error_status_flag = STATE_NO, dev_src_arr_index, dev_src_arr_bit, dev_ch_id;
	 
	   if(keyboard_ch_id >= NUM_INPUT_DEV_ID_KEYBOARD_CHS || cur_data_id >= NUM_DATA_IDS)
		 {
			   error_flag = ERR_DEV_CH_ID_OR_DATA_ID_INVALID;
			   return error_flag;
		 }
		 dev_src_arr_index =  INPUT_DEV_ID_KEYBOARD/ (INT_BIT_SIZE / (DEV_CH_ID_BIT_SIZE + 1));
		 dev_src_arr_bit = ((((INPUT_DEV_ID_KEYBOARD * (DEV_CH_ID_BIT_SIZE + 1)) % INT_BIT_SIZE ) + 1) % INT_BIT_SIZE);
		 mask_dev_ch_id.bits_len = DEV_CH_ID_BIT_SIZE;
		 mask_dev_ch_id.consucc_val = 0;
		 mask_dev_ch_id.start_bit_pos = 0;
		 Config_Consucc_Bits(FLAG_CONSUCC_BITS_1, &mask_dev_ch_id);
		 cur_data_id_status_para_ptr = data_id_status_para + cur_data_id;
		 dev_ch_id = cur_data_id_status_para_ptr->data_input_devs_conf[dev_src_arr_index] >> (dev_src_arr_bit + 1) & mask_dev_ch_id.consucc_val;
		 if( Test_Bit_Is_Clear_in_Data(&cur_data_id_status_para_ptr->data_input_devs_conf[dev_src_arr_index], dev_src_arr_bit) || dev_ch_id != keyboard_ch_id) 
	   {  
          error_flag = ERR_DEV_CH_ID_NO_ACCESS;	
          return  error_flag;
	   } 
	   
	   //check for keyboard for keyboard_ch_id is enabled 
	   return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Seg7_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           :

Func ID        : 04.01  

BUGS           :     
-*------------------------------------------------------------*/
uint8_t Seg7_Proc(const uint8_t seg7_ch_id, const uint32_t  seg7_rcv_disp_num)
{
	   data_id_status_para_t *cur_data_id_status_para_ptr = NULL_PTR;
	   consucc_bit_t mask_dev_ch_id;
	 //	seg7_ctrl_t *cur_seg7_ctrl_ptr = NULL_PTR;   
	   uint8_t ret_status = SUCCESS, dev_src_arr_index, dev_src_arr_bit, dev_ch_id;
	 
	   if(seg7_ch_id >= NUM_OUTPUT_DEV_ID_SEG7_CHS || cur_data_id >= NUM_DATA_IDS)
		 {
			   error_flag = ERR_DEV_CH_ID_OR_DATA_ID_INVALID;
			   return error_flag;
		 }
		 dev_src_arr_index = OUTPUT_DEV_ID_SEG7 / (INT_BIT_SIZE / (DEV_CH_ID_BIT_SIZE + 1));
		 dev_src_arr_bit = (((( OUTPUT_DEV_ID_SEG7 * (DEV_CH_ID_BIT_SIZE + 1)) % INT_BIT_SIZE ) + 1) % INT_BIT_SIZE);
		 mask_dev_ch_id.bits_len = DEV_CH_ID_BIT_SIZE;
		 mask_dev_ch_id.consucc_val = 0;
		 mask_dev_ch_id.start_bit_pos = 0;
		 Config_Consucc_Bits(FLAG_CONSUCC_BITS_1, &mask_dev_ch_id);
		 cur_data_id_status_para_ptr = data_id_status_para + cur_data_id;
		 dev_ch_id = cur_data_id_status_para_ptr->data_output_devs_conf[dev_src_arr_index] >> (dev_src_arr_bit + 1) & mask_dev_ch_id.consucc_val;
		 if( Test_Bit_Is_Clear_in_Data(&cur_data_id_status_para_ptr->data_output_devs_conf[dev_src_arr_index], dev_src_arr_bit) || dev_ch_id != seg7_ch_id) 
	   {  
          error_flag = ERR_DEV_CH_ID_NO_ACCESS;	
          return  error_flag;
	   } 
	   
	   //check for seg7 for seg7_ch_id is enabled 
	   return SUCCESS;
}
