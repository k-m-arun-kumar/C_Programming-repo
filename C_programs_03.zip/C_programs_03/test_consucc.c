/* ********************************************************************
FILE                   : test_consucc.c

PROGRAM DESCRIPTION    : check a integer datas with selective consuccessive 0 bits or 1 bits 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include <stdio.h>

#define FLAG_CONSUCC_BITS_1         (1)
#define FLAG_CONSUCC_BITS_0         (2)
#define FLAG_CONSUCC_BITS_TOGGLE    (3)
#define TEST_OK_1_CONSUCC_BITS      (4)
#define TEST_FAIL_1_CONSUCC_BITS    (5)
#define TEST_OK_0_CONSUCC_BITS      (6)
#define TEST_FAIL_0_CONSUCC_BITS    (7)

#define SUCCESS            (0)
#define FAILURE            (1)

#define NULL_PTR            ((void *) 0)
#define INT_BIT_SIZE         (32) 
 
typedef unsigned int uint32_t;
typedef unsigned char uint8_t;

typedef enum 
{
	NO_ERROR, ERR_IO_CONFIG_NULL_PTR, ERR_CONFIG_PORT_NULL_PTR_OR_END_PIN_VAL, ERR_CONFIG_PORT_BIT_VAL, ERR_IO_CH_WRITE_DATA,
	ERR_IO_CONFIG_INDEX_INVALID, ERR_IO_CH_INVALID, ERR_CONFIG_IO_CH_MATCH_INVALID, ERR_GPIO_FUNC_SET,  ERR_IO_CH_00_FUNC_SET, 
	ERR_TRACE_FUNC_SET, ERR_IO_CH_48_FUNC_SET, ERR_IO_CH_58_FUNC_SET, ERR_PORT1_PIN_FUNC_SET, ERR_PORT_INVALID,
  ERR_CONFIG_PORT_INIT_VAL, ERR_IO_CH_GPIO_FUNC_SET, ERR_SW_CH_GPIO_FUNC_SET, ERR_GPIO_INPUT_FUNC_STATE, ERR_PIN_SIGNAL,
	ERR_PORT0_IO_PIN, ERR_PORT1_IO_PIN,  ERR_GPIO_CH_SET_PORT, ERR_IO_PIN_RANGE,  ERR_IO_CH_24_PIN, ERR_IO_CH_32_TO_47,
	ERR_CONF_INDEX_IO_CH_NULL_PTR, ERR_PORT_TO_IO_CONF_NULL_PTR, ERR_MAX_SW_CH_EXCEEDS, ERR_CONSUCC_PARA, ERR_STR_TO_NUM_PARA,
	ERR_STR_PTR_NULL, ERR_GPIO_OUTPUT_DATA, ERR_INVALID_PORT, ERR_IO_CH_READ_DATA, ERR_IO_CH_TO_SW_CH,
	ERR_IO_CH_RESERVE_PIN_FUNC_SET, ERR_GPIO_OUTPUT_FUNC_STATE, ERR_SW_CH_NOT_MATCH_IO_CH, ERR_CONFIG_PIN_RANGE, 
	ERR_CONFIG_DEBUG_FUNC_SET, ERR_CONFIG_TRACE_FUNC_SET, ERR_IO_CONFIG_TABLE_LARGE, NUM_SYS_ERR 
} system_error_flags_t;

 typedef enum
{
    PORT_CH_00, PORT_CH_01, NUM_PORT_CHS	
} port_ch_t;

typedef struct
{
	  uint8_t port;
	  uint8_t port_pin;
} io_port_t;

typedef enum 
{ 
  PIN_00, PIN_01, PIN_02, PIN_03, PIN_04, PIN_05, PIN_06, PIN_07, 
  PIN_08, PIN_09, PIN_10, PIN_11, PIN_12, PIN_13, PIN_14, PIN_15,
  PIN_16, PIN_17, PIN_18, PIN_19, PIN_20, PIN_21, PIN_22, PIN_23,
  PIN_24, PIN_25, PIN_26, PIN_27, PIN_28, PIN_29, PIN_30, PIN_31,
  NUM_PINS_PER_PORT   
} io_pin_t;

typedef enum 
{
  IO_CH_00, IO_CH_01, IO_CH_02, IO_CH_03, IO_CH_04, IO_CH_05, IO_CH_06, IO_CH_07, 
  IO_CH_08, IO_CH_09, IO_CH_10, IO_CH_11, IO_CH_12, IO_CH_13, IO_CH_14, IO_CH_15,
  IO_CH_16, IO_CH_17, IO_CH_18, IO_CH_19, IO_CH_20, IO_CH_21, IO_CH_22, IO_CH_23,
  IO_CH_24, IO_CH_25, IO_CH_26, IO_CH_27, IO_CH_28, IO_CH_29, IO_CH_30, IO_CH_31,
	IO_CH_48 = 48, IO_CH_49, IO_CH_50, IO_CH_51, IO_CH_52, IO_CH_53, IO_CH_54, IO_CH_55, 
  IO_CH_56, IO_CH_57, IO_CH_58, IO_CH_59, IO_CH_60, IO_CH_61, IO_CH_62, IO_CH_63, NUM_IO_CHS = 48
} io_ch_t; 


typedef struct 
{
	uint32_t consucc_val;
	uint8_t start_bit_pos;
	uint8_t bits_len;
} consucc_bit_t;

uint32_t error_flag = NO_ERROR;

uint8_t Test_Consucc_Bits( const uint8_t flag_consucc_bit, const void *const data_ptr);
int main()
{
	consucc_bit_t consucc_bit_data;
	uint32_t temp_data;
	uint8_t to_continue, config_consucc_bit_flag, ret_status ;
	
	do
	{
		printf("\n Enter start pos - ");
		scanf("%u", &temp_data);
		consucc_bit_data.start_bit_pos  =  temp_data;
		printf("\n Enter bits len - ");
		scanf("%u", &temp_data);
		consucc_bit_data.bits_len  =  temp_data;
		printf("\n Enter data - 0x");
		scanf("%x", &consucc_bit_data.consucc_val);
		printf("\n Enter MODE - 1: SET, 2:CLEAR -  ");
		scanf("%u", &temp_data);
		config_consucc_bit_flag = temp_data;
		ret_status = Test_Consucc_Bits(config_consucc_bit_flag, &consucc_bit_data );
		switch(ret_status)
		{
			case TEST_OK_1_CONSUCC_BITS:
			   printf("\n Pass of consucc 1 ");
			break;
			case TEST_OK_0_CONSUCC_BITS:
			    printf("\n Pass of consucc 0 ");
			break;
			case TEST_FAIL_1_CONSUCC_BITS:
			     printf("\n Fail of consucc 1 ");
			break;
			case TEST_FAIL_0_CONSUCC_BITS:
			    printf("\n Fail of consucc 0 ");
			break;
			default:
				printf("\n invalid flag");
			   break;	
		}
		printf("\n Start_bit_pos: %u, bits_len; %u, consucc_val: 0x%X", consucc_bit_data.start_bit_pos, consucc_bit_data.bits_len, consucc_bit_data.consucc_val );		
		printf("\n Do u want to continue: press Y or y - ");
		to_continue = getch();		
	} while(to_continue == 'Y' || to_continue == 'y');
    return 0;    
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Test_consucc_Bits

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.03 

BUGS           :
-*------------------------------------------------------------*/
uint8_t Test_Consucc_Bits( const uint8_t flag_consucc_bit, const void *const data_ptr)
{
	uint32_t from_bit0_consucc_bits = 0, mask_configured_bits ;
	consucc_bit_t *consucc_bit_ptr = (consucc_bit_t *)data_ptr;
	uint8_t i, ret_status = SUCCESS, end_bit_pos;	
	
	end_bit_pos = consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len - 1;
	if(consucc_bit_ptr == NULL_PTR || end_bit_pos >= INT_BIT_SIZE)
	{
		error_flag = ERR_CONSUCC_PARA;
		return error_flag;
	}
	for(i = 0; i < consucc_bit_ptr->bits_len; ++i)
	{
	  	from_bit0_consucc_bits |= 1 << i;			
	}
	switch(flag_consucc_bit)
	{
         case FLAG_CONSUCC_BITS_1:
					 mask_configured_bits = from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos;
		       if( mask_configured_bits == (consucc_bit_ptr->consucc_val & mask_configured_bits))
				   {
					    ret_status = TEST_OK_1_CONSUCC_BITS;
				   }
				   else
				   {
					    ret_status = TEST_FAIL_1_CONSUCC_BITS;
				   }
	     break;		
	     case FLAG_CONSUCC_BITS_0:
				  mask_configured_bits = ~(from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
			    if(mask_configured_bits == (consucc_bit_ptr->consucc_val | mask_configured_bits))
					{
					    ret_status = TEST_OK_0_CONSUCC_BITS;
				  }
				  else
				  {
					    ret_status = TEST_FAIL_0_CONSUCC_BITS;
				  }		     
	     break;
			 default:
			 error_flag = ERR_CONSUCC_PARA;
		      ret_status = error_flag;
	}
	return ret_status;
}
