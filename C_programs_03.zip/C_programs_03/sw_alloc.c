/* ********************************************************************
FILE                   : sw_alloc.c

PROGRAM DESCRIPTION    : 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include <stdio.h>
#include <stdlib.h>

#define FLAG_CONSUCC_BITS_1         (1)
#define FLAG_CONSUCC_BITS_0         (2)
#define FLAG_CONSUCC_BITS_TOGGLE    (3)
#define TEST_OK_1_CONSUCC_BITS      (4)
#define TEST_FAIL_1_CONSUCC_BITS    (5)
#define TEST_OK_0_CONSUCC_BITS      (6)
#define TEST_FAIL_0_CONSUCC_BITS    (7)

#define SUCCESS                                 (0)
#define FAILURE                                 (1)

 /* Bit Operation macros */
     /* Set bit pos  in byte data   */
#define Set_Bit_in_Data(data_ptr , bit_pos)                         ((*(data_ptr)) |=   (1<<(bit_pos)))     
      /* Clear bit pos in byte data */ 
#define Clear_Bit_in_Data(data_ptr ,bit_pos)                         ((*(data_ptr)) &= (~(1<<(bit_pos))))      
    /* flip bit pos in byte data  */ 
#define Toggle_Bit_in_Data(data_ptr , bit_pos)                       ((*(data_ptr)) ^=   (1<<(bit_pos)))        
    /* Test if bit pos in byte data  is set   */
#define Test_Bit_Is_Set_in_Data(data_ptr ,bit_pos)                    ((*(data_ptr)) & (1<<bit_pos))       
   /* Test if bit pos in byte data is clear */  
#define Test_Bit_Is_Clear_in_Data(data_ptr ,bit_pos)                  (!((*(data_ptr)) & (1<<bit_pos))) 

#define CH_ID_INVALID                      (17)
#define ERR_MAX_SW_CH_EXCEEDS              (10)
#define ERR_SW_CONFIG                      (11)
#define ERR_CONSUCC_PARA                   (12)
#define ERR_TEST_FAIL_1_CONSUCC_BITS       (13)
#define ERR_TEST_FAIL_0_CONSUCC_BITS       (14)
#define NULL_PTR                           ((void *) 0)
#define INT_BIT_SIZE                       (32)
#define NUM_INPUT_DEV_ID_SW_CHS           (16)

typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long uint64_t;

typedef char int8_t;
typedef short int int16_t;
typedef int int32_t;
typedef long int64_t;

typedef struct 
{
	uint32_t consucc_val;
	uint8_t start_bit_pos;
	uint8_t bits_len;
} consucc_bit_t;

uint8_t last_sw_ch_id = 0, error_flag = 0;
static uint16_t alloc_sw_ch_ids_bit_field = 0;

uint8_t SW_Ch_Config(const uint8_t port_pin_len);
uint8_t Check_Free_SW_Ch(const uint8_t port_pin_len, uint8_t *const alloc_start_sw_ch_id_ptr );
uint8_t SW_Ch_UnConfig(const uint8_t sw_ch_id, const uint8_t port_pin_len);
uint8_t Reset_SW_Ch(const uint8_t sw_ch_id);
uint8_t Config_Consucc_Bits( const uint8_t flag_consucc_bit, void *const data_ptr);
uint8_t Test_Consucc_Bits( const uint8_t flag_consucc_bit, const void *const data_ptr);

int main()
{
	unsigned int num_sw_ch, base_sw_ch_id, ret_status;
	char to_continue, mode;
	
	do
	{
		printf("\n Mode: Alloc - a or A; Free - f or F: Enter :");
		mode = getch();
		switch(mode)
		{
			case 'a':
			case 'A':
				printf("\n Enter alloc num sw ch: ");
				scanf("%u", &num_sw_ch);
			    if((ret_status = SW_Ch_Config(num_sw_ch)) != SUCCESS)
				{
				    printf("\n ERR: error_flag : %u", error_flag);	
				}
				printf("\n after alloc, alloc_sw_ch_ids_bit_field = 0x%X, last_sw_ch_id = 0x%X", alloc_sw_ch_ids_bit_field, last_sw_ch_id);				
			break;
			case 'f':
			case 'F':
				printf("\n Enter Base SW Ch : ");
				scanf("%u", &base_sw_ch_id);
				printf("\n Enter free num sw ch: ");
				scanf("%u", &num_sw_ch);
				if((ret_status = SW_Ch_UnConfig(base_sw_ch_id, num_sw_ch)) != SUCCESS)
				{
				    printf("\n ERR: error_flag : %u", error_flag);	
				}
				printf("\n after free,  alloc_sw_ch_ids_bit_field = 0x%X, last_sw_ch_id = 0x%X", alloc_sw_ch_ids_bit_field, last_sw_ch_id);
			break;
			default:		
			  printf("\n Invalid mode ");	
		}
	    printf("\n Do u want to continue: press Y or y - ");
		to_continue = getch();		
	} while(to_continue == 'Y' || to_continue == 'y');
	return 0;
}


/*------------------------------------------------------------*
FUNCTION NAME  : SW_Ch_Config

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.02  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t SW_Ch_Config(const uint8_t port_pin_len)
{
  consucc_bit_t check_free_sw_ch ;
	uint8_t alloc_start_sw_ch_id, i, ret_status;
	
	if(last_sw_ch_id + port_pin_len  > NUM_INPUT_DEV_ID_SW_CHS)
	{
		   error_flag = ERR_MAX_SW_CH_EXCEEDS;
		   return error_flag;
	}
	
    if((ret_status = Check_Free_SW_Ch(port_pin_len, &alloc_start_sw_ch_id)) != SUCCESS)
	{
		error_flag = ERR_SW_CONFIG;
		return error_flag; 
	}
    if(alloc_start_sw_ch_id == last_sw_ch_id)
	{
		last_sw_ch_id += port_pin_len;
	}

	check_free_sw_ch.start_bit_pos = alloc_start_sw_ch_id;
	check_free_sw_ch.bits_len = port_pin_len;
	check_free_sw_ch.consucc_val = alloc_sw_ch_ids_bit_field;
    if((ret_status = Config_Consucc_Bits(FLAG_CONSUCC_BITS_1, &check_free_sw_ch )) != SUCCESS)
	{
		error_flag = ERR_SW_CONFIG;
		return error_flag; 
	}
	alloc_sw_ch_ids_bit_field = check_free_sw_ch.consucc_val;
    return SUCCESS;
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Check_Free_SW_Ch

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.17 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Check_Free_SW_Ch(const uint8_t port_pin_len, uint8_t *const alloc_start_sw_ch_id_ptr )
{
	consucc_bit_t check_free_sw_ch ;
	uint8_t i, ret_status ;
	
	*alloc_start_sw_ch_id_ptr = CH_ID_INVALID;
	check_free_sw_ch.bits_len = port_pin_len;
	check_free_sw_ch.consucc_val = alloc_sw_ch_ids_bit_field;
	for(i = 0; i < sizeof(alloc_sw_ch_ids_bit_field) * 8; ++i)
	{
		if(Test_Bit_Is_Clear_in_Data( &alloc_sw_ch_ids_bit_field, i) )
		{
			check_free_sw_ch.start_bit_pos = i; 
			ret_status = Test_Consucc_Bits(FLAG_CONSUCC_BITS_0, &check_free_sw_ch);
			if(ret_status == TEST_OK_0_CONSUCC_BITS)
			{
				*alloc_start_sw_ch_id_ptr = i;
				break;				
			}
			else
			{
				continue;
			}
		}
	}
	if(*alloc_start_sw_ch_id_ptr == CH_ID_INVALID)
	{
		error_flag = ERR_SW_CONFIG;
		return error_flag; 
	}
	
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : SW_Ch_UnConfig

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.09  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t SW_Ch_UnConfig(const uint8_t sw_ch_id, const uint8_t port_pin_len)
{
	int16_t i = 0;
	uint8_t  ret_status;	
		
	for(i = port_pin_len - 1; i >=0 ; --i)
	{		
	    Reset_SW_Ch(sw_ch_id + i);		
	}  	
	return SUCCESS;
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_SW_Ch

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 07.03  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t Reset_SW_Ch(const uint8_t sw_ch_id)
{
	 if(sw_ch_id >= last_sw_ch_id) 
	 {
		   error_flag = ERR_MAX_SW_CH_EXCEEDS;
		   return error_flag;
	 }		 
    Clear_Bit_in_Data(&alloc_sw_ch_ids_bit_field, sw_ch_id); 
   if(sw_ch_id == last_sw_ch_id - 1)
   {
	  --last_sw_ch_id;
   }
   return SUCCESS;
}
/*------------------------------------------------------------*-
FUNCTION NAME  : Config_Consucc_Bits

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.02 

BUGS           :
-*------------------------------------------------------------*/
uint8_t Config_Consucc_Bits( const uint8_t flag_consucc_bit, void *const data_ptr)
{
	uint32_t from_bit0_consucc_bits = 0;	
	consucc_bit_t *consucc_bit_ptr = (consucc_bit_t *)data_ptr;
	uint8_t i, ret_status = SUCCESS, end_bit_pos;     
	
	end_bit_pos = consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len - 1;
	if(consucc_bit_ptr == NULL_PTR || end_bit_pos >= INT_BIT_SIZE)
	{
		error_flag = ERR_CONSUCC_PARA;
		return  error_flag;
	}
	for(i = 0; i < consucc_bit_ptr->bits_len; ++i)
	{
	  	from_bit0_consucc_bits |= 1 << i;			
	}
	switch(flag_consucc_bit)
	{
         case FLAG_CONSUCC_BITS_1:
		    consucc_bit_ptr->consucc_val |=  (from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
	     break;		
	     case FLAG_CONSUCC_BITS_0:
		    consucc_bit_ptr->consucc_val &= ~(from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
	     break;
		 case FLAG_CONSUCC_BITS_TOGGLE:
		    consucc_bit_ptr->consucc_val ^= (from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
		 break;
		 default:
		    error_flag = ERR_CONSUCC_PARA;
		    ret_status = error_flag;
	}
	return ret_status;
}

/*------------------------------------------------------------*-
FUNCTION NAME  : Test_consucc_Bits

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.03 

BUGS           :
-*------------------------------------------------------------*/
uint8_t Test_Consucc_Bits( const uint8_t flag_consucc_bit, const void *const data_ptr)
{
	uint32_t from_bit0_consucc_bits = 0, mask_configured_bits ;
	consucc_bit_t *consucc_bit_ptr = (consucc_bit_t *)data_ptr;
	uint8_t i, ret_status = SUCCESS, end_bit_pos;	
	
	end_bit_pos = consucc_bit_ptr->start_bit_pos + consucc_bit_ptr->bits_len - 1;
	if(consucc_bit_ptr == NULL_PTR || end_bit_pos >= INT_BIT_SIZE)
	{
		error_flag = ERR_CONSUCC_PARA;
		return error_flag;
	}
	for(i = 0; i < consucc_bit_ptr->bits_len; ++i)
	{
	  	from_bit0_consucc_bits |= 1 << i;			
	}
	switch(flag_consucc_bit)
	{
         case FLAG_CONSUCC_BITS_1:
					 mask_configured_bits = from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos;
		       if( mask_configured_bits == (consucc_bit_ptr->consucc_val & mask_configured_bits))
				   {
					    ret_status = TEST_OK_1_CONSUCC_BITS;
				   }
				   else
				   {
					   error_flag = ERR_TEST_FAIL_1_CONSUCC_BITS;
					    ret_status = TEST_FAIL_1_CONSUCC_BITS;
				   }
	     break;		
	     case FLAG_CONSUCC_BITS_0:
				  mask_configured_bits = ~(from_bit0_consucc_bits << consucc_bit_ptr->start_bit_pos);
			    if(mask_configured_bits == (consucc_bit_ptr->consucc_val | mask_configured_bits))
					{
					    ret_status = TEST_OK_0_CONSUCC_BITS;
				  }
				  else
				  {
					    error_flag = ERR_TEST_FAIL_0_CONSUCC_BITS;
					    ret_status = TEST_FAIL_0_CONSUCC_BITS;
				  }		     
	     break;
			 default:
			 error_flag = ERR_CONSUCC_PARA;
		      ret_status = error_flag;
	}
	return ret_status;
}
