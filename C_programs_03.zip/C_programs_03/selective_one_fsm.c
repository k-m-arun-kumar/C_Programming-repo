/* ********************************************************************
FILE                   : selective_one_fsm.c

PROGRAM DESCRIPTION    : elevator control is based on two basic principles.
  1: Continue to travel in the current elevator movement direction(up or down) while there are still remaining requests in that same elevator movement direction.
  2: If there are no further requests in that direction, then stop and become idle, or change direction if there are requests in the opposite direction.
  elevator's in cabin floor call for each floor and only one hall floor call for each floor are considered. 
  So when either in cabin floor call or hall floor call is active, then floor call for that floor is active.
  We simulate, floor call as request for that floor and implemented elevator control principles 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include <stdio.h>
#define SUCCESS         (0) 
#define FAILURE         (1)

typedef enum 
{
	NO_ERROR, ERR_NULL_PTR,ERR_FORMAT_INVALID , ERR_QUEUE_FULL, ERR_QUEUE_EMPTY, ERR_ENQUEUE_PROC, ERR_DEQUEUE_PROC, ERR_QUEUE_INSERT_FRONT_PROC, ERR_QUEUE_DELETE_REAR_PROC,
	ERR_QUEUE_RETRIEVE_INFO_PROC, ERR_DISP_QUEUE_PROC, ERR_INSERT_DATA_PROC, ERR_RETRIEVE_DATA_PROC, NUM_SYS_STATUS
} system_status_t;

typedef enum
{
	 ERR_UART_NOT_DATA_SRC = NUM_SYS_STATUS, ERR_FLOOR_INVALID, ERR_ELEVATOR_CH_ID_EXCEEDS, ERR_ELEVATOR_DISP_STATUS, ERR_ELEVATOR_FSM_PROC, ERR_ELEVATOR_FSM_INVALID,
	 ERR_ELEVATOR_PREVIOUS_FSM_INVALID, ERR_ELEVATOR_DISP_PROC, ERR_ELEVATOR_CUR_FSM_INVALID, ERR_CAR_MOVE_STATE_PROC, ERR_DELAY_TIME_ELEVATOR_PROC, 
	 ERR_REQ_CONDITION_PROC, ERR_POLL_FLOOR_CALLS_PROC, ERR_CAR_UNMOVED, ERR_NEXT_FLOOR_INVALID, ERR_NEXT_STOP_FLOOR_PROC, ERR_STOP_NOT_CUR_FLOOR, ERR_FLOOR_CALLS_NOT_ALLOWED,
	 WARN_HALL_FLOOR_CALL_IS_ACTIVE, WARN_IN_CAR_FLOOR_CALL_IS_ACTIVE, NUM_APPL_STATUS
} appl_status_t;

typedef enum 
{
	MOVE_UP, MOVE_DOWN, STARTUP_STATIONARY, MOVED_UP_STATIONARY, MOVED_DOWN_STATIONARY, STARTUP_MOVE_UP, STARTUP_MOVE_DOWN, NO_PENDING_FLOOR_CALLS, 
	TRIGGER_MOVE_UP_NO_DIR_CHANGE, TRIGGER_MOVE_UP_DIR_CHANGE, TRIGGER_MOVE_DOWN_NO_DIR_CHANGE, TRIGGER_MOVE_DOWN_DIR_CHANGE, 
	TRIGGERED_EMERGENCY_STOP, ERR_MOVE_UP_NEXT_FLOOR_INVALID, ONE_PENDING_FLOOR_CALL, ERR_MOVE_DOWN_NEXT_FLOOR_INVALID, ERR_DOOR_OPEN_NOT_DETECT, 
	ERR_DOOR_CLOSE_NOT_DETECT, ERR_REQ_DOORS_ALIGN_BUT_UNALIGN, ERR_AT_LEAST_TWO_LIMIT_SW_DETECT, ERR_STARTUP_AT_LEAST_TWO_LIMIT_SW_DETECT, 
	ERR_MOVING_UP_NEXT_FLOOR_NOT_DETECT, ERR_MOVING_DOWN_NEXT_FLOOR_NOT_DETECT, ERR_DOORS_NOT_ALIGNED_PROPERLY, ERR_REQ_DOOR_CLOSE_BUT_OPENED, 
	ERR_REQ_DOOR_OPEN_BUT_CLOSED, ERR_MOVE_UP_BUT_UNMOVED, ERR_MOVE_DOWN_BUT_UNMOVED, ERR_STARTUP_CUR_FLOOR_NOT_DETECT, ERR_DOOR_OPEN_AND_CLOSE_ACTIVE_FOR_OPEN, 
	ERR_DOOR_OPEN_AND_CLOSE_ACTIVE_FOR_CLOSE, ERR_DOOR_OPEN_FAST, ERR_DOOR_CLOSE_FAST, ERR_REQ_DOOR_CLOSED_BUT_NOT_CLOSED, ERR_REQ_DOORS_UNALIGN_BUT_ALIGN, 
	ERR_DOOR_OPENED_BUT_READY_MOVE, ERR_DOOR_NOT_CLOSED_BUT_READY_MOVE, ERR_STARTUP_DOOR_OPEN_AND_CLOSE_ACTIVE, ERR_DOORS_UNALIGNED_BUT_OPENED,
	ERR_DOORS_UNALIGNED_BUT_NOT_CLOSED, ERR_DOORS_ALIGNED_FOR_MOVE, ERR_DOORS_UNALIGNED_AT_STATIONARY, ERR_DOOR_NOT_OPENED_AT_STATIONARY,
	ERR_DOORS_CLOSED_AT_STATIONARY, ERR_LIMIT_FLOOR_NOT_DETECT_AT_STATIONARY, ERR_OVERLOAD_BUT_NO_IN_CAR_USER_PRESENT, 
	ERR_NEXT_STOP_FLOOR_REACH_BUT_NOT_IN_STOP_LIST, ERR_MAX_STOP_FLOOR_REACH_BUT_NOT_IN_STOP_LIST, ERR_MIN_STOP_FLOOR_REACH_BUT_NOT_IN_STOP_LIST,
	ERR_NEXT_STOP_MORE_THAN_MAX_STOP_FLOOR, ERR_NEXT_STOP_LESS_THAN_MIN_STOP_FLOOR, ERR_COMPUTE_NEXT_FLOOR_STOP_PROC, ERR_ELEVATOR_NOT_STATIONARY, 
	ERR_MIN_STOP_FLOOR_INVALID, ERR_MIN_STOP_FLOOR_NOT_IN_STOP_LIST, ERR_MAX_STOP_FLOOR_INVALID, WARN_FLOOR_CALL_ALREADY_SELECT, WARN_FLOOR_CALL_SAME_CUR_FLOOR,
	ERR_COMPUTE_NEXT_STOP_FLOOR, ERR_NEXT_STOP_FLOOR_NOT_STOPPED, ERR_INTERNAL_PROC_ABNORMAL, ERR_CUR_FLOOR_INVALID, ERR_POLL_HALL_AND_IN_CAR_PROC, 
	ERR_DELAY_TIME_PROC, ERR_CAR_MOVEMENT_PROC, ERR_DISP_STATUS, NUM_ELEVATOR_STATUS
} elevator_status_t;

typedef enum
{
	FSM_IDLE, FSM_WAIT_FOR_START_OPER, FSM_STARTUP, FSM_DECIDE_CAR_MOVEMENT, FSM_TRIGGER_MOVE_UP, FSM_TRIGGER_MOVE_DOWN, 
	FSM_PREPARE_TO_MOVE, FSM_MOVING, FSM_TRIGGER_CAR_STOP, FSM_WAIT_TILL_CAR_STOPPED, FSM_PREPARE_DOORS_TO_ALIGN, 
	FSM_WAIT_TILL_DOORS_ALIGN, FSM_TRIGGER_DOOR_OPEN, FSM_WAIT_TILL_DOOR_START_OPEN, FSM_WAIT_TILL_DOOR_OPENED, 
	FSM_PREPARE_USER_ENTRY_AND_EXIT, FSM_USER_ENTRY_AND_EXIT, FSM_PREPARE_FOR_DOOR_CLOSE, FSM_TRIGGER_DOOR_CLOSE, 
	FSM_WAIT_TILL_DOOR_START_CLOSE, FSM_WAIT_TILL_DOOR_CLOSED, FSM_WAIT_TILL_DOORS_TO_UNALIGN, FSM_COMPUTE_NEXT_STOP_FLOOR, 
	FSM_ABNORMAL_EVENT, NUM_ELEVATOR_FSM_STATES  	
} elevator_oper_fsm_states_t;


#define ERROR_OCCURED    (1)
#define WARNING_OCCURED  (2) 
#define NULL_PTR                          ((void *) 0)
#define DATA_NA                           (0)

typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long uint64_t;

typedef char int8_t;
typedef short int int16_t;
typedef int int32_t;
typedef long int64_t;

uint32_t system_status_flag = NO_ERROR;
uint32_t appl_status_flag = NO_ERROR;

typedef enum
{
	RESET_WHOLE, RESET_DATA_IDS_AND_APPL, RESET_APPL
} reset_status_t;

uint8_t Error_or_Warning_Proc(const char *const error_trace_str, const uint8_t warn_or_error_format, const uint32_t warning_or_error_code);
uint16_t Appl_Reset(const uint8_t reset_type);
uint16_t Appl_Reset_Proc(const uint8_t cur_ctrl_elevator_ch_id);
uint16_t Validate_Floor(const uint8_t floor);
uint16_t Compute_Next_Floor_Stop(const uint8_t cur_ctrl_elevator_ch_id, uint8_t *const elevator_next_fsm_state_ptr);
uint16_t FSM_StartUp_Proc(const uint8_t ctrl_elevator_ch_id);
uint16_t FSM_Decide_Car_Move_Proc(const uint8_t ctrl_elevator_ch_id);
uint16_t FSM_Car_Moving_Proc(const uint8_t ctrl_elevator_ch_id);
uint16_t FSM_User_Entry_And_Exit_Proc(const uint8_t ctrl_elevator_ch_id);
uint16_t FSM_Compute_Next_Stop_Floor_Proc(const uint8_t ctrl_elevator_ch_id);
uint16_t FSM_Abnormal_Event_Proc(const uint8_t ctrl_elevator_ch_id);
uint16_t Active_Hall_And_In_Car_Calls_Proc(const uint8_t ctrl_elevator_ch_id);
uint16_t Disp_Oper_Proc(const uint8_t ctrl_elevator_ch_id);
uint16_t Car_Movement_Direction(const uint8_t ctrl_elevator_ch_id, const uint8_t cur_floor, uint8_t *const elevator_trigger_move_ptr);
uint16_t Compute_Floor_Stop_Datas(const uint8_t ctrl_elevator_ch_id, const uint8_t stage_type, uint8_t *const elevator_status_ptr);
uint16_t Reset_Elevator_Datas(const uint8_t cur_ctrl_elevator_ch_id, const uint8_t reset_type);
	
#define DEFAULT_FLOOR           (0)
#define DEFAULT_MAX_NUM_FLOORS  (5)
#define MIN_NUM_FLOORS          (3)
#define MAX_NUM_FLOORS         (32)
#define MAX_NUM_ELEVATORS       (1)
#define CTRL_ELEVATOR_CH_ID     (0)

//#define TRACE                                 (1U)
#define TRACE_ERROR                             (2U)
#define TRACE_REQ                               (3U)
#define TRACE_INFO                              (4U)
//#define TRACE_DATA                            (5U)
#define TRACE_FLOW                            (6U)

typedef enum 
{ 
  DOOR_CLOSED_STAGE, DOOR_OPENED_STAGE, NUM_ELEVATOR_STAGES 
} elevator_stages_t;

typedef enum 
{
	FLOOR_00, FLOOR_01, FLOOR_02, FLOOR_03, FLOOR_04
} floor_id_t;

typedef struct
{   
   uint8_t cur_fsm_state;
   uint8_t before_fsm_state;
   uint8_t elevator_status;
   uint8_t cur_floor;
   uint8_t next_stop_floor;
   uint8_t pending_floor_calls_bit_field;
   uint8_t num_pending_floor_calls;
   uint8_t cur_max_floor_call;
   uint8_t cur_min_floor_call;
   uint8_t pending_in_car_floor_calls_bit_field;
   uint8_t cur_min_floor_call_in_car;
   uint8_t cur_max_floor_call_in_car;
   uint8_t num_pending_floor_calls_in_car;
   uint8_t pending_hall_floor_calls_bit_field;
   uint8_t cur_min_floor_call_hall;
   uint8_t cur_max_floor_call_hall;
   uint8_t num_pending_floor_calls_hall;
} elevator_ctrl_and_status_t;

elevator_ctrl_and_status_t elevator_ctrl_and_status[MAX_NUM_ELEVATORS];

typedef enum
{
	RESET_STOP_DATAS, RESET_WHOLE_DATAS
} elevator_reset_type_t;

typedef enum
{
	FSM_OPER = 1, FLOOR_CALL_OPER, DISP_OPER, RESET_OPER, EXIT_OPER, IN_CAR_FLOOR_CALL_OPER = 1, HALL_FLOOR_CALL_OPER = 2
} choice_oper_t;

uint32_t uint32_temp_disp_data = 0;
uint32_t max_num_floors = DEFAULT_MAX_NUM_FLOORS;

/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.13  

BUGS           :              
-*------------------------------------------------------------*/
int main()
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	int32_t choice;
	
	cur_elevator_ptr = elevator_ctrl_and_status + CTRL_ELEVATOR_CH_ID;	
	if((ret_status = Appl_Reset(RESET_APPL)) != SUCCESS)
	{
       return FAILURE;
	}		
	while(1)
	{
		printf("\n 1 - FSM , 2 - floor call, 3 - Disp,  4 - reset, 5 - exit ");
		printf("\n Enter choice : ");
		scanf("%d", &choice);
		switch(choice)
		{
			case FSM_OPER:
				
		        switch(cur_elevator_ptr->cur_fsm_state)
		        {
		           case FSM_STARTUP:			
			         FSM_StartUp_Proc(CTRL_ELEVATOR_CH_ID);
                   break;
                   case FSM_DECIDE_CAR_MOVEMENT:			 
			          FSM_Decide_Car_Move_Proc(CTRL_ELEVATOR_CH_ID);
                   break;
			       case FSM_MOVING:
			          FSM_Car_Moving_Proc(CTRL_ELEVATOR_CH_ID);				      
                   break;
			       case FSM_USER_ENTRY_AND_EXIT:
			          FSM_User_Entry_And_Exit_Proc(CTRL_ELEVATOR_CH_ID);				      
			       break;
			       case FSM_COMPUTE_NEXT_STOP_FLOOR:
			          FSM_Compute_Next_Stop_Floor_Proc(CTRL_ELEVATOR_CH_ID);
                   break;
			       case FSM_ABNORMAL_EVENT:
                       FSM_Abnormal_Event_Proc(CTRL_ELEVATOR_CH_ID);			       
			       break;	
		        }			 
            break;  
			case FLOOR_CALL_OPER:
			    Active_Hall_And_In_Car_Calls_Proc(CTRL_ELEVATOR_CH_ID);  
			break;
			case DISP_OPER:
			   Disp_Oper_Proc(CTRL_ELEVATOR_CH_ID);
			break;
			case RESET_OPER:
			  Appl_Reset(RESET_APPL);
			break;
			case EXIT_OPER:
			  return SUCCESS;
			//break;
			default:
			  printf("Invalid oper\n");
		}
	}
    return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_StartUp_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.03  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_StartUp_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	int32_t cur_floor;
	
	cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	printf("\n Enter car startup floor : ");
	scanf("%d", &cur_floor);
	printf("\n");
	if((ret_status = Validate_Floor(cur_floor)) != SUCCESS)
	{
	   Error_or_Warning_Proc("14.04.02", ERROR_OCCURED, appl_status_flag);
	   return FAILURE;		  
	}
	cur_elevator_ptr->cur_floor = cur_floor;
	#ifdef TRACE_FLOW
	   printf("STARTUP -> USER_ENTRY_AND_EXIT \n");
	#endif
	cur_elevator_ptr->cur_fsm_state = FSM_USER_ENTRY_AND_EXIT;
    cur_elevator_ptr->elevator_status = STARTUP_STATIONARY; 
	return SUCCESS;
}      

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_Decide_Car_Move_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.04 

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Decide_Car_Move_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;	
	uint16_t ret_status;
	uint8_t car_movement_state;
	
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.04.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	if((ret_status = Car_Movement_Direction(ctrl_elevator_ch_id, cur_elevator_ptr->cur_floor, &car_movement_state)) != SUCCESS)
	{
	    appl_status_flag = ERR_CAR_MOVE_STATE_PROC;
	    Error_or_Warning_Proc("14.04.03", ERROR_OCCURED, appl_status_flag);
	    #ifdef TRACE_ERROR 
	       printf("DECIDE_CAR_MOVEMENT -> ABNORMAL_EVENT \n");
		   printf("ERR: event - Car movement proc \n");
	    #endif
		cur_elevator_ptr->elevator_status = ERR_CAR_MOVEMENT_PROC;
	    cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		return SUCCESS;	 
	}
	switch(car_movement_state)
	{
		   case STARTUP_STATIONARY:
		       #ifdef TRACE_FLOW
	              printf("DECIDE_CAR_MOVEMENT -> USER_ENTRY_AND_EXIT \n");	                  
	           #endif			   
			   cur_elevator_ptr->cur_fsm_state =  FSM_USER_ENTRY_AND_EXIT;			 
		   break;
		   case MOVED_DOWN_STATIONARY:
		   case MOVED_UP_STATIONARY:
		       #ifdef TRACE_FLOW
	              printf("DECIDE_CAR_MOVEMENT -> USER_ENTRY_AND_EXIT \n");	                  
	           #endif
		       cur_elevator_ptr->cur_fsm_state = FSM_USER_ENTRY_AND_EXIT ;			  
		   break;
           case MOVE_UP:
		       #ifdef TRACE_FLOW
	              printf("DECIDE_CAR_MOVEMENT -> MOVING, dir up, stop_floor : %u \n", cur_elevator_ptr->next_stop_floor);	                  
	           #endif 
               cur_elevator_ptr->cur_fsm_state =  FSM_MOVING;			  
           break;
           case MOVE_DOWN:
		       #ifdef TRACE_FLOW
	              printf("DECIDE_CAR_MOVEMENT -> MOVING, dir down, stop_floor: %u \n", cur_elevator_ptr->next_stop_floor);	                  
	           #endif 
               cur_elevator_ptr->cur_fsm_state =  FSM_MOVING;			  
           break;
		   default:
              appl_status_flag = ERR_FORMAT_INVALID;
	          Error_or_Warning_Proc("14.04.04", ERROR_OCCURED, appl_status_flag);
	          return appl_status_flag;	
	 }
	 cur_elevator_ptr->elevator_status = car_movement_state;	
     return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_Car_Moving_Proc 

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.08 

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Car_Moving_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	uint8_t limit_sw_cur_floor, limit_sw_min_floor, limit_sw_max_floor, cur_floor, car_movement_state;
  
	 if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.08.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
    printf("\n Enter cur floor : ");
	scanf("%u", &cur_floor);
	if((ret_status = Car_Movement_Direction(ctrl_elevator_ch_id, cur_floor, &car_movement_state)) != SUCCESS)
	{
		 appl_status_flag = ERR_CAR_MOVE_STATE_PROC;
	     Error_or_Warning_Proc("14.08.11", ERROR_OCCURED, appl_status_flag);
	     printf("ERR: event - car movement proc invalid \n");	        
		 return FAILURE;   	 
	}
	switch(car_movement_state)
	{
			   case MOVE_UP:			     
			   case MOVED_UP_STATIONARY:
                 if(cur_elevator_ptr->cur_floor + 1 == cur_floor)
				 {
					 cur_elevator_ptr->cur_floor = cur_floor;
                     switch(car_movement_state)
					 {
                         case MOVED_UP_STATIONARY:
						   #ifdef TRACE_FLOW
	                           printf("MOVING -> USER_ENTRY_AND_EXIT \n");	                  
	                       #endif
						    cur_elevator_ptr->elevator_status = MOVED_UP_STATIONARY;
		                   cur_elevator_ptr->cur_fsm_state =  FSM_USER_ENTRY_AND_EXIT;			               					  
						 break;
						 case MOVE_UP:						   
						    #ifdef TRACE_INFO
							   uint32_temp_disp_data = cur_elevator_ptr->cur_floor;
	                           printf("TRA: Moving Up non stop - cur_floor: %u, stop_floor: %u \n", uint32_temp_disp_data, cur_elevator_ptr->next_stop_floor);              
	                        #endif
						 break;
					 }						 
			     }
				 else
				 {
					 #ifdef TRACE_ERROR
	                     printf("MOVING -> ABNORMAL_EVENT \n");	                    
	                 #endif					 
					 if(cur_elevator_ptr->cur_floor == cur_floor)
					 {
						#ifdef TRACE_ERROR
						   printf("ERR: event - move up but stationary \n");  
                        #endif  
                        cur_elevator_ptr->elevator_status = ERR_MOVE_UP_BUT_UNMOVED; 
						appl_status_flag = ERR_CAR_UNMOVED;
					    Error_or_Warning_Proc("14.08.02", ERROR_OCCURED, appl_status_flag);                         						
					 }
					 else
					 {
						 #ifdef TRACE_ERROR
						    printf("ERR: Event - move up next floor invalid \n");
						 #endif 
						 cur_elevator_ptr->elevator_status = ERR_MOVE_UP_NEXT_FLOOR_INVALID;
						 appl_status_flag = ERR_NEXT_FLOOR_INVALID;
					    Error_or_Warning_Proc("14.08.03", ERROR_OCCURED, appl_status_flag);  	
					 }					 
				     cur_elevator_ptr->cur_fsm_state =  FSM_ABNORMAL_EVENT; 
					 return FAILURE;
				 }
               break;
               case MOVE_DOWN:			     
			   case MOVED_DOWN_STATIONARY:
                 if(cur_elevator_ptr->cur_floor - 1 == cur_floor)
				 {
					  cur_elevator_ptr->cur_floor = cur_floor;
					  switch(car_movement_state)
					  {
                         case MOVED_DOWN_STATIONARY:
						   #ifdef TRACE_FLOW
	                           printf("MOVING -> USER_ENTRY_AND_EXIT \n");	                  
	                       #endif
						    cur_elevator_ptr->elevator_status = MOVED_DOWN_STATIONARY;
		                   cur_elevator_ptr->cur_fsm_state = FSM_USER_ENTRY_AND_EXIT;			               					   
						 break;
						 case MOVE_DOWN: 		 
						    #ifdef TRACE_INFO
							   uint32_temp_disp_data = cur_elevator_ptr->cur_floor;
	                           printf("TRA: Moving Down non stop - cur_floor: %u, stop_floor: %u\n", uint32_temp_disp_data, cur_elevator_ptr->next_stop_floor);              
	                       #endif
						 break;
					  }		
				 }
				 else
				 {					 
					 #ifdef TRACE_ERROR
	                     printf("MOVING -> ABNORMAL_EVENT \n");	                    
	                 #endif					 
					 if(cur_elevator_ptr->cur_floor == cur_floor)
					 {
						#ifdef TRACE_ERROR
						   printf("ERR: event - move down but stationary\n");  
                        #endif  
                        cur_elevator_ptr->elevator_status = ERR_MOVE_DOWN_BUT_UNMOVED; 
                        appl_status_flag = ERR_CAR_UNMOVED;
					    Error_or_Warning_Proc("14.08.04", ERROR_OCCURED, appl_status_flag);  	  						
					 }
					 else
					 {
						 #ifdef TRACE_ERROR
						    printf("ERR: Event - move down next floor invalid \n");
						 #endif 
						 cur_elevator_ptr->elevator_status = ERR_MOVE_DOWN_NEXT_FLOOR_INVALID;
						 appl_status_flag = ERR_NEXT_FLOOR_INVALID;
					     Error_or_Warning_Proc("14.08.05", ERROR_OCCURED, appl_status_flag);  
					 }
				      cur_elevator_ptr->cur_fsm_state =  FSM_ABNORMAL_EVENT;
                      return FAILURE;					  
				 }	
               break;
			   default:
                  appl_status_flag = ERR_FORMAT_INVALID;
	              Error_or_Warning_Proc("14.08.14", ERROR_OCCURED, appl_status_flag);
	              return FAILURE;	
		}
       		
	return SUCCESS;
}
 
 /*------------------------------------------------------------*
FUNCTION NAME  :  FSM_User_Entry_And_Exit_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.17

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_User_Entry_And_Exit_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	uint8_t elevator_status;
	static uint8_t loop_flag = 0;
	
	 if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.17.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	if(((loop_flag & (1 << 3)) == 0))
	{
		if(cur_elevator_ptr->before_fsm_state == FSM_PREPARE_USER_ENTRY_AND_EXIT  )
	    {
			if(cur_elevator_ptr->next_stop_floor != cur_elevator_ptr->cur_floor)
	        {
	  	       appl_status_flag = ERR_STOP_NOT_CUR_FLOOR;
	           Error_or_Warning_Proc("14.17.02", ERROR_OCCURED, appl_status_flag);
		       #ifdef TRACE_ERROR
		        	printf("USER_ENTRY_AND_EXIT -> ABNORMAL_EVENT \n"); 
		            printf("ERR: event - next stop floor != cur_floor\n");
		       #endif
		       cur_elevator_ptr->elevator_status = ERR_NEXT_STOP_FLOOR_NOT_STOPPED;
		       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
              return SUCCESS;	
	        }
			if((cur_elevator_ptr->pending_floor_calls_bit_field & (1 << cur_elevator_ptr->cur_floor)) == 0)
			{
		       appl_status_flag = ERR_NEXT_STOP_FLOOR_PROC;
		       Error_or_Warning_Proc("14.17.03", ERROR_OCCURED, appl_status_flag);  
		       #ifdef TRACE_ERROR
		        	printf("USER_ENTRY_AND_EXIT -> ABNORMAL_EVENT \n"); 
			        printf("ERR: event - next stop floor but not stop list\n");
			   #endif
			   cur_elevator_ptr->elevator_status = ERR_NEXT_STOP_FLOOR_REACH_BUT_NOT_IN_STOP_LIST;
			   cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
               return FAILURE;	
			}
            if((cur_elevator_ptr->pending_in_car_floor_calls_bit_field & (1 << cur_elevator_ptr->cur_floor)))
	        {
		    	cur_elevator_ptr->pending_in_car_floor_calls_bit_field &= ~(1 << cur_elevator_ptr->cur_floor);
		        --cur_elevator_ptr->num_pending_floor_calls_in_car;
		       if(cur_elevator_ptr->num_pending_floor_calls_in_car == 0 && cur_elevator_ptr->pending_in_car_floor_calls_bit_field == 0)
		       {
		           cur_elevator_ptr->cur_min_floor_call_in_car = max_num_floors + 1;
	                cur_elevator_ptr->cur_max_floor_call_in_car = max_num_floors + 1;
		       }
	        }
	        if((cur_elevator_ptr->pending_hall_floor_calls_bit_field & (1 << cur_elevator_ptr->cur_floor)))
	        {
		       cur_elevator_ptr->pending_hall_floor_calls_bit_field &= ~(1 << cur_elevator_ptr->cur_floor);
		       --cur_elevator_ptr->num_pending_floor_calls_hall;
		      if(cur_elevator_ptr->num_pending_floor_calls_hall == 0 && cur_elevator_ptr->pending_hall_floor_calls_bit_field == 0)
		      {
		         cur_elevator_ptr->cur_min_floor_call_hall = max_num_floors + 1;
	             cur_elevator_ptr->cur_max_floor_call_hall = max_num_floors + 1;
		      }
	        }
            cur_elevator_ptr->pending_floor_calls_bit_field &= ~(1 << cur_elevator_ptr->cur_floor); 
			--cur_elevator_ptr->num_pending_floor_calls;
			if(cur_elevator_ptr->num_pending_floor_calls == 0 && cur_elevator_ptr->pending_floor_calls_bit_field == 0)
			{
				 cur_elevator_ptr->cur_min_floor_call = max_num_floors + 1;
	             cur_elevator_ptr->cur_max_floor_call = max_num_floors + 1;
			}
	        #ifdef TRACE_INFO	    
		      printf("TRA: serviced floor call: %u\n", cur_elevator_ptr->cur_floor);				           
	        #endif 			
	    }
	   cur_elevator_ptr->before_fsm_state = FSM_PREPARE_USER_ENTRY_AND_EXIT;
	   loop_flag |= (1 << 3); 
	}
	if((ret_status = Compute_Floor_Stop_Datas(ctrl_elevator_ch_id, DOOR_OPENED_STAGE, &elevator_status)) != SUCCESS)
	{
	     appl_status_flag = ERR_NEXT_STOP_FLOOR_PROC;
    	 Error_or_Warning_Proc("14.23.02", ERROR_OCCURED, appl_status_flag);   
		 cur_elevator_ptr->elevator_status = ERR_COMPUTE_NEXT_STOP_FLOOR;
		 cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		 return SUCCESS;
	}	
    switch(elevator_status)
	{
        case NO_PENDING_FLOOR_CALLS:
		case STARTUP_STATIONARY:
          return SUCCESS;      		  
	   // break;
        default:  
           loop_flag &= ~(1 << 3);  		
          #ifdef TRACE_FLOW		 
            printf("USER_ENTRY_AND_EXIT -> COMPUTE_NEXT_STOP_FLOOR\n"); 
          #endif
          cur_elevator_ptr->cur_fsm_state = FSM_COMPUTE_NEXT_STOP_FLOOR;
		  		
	} 
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : FSM_Compute_Next_Stop_Floor_Proc 

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.23

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Compute_Next_Stop_Floor_Proc(const uint8_t ctrl_elevator_ch_id)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	uint8_t cur_floor, elevator_status = 0;

	
	 if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("14.23.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	
	if((ret_status = Compute_Floor_Stop_Datas(ctrl_elevator_ch_id, DOOR_CLOSED_STAGE, &elevator_status)) != SUCCESS)
	{
	     appl_status_flag = ERR_NEXT_STOP_FLOOR_PROC;
    	 Error_or_Warning_Proc("14.23.02", ERROR_OCCURED, appl_status_flag);   
		 cur_elevator_ptr->elevator_status = ERR_COMPUTE_NEXT_STOP_FLOOR;
		 cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
		 return SUCCESS;
	}
	switch(elevator_status)
	{
		case NO_PENDING_FLOOR_CALLS:
		   #ifdef TRACE_ERROR
	          printf("COMPUTE_NEXT_STOP_FLOOR -> ABNORMAL_EVENT \n");
	          printf("ERR: Event - no pending floor call\n");
	       #endif
		   cur_elevator_ptr->elevator_status = ERR_COMPUTE_NEXT_STOP_FLOOR;
	       cur_elevator_ptr->cur_fsm_state = FSM_ABNORMAL_EVENT;
           return SUCCESS;		   
		//break;
		case ONE_PENDING_FLOOR_CALL:
		  //one pending floor calls
        case STARTUP_STATIONARY:
           //startup stationary		
        case TRIGGER_MOVE_UP_NO_DIR_CHANGE:						
		    //trigger car to move up		
		case TRIGGER_MOVE_UP_DIR_CHANGE:
		  //trigger car to move up
		case TRIGGER_MOVE_DOWN_NO_DIR_CHANGE:						
		   //trigger car to move down		  
		case TRIGGER_MOVE_DOWN_DIR_CHANGE:
		   //trigger car to move down
		   
		   #ifdef TRACE_DATA
		    printf("TRA: After compute floor data - Closed Stage \n");
            printf("==============================================\n");			
		    Disp_Oper_Proc(CTRL_ELEVATOR_CH_ID);
			printf("==============================================\n");
			#elseif defined TRACE_INFO
			   printf("cur_floor                     : %u\n", cur_elevator_ptr->cur_floor);
	           printf("next_stop_floor               : %u\n", cur_elevator_ptr->next_stop_floor);
			   printf("pending floor calls           : 0x%X\n", cur_elevator_ptr->pending_floor_calls_bit_field);
		   #endif	
           #ifdef TRACE_FLOW			
	         printf("COMPUTE_NEXT_STOP_FLOOR -> DECIDE_CAR_MOVEMENT \n");  
		   #endif
          	cur_elevator_ptr->cur_fsm_state = FSM_DECIDE_CAR_MOVEMENT;	   
		break;  
        default:	
            appl_status_flag = ERR_FORMAT_INVALID;
		    Error_or_Warning_Proc("14.23.03", ERROR_OCCURED, appl_status_flag);
		   	return FAILURE;			   
	}

	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  :  FSM_Abnormal_Event_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 14.24

BUGS           :              
-*------------------------------------------------------------*/
uint16_t FSM_Abnormal_Event_Proc(const uint8_t ctrl_elevator_ch_id)
{
	#ifdef TRACE_ERROR
    	printf("ERR: Abnormal \n");
	#endif
    return FAILURE;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Active_Hall_And_In_Car_Calls_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.21

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Active_Hall_And_In_Car_Calls_Proc(const uint8_t ctrl_elevator_ch_id)
{
    elevator_ctrl_and_status_t *cur_elevator_ptr;
    uint16_t ret_status; 
	uint8_t floor_call_type, floor_call;
	
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("11.21.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	switch(cur_elevator_ptr->before_fsm_state)
	{
		case FSM_STARTUP:
		  #ifdef TRACE_ERROR
		     printf("WRN: floor calls not allowed \n");
		  #endif
		  appl_status_flag = ERR_FLOOR_CALLS_NOT_ALLOWED;
	      Error_or_Warning_Proc("11.21.02", WARNING_OCCURED, appl_status_flag);		 
		  return appl_status_flag;
	    //break;
        case FSM_PREPARE_USER_ENTRY_AND_EXIT:
         	printf("1 - in car, 2 - hall \n");
			printf("Enter floor call type : ");
	        scanf("%u", &floor_call_type);
			switch(floor_call_type)
			{
		    	case IN_CAR_FLOOR_CALL_OPER:
			    case HALL_FLOOR_CALL_OPER:				
				    printf("Enter floor call : ");	
	                scanf("%u", &floor_call);
					if((ret_status = Validate_Floor(floor_call)) != SUCCESS)
					{
						appl_status_flag = ERR_FLOOR_INVALID;
	                    Error_or_Warning_Proc("11.21.03", ERROR_OCCURED, appl_status_flag);		 
		                return appl_status_flag;
					}
					if(cur_elevator_ptr->elevator_status == STARTUP_STATIONARY || cur_elevator_ptr->elevator_status == MOVED_UP_STATIONARY || cur_elevator_ptr->elevator_status == MOVED_DOWN_STATIONARY)
					{
					    if(floor_call == cur_elevator_ptr->cur_floor)
	                    {
	        	            #ifdef TRACE_ERROR 
		                       uint32_temp_disp_data = floor_call;
		                       printf("WARN: floor_call: %u = cur_floor \n", uint32_temp_disp_data);
                            #endif 		
	                        appl_status_flag = WARN_FLOOR_CALL_SAME_CUR_FLOOR;
	                        Error_or_Warning_Proc("11.21.04", WARNING_OCCURED, appl_status_flag);
	                        return appl_status_flag; 
	                   }
					}
				break;
				default:
				   printf("Invalid choice \n");
				   appl_status_flag = ERR_FORMAT_INVALID ;
	               Error_or_Warning_Proc("11.21.05", ERROR_OCCURED, appl_status_flag);		 
		           return appl_status_flag;
			}
	}
	switch(floor_call_type)
	{
		case IN_CAR_FLOOR_CALL_OPER:
		   if((cur_elevator_ptr->pending_in_car_floor_calls_bit_field & (1 << floor_call)))
		   {
			   #ifdef TRACE_ERROR
			       uint32_temp_disp_data = floor_call;
			       printf("WRN: in car floor call : %u is already pend\n", uint32_temp_disp_data);
			   #endif
			   appl_status_flag = WARN_IN_CAR_FLOOR_CALL_IS_ACTIVE ;
	           Error_or_Warning_Proc("11.21.08", WARNING_OCCURED, appl_status_flag);		 
		       return appl_status_flag;
		   }					   
		   cur_elevator_ptr->pending_in_car_floor_calls_bit_field |= (1 << floor_call);
		   #ifdef TRACE_DATA
		       uint32_temp_disp_data = cur_elevator_ptr->pending_in_car_floor_calls_bit_field;
	           printf("in car floor calls bit field        : 0x%x\n",uint32_temp_disp_data );
		   #endif
		   if(cur_elevator_ptr->num_pending_floor_calls_in_car == 0)
	       {
	 	       cur_elevator_ptr->cur_max_floor_call_in_car = floor_call;
		       cur_elevator_ptr->cur_min_floor_call_in_car = floor_call;
			   cur_elevator_ptr->num_pending_floor_calls_in_car = 1;    
	       }
	       else
	       {
			   ++cur_elevator_ptr->num_pending_floor_calls_in_car;
	           if(cur_elevator_ptr->cur_max_floor_call_in_car < floor_call)
		       {
	 	          	cur_elevator_ptr->cur_max_floor_call_in_car = floor_call;
	           }
		       if(cur_elevator_ptr->cur_min_floor_call_in_car > floor_call)
		       {
		          	cur_elevator_ptr->cur_min_floor_call_in_car = floor_call;
		       }			  
		      #ifdef TRACE_DATA
		            uint32_temp_disp_data = cur_elevator_ptr->cur_min_floor_call_in_car;
		            printf("TRA: pending in car floor calls range[%u , ", uint32_temp_disp_data);
		            uint32_temp_disp_data = cur_elevator_ptr->cur_max_floor_call_in_car;
		            printf("%u], ", uint32_temp_disp_data); 
					uint32_temp_disp_data = cur_elevator_ptr->num_pending_floor_calls_in_car;
		            printf("num in_car calls: %u\n", uint32_temp_disp_data);
		      #endif	 
	       }
		break;
		case HALL_FLOOR_CALL_OPER:
		   if((cur_elevator_ptr->pending_hall_floor_calls_bit_field & (1 << floor_call)))
		   {
			   #ifdef TRACE_ERROR
			       uint32_temp_disp_data = floor_call;
			       printf("WRN: hall floor call : %u is already pend\n", uint32_temp_disp_data);
			   #endif
			   appl_status_flag = WARN_HALL_FLOOR_CALL_IS_ACTIVE ;
	           Error_or_Warning_Proc("11.21.08", WARNING_OCCURED, appl_status_flag);		 
		       return appl_status_flag;
		   }					   
		   cur_elevator_ptr->pending_hall_floor_calls_bit_field |= (1 << floor_call);
		   #ifdef TRACE_DATA
		       uint32_temp_disp_data = cur_elevator_ptr->pending_in_car_floor_call_bit_field;
	           printf("hall floor calls bit field         : 0x%x\n",uint32_temp_disp_data );
		   #endif
		   if(cur_elevator_ptr->num_pending_floor_calls_hall == 0)
	       {
	 	       cur_elevator_ptr->cur_max_floor_call_hall = floor_call;
		       cur_elevator_ptr->cur_min_floor_call_hall = floor_call;
			   cur_elevator_ptr->num_pending_floor_calls_hall = 1;    
	       }
	       else
	       {
			   ++cur_elevator_ptr->num_pending_floor_calls_hall;
	           if(cur_elevator_ptr->cur_max_floor_call_hall < floor_call)
		       {
	 	          	cur_elevator_ptr->cur_max_floor_call_hall = floor_call;
	           }
		       if(cur_elevator_ptr->cur_min_floor_call_hall > floor_call)
		       {
		          	cur_elevator_ptr->cur_min_floor_call_hall = floor_call;
		       }			  
		      #ifdef TRACE_DATA
		            uint32_temp_disp_data = cur_elevator_ptr->cur_min_floor_call_hall;
		            printf("TRA: pending hall floor calls range[%u , ", uint32_temp_disp_data);
		            uint32_temp_disp_data = cur_elevator_ptr->cur_max_floor_call_hall;
		            printf("%u], ", uint32_temp_disp_data); 
					uint32_temp_disp_data = cur_elevator_ptr->num_pending_floor_calls_hall;
		            printf("num hall calls: %u\n", uint32_temp_disp_data);
		      #endif	 
	       }
       break;
       default:
         appl_status_flag = ERR_FORMAT_INVALID;
	     Error_or_Warning_Proc("11.21.09", ERROR_OCCURED, appl_status_flag);
	     return appl_status_flag;
	}		  
	if(cur_elevator_ptr->pending_floor_calls_bit_field & (1 << floor_call))
	{
		return SUCCESS;			    		
	}
	cur_elevator_ptr->pending_floor_calls_bit_field |= (1 << floor_call);
	#ifdef TRACE_INFO
	   uint32_temp_disp_data = floor_call; 
	   printf("Pending floor call : %u added \n", uint32_temp_disp_data);
    #endif	
	if(cur_elevator_ptr->num_pending_floor_calls == 0)
	{
	 	 cur_elevator_ptr->cur_max_floor_call = floor_call;
		 cur_elevator_ptr->cur_min_floor_call = floor_call;
		 cur_elevator_ptr->next_stop_floor = floor_call;
		 cur_elevator_ptr->num_pending_floor_calls  = 1;
		 #ifdef TRACE_DATA
		      uint32_temp_disp_data = floor_call;
		      printf("TRA: first pending, next_stop : %u \n", uint32_temp_disp_data);
	     #endif		  
	}
	else
	{
		 ++cur_elevator_ptr->num_pending_floor_calls;
		 if(cur_elevator_ptr->cur_max_floor_call < floor_call)
		 {
	 	 	cur_elevator_ptr->cur_max_floor_call = floor_call;
	     }
		 if(cur_elevator_ptr->cur_min_floor_call > floor_call)
		 {
		 	cur_elevator_ptr->cur_min_floor_call = floor_call;
		 }
		 #ifdef TRACE_DATA
		     uint32_temp_disp_data = cur_elevator_ptr->cur_min_floor_call;
		     printf("TRA: pending floor call range [%u , ", uint32_temp_disp_data);
			 uint32_temp_disp_data = cur_elevator_ptr->cur_max_floor_call;
			 printf("%u] \n", uint32_temp_disp_data); 
			 uint32_temp_disp_data = cur_elevator_ptr->num_pending_floor_calls;
		     printf("num calls: %u\n", uint32_temp_disp_data);
		#endif	 
	}
	#ifdef TRACE_DATA
	   uint32_temp_disp_data = cur_elevator_ptr->pending_floor_calls_bit_field;
	   printf("TRA: pending floor calls bit field : 0x%x \n", uint32_temp_disp_data);
	#endif
	return SUCCESS;				
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Reset_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.11

BUGS           :    
-*------------------------------------------------------------*/ 
uint16_t Disp_Oper_Proc(const uint8_t ctrl_elevator_ch_id)
{
	 elevator_ctrl_and_status_t *cur_elevator_ptr;
	 cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	printf("num floors                        : %u\n", max_num_floors); 
	printf("cur fsm                           : %u\n", cur_elevator_ptr->cur_fsm_state);
	printf("status                            : %u\n", cur_elevator_ptr->elevator_status);
	printf("cur_floor                         : %u\n", cur_elevator_ptr->cur_floor);
	printf("next_stop_floor                   : %u\n", cur_elevator_ptr->next_stop_floor);
	printf("min_stop_floor                    : %u\n", cur_elevator_ptr->cur_min_floor_call);
	printf("max_stop_floor                    : %u\n", cur_elevator_ptr->cur_max_floor_call);
	printf("num pending calls                 : %u\n", cur_elevator_ptr->num_pending_floor_calls);
	printf("pending floor calls - bit         : 0x%X\n", cur_elevator_ptr->pending_floor_calls_bit_field);
	printf("min_stop_floor in car             : %u\n", cur_elevator_ptr->cur_min_floor_call_in_car);
	printf("max_stop_floor in car             : %u\n", cur_elevator_ptr->cur_max_floor_call_in_car);
	printf("num pending calls in car          : %u\n", cur_elevator_ptr->num_pending_floor_calls_in_car);
	printf("pending floor calls in car - bit  : 0x%X\n", cur_elevator_ptr->pending_in_car_floor_calls_bit_field);
	printf("min_stop_floor hall               : %u\n", cur_elevator_ptr->cur_min_floor_call_hall);
	printf("max_stop_floor hall               : %u\n", cur_elevator_ptr->cur_max_floor_call_hall);
	printf("num pending calls hall            : %u\n", cur_elevator_ptr->num_pending_floor_calls_hall);
	printf("pending floor calls hall - bit    : 0x%X\n", cur_elevator_ptr->pending_hall_floor_calls_bit_field);
	return SUCCESS;
}
/*------------------------------------------------------------*
FUNCTION NAME  : Car_Movement_Direction 

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.16

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Car_Movement_Direction(const uint8_t ctrl_elevator_ch_id, const uint8_t cur_floor, uint8_t *const elevator_trigger_move_ptr)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	
	if(elevator_trigger_move_ptr == NULL_PTR)
	{
		appl_status_flag = ERR_NULL_PTR;
	    Error_or_Warning_Proc("11.16.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
	}
	*elevator_trigger_move_ptr = NUM_ELEVATOR_STATUS;
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("11.16.02", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;	
	
    if(cur_floor == cur_elevator_ptr->next_stop_floor)
	{
		switch(cur_elevator_ptr->elevator_status)
		{
			case STARTUP_STATIONARY:
			   *elevator_trigger_move_ptr = STARTUP_STATIONARY;
			break;
			case MOVE_UP:
			case MOVED_UP_STATIONARY:
			   *elevator_trigger_move_ptr = MOVED_UP_STATIONARY;
			break;
			case MOVE_DOWN:
			case MOVED_DOWN_STATIONARY:
			   *elevator_trigger_move_ptr = MOVED_DOWN_STATIONARY;
			break;
            default:
               appl_status_flag = ERR_FORMAT_INVALID;
	           Error_or_Warning_Proc("11.16.03", ERROR_OCCURED, appl_status_flag);
	           return appl_status_flag;
		}			   
	}
	else
	{
		if(cur_floor < cur_elevator_ptr->next_stop_floor) 
	    {			
			 *elevator_trigger_move_ptr = MOVE_UP;
		}
		else
		{	
	         *elevator_trigger_move_ptr = MOVE_DOWN;		   
		}	
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Compute_Floor_Stop_Datas

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.22

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Compute_Floor_Stop_Datas(const uint8_t ctrl_elevator_ch_id, const uint8_t stage_type, uint8_t *const elevator_status_ptr)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	uint16_t ret_status;
	uint8_t cur_floor, stop_floor_call_move, stop_floor_call_in_car_and_move;
	static uint8_t loop_flag = 0;
	
	if(elevator_status_ptr == NULL_PTR)
	{
		appl_status_flag = ERR_NULL_PTR;
	    Error_or_Warning_Proc("11.22.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
	}
	switch(stage_type)
	{
		case DOOR_OPENED_STAGE:
	    case DOOR_CLOSED_STAGE:
		break;
		default:
		   	appl_status_flag = ERR_FORMAT_INVALID;
	        Error_or_Warning_Proc("11.22.01", ERROR_OCCURED, appl_status_flag);
	        return appl_status_flag;  		
	}
	if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("11.22.02", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	if(cur_elevator_ptr->num_pending_floor_calls == 0)
	{
		//no more floor calls 
		  Reset_Elevator_Datas(ctrl_elevator_ch_id, RESET_STOP_DATAS);		
		 #ifdef TRACE_INFO
		     printf("TRA: NO_PENDING_FLOOR_CALLS \n");
		 #endif	 
		*elevator_status_ptr = NO_PENDING_FLOOR_CALLS;		 
		return SUCCESS;
	}
	switch(cur_elevator_ptr->elevator_status)
    { 
      	case MOVED_UP_STATIONARY:
			loop_flag &= ~(1 << 2);
		    if(cur_elevator_ptr->cur_floor < cur_elevator_ptr->cur_max_floor_call)
			{
			  	 for(cur_floor = cur_elevator_ptr->cur_floor + 1; cur_floor <= cur_elevator_ptr->cur_max_floor_call; ++cur_floor)
			     {
			    	 if((cur_elevator_ptr->pending_floor_calls_bit_field & (1 << cur_floor)))
			    	 {
			    	 	switch(stage_type)						
			    	 	{
			    	 		case DOOR_OPENED_STAGE:
							   if((cur_elevator_ptr->pending_in_car_floor_calls_bit_field & (1 << cur_floor)))
							   {
								  if(cur_elevator_ptr->cur_min_floor_call_in_car == cur_elevator_ptr->cur_floor)
			    	              {
			    	           	    cur_elevator_ptr->cur_min_floor_call_in_car = cur_floor;
						          } 
							   } 
                              if((cur_elevator_ptr->pending_hall_floor_calls_bit_field & (1 << cur_floor)))
							   {
								  if(cur_elevator_ptr->cur_min_floor_call_hall == cur_elevator_ptr->cur_floor)
			    	              {
			    	           	      cur_elevator_ptr->cur_min_floor_call_hall = cur_floor;
						          } 
							   }  						   
			    	           if(cur_elevator_ptr->cur_min_floor_call == cur_elevator_ptr->cur_floor)
			    	           {
			    	           	 cur_elevator_ptr->cur_min_floor_call = cur_floor;
						       }
						     break;
							 case DOOR_CLOSED_STAGE:  
							   cur_elevator_ptr->next_stop_floor = cur_floor;
							 break;   
				    	}			 	    	 
					   	break;
			   	     }
			     }				 
			     if(cur_floor > cur_elevator_ptr->cur_max_floor_call)
			     {
					 #ifdef TRACE_ERROR
					    printf("COMPUTE_NEXT_STOP_FLOOR -> ABNORMAL_EVENT \n");
					    uint32_temp_disp_data = cur_elevator_ptr->cur_max_floor_call;						
			            printf("ERR: event - cur_floor > max_call: %u \n", uint32_temp_disp_data);
				     #endif		
					 appl_status_flag = ERR_MAX_STOP_FLOOR_REACH_BUT_NOT_IN_STOP_LIST;
	                 Error_or_Warning_Proc("11.22.04", ERROR_OCCURED, appl_status_flag);
	                 return appl_status_flag;
			     }
				 #ifdef TRACE_FLOW				     
					  printf("TRA: TRIGGER_MOVE_UP_NO_DIR_CHANGE \n"); 
				  #endif				  
				    *elevator_status_ptr = TRIGGER_MOVE_UP_NO_DIR_CHANGE;
				 return SUCCESS;				 
		    }
		    // cur_elevator_ptr->cur_floor == cur_elevator_ptr->cur_max_floor_call
			// action to move down      
			//cur_elevator_ptr->cur_floor > cur_elevator_ptr->cur_min_floor_call 
			for(cur_floor = cur_elevator_ptr->cur_floor - 1; cur_floor >= cur_elevator_ptr->cur_min_floor_call; --cur_floor)
			{
			  	 if((cur_elevator_ptr->pending_floor_calls_bit_field & (1 << cur_floor)))
			   	 {
					switch(stage_type)						
			     	{
			    	 	case DOOR_OPENED_STAGE:
						   if((cur_elevator_ptr->pending_in_car_floor_calls_bit_field & (1 << cur_floor)))
						   {
							   cur_elevator_ptr->cur_max_floor_call_in_car = cur_floor;
						   } 
						   if((cur_elevator_ptr->pending_hall_floor_calls_bit_field & (1 << cur_floor)))
						   {
							   cur_elevator_ptr->cur_max_floor_call_hall = cur_floor;
						   } 
			   	           cur_elevator_ptr->cur_max_floor_call = cur_floor;				        
						break;
						case DOOR_CLOSED_STAGE:		
			            	cur_elevator_ptr->next_stop_floor = cur_floor;	
					    break;
					}
			     	break;
			     }
			}
			if(cur_floor < cur_elevator_ptr->cur_min_floor_call)
			{
				#ifdef TRACE_ERROR
			        printf("COMPUTE_NEXT_STOP_FLOOR -> ABNORMAL_EVENT \n");
					printf("ERR: event - move down, cur  < min_call \n");
				#endif
				appl_status_flag = ERR_MIN_STOP_FLOOR_INVALID;
	            Error_or_Warning_Proc("11.22.06", ERROR_OCCURED, appl_status_flag);
	            return appl_status_flag; 
			}
			 #ifdef TRACE_FLOW
			       printf("TRA: TRIGGER_MOVE_DOWN_DIR_CHANGE \n"); 
			  #endif
			   *elevator_status_ptr = TRIGGER_MOVE_DOWN_DIR_CHANGE;
			  return SUCCESS;			
		//break;
		case MOVED_DOWN_STATIONARY:
		    loop_flag &= ~(1 << 2);
		    if(cur_elevator_ptr->cur_floor > cur_elevator_ptr->cur_min_floor_call)
			{
			  	 for(cur_floor = cur_elevator_ptr->cur_floor - 1; cur_floor >= cur_elevator_ptr->cur_min_floor_call; --cur_floor)
			     {
			    	 if((cur_elevator_ptr->pending_floor_calls_bit_field & (1 << cur_floor)))
			    	 {
			    	 	switch(stage_type)						
			     	    {
			    	    	case DOOR_OPENED_STAGE:
							   if((cur_elevator_ptr->pending_in_car_floor_calls_bit_field & (1 << cur_floor)))
						       {
							      if(cur_elevator_ptr->cur_max_floor_call_in_car == cur_elevator_ptr->cur_floor)
					              { 
					            	 cur_elevator_ptr->cur_max_floor_call_in_car = cur_floor;
					              } 
						       } 
						       if((cur_elevator_ptr->pending_hall_floor_calls_bit_field & (1 << cur_floor)))
						       {
							      if(cur_elevator_ptr->cur_max_floor_call_hall == cur_elevator_ptr->cur_floor)
					              { 
					            	 cur_elevator_ptr->cur_max_floor_call_hall = cur_floor;
					              }   
						       } 
			    	           if(cur_elevator_ptr->cur_max_floor_call == cur_elevator_ptr->cur_floor)
					           {
					            	cur_elevator_ptr->cur_max_floor_call = cur_floor;
					           }
					        break;
							case DOOR_CLOSED_STAGE:    
			 	    	       cur_elevator_ptr->next_stop_floor = cur_floor;
			 	    	    break;
						}
						 break;
			   	     }
			     }	
                 // cur_elevator_ptr->cur_floor == cur_elevator_ptr->cur_min_floor_call				 
			     if(cur_floor < cur_elevator_ptr->cur_min_floor_call)
			     {
					 #ifdef TRACE_ERROR
					    printf("COMPUTE_NEXT_STOP_FLOOR -> ABNORMAL_EVENT \n");
			    	    printf("ERR: event- cur_floor < min_call, but not in stop list\n" );
					 #endif
			         appl_status_flag = ERR_MIN_STOP_FLOOR_REACH_BUT_NOT_IN_STOP_LIST;
	                 Error_or_Warning_Proc("11.22.08", ERROR_OCCURED, appl_status_flag);
	                 return appl_status_flag;
				 }					
			     #ifdef TRACE_FLOW
			         printf("TRA: TRIGGER_MOVE_DOWN_NO_DIR_CHANGE \n"); 
			      #endif
				   *elevator_status_ptr = TRIGGER_MOVE_DOWN_NO_DIR_CHANGE;
				 return SUCCESS;				 
		    }
			// action to move up     
			//cur_elevator_ptr->cur_floor < cur_elevator_ptr->cur_max_floor_call 
			for(cur_floor = cur_elevator_ptr->cur_floor + 1; cur_floor <= cur_elevator_ptr->cur_max_floor_call; ++cur_floor)
			{
			  	 if((cur_elevator_ptr->pending_floor_calls_bit_field & (1 << cur_floor)))
			   	 {
			   	 	switch(stage_type)						
			     	{
			    	   case DOOR_OPENED_STAGE:
					       if((cur_elevator_ptr->pending_in_car_floor_calls_bit_field & (1 << cur_floor)))
						   {
							   cur_elevator_ptr->cur_min_floor_call_in_car = cur_floor;
						   } 
						   if((cur_elevator_ptr->pending_hall_floor_calls_bit_field & (1 << cur_floor)))
						   {
							   cur_elevator_ptr->cur_min_floor_call_hall = cur_floor;
						   } 
			   	 	       cur_elevator_ptr->cur_min_floor_call = cur_floor;
					   break;
					   case DOOR_CLOSED_STAGE:
					     cur_elevator_ptr->next_stop_floor = cur_floor;
					   break;
				    }
				    break;
			     }
			}
			if(cur_floor > cur_elevator_ptr->cur_max_floor_call)
			{
				#ifdef TRACE_ERROR
				  printf("COMPUTE_NEXT_STOP_FLOOR -> ABNORMAL_EVENT \n"); 
		          printf("ERR: event - cur_floor > max_call, so invalid \n");
				#endif 
		      	appl_status_flag = ERR_MAX_STOP_FLOOR_INVALID;
	            Error_or_Warning_Proc("11.22.10", ERROR_OCCURED, appl_status_flag);
	            return appl_status_flag;
			}
			#ifdef TRACE_FLOW
			     printf("TRA: TRIGGER_MOVE_UP_DIR_CHANGE \n"); 
			 #endif
			 *elevator_status_ptr = TRIGGER_MOVE_UP_DIR_CHANGE;
			return SUCCESS;			
	//	break;
        case STARTUP_STATIONARY:
		  for(cur_floor = cur_elevator_ptr->cur_floor + 1; cur_floor <= cur_elevator_ptr->cur_max_floor_call; ++cur_floor)
		  {
		  	   if((cur_elevator_ptr->pending_floor_calls_bit_field & (1 << cur_floor)) )
			   { 
			     ++stop_floor_call_move;
			   }
		  }
		  for(cur_floor = cur_elevator_ptr->cur_floor - 1; cur_floor >= (int8_t)cur_elevator_ptr->cur_min_floor_call; --cur_floor)
		  {
		  	   if((cur_elevator_ptr->pending_floor_calls_bit_field & (1 << cur_floor)))
			   { 
			     ++stop_floor_call_in_car_and_move;
			   }
		  }
		  if(stop_floor_call_move >= stop_floor_call_in_car_and_move)
		  {
		  	  cur_elevator_ptr->elevator_status = MOVED_UP_STATIONARY;
			  #ifdef TRACE_FLOW
			     printf("STARTUP_STATIONARY -> MOVED_UP_STATIONARY \n");
			  #endif	
		  }
		  else
		  {
		  	   cur_elevator_ptr->elevator_status = MOVED_DOWN_STATIONARY;
			    #ifdef TRACE_FLOW
			     printf("STARTUP_STATIONARY -> MOVED_DOWN_STATIONARY \n");
			   #endif
		  }
		  *elevator_status_ptr = STARTUP_STATIONARY;
		break; 	
		default:
		   loop_flag &= ~(1 << 2);
		   appl_status_flag = ERR_FORMAT_INVALID;
		   Error_or_Warning_Proc("11.22.11", ERROR_OCCURED, appl_status_flag);
		   return appl_status_flag;	
	 }
	 return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Reset_Elevator_Datas

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.13  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Reset_Elevator_Datas(const uint8_t ctrl_elevator_ch_id, const uint8_t reset_type)
{
	elevator_ctrl_and_status_t *cur_elevator_ptr;
	
    if(ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("11.13.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    }	
    cur_elevator_ptr = elevator_ctrl_and_status + ctrl_elevator_ch_id;
	switch(reset_type)
	{
		case RESET_WHOLE_DATAS:
		  cur_elevator_ptr->elevator_status = STARTUP_STATIONARY;	
	      cur_elevator_ptr->cur_fsm_state = FSM_STARTUP;
	      cur_elevator_ptr->before_fsm_state = FSM_STARTUP;
		  cur_elevator_ptr->cur_floor = max_num_floors + 1;
		case RESET_STOP_DATAS:  
		  cur_elevator_ptr->next_stop_floor = max_num_floors + 1;  
		  cur_elevator_ptr->cur_max_floor_call = max_num_floors + 1;
          cur_elevator_ptr->cur_min_floor_call = max_num_floors + 1;		        
	      cur_elevator_ptr->pending_floor_calls_bit_field = 0; 
		  cur_elevator_ptr->num_pending_floor_calls = 0;
		  cur_elevator_ptr->cur_min_floor_call_in_car = max_num_floors + 1;
		  cur_elevator_ptr->cur_max_floor_call_in_car = max_num_floors + 1;
		  cur_elevator_ptr->pending_in_car_floor_calls_bit_field = 0;
          cur_elevator_ptr->num_pending_floor_calls_in_car = 0; 
		  cur_elevator_ptr->cur_min_floor_call_hall = max_num_floors + 1;
		  cur_elevator_ptr->cur_max_floor_call_hall = max_num_floors + 1;
		  cur_elevator_ptr->pending_hall_floor_calls_bit_field = 0;
          cur_elevator_ptr->num_pending_floor_calls_hall = 0; 
		break;
     	default:
	      appl_status_flag = ERR_FORMAT_INVALID;
	      Error_or_Warning_Proc("11.13.02", ERROR_OCCURED, appl_status_flag);
	      return appl_status_flag;
	}		
	return SUCCESS;
}



/*------------------------------------------------------------*
FUNCTION NAME  : Validate_Floor

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.12  

BUGS           :              
-*------------------------------------------------------------*/
uint16_t Validate_Floor(const uint8_t floor)
{
	if(floor < 0 || floor >=  max_num_floors)
	{
		#ifdef TRACE_ERROR
		   printf("ERR: floor: %u invalid, valid range [ 0 , %u ]", floor, max_num_floors - 1);
		#endif
		appl_status_flag = ERR_FLOOR_INVALID;
		Error_or_Warning_Proc("11.12.01", ERROR_OCCURED, appl_status_flag);
		return appl_status_flag;
	}
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Error_or_Warning_Proc

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.14  

BUGS           :              
-*------------------------------------------------------------*/
uint8_t Error_or_Warning_Proc(const char *const error_trace_str, const uint8_t warn_or_error_format, const uint32_t warning_or_error_code)
{
	switch(warn_or_error_format)
	{
		case WARNING_OCCURED:
		  printf("WRN: ");
		break;
        default:
           printf("ERR: ");
	}		   
	printf("%s, code: %u \n", error_trace_str, warning_or_error_code);
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Reset_Proc

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.11

BUGS           :    
-*------------------------------------------------------------*/ 
uint16_t Appl_Reset_Proc(const uint8_t cur_ctrl_elevator_ch_id)
{
	int32_t enter_num_floors;
	
	if(cur_ctrl_elevator_ch_id >= MAX_NUM_ELEVATORS)
	{
		appl_status_flag = ERR_ELEVATOR_CH_ID_EXCEEDS;
	    Error_or_Warning_Proc("11.11.01", ERROR_OCCURED, appl_status_flag);
	    return appl_status_flag;
    } 
	printf("Enter max num floors: ");
	scanf("%d", &enter_num_floors);
	if(enter_num_floors < MIN_NUM_FLOORS ||  enter_num_floors > MAX_NUM_FLOORS)
	{
		printf("ERR: max_num_floor entered: %u invalid, valid range[ %u, %u ]\n",enter_num_floors, MIN_NUM_FLOORS, MAX_NUM_FLOORS );
		printf("Considered Max num floors: %u\n", max_num_floors);
		Reset_Elevator_Datas(cur_ctrl_elevator_ch_id, RESET_WHOLE_DATAS);
		return FAILURE;
	}
	max_num_floors = enter_num_floors; 
	#ifdef TRACE_INFO
    	printf("Entered max num floors: %u \n", max_num_floors);
	#endif
    Reset_Elevator_Datas(cur_ctrl_elevator_ch_id, RESET_WHOLE_DATAS);
	return SUCCESS;
}
	
/*------------------------------------------------------------*
FUNCTION NAME  : Appl_Reset

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 11.01

BUGS           :    
-*------------------------------------------------------------*/
 uint16_t Appl_Reset(const uint8_t reset_type)
{
	uint16_t ret_status;
	
	switch(reset_type)
	{
		case RESET_APPL:	
           appl_status_flag = NO_ERROR;
           if((ret_status = Appl_Reset_Proc(CTRL_ELEVATOR_CH_ID)) != SUCCESS)
		   {
			   return FAILURE;
		   }			   
		break;
		default:
		   appl_status_flag = ERR_FORMAT_INVALID;
		   Error_or_Warning_Proc("11.01.04", ERROR_OCCURED, appl_status_flag);
		   return appl_status_flag;
	}
	return SUCCESS;
}
