/* ********************************************************************
FILE                   : encap using ptr.c

PROGRAM DESCRIPTION    : encapulation by using pointer

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "alloc.h"

#define IDLE_STATE    0

typedef struct
{
   int (*FsmPtr)();
} fsmhandletable;

typedef struct 
{
    int mac;
    int msgtype;
    unsigned char *dataptr;
} mainencap;

typedef struct
{
    int ip;
    int namelen;
    char name[10];
    int msgtype;
    unsigned char dataptr[1];    
} subencap1;

typedef struct
{
    int port;
    unsigned char dataptr[1];    
} lastencap;

unsigned char tempdata[30];

int main()
{
    mainencap *mainptr = NULL;
    subencap1 *subptr;
    lastencap *lastptr;

    clrscr();
    Main_Encap();
    mainptr = tempdata;               /* warning: suspicous ptr conv */
    printf("\n inside main: mainptr: %#X",mainptr );
    printf("\n mainencap: mac: %d",mainptr->mac);
    if(mainptr->msgtype == 1)
    {
       /* subptr points to garbage address */
       /* subptr = mainptr->dataptr; */    /* warning: suspicous ptr conv */
       subptr = &mainptr->dataptr;         /* warning: suspicous ptr conv */
       printf("\n subptr: %#X, subencap1: ip: %d, name: %s, namelen: %d",subptr,subptr->ip, subptr->name, subptr->namelen);
       if(subptr->msgtype == 2)
       {
	    lastptr = subptr->dataptr;  /* warning: suspicous ptr conv */
            printf("\n lastptr: %#X, last encap: port: %d, uchar: %c ", lastptr,lastptr->port, lastptr->dataptr[0]);
       }
    }
    return 1;
}

int Main_Encap(void )
{
   mainencap *mainptr = NULL;
   mainptr = tempdata;            /* warning: suspicous ptr conv */
   
   
   printf("\n mainptr: %#X ,Enter mainencap's mac & msgtype: 1 for encap 1: ", mainptr );
   scanf("%d %d", &mainptr->mac, &mainptr->msgtype);

   if(mainptr->msgtype == 1)
       Sub_Encap1(mainptr);
   return 1;
}

int Sub_Encap1(void *ptr)
{
   subencap1 *subptr;

  /* subptr = ptr->dataptr; */  /* error: ptr req at left side of -> */
   
   /* subptr points to NULL, if assigned below */
   /* subptr = ((mainencap *)ptr)->dataptr; */        /* warning: suspicous ptr conv */
   /* we are using address allocated dataptr, */
   subptr = &((mainencap *)ptr)->dataptr;         /* warning: suspicous ptr conv */
   printf("\n subptr: %#X, Inside sub_encap1: eNTER ip, name: ",subptr );
   scanf("%d %s", &subptr->ip, subptr->name);
   subptr->namelen = strlen(subptr->name);
   printf("\n ((mainencap *)ptr)->dataptr: %#X,&subptr->ip: %#X",((mainencap *)ptr)->dataptr,&subptr->ip);
   printf("\n enter msgtype: 2 for last encap: ");
   scanf("%d", &subptr->msgtype);
   if(subptr->msgtype == 2)
     LastEncap(ptr);
   return 1;
}

int LastEncap(void *ptr)
{
   subencap1 *subptr;
   lastencap *lastptr;

   /* lastptr =  (lastencap *)((subencap1 *)ptr->dataptr)->dataptr; */
    /* error: ptr req on left side of -> */

/* subptr = ((mainencap *)ptr)->dataptr;*/     /* warning: suspicous ptr conv */
/* lastptr = subptr->dataptr; */               /* warning: suspicous ptr conv */
   
  /* lastptr, is garbage */
  /* lastptr =  (lastencap *)((subencap1 *)((mainencap *)ptr)->dataptr)->dataptr; */
   lastptr =  (lastencap *)((subencap1 *)&((mainencap *)ptr)->dataptr)->dataptr;
   printf("\n lastptr: %#X, Inside lastencap: Enter:  port & uchar: ",lastptr );
   scanf("%d %c", &lastptr->port, &lastptr->dataptr[0]);
   return 1;

}

