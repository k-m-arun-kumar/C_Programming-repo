/* ********************************************************************
FILE                   : Print_Scan_1.c

PROGRAM DESCRIPTION    : implementation of scanf function

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.

reference             : 

   https://www.menie.org/georges/embedded/small_printf_source_code.html
   https://www.geeksforgeeks.org/program-for-conversion-of-32-bits-single-precision-ieee-754-floating-point-representation/ 
   https://www.geeksforgeeks.org/convert-floating-point-number-string/
   http://www.ryanjuckett.com/programming/printing-floating-point-numbers/ 
   http://mirror.fsf.org/pmon2000/2.x/src/lib/libc/scanf.c
   https://opensource.apple.com/source/xnu/xnu-1228/libkern/stdio/scanf.c
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <limits.h>
#include <ctype.h>
/* prints a lot of information about floating-point numbers */
#include <math.h>


#define PAD_RIGHT                     (1 << 0)
#define PAD_ZERO                      (1 << 1)
/* the following should be enough for 32 bit int */
#define PRINT_BUF_LEN                (12)
#define MAX_WIDTH_SPECIFIER          (PRINT_BUF_LEN - 1)     
#define MAX_PREC_SPECIFIER            (9)

#define MAX_STREAM_BUFFER_SIZE                       (32)

#define STATE_NO                                 (0)
#define STATE_YES                                (1)


/* endianness testing */
const int EndianTest = 0x04030201;

#define LITTLE_ENDIAN() ((*((const char *) &EndianTest) == 0x01))

#define CHARBITS               (8)
#define FLOATBITS              (sizeof(float) * CHARBITS)

/* extract nth LSB from object stored in lvalue x */
#define GET_BIT(float_num, float_bit_index) ((((const char *) &float_num)[LITTLE_ENDIAN() ? (float_bit_index) / CHARBITS : sizeof(float_num) - (float_bit_index) / CHARBITS - 1] >> ((float_bit_index) % CHARBITS)) & 0x01)

#define PUT_BIT(conv_float, float_bit_index) ((GET_BIT((conv_float.raw_ieee_754_format.float_num), (float_bit_index)) ? (conv_float.ieee_754_format |= (1 << float_bit_index)) : (conv_float.ieee_754_format &= ~(1 << float_bit_index)) ))

#define NULL_PTR                                      ((void *)0)
#define NULL_CHAR                                           ('\0')
#define BACKSPACE_CHAR                                      ('\b')
#define ENTER_CHAR                                          ('\n')
#define HORIZONTAL_TAB                                      ('\t')
#define VERTICAL_TAB                                        ('\v') 
#define EOF                                                  (-1)
#define SUCCESS                                               (0)
#define FAILURE                                               (1)

	

/*
 * Flags used during conversion.
 */
#define	LONG		0x01	/* l: long or double */
#define	SHORT		0x04	/* h: short */
#define	SUPPRESS	0x08	/* *: suppress assignment */
#define	POINTER		0x10	/* p: void * (as hex) */
#define	NOSKIP		0x20	/* [ or c: do not skip blanks */
#define	LONGLONG	0x400	/* ll: long long (+ deprecated q: quad) */
#define	SHORTSHORT	0x4000	/* hh: char */
#define	UNSIGNED	0x8000	/* %[oupxX] conversions */
#define REAL        0x10000 /* float or double */
/*
 * The following are used in numeric conversions only:
 * SIGNOK, NDIGITS, DPTOK, and EXPOK are for floating point;
 * SIGNOK, NDIGITS, PFXOK, and NZDIGITS are for integral.
 */
#define	SIGNOK		0x40	/* +/- is (still) legal */
#define	NDIGITS		0x80	/* no digits detected */

#define	DPTOK		0x100	/* (float) decimal point is still legal */
#define	EXPOK		0x200	/* (float) exponent (e+3, etc) still legal */

#define	PFXOK		0x100	/* 0x prefix is (still) legal */
#define	NZDIGITS	0x200	/* no zero digits detected */

/*
 * Conversion types.
 */
#define	CT_CHAR		0	/* %c conversion */
#define	CT_CCL		1	/* %[...] conversion */
#define	CT_STRING	2	/* %s conversion */
#define	CT_INT		3	/* %[dioupxX] conversion */
#define CT_REAL     4   /* [%f or %lf */
#define	UQUAD_MAX	((u_quad_t)0-1)	/* max value for a uquad_t */
					/* max value for a quad_t */
#define	QUAD_MAX	((quad_t)(UQUAD_MAX >> 1))
#define	QUAD_MIN	(-QUAD_MAX-1)	/* min value for a quad_t */

/*inline uint8_t isspace(const char c)
{
	return (c == '\n' || c == ' ' || c == '\r' || c == '\t' || c == '\v');
}*/

typedef unsigned char uint8_t;
typedef unsigned short int uint16_t;
typedef unsigned int uint32_t;
typedef unsigned long uint64_t;

typedef char int8_t;
typedef short int  int16_t;
typedef int int32_t;
typedef long int64_t;
typedef unsigned int u_quad_t;
typedef int quad_t;
typedef long double real_t;

typedef enum
{
	BASE_02 = 2, BASE_08 = 8, BASE_10 = 10, BASE_16 = 16
} base_t;

typedef enum 
{
	NUM_CONV_BIG_ALPHA, NUM_CONV_SMALL_ALPHA, NUM_CONV_ALPHA_NA
} num_conv_alpha_t;

typedef enum
{
	BASE_BIT_POS = 0, SIGN_FLAG_BIT_POS = 5, PAD_FORMAT_BIT_POS = 6, ALPHA_BIT_POS = 8 
} print_num_flag_bit_pos_t;


typedef union
{ 
  
    float float_num; 
    struct
    { 
  
        // Order is important. 
        // Here the members of the union data structure 
        // use the same memory (32 bits). 
        // The ordering is taken 
        // from the LSB to the MSB. 
        unsigned int mantissa : 23; 
        unsigned int exponient : 8; 
        unsigned int sign : 1; 
    } raw; 
} raw_ieee_754_format_t; 

typedef struct 
{
	raw_ieee_754_format_t raw_ieee_754_format;	
	uint32_t ieee_754_format;	
} float_ieee_754_format_t;	

#define CHAR_DEVICE                    (0)
#define BLOCK_DEVICE                   (1)
#define DEVICE_NA                      (2) 

#define STREAM_IO_INPUT                   (0)
#define STREAM_IO_OUTPUT                  (1)
#define STREAM_IO_BOTH                    (2)

#define STREAM_TYPE_IO                     (0)
#define STREAM_TYPE_FILE                   (1)
#define STREAM_TYPE_SOCKET                 (2)                                
 
typedef struct
{
	char stream_buf[MAX_STREAM_BUFFER_SIZE + 1];
	uint8_t file_desp;
	uint8_t num_chars_stream_buf;
	uint8_t cur_buf_pos;
	uint8_t device_type	    : 2; //char or block
	uint8_t stream_type     : 2; //io_type, file or socket
	uint8_t stream_io_type  : 2; //input, output, both	
	uint8_t                 : 2;	
} io_file_t;
io_file_t stdin_keyboard;

char Put_Char(const char to_disp_char);
uint8_t Str_Len(const char *const str);
int16_t Print(const char *const format_ptr, ...);
int16_t Str_Print(char *const out_str, const char *const format_ptr, ...);
char Print_Char(char **const out_str_ptr, const char print_char);
int16_t Print_Str(char **const out_str_ptr, const char *print_str, const uint8_t conf_width_spec, const uint8_t pad_format);
int16_t Print_Num(char **const out_str_ptr, const int32_t print_num, const uint8_t conf_width_spec, const uint16_t ctrl_flag );
int16_t Print_Float(char **const out_str_ptr, const float print_float, const uint8_t conf_width_spec, const uint8_t conf_num_digits_after_point, const uint16_t ctrl_flag );
uint16_t Real_Val_To_IEEE_754_float(const float src_float_num, float_ieee_754_format_t *const result_float_ptr);
uint16_t IEEE_754_float_To_Real_Val(const float_ieee_754_format_t *const src_float_ptr, float *const result_float_num_ptr);
uint16_t Double_To_Str_Conv(const double double_num, char *const double_to_str, uint8_t num_digits_after_point);
double Str_To_Double_Conv(const char *const double_to_str); 
uint16_t Str_Reverse(char *const str, const uint8_t len);
uint32_t Power_Of(const uint8_t base, const uint8_t power );
int16_t Scan(const char *const fmt, ...);
int16_t File_Scan(io_file_t *const fp, const char *const fmt, va_list ap);
int16_t Scan_Data(const char *inp, const char  *const fmt0, va_list ap);
char *File_Get_Str(char *const dst_str_ptr, const uint8_t max_chars_to_get,io_file_t  *const fp);
char Get_Char(void);
char *Get_Str(char *const get_str);
static const unsigned char *Scan_Input_Limit_Chars(char *, const char *);
quad_t strtoq(const char *nptr, char **endptr, int base);
uint16_t Init_IO_File(io_file_t *const file_ptr, const uint8_t file_desp, const uint8_t device_type, const uint8_t stream_type, const uint8_t stream_io_type);
uint8_t Read_Oper(io_file_t *const fp, char *const out_buf_ptr, const uint8_t max_num_chars_to_read);
//inline uint8_t isspace(const char c);

/*------------------------------------------------------------*
FUNCTION NAME  : main

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.01 

Bugs           :  
-*------------------------------------------------------------*/
int main(void)
{

	uint32_t uint32_num = 30;
	int32_t int32_num = -40;
	uint16_t num_chars_printed = 0;
	int16_t int16_num = -20;
	uint8_t uint8_num = 97;
	float float_num = -20.56, disp_float_num;
	char str_print[30];
    
	Init_IO_File(&stdin_keyboard, 0, CHAR_DEVICE, STREAM_TYPE_IO, STREAM_IO_INPUT );
    num_chars_printed = printf("printf: float_num = %05.10f, ", float_num);
	printf("num_chars: %5.1u \n", num_chars_printed);
    num_chars_printed = Print("Print: float_num = %10f, int16_num = %05.1h, ", float_num, int16_num);
	Print("uint32_num : %-4X, %% hello\n", uint32_num); 
	
   printf("Enter a float & number : ");
   Scan("%f %d",&float_num , &uint8_num );	
   Print("Scan: Entered float = %.9f, num = %d \n",float_num , uint8_num); 
    
   printf("Enter a number: ");
   Scan("%d", &uint32_num);	
   Print("Scan: Entered int_num = %d \n",uint32_num);
   
   return SUCCESS; 
}

/*------------------------------------------------------------*
FUNCTION NAME  : Print_Data

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.02 

Bugs           :  
-*------------------------------------------------------------*/
int16_t Print_Data(va_list *const print_va_list_ptr, char **const out_str_ptr, const char *const format_ptr)
{
	const char *transverse_ptr = format_ptr;
	char *print_str;
	float float_print_data;
	uint32_t uint32_print_data; 
	int32_t int32_print_data, width_specifier = 0; 
	uint16_t uint16_print_data; 
	int16_t int16_print_data, num_chars_printed = 0, ret_status;	
    uint8_t width_spec, pad_format, num_digits_after_point, proc_bit_field = 0; 
	char char_print_data;
	char char_in_str_arr[2];
    
    if(print_va_list_ptr == NULL_PTR)
	{
		return EOF;
	}		
	for (; *transverse_ptr != NULL_CHAR; ++transverse_ptr)
	{
		if (*transverse_ptr == '%')
		{
			++transverse_ptr;
			width_spec = pad_format = num_digits_after_point = 0;
			proc_bit_field &= ~(1 << 0); 
			if (*transverse_ptr == NULL_CHAR)
			{
				if(out_str_ptr)
	            {	
                   **out_str_ptr = NULL_CHAR;
	            }
				return num_chars_printed;
			}
			if (*transverse_ptr == '%')
			{
				if((Print_Char (out_str_ptr, *transverse_ptr)) == NULL_CHAR)
				{
					if(out_str_ptr)
	                {	
                       **out_str_ptr = NULL_CHAR;
	                }
					return num_chars_printed;
				}
			    ++num_chars_printed;
				continue;
			}
			if (*transverse_ptr == '-')
			{
				++transverse_ptr;
				pad_format = PAD_RIGHT;
			}
			while (*transverse_ptr == '0')
			{
				++transverse_ptr;
				pad_format |= PAD_ZERO;
			}
			for(; *transverse_ptr >= '0' && *transverse_ptr <= '9';	++transverse_ptr)
			{
			    width_spec *= 10;
			    width_spec += *transverse_ptr - '0';
			    if(width_spec > MAX_WIDTH_SPECIFIER)
			    {
			        width_spec = MAX_WIDTH_SPECIFIER;
			        for(;*transverse_ptr >= '0' && *transverse_ptr <= '9'; ++transverse_ptr);
				    break;
		    	}
			}
			
		    if(*transverse_ptr == '.')
			{
				++transverse_ptr;
				proc_bit_field |= (1 << 0); 
			}
			if((proc_bit_field & (1 << 0) ))
			{
				for(;*transverse_ptr >= '0' && *transverse_ptr <= '9';  ++transverse_ptr)	
			    {
			        num_digits_after_point *= 10;
			        num_digits_after_point += *transverse_ptr - '0';
			        if(num_digits_after_point > MAX_PREC_SPECIFIER)
			        {
			           num_digits_after_point = MAX_PREC_SPECIFIER;
			           for(;*transverse_ptr >= '0' && *transverse_ptr <= '9'; ++transverse_ptr);
				       break;
		        	}
		    	}	
			}
		    if(*transverse_ptr == 'c' )
			{
				/* char are converted to int then pushed on the stack */
				char_print_data = (char) va_arg(*print_va_list_ptr, int32_t);		
		       	char_in_str_arr[0] = char_print_data;
				char_in_str_arr[1] = NULL_CHAR;
				if((ret_status = Print_Str(out_str_ptr, char_in_str_arr, width_spec, pad_format)) == EOF)
				{
					if(out_str_ptr)
	                {	
                       **out_str_ptr = NULL_CHAR;
	                }
				    return num_chars_printed;
				}
				num_chars_printed += ret_status;
				continue;
			}
			if(*transverse_ptr == 's')
			{		
				  print_str = va_arg(*print_va_list_ptr, char *);
				  if((ret_status = Print_Str(out_str_ptr, print_str ? print_str: NULL_PTR, width_spec, pad_format)) == EOF)
				  {
					  if(out_str_ptr)
	                  {	
                         **out_str_ptr = NULL_CHAR;
	                  }
					  return num_chars_printed;
				  } 
				  num_chars_printed += ret_status;
				  continue;
			}
			if(*transverse_ptr == 'b' )
			{
				uint32_print_data = va_arg(*print_va_list_ptr, uint32_t); 
				if((ret_status = Print_Num(out_str_ptr, uint32_print_data, width_spec, BASE_02 | STATE_NO << SIGN_FLAG_BIT_POS | pad_format << PAD_FORMAT_BIT_POS | NUM_CONV_ALPHA_NA << ALPHA_BIT_POS)) == EOF)
				{
					if(out_str_ptr)
	                {	
                       **out_str_ptr = NULL_CHAR;
	                }
				    return num_chars_printed;
				}
				num_chars_printed += ret_status;
				continue;
			}			
			if(*transverse_ptr == 'o' )
			{
				uint32_print_data = va_arg(*print_va_list_ptr, uint32_t); 
				if((ret_status = Print_Num(out_str_ptr, uint32_print_data, width_spec, BASE_08 | STATE_NO << SIGN_FLAG_BIT_POS | pad_format << PAD_FORMAT_BIT_POS | NUM_CONV_ALPHA_NA << ALPHA_BIT_POS)) == EOF)
				{
					if(out_str_ptr)
	                {	
                       **out_str_ptr = NULL_CHAR;
	                }
				    return num_chars_printed;
				}
				num_chars_printed += ret_status;
				continue;
			}
			if(*transverse_ptr == 'x')	
			{   
		        uint32_print_data = va_arg(*print_va_list_ptr, uint32_t); 
		        if((ret_status = Print_Num(out_str_ptr, uint32_print_data, width_spec, BASE_16 | STATE_NO << SIGN_FLAG_BIT_POS | pad_format << PAD_FORMAT_BIT_POS | NUM_CONV_SMALL_ALPHA << ALPHA_BIT_POS)) == EOF)
				{
					if(out_str_ptr)
	                {	
                       **out_str_ptr = NULL_CHAR;
	                }
					return num_chars_printed;
				}
				num_chars_printed += ret_status;
				continue;
			}
			if(*transverse_ptr == 'X')
			{	
		        uint32_print_data = va_arg(*print_va_list_ptr, uint32_t); 
		        if((ret_status = Print_Num (out_str_ptr, uint32_print_data, width_spec, BASE_16 | STATE_NO << SIGN_FLAG_BIT_POS | pad_format << PAD_FORMAT_BIT_POS | NUM_CONV_BIG_ALPHA << ALPHA_BIT_POS )) == EOF)
				{
					if(out_str_ptr)
	                {	
                       **out_str_ptr = NULL_CHAR;
	                }
				    return num_chars_printed;
				}
				 num_chars_printed += ret_status;
				continue;
			}
			if(*transverse_ptr == 'h' )
			{
				++transverse_ptr;
			    switch(*transverse_ptr)
			    {
			        case 'u':
					   uint16_print_data = (uint16_t)va_arg(*print_va_list_ptr, uint32_t); 
				       if((ret_status = Print_Num(out_str_ptr, uint16_print_data, width_spec, BASE_10 | STATE_NO << SIGN_FLAG_BIT_POS | pad_format << PAD_FORMAT_BIT_POS | NUM_CONV_ALPHA_NA << ALPHA_BIT_POS)) == EOF)
				       {
						   if(out_str_ptr)
	                       {	
                             **out_str_ptr = NULL_CHAR;
	                       }
				           return num_chars_printed;
				       }
					break;
					default:
				       int16_print_data = (int16_t)va_arg(*print_va_list_ptr, int32_t); 
				       if((ret_status = Print_Num(out_str_ptr, int16_print_data, width_spec, BASE_10 | STATE_YES << SIGN_FLAG_BIT_POS | pad_format << PAD_FORMAT_BIT_POS | NUM_CONV_ALPHA_NA << ALPHA_BIT_POS)) == EOF)
				       {
						   if(out_str_ptr)
	                       {	
                               **out_str_ptr = NULL_CHAR;
	                       }
				           return num_chars_printed;
				       }
			           --transverse_ptr;
				}
				num_chars_printed += ret_status;
				continue;
			}
			if(*transverse_ptr == 'u' )
			{
				uint32_print_data = va_arg(*print_va_list_ptr, uint32_t); 
				if((ret_status = Print_Num(out_str_ptr, uint32_print_data, width_spec, BASE_10 | STATE_NO << SIGN_FLAG_BIT_POS | pad_format << PAD_FORMAT_BIT_POS | NUM_CONV_ALPHA_NA << ALPHA_BIT_POS)) == EOF)
				{
					 if(out_str_ptr)
	                 {	
                          **out_str_ptr = NULL_CHAR;
	                 }
				   	 return num_chars_printed;
				}
				num_chars_printed += ret_status;
				continue;
			}
			if(*transverse_ptr == 'd' || *transverse_ptr == 'i')
			{	
                 int32_print_data = va_arg(*print_va_list_ptr, int32_t);		
                 if((ret_status = Print_Num(out_str_ptr, int32_print_data, width_spec, BASE_10 | STATE_YES << SIGN_FLAG_BIT_POS | pad_format << PAD_FORMAT_BIT_POS | NUM_CONV_ALPHA_NA << ALPHA_BIT_POS)) == EOF)
				 {
					 if(out_str_ptr)
	                 {	
                          **out_str_ptr = NULL_CHAR;
	                 }
					  return num_chars_printed;
				 }					 
			  	 num_chars_printed += ret_status;
				 continue;
			}
			if(*transverse_ptr == 'f' )
			{
				float_print_data = (float)va_arg(*print_va_list_ptr, double); 
				if(((proc_bit_field & (1 << 0)) == 0))
				{
					//default max digits after point if '.'  operator for max precision spec is not specified
					num_digits_after_point = 6;
				}
				if((ret_status = Print_Float(out_str_ptr, float_print_data, width_spec, num_digits_after_point, BASE_10 | STATE_YES << SIGN_FLAG_BIT_POS | pad_format << PAD_FORMAT_BIT_POS | NUM_CONV_ALPHA_NA << ALPHA_BIT_POS)) == EOF)
				{
					 if(out_str_ptr)
	                 {	
                          **out_str_ptr = NULL_CHAR;
	                 }
				   	 return num_chars_printed;
				}
				num_chars_printed += ret_status;
				continue;
			}
		}
		else
		{
			switch(*transverse_ptr) 
			{
			    case '\\':	
			      if((ret_status = Put_Char('\\')) == NULL_CHAR)
			      {
					 if(out_str_ptr)
	                 {	
                          **out_str_ptr = NULL_CHAR;
	                 }
			         return num_chars_printed;
			      }
			     ++num_chars_printed;  
			    break;
			    case '\'':	
				  if((ret_status = Put_Char('\'')) == NULL_CHAR)
			      {
					 if(out_str_ptr)
	                 {	
                          **out_str_ptr = NULL_CHAR;
	                 }
			   	     return num_chars_printed;
			      }
			      ++num_chars_printed;  
			    break;
			    case '\"':	
				  if((ret_status = Put_Char('\"')) == NULL_CHAR)
			      {
					  if(out_str_ptr)
	                  {	
                          **out_str_ptr = NULL_CHAR;
	                  }
			   	      return num_chars_printed;
			      }
			      ++num_chars_printed;  
			    break;
				case '\n':
				  if((ret_status = Put_Char('\n')) == NULL_CHAR)
			      {
					  if(out_str_ptr)
	                  {	
                          **out_str_ptr = NULL_CHAR;
	                  }
			   	      return num_chars_printed;
			      }
			      ++num_chars_printed;
				break;
			    case '\r':
				   if((ret_status = Put_Char('\r')) == NULL_CHAR)
			       {
					   if(out_str_ptr)
	                  {	
                          **out_str_ptr = NULL_CHAR;
	                  } 
			   	      return num_chars_printed;
			       }
				   ++num_chars_printed;
                break;
                default:
		   	      if((Print_Char (out_str_ptr, *transverse_ptr)) == NULL_CHAR)
			      {
					  if(out_str_ptr)
	                  {	
                          **out_str_ptr = NULL_CHAR;
	                  }
					  return num_chars_printed;
			      }
			      ++num_chars_printed;
			}
		}
	}
	if(out_str_ptr)
	{	
       **out_str_ptr = NULL_CHAR;
	}	
	return num_chars_printed;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Print

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : Print function is similar to printf
                 assuming sizeof(void *) == sizeof(int)   

Func ID        : 01.03 

Bugs           :  
-*------------------------------------------------------------*/
int16_t Print(const char *const format_ptr, ...)
{
	va_list arg;
	int16_t num_chars_printed; 	
	int16_t Print_Data(va_list *const print_va_list_ptr, char **const out_str_ptr, const char *const format_ptr);
	
	if(format_ptr == NULL_PTR)
	{
		return EOF;
	}
	va_start(arg, format_ptr); 
	num_chars_printed = Print_Data(&arg, NULL_PTR, format_ptr);
	va_end(arg);
	return num_chars_printed;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Str_Print

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : Str_Print function is similar to sprintf
                 assuming sizeof(void *) == sizeof(int)   

Func ID        : 01.04 

Bugs           :  
-*------------------------------------------------------------*/
int16_t Str_Print(char *const out_str, const char *const format_ptr, ...)
{
	va_list arg;
	int16_t num_chars_printed;	
	int16_t Print_Data(va_list *const print_va_list_ptr, char **const out_str_ptr, const char *const format_ptr);
	
	if(out_str == NULL_PTR)
	{
		return EOF;
	}
	if(format_ptr == NULL_PTR)
	{
		return EOF;
	}
	va_start(arg, format_ptr); 
	num_chars_printed = Print_Data(&arg, &out_str, format_ptr);
	va_end(arg);
	return num_chars_printed;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : Print_Char

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           :   

Func ID        : 01.05 

Bugs           :  
-*------------------------------------------------------------*/
char Print_Char(char **const out_str_ptr, const char print_char)
{
	char char_proc;
	
	if(out_str_ptr)
	{
		char_proc = print_char;
		**out_str_ptr = char_proc;
		++(*out_str_ptr);
	}
	else 
	{
		char_proc = Put_Char(print_char);
	}
	return char_proc;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Print_Str

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           :   

Func ID        : 01.06 

Bugs           :  
-*------------------------------------------------------------*/
int16_t Print_Str(char **const out_str_ptr, const char *print_str, const uint8_t conf_width_spec, const uint8_t pad_format)
{
	int16_t num_chars_printed = 0;
	int8_t width_spec = conf_width_spec;
    char pad_char = ' ' ;
    const char *print_char_ptr = print_str;
    uint8_t str_len = 0;
	
	if(print_str == NULL_PTR)
	{
		return 0;
	}
	if (width_spec > 0)
	{
		str_len = Str_Len(print_str);
		if(str_len == 0)
		{
			return 0;
		}
		if (str_len >= width_spec) 
		{
			width_spec = 0;
		}
		else 
		{ 
	       width_spec -= str_len;
		}
		if (pad_format & PAD_ZERO) 
		{ 
	        pad_char = '0';
		}
	}
	if (!(pad_format & PAD_RIGHT))
	{
		// pad_format left justified
		for ( ;width_spec > 0; --width_spec)
		{
			if((Print_Char(out_str_ptr, pad_char)) == NULL_CHAR)
			{
				return num_chars_printed;
			}
			++num_chars_printed;
		}
	}
	for ( ;*print_char_ptr; ++print_char_ptr)
	{
		if((Print_Char(out_str_ptr, *print_char_ptr)) == NULL_CHAR)
		{
			return num_chars_printed;
		}
		++num_chars_printed;
	}
	for ( ; width_spec > 0; --width_spec)
	{
		if((Print_Char(out_str_ptr, pad_char)) == NULL_CHAR)
		{
			return num_chars_printed;
		}
		++num_chars_printed;
	}
	return num_chars_printed;
}


/*------------------------------------------------------------*
FUNCTION NAME  : Print_Num

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           :   

Func ID        : 01.06 

Bugs           :  
-*------------------------------------------------------------*/
int16_t Print_Num(char **const out_str_ptr, const int32_t print_num, const uint8_t conf_width_spec, const uint16_t ctrl_flag )
{
	char print_buf[PRINT_BUF_LEN];
	char *cur_print_buf_ptr;
	uint32_t cur_unsign_print_num = (uint32_t)print_num;
	int32_t cur_digit; 
	int16_t num_chars_printed = 0;
    char alpha_start_char;
	uint8_t num_negative_flag = STATE_NO, width_spec = conf_width_spec;
    const uint8_t base = ctrl_flag & 0x1F, sign_flag = (ctrl_flag >> SIGN_FLAG_BIT_POS) & 0x01, 
	   pad_format = (ctrl_flag >> PAD_FORMAT_BIT_POS) & 0x03, alpha_print_flag = (ctrl_flag >> ALPHA_BIT_POS ) & 0x03;
	
	if(print_num == 0)
	{
		print_buf[0] = '0';
		print_buf[1] = NULL_CHAR;
		return Print_Str(out_str_ptr, print_buf, width_spec, pad_format);
	}
	if(sign_flag == STATE_YES && base == BASE_10 && print_num < 0)
	{
		num_negative_flag = STATE_YES;
		cur_unsign_print_num = -print_num;
	}
	if(base > BASE_10)
	{
		switch(alpha_print_flag)
		{
			case NUM_CONV_BIG_ALPHA:
			   alpha_start_char = 'A';
			break;
			case NUM_CONV_SMALL_ALPHA:
			   alpha_start_char = 'a';
			break;
			default:
			  return 0;
		}
	}
	cur_print_buf_ptr = print_buf + PRINT_BUF_LEN - 1;
	*cur_print_buf_ptr = NULL_CHAR;
	while(cur_unsign_print_num)
	{
		cur_digit = cur_unsign_print_num % base;
		if( cur_digit >= 10 )
		{
			cur_digit += alpha_start_char - '0' - 10;
		}
		*--cur_print_buf_ptr = cur_digit + '0';
		cur_unsign_print_num /= base;
	}
	if(num_negative_flag == STATE_YES)
	{
		if( width_spec && (pad_format & PAD_ZERO) ) 
		{
			if((Print_Char(out_str_ptr, '-')) == NULL_CHAR)
			{
				return num_chars_printed;
			}
			++num_chars_printed;
			--width_spec;
		}
		else
		{
			*--cur_print_buf_ptr = '-';
		}
	}
    return num_chars_printed + Print_Str(out_str_ptr, cur_print_buf_ptr, width_spec, pad_format);
}

/*------------------------------------------------------------*
FUNCTION NAME  : Print_Float

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           :   

Func ID        : 01.06 

Bugs           :  
-*------------------------------------------------------------*/
int16_t Print_Float(char **const out_str_ptr, const float print_float, const uint8_t conf_width_spec, const uint8_t conf_num_digits_after_point, const uint16_t ctrl_flag )
{
	char print_buf[PRINT_BUF_LEN];
	char *cur_print_buf_ptr;
	float_ieee_754_format_t result_float;
	float result_float_num;
	uint32_t  cur_unsign_print_num;
    int32_t int_part;	
    float frac_part; 
	int16_t num_chars_printed = 0;
    char alpha_start_char;
	uint8_t proc_bit_field = 0, width_spec = conf_width_spec, cur_digit;
    const uint8_t base = ctrl_flag & 0x1F, sign_flag = (ctrl_flag >> SIGN_FLAG_BIT_POS) & 0x01, 
	   pad_format = (ctrl_flag >> PAD_FORMAT_BIT_POS) & 0x03, alpha_print_flag = (ctrl_flag >> ALPHA_BIT_POS ) & 0x03;
	int8_t num_digits_after_point = conf_num_digits_after_point;
	
	if(base > BASE_10)
	{
		switch(alpha_print_flag)
		{
			case NUM_CONV_BIG_ALPHA:
			   alpha_start_char = 'A';
			break;
			case NUM_CONV_SMALL_ALPHA:
			   alpha_start_char = 'a';
			break;
			default:
			  return 0;
		}
	}
	if((Real_Val_To_IEEE_754_float(print_float, &result_float)) != SUCCESS)
	{
		return 0;
	}
	if((IEEE_754_float_To_Real_Val(&result_float, &result_float_num)) != SUCCESS)
	{
		return 0;
	}
	memset(print_buf, NULL_CHAR, PRINT_BUF_LEN);
	cur_print_buf_ptr = print_buf + PRINT_BUF_LEN - 1;
	*cur_print_buf_ptr = NULL_CHAR;
	int_part = (int32_t)result_float_num;		
	if(num_digits_after_point != 0)
	{
		frac_part = result_float_num - (float)int_part; 
	    if(frac_part < 0)
        {
          frac_part = -frac_part;
        }
	    frac_part = frac_part * (float)Power_Of(base, num_digits_after_point); 
	    cur_unsign_print_num = (int32_t)frac_part;
    	while(num_digits_after_point != 0)
	    {
		   cur_digit = cur_unsign_print_num % base;
		   if( cur_digit >= 10 )
		   {
		    	cur_digit += alpha_start_char - '0' - 10;
		   }
		    *--cur_print_buf_ptr = cur_digit + '0';
	       cur_unsign_print_num /= base;
		   --num_digits_after_point;		   
	    }
	     *--cur_print_buf_ptr = '.';
	}
	if(sign_flag == STATE_YES && base == BASE_10 && result_float.raw_ieee_754_format.raw.sign == 1)
	{
		// negative 
		proc_bit_field |= (1 << 0);
		cur_unsign_print_num = -int_part;
	}	
    else
    {
    	cur_unsign_print_num = int_part;
	}
    if(cur_unsign_print_num == 0)
	{
		*--cur_print_buf_ptr = '0';
	}		
	while(cur_unsign_print_num)
	{
		cur_digit = cur_unsign_print_num % base;
		if( cur_digit >= 10 )
		{
			cur_digit += alpha_start_char - '0' - 10;
		}
		*--cur_print_buf_ptr = cur_digit + '0';
		cur_unsign_print_num /= base;
	}	
	if((proc_bit_field & (1 << 0)))
	{
		// negative 
		if( width_spec && (pad_format & PAD_ZERO) ) 
		{
			if((Print_Char(out_str_ptr, '-')) == NULL_CHAR)
			{
				return num_chars_printed;
			}
			++num_chars_printed;
			--width_spec;
		}
		else
		{
			*--cur_print_buf_ptr = '-';
		}
	}
   	return num_chars_printed + Print_Str(out_str_ptr, cur_print_buf_ptr, width_spec, pad_format); 
}

/*------------------------------------------------------------*
FUNCTION NAME  : Put_Char

DESCRIPTION    : Put_Char() operation is similar to putchar()
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 10.19 

Bugs           :  
-*------------------------------------------------------------*/
char Put_Char(const char to_disp_char)
{
    char displayed_char;
	displayed_char = putchar(to_disp_char);
	return displayed_char;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Str_Len

DESCRIPTION    :
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 02.05  

BUGS           :  
-*------------------------------------------------------------*/
uint8_t Str_Len(const char *const str)
{
    uint8_t num_chars = 0;
	
	  if(str == NULL_PTR)
	  {
		  return 0;
	  }
    while(*(str + num_chars))
	{
		++num_chars;
	}
    return num_chars;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Power_Of

DESCRIPTION    :
								
INPUT          :

OUTPUT         : 

NOTE           : 

Func ID        : 02.10 

Bugs           :   
-*------------------------------------------------------------*/
uint32_t Power_Of(const uint8_t base, const uint8_t power )
{
    uint32_t power_val = 1;
    uint8_t i = 0;
  
    if(power == 0)
    {
       return 1;
    }
    for(i = 1; i <= power; ++i)
    {
      power_val *= base;
    }
    return power_val;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Real_Val_To_IEEE_754_float

DESCRIPTION    : convert a real value to IEEE 754 floating point representaion 
								
INPUT          : 

OUTPUT         : 

NOTE           : single precision IEEE 754 floating point rep

Func ID        : 01.01 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Real_Val_To_IEEE_754_float(const float src_float_num, float_ieee_754_format_t *const result_float_ptr)
{
	int8_t float_bit_index;
     
    if(result_float_ptr == NULL_PTR)
	{
		return FAILURE;
	}
	result_float_ptr->raw_ieee_754_format.float_num = src_float_num;
	result_float_ptr->ieee_754_format = 0;
    float_bit_index = FLOATBITS - 1;
	//sign_bit part
    PUT_BIT((*result_float_ptr), float_bit_index);
    result_float_ptr->raw_ieee_754_format.raw.sign  = (result_float_ptr->ieee_754_format >> 31) & 0x01;
   // exponient part
    for(float_bit_index--; float_bit_index >= 23; float_bit_index--)
	{
        PUT_BIT((*result_float_ptr), float_bit_index);
    }
	result_float_ptr->raw_ieee_754_format.raw.exponient = (result_float_ptr->ieee_754_format >> 23) & 0xFF;
	//mantissa part
    for(; float_bit_index  >= 0; float_bit_index--)
	{
        PUT_BIT((*result_float_ptr), float_bit_index);
    }
	result_float_ptr->raw_ieee_754_format.raw.mantissa = (result_float_ptr->ieee_754_format) & 0x7FFFFF;
	//printf("IEEE rep : 0x%X \n", result_float_ptr->ieee_754_format);
	return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : IEEE_754_Float_Raw_To_Int

DESCRIPTION    : convert a raw IEEE float rep to the corresponding integer
								
INPUT          : 

OUTPUT         : 

NOTE           : single precision IEEE 754 floating point rep

Func ID        : 01.01 

Bugs           :  
-*------------------------------------------------------------*/
uint32_t IEEE_754_Float_Raw_To_Int(const uint32_t ieee_754_float_format, const uint8_t low, const uint8_t high) 
{ 
    uint32_t float_to_int = 0, i; 
	
    for (i = high; i >= low; i--)
	{ 
        float_to_int = float_to_int + ((ieee_754_float_format >> (31 - i)) & 0x01) * Power_Of(BASE_02, high - i); 
    } 
    return float_to_int; 
} 

/*------------------------------------------------------------*
FUNCTION NAME  : IEEE_754_float_To_Real_Val

DESCRIPTION    : convert IEEE 754 floating point representation into real value 
								
INPUT          : 

OUTPUT         : 

NOTE           : single precision IEEE 754 floating point rep

Func ID        : 01.01 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t IEEE_754_float_To_Real_Val(const float_ieee_754_format_t *const src_float_ptr, float *const result_float_num_ptr)
{
	float_ieee_754_format_t result_float;
	uint32_t float_in_int;
	
	if(src_float_ptr == NULL_PTR || result_float_num_ptr == NULL_PTR)
	{
		return FAILURE;
	}
    // Convert mantissa part (23 bits) to corresponding decimal integer 
     float_in_int = IEEE_754_Float_Raw_To_Int(src_float_ptr->ieee_754_format, 9, 31); 
  
    // Assign integer representation of mantissa 
    result_float.raw_ieee_754_format.raw.mantissa = float_in_int; 
  
    // Convert the exponent part (8 bits) to a corresponding decimal integer 
    float_in_int = IEEE_754_Float_Raw_To_Int(src_float_ptr->ieee_754_format, 1, 8); 
  
    // Assign integer representation of the exponent 
    result_float.raw_ieee_754_format.raw.exponient = float_in_int; 
  
    // Assign sign bit 
    result_float.raw_ieee_754_format.raw.sign = ((src_float_ptr->ieee_754_format >> 31) & 0x01 ); 
    memcpy(result_float_num_ptr, &result_float.raw_ieee_754_format.float_num, sizeof(float));
	//printf("Float val of IEEE-754 representation is : %f \n",  *result_float_num_ptr ); 
    return SUCCESS;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Str_Reverse

DESCRIPTION    : reverses a string 'str' of length 'len'
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.01 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Str_Reverse(char *const str, const uint8_t len) 
{ 
    uint8_t i = 0, j = len - 1;
    char temp;
 	
	if(str == NULL_PTR)
	{
		return FAILURE;
	}
    while (i < j) 
    { 
        temp = str[i]; 
        str[i] = str[j]; 
        str[j] = temp; 
        ++i; 
		--j; 
    } 
	return SUCCESS;
} 	

/*------------------------------------------------------------*
FUNCTION NAME  : Int_To_Str

DESCRIPTION    : Converts a given integer num to string str_ptr. 
                 req_num_digits is the number of digits required in output. 
				 If req_num_digits is more than the number of digits in num, 
				 then 0s are added at the beginning. 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.01 

Bugs           :  
-*------------------------------------------------------------*/
int16_t Int_To_Str(const int32_t num, char *const str_ptr, const uint8_t req_num_digits) 
{ 
    uint32_t cur_num; 
    uint8_t str_len = 0; 
	
	if(str_ptr == NULL_PTR)
	{
		return -1;
	}
	if(num < 0)
	{
		cur_num = -num;		
	}
	else
	{
		cur_num = num;
	}
    while (cur_num) 
    { 
        str_ptr[str_len++] = (cur_num % BASE_10) + '0'; 
        cur_num = cur_num / BASE_10; 
    } 
    // If number of digits required is more, then add 0s at the beginning 
    while (str_len < req_num_digits)
	{		
        str_ptr[str_len++] = '0'; 
	}
    if(num < 0)
    {
     	str_ptr[str_len++] = '-';
    }
    if((Str_Reverse(str_ptr, str_len)) != SUCCESS)
	{
		return -1;
	}			
    str_ptr[str_len] = NULL_CHAR; 
    return str_len; 
}
 
/*------------------------------------------------------------*
FUNCTION NAME  : Double_To_Str_Conv

DESCRIPTION    :  Converts a floating point number to string. 
								
INPUT          : 

OUTPUT         : 

NOTE           : Double_To_Str_Conv() function is similar to ftoa()

Func ID        : 01.01 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Double_To_Str_Conv(const double double_num, char *const double_to_str, uint8_t num_digits_after_point) 
{ 
    // Extract integer part 
     int32_t int_part = (int32_t)double_num; 
  
    // Extract frac part 
    double frac_part = double_num - (double)int_part; 
  
    // convert integer part to string 
    int16_t int_part_str_len, frac_part_str_len ; 
    
    memset(double_to_str, NULL_CHAR, 1);
  	if(double_to_str == NULL_PTR)
	{
		return FAILURE;
	}
	if(num_digits_after_point > MAX_PREC_SPECIFIER)
	{
		num_digits_after_point = MAX_PREC_SPECIFIER;
	}
	if((int_part_str_len = Int_To_Str(int_part, double_to_str, 0)) <= 0)
	{		
		return FAILURE;
	}
	// check for display option after point 
    if(num_digits_after_point != 0) 
    { 
        double_to_str[int_part_str_len] = '.';  // add dot 
  
        // Get the value of fraction part upto given no. of points after dot.
        // The third parameter is needed to handle cases like 233.007 
        if(frac_part < 0)
        {
        	frac_part = -frac_part;
		}
		
        frac_part = frac_part * (double)Power_Of(BASE_10, num_digits_after_point); 
        if((frac_part_str_len = Int_To_Str((int32_t)frac_part, double_to_str + int_part_str_len + 1, num_digits_after_point)) <= 0)
		{
			return FAILURE;
		}
    } 
     printf("\nint_part: %d, frac_part: %f, int_part_str: %u, frac_part_in_str: %u\n",int_part, frac_part, int_part_str_len, frac_part_str_len);
    return SUCCESS;
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Str_To_Double_Conv

DESCRIPTION    :  Converts a string to floating point number. 
								
INPUT          : 

OUTPUT         : 

NOTE           : Str_To_Double_Conv() function is similar to atof().
                 float in str is in base 10 and converted float is in base 10.  

Func ID        : 01.01 

Bugs           :  
-*------------------------------------------------------------*/
double Str_To_Double_Conv(const char *const double_to_str) 
{
     double integerPart = 0;
     double fractionPart = 0;
	 int32_t divisorForFraction = 1;
     int8_t sign = 1;
     uint8_t inFraction = STATE_NO;
	 const char *cur_float_str_pos_ptr  = double_to_str;
	 
	 if(cur_float_str_pos_ptr == NULL_PTR)
	 {
         return 0.0;
	 }		 
     /*Take care of +/- sign*/
     if (*cur_float_str_pos_ptr == '-')
     {
         ++cur_float_str_pos_ptr;
         sign = -1;
     }
     else if (*cur_float_str_pos_ptr == '+')
     {
         ++cur_float_str_pos_ptr;
     }
     while (*cur_float_str_pos_ptr != NULL_CHAR)
     {
         if (*cur_float_str_pos_ptr >= '0' && *cur_float_str_pos_ptr <= '9')
         {
             if (inFraction == STATE_YES)
             {
                 /*See how are we converting a character to integer*/
                 fractionPart = fractionPart * BASE_10 + (*cur_float_str_pos_ptr - '0');
                 divisorForFraction *= BASE_10;
             }
             else
             {
                 integerPart = integerPart * BASE_10 + (*cur_float_str_pos_ptr - '0');
             }
         }
         else if (*cur_float_str_pos_ptr == '.')
         {
             if (inFraction == STATE_YES)
                 return sign * (integerPart + fractionPart/divisorForFraction);
             else
                 inFraction = STATE_YES;
         }
         else
         {
             return sign * (integerPart + fractionPart/divisorForFraction);
         }
         ++cur_float_str_pos_ptr;
     }
     return sign * (integerPart + fractionPart/divisorForFraction);
} 

/*------------------------------------------------------------*
FUNCTION NAME  : Get_Char

DESCRIPTION    : Get_Char() operation is similar to getchar()
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 04.19 

Bugs           :  
-*------------------------------------------------------------*/
char Get_Char(void)
{
	char last_read_char , disp_char;
		
	last_read_char = getchar();
	if(last_read_char == NULL_CHAR)
	{
		return NULL_CHAR;
	}
	if((disp_char = Put_Char(last_read_char)) == NULL_CHAR)
	{
		return NULL_CHAR;
	}
	return last_read_char;
}

/*------------------------------------------------------------*
FUNCTION NAME  : Get_Str

DESCRIPTION    : Get_Str() operation is similar to gets()
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 04.20 

Bugs           :  
-*------------------------------------------------------------*/
char *Get_Str(char *const get_str)
{
	static char read_str[MAX_STREAM_BUFFER_SIZE];
    char last_read_char = NULL_CHAR, disp_char;
	uint8_t num_chars_read_str = 0;	
	
	memset(read_str, NULL_CHAR, MAX_STREAM_BUFFER_SIZE);
    do
	{
        last_read_char = getchar();
		if(last_read_char != NULL_CHAR && last_read_char != EOF )
		{
		   if((Put_Char(last_read_char)) == NULL_CHAR)
		   {
			   return NULL_PTR;
		   }
		   if(num_chars_read_str + 1 < MAX_STREAM_BUFFER_SIZE && last_read_char != BACKSPACE_CHAR && last_read_char != ENTER_CHAR)
		   {
			   read_str[num_chars_read_str] = last_read_char;
			   ++num_chars_read_str;
			   read_str[num_chars_read_str] = NULL_CHAR;
		   }
		   else
		   {
			   if(last_read_char == BACKSPACE_CHAR && num_chars_read_str > 0 )
			   {
				   --num_chars_read_str;
				   read_str[num_chars_read_str] = NULL_CHAR;				   
			   }
		   }
		}			
	}
    while(last_read_char != ENTER_CHAR && last_read_char != EOF);
	memcpy(get_str, read_str, MAX_STREAM_BUFFER_SIZE); 
	return read_str;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : Init_IO_File

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : 

Func ID        : 01.01 

Bugs           :  
-*------------------------------------------------------------*/
uint16_t Init_IO_File(io_file_t *const file_ptr, const uint8_t file_desp, const uint8_t device_type, const uint8_t stream_type, const uint8_t stream_io_type)
{
	if(file_ptr == NULL_PTR)
	{
		return FAILURE;
	}
	if(device_type >= DEVICE_NA)
	{
		return FAILURE;
	}
	if(stream_type > STREAM_TYPE_SOCKET)
	{
		return FAILURE;
	}
	if(stream_io_type > STREAM_IO_BOTH)
	{
		return FAILURE;
	}
	memset(file_ptr->stream_buf, NULL_CHAR, MAX_STREAM_BUFFER_SIZE + 1);
	file_ptr->num_chars_stream_buf = 0;
	file_ptr->cur_buf_pos = 0;
	file_ptr->device_type = device_type;
	file_ptr->stream_type = stream_type;
	file_ptr->stream_io_type = stream_io_type;
	file_ptr->file_desp = file_desp;
	return SUCCESS;
		
}
/*------------------------------------------------------------*
FUNCTION NAME  : File_Get_Char

DESCRIPTION    : get char from stream
								
INPUT          : 

OUTPUT         : 

NOTE           : File_Get_Char operation is similar to fgetc()

Func ID        : 04.20 

Bugs           :  
-*------------------------------------------------------------*/
char File_Get_Char(io_file_t *const fp)
{
	char get_char;
	
	if(fp == NULL_PTR)
	{
		return (EOF);
	}	
	if (Read_Oper(fp, &get_char, 1) == 0)
	{
		return (EOF);
	}
	return (get_char);
}

/*------------------------------------------------------------*
FUNCTION NAME  : Read_Oper

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : Read operation is similar to read() in linux

Func ID        : 04.20 

Bugs           :  
-*------------------------------------------------------------*/
uint8_t Read_Oper(io_file_t *const fp, char *const out_buf_ptr, const uint8_t max_num_chars_to_read)
{
	char *out_buf_pos_ptr = out_buf_ptr;
	uint8_t num_chars_read = 0, before_cur_buf_pos;
	
	if(out_buf_ptr == NULL_PTR || fp == NULL_PTR)
	{
		return 0;
	}
    if(fp->stream_io_type != STREAM_IO_INPUT && fp->stream_io_type != STREAM_IO_BOTH)
	{
		return 0;
	}
	if(fp->file_desp == 0)
	{
		// stdin_keyboard
		*out_buf_ptr =  Get_Char();
		if(*out_buf_ptr == NULL_CHAR)
		{
			return 0;
		}
		num_chars_read = 1;
	}
	else
	{
	    if(fp->num_chars_stream_buf == 0)
	    {
	    	return 0;
    	}	
	   before_cur_buf_pos = fp->cur_buf_pos;
	   for(num_chars_read = 0; num_chars_read < max_num_chars_to_read; ++num_chars_read)
	   {
	    	if(fp->cur_buf_pos + 1 == fp->num_chars_stream_buf)
		    {
		    	break;
		    }
		    *out_buf_pos_ptr++ = fp->stream_buf[fp->cur_buf_pos++];		 
	   }
	   out_buf_pos_ptr = NULL_CHAR;
	   if(fp->stream_type == STREAM_TYPE_IO)
	   {
	    	memset(fp->stream_buf + before_cur_buf_pos, NULL_CHAR, num_chars_read);
		    fp->num_chars_stream_buf = 0;
		    fp->cur_buf_pos = 0;
	   }
	}
    return num_chars_read;	
}

/*------------------------------------------------------------*
FUNCTION NAME  : File_Get_Str

DESCRIPTION    : get string from stream
								
INPUT          : 

OUTPUT         : 

NOTE           : File_Get_Str() operation is similiar to fgets()

Func ID        : 04.20 

Bugs           :  
-*------------------------------------------------------------*/
char *File_Get_Str(char *const dst_str_ptr, const uint8_t max_chars_to_get, io_file_t *const fp)
{
	char get_char;
	char *char_ptr;
    uint8_t num_chars_got;
	/* get max bytes or upto a newline */

	if(fp == NULL_PTR)
	{
		return (NULL_PTR);
	}
	for (char_ptr = dst_str_ptr, num_chars_got = 0; num_chars_got < max_chars_to_get; ++num_chars_got)
	{
		if ((get_char =  File_Get_Char(fp)) == EOF)
		{
			break;
		}
		*char_ptr++ = get_char;
		if(get_char == ENTER_CHAR)
		{
			break;
		}
	}
	*char_ptr = NULL_CHAR;
	if (char_ptr == dst_str_ptr)
	{
		return (NULL_PTR);
	}
	return (char_ptr);
}

/*------------------------------------------------------------*
FUNCTION NAME  : Scan

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : Scan() operation is similar to scanf()

Func ID        : 04.20 

Bugs           :  
-*------------------------------------------------------------*/		    			    
int16_t Scan(const char *const fmt, ...)
{
	va_list ap;
	int16_t count;
	
	if(fmt == NULL_PTR)
	{
		return EOF;
	}
	va_start(ap, fmt);
    count = File_Scan(&stdin_keyboard, fmt, ap);
	va_end(ap);
	return(count);
}

/*------------------------------------------------------------*
FUNCTION NAME  : vfscanf

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           :

Func ID        : 04.20 

Bugs           :  
-*------------------------------------------------------------*/
int16_t File_Scan(io_file_t *const fp, const char *const fmt, va_list ap)
{
    int16_t    count;
    char       buf[MAX_STREAM_BUFFER_SIZE + 1];

    if (File_Get_Str(buf, MAX_STREAM_BUFFER_SIZE , fp) == 0)
	{
	    return (EOF);
	}
    count =  Scan_Data(buf, fmt, ap);
    return (count);
}
/*------------------------------------------------------------*
FUNCTION NAME  : Str_Scan

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : Str_Scan() operation is similar to sscanf()

Func ID        : 04.20 

Bugs           :  
-*------------------------------------------------------------*/		    			    
int16_t Str_Scan(const char *const ibuf, const char *const fmt, ...)
{
	va_list ap;
	int16_t ret_status;
	
	if(ibuf == NULL_PTR || *ibuf == NULL_CHAR)
	{
		return EOF;
	}
	if(fmt == NULL_PTR)
	{
		return EOF;
	}
	va_start(ap, fmt);
	ret_status = Scan_Data(ibuf, fmt, ap);
	va_end(ap);
	return(ret_status);
}

/*------------------------------------------------------------*
FUNCTION NAME  : Scan_Data

DESCRIPTION    : 
								
INPUT          : 

OUTPUT         : 

NOTE           : Scan_Data() operation is similar to vsscanf()

Func ID        : 04.20 

Bugs           :  
-*------------------------------------------------------------*/
int16_t Scan_Data(const char *inp, const char  *const fmt0, va_list ap)
{
	long double long_double_num;
	double double_num;
	float float_num;
	int inr;
	const char *fmt = (const char *)fmt0;
	int c;			/* character from format, or conversion */
	size_t width;		/* field width, or 0 */
	char *p;		/* points into all kinds of strings */
	int n;			/* handy integer */
	int flags;		/* flags as defined above */
	char *p0;		/* saves original value of p when necessary */
	int nassigned;		/* number of fields assigned */
	int nconversions;	/* number of conversions */
	int nread;		/* number of characters consumed from fp */
	int base;		/* base argument to conversion function */
	char ccltab[256];	/* character class table for %[...] */
	char buf[MAX_STREAM_BUFFER_SIZE];		/* buffer for numeric conversions */     
	/* `basefix' is used to avoid `if' tests in the integer scanner */
	static short basefix[17] =
		{ 10, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16 };
    int8_t num_digits_after_point, num_digits_before_point, num_chars_in_buf = 0; 
	
	inr = strlen(inp);
	
	nassigned = 0;
	nconversions = 0;
	nread = 0;
	base = 0;		/* XXX just to keep gcc happy */
	for (;;)
	{
		c = *fmt++;
		if (c == 0)
			return (nassigned);
		if (isspace(c))
		{
			while (inr > 0 && isspace(*inp))
			{
				nread++, inr--, inp++;
			}
			continue;
		}
		if (c != '%')
			goto literal;
		width = 0;
		flags = 0;
		/*
		 * switch on the format.  continue if done;
		 * break once format type is derived.
		 */
again:		c = *fmt++;
		switch (c)
		{
		case '%':
literal:
			if (inr <= 0)
				goto input_failure;
			if (*inp != c)
				goto match_failure;
			inr--, inp++;
			nread++;
			continue;

		case '*':
			flags |= SUPPRESS;
			goto again;
		case 'l':
			if (flags & LONG)
			{
				flags &= ~LONG;
				flags |= LONGLONG;
			}
			else
				flags |= LONG;
			goto again;
		case 'L':
        	flags |= LONGLONG;	
			goto again;	
		case 'q':
			flags |= LONGLONG;	/* not quite */
			goto again;
		case 'h':
			if (flags & SHORT)
			{
				flags &= ~SHORT;
				flags |= SHORTSHORT;
			}
			else
				flags |= SHORT;
			goto again;

		case '0': case '1': case '2': case '3': case '4':
		case '5': case '6': case '7': case '8': case '9':
			width = width * 10 + c - '0';
			goto again;

		/*
		 * Conversions.
		 */
		case 'd':
			c = CT_INT;
			base = 10;
			break;

		case 'i':
			c = CT_INT;
			base = 0;
			break;

		case 'o':
			c = CT_INT;
			flags |= UNSIGNED;
			base = 8;
			break;

		case 'u':
			c = CT_INT;
			flags |= UNSIGNED;
			base = 10;
			break;

		case 'X':
		case 'x':
			flags |= PFXOK;	/* enable 0x prefixing */
			c = CT_INT;
			flags |= UNSIGNED;
			base = 16;
			break;
		case 's':
			c = CT_STRING;
			break;
        case 'f':
		    c = CT_REAL;
			flags |= REAL;
			base = 10;			
        break;		
		case '[':
			fmt = Scan_Input_Limit_Chars(ccltab, fmt);
			flags |= NOSKIP;
			c = CT_CCL;
			break;

		case 'c':
			flags |= NOSKIP;
			c = CT_CHAR;
			break;

		case 'p':	/* pointer format is like hex */
			flags |= POINTER | PFXOK;
			c = CT_INT;
			flags |= UNSIGNED;
			base = 16;
			break;

		case 'n':
			nconversions++;
			if (flags & SUPPRESS)	/* ??? */
				continue;
			if (flags & SHORTSHORT)
				*va_arg(ap, char *) = nread;
			else if (flags & SHORT)
				*va_arg(ap, short *) = nread;
			else if (flags & LONG)
				*va_arg(ap, long *) = nread;
			else if (flags & LONGLONG)
				*va_arg(ap, long long *) = nread;
			else
				*va_arg(ap, int *) = nread;
			continue;
		}

		/*
		 * We have a conversion that requires input.
		 */
		if (inr <= 0)
			goto input_failure;

		/*
		 * Consume leading white space, except for formats
		 * that suppress this.
		 */
		if ((flags & NOSKIP) == 0)
		{
			while (isspace(*inp))
			{
				nread++;
				if (--inr > 0)
					inp++;
				else 
					goto input_failure;
			}
			/*
			 * Note that there is at least one character in
			 * the buffer, so conversions that do not set NOSKIP
			 * can no longer result in an input failure.
			 */
		}

		/*
		 * Do the conversion.
		 */
		switch (c)
		{

		   case CT_CHAR:
			/* scan arbitrary characters (sets NOSKIP) */
			if (width == 0)
				width = 1;
			if (flags & SUPPRESS)
			{
				memset(va_arg(ap, char *), NULL_CHAR , 1);
				size_t sum = 0;				
				for (;;)
				{
					if ((n = inr) < (int)width)
					{
						sum += n;
						width -= n;
						inp += n;
						if (sum == 0)
							goto input_failure;
						break;
					} 
					else
					{
						sum += width;
						inr -= width;
						inp += width;
						break;
					}
				}
				nread += sum;
			} 
			else
			{
				memcpy(va_arg(ap, char *), inp, width);
				inr -= width;
				inp += width;
				nread += width;
				nassigned++;
			}
			nconversions++;
			break;

		case CT_CCL:
			/* scan a (nonempty) character class (sets NOSKIP) */
	    	/*	
			   if (width == 0)
				width = (size_t)~0; // size is infinity 
			*/
			if (width == 0 || width > sizeof(buf) - 1)
				width = sizeof(buf) - 1;
			/* take only those things in the class */
			if (flags & SUPPRESS)
			{
				n = 0;	
				memset(va_arg(ap, char *), NULL_CHAR, 1);			
				while (ccltab[(unsigned char)*inp])
				{
					n++, inr--, inp++;
					if (--width == 0)
					{
						break;
					}
					if (inr <= 0)
					{
						if (n == 0)
							goto input_failure;					    						   
						break;
					}
				}
				if (n == 0)
					goto match_failure;					
			}
			else
			{
				p0 = p = va_arg(ap, char *);
				while (ccltab[(unsigned char)*inp])
				{
					inr--;
					*p++ = *inp++;
					if (--width == 0)
						break;
					if (inr <= 0)
					{
						if (p == p0)
							goto input_failure;
						break;
					}
				}
				n = p - p0;
				if (n == 0)
					goto match_failure;
				*p = 0;
				nassigned++;
			}
			nread += n;
			nconversions++;
			break;
		case CT_STRING:
			/* like CCL, but zero-length string OK, & no NOSKIP */
	 	/*	
		    if (width == 0)
				width = (size_t)~0; // size is infinity
		*/
		   	if (width == 0 || width > sizeof(buf) - 1)
				width = sizeof(buf) - 1;	
			if (flags & SUPPRESS)
			{
				n = 0;
				memset(va_arg(ap, char *), NULL_CHAR, 1);
				while (!isspace(*inp))
				{
					n++, inr--, inp++;
					if (--width == 0)
						break;
					if (inr <= 0)
						break;
				}
				nread += n;
			}
			else
			{
				p0 = p = va_arg(ap, char *);
				while (!isspace(*inp))
				{
					inr--;
					*p++ = *inp++;
					if (--width == 0)
						break;
					if (inr <= 0)
						break;
				}
				*p = NULL_CHAR;
				nread += p - p0;
				nassigned++;
			}
			nconversions++;
			continue;
			
		case CT_INT:
			/* scan an integer as if by the conversion function */
/*#ifdef hardway
			if (width == 0 || width > sizeof(buf) - 1)
				width = sizeof(buf) - 1;
#else
			// size_t is unsigned, hence this optimisation 
			if (--width > sizeof(buf) - 2)
				width = sizeof(buf) - 2;
			width++;
#endif */
           if (width == 0 || width > MAX_WIDTH_SPECIFIER)
				width = MAX_WIDTH_SPECIFIER;
			memset(buf, NULL_CHAR, MAX_STREAM_BUFFER_SIZE);
           	flags |= SIGNOK | NDIGITS | NZDIGITS;
			for (p = buf; width; width--)
			{
				c = *inp;
				/*
				 * Switch on the character; `goto int_ok'
				 * if we accept it as a part of number.
				 */
				switch (c)
				{

				/*
				 * The digit 0 is always legal, but is
				 * special.  For %i conversions, if no
				 * digits (zero or nonzero) have been
				 * scanned (only signs), we will have
				 * base==0.  In that case, we should set
				 * it to 8 and enable 0x prefixing.
				 * Also, if we have not scanned zero digits
				 * before this, do not turn off prefixing
				 * (someone else will turn it off if we
				 * have scanned any nonzero digits).
				 */
				case '0':
					if (base == 0)
					{
						base = BASE_08;
						flags |= PFXOK;
					}
					if (flags & NZDIGITS)
					    flags &= ~(SIGNOK|NZDIGITS|NDIGITS);
					else
					    flags &= ~(SIGNOK|PFXOK|NDIGITS);
					goto int_ok;

				/* 1 through 7 always legal */
				case '1': case '2': case '3':
				case '4': case '5': case '6': case '7':
					base = basefix[base];
					flags &= ~(SIGNOK | PFXOK | NDIGITS);
					goto int_ok;

				/* digits 8 and 9 ok if decimal or hex */
				case '8': case '9':
					base = basefix[base];
					if (base <= BASE_08)
						break;	/* not legal here */
					flags &= ~(SIGNOK | PFXOK | NDIGITS);
					goto int_ok;

				/* letters ok if hex */
				case 'A': case 'B': case 'C':
				case 'D': case 'E': case 'F':
				case 'a': case 'b': case 'c':
				case 'd': case 'e': case 'f':
					/* no need to fix base here */
					if (base <= BASE_10)
						break;	/* not legal here */
					flags &= ~(SIGNOK | PFXOK | NDIGITS);
					goto int_ok;

				/* sign ok only as first character */
				case '+': case '-':
					if (flags & SIGNOK)
					 {
						flags &= ~SIGNOK;
						goto int_ok;
					}
					break;

				/* x ok if flag still set & 2nd char */
				case 'x': case 'X':
					if (flags & PFXOK && p == buf + 1)
					 {
						base = 16;	/* if %i */
						flags &= ~PFXOK;
						goto int_ok;
					}
					break;
				}

				/*
				 * If we got here, c is not a legal character
				 * for a number.  Stop accumulating digits.
				 */
				break;
		int_ok:
				/*
				 * c is legal: store it and look at the next.
				 */
				*p++ = c;
				if (--inr > 0)
					inp++;
				else 
					break;		/* end of input */
			}
			/*
			 * If we had only a sign, it is no good; push
			 * back the sign.  If the number ends in `x',
			 * it was [sign] '0' 'x', so push back the x
			 * and treat it as [sign] '0'.
			 */
			if (flags & NDIGITS)
			 {
				if (p > buf)
				{
					inp--;
					inr++;
				}
				goto match_failure;
			}
			c = ((char *)p)[-1];
			if (c == 'x' || c == 'X')
			 {
				--p;
				inp--;
				inr++;
			}
			if (flags & SUPPRESS)
			{
				if (flags & POINTER)
					*va_arg(ap, void **) = NULL_PTR;
				else if (flags & SHORTSHORT)
					*va_arg(ap, char *) = NULL_CHAR;
				else if (flags & SHORT)
					*va_arg(ap, short *) = 0;
				else if (flags & LONG)
					*va_arg(ap, long *) = 0;
				else if (flags & LONGLONG)
					*va_arg(ap, long long *) = 0;
				else
					*va_arg(ap, int *) = 0;
				
			}
			else
			{
			    u_quad_t res;

				*p = NULL_CHAR;
				if (flags & UNSIGNED) 
					 res = strtoul(buf, (char **)NULL, base);				   
				else
				    res = strtoq(buf, (char **)NULL, base);
				if (flags & POINTER)
					*va_arg(ap, void **) = (void *)(uintptr_t)res;
				else if (flags & SHORTSHORT)
					*va_arg(ap, char *) = res;
				else if (flags & SHORT)
					*va_arg(ap, short *) = res;
				else if (flags & LONG)
					*va_arg(ap, long *) = res;
				else if (flags & LONGLONG)
					*va_arg(ap, long long *) = res;
				else
					*va_arg(ap, int *) = res;
				nassigned++; 	
			}
			nread += p - buf;
			nconversions++;
		break;
        case CT_REAL:
		     if (width == 0 || width > MAX_WIDTH_SPECIFIER + 1 + MAX_PREC_SPECIFIER)				 
				width = MAX_WIDTH_SPECIFIER +  1 + MAX_PREC_SPECIFIER;
			num_digits_after_point = 0;
			num_digits_before_point = 0;
			num_chars_in_buf = 0;
			memset(buf, NULL_CHAR, MAX_STREAM_BUFFER_SIZE);
			flags |= SIGNOK | DPTOK |NDIGITS| NZDIGITS;
			for (p = buf; width; width--)
			{
				c = *inp;
				switch(c)
				{
					case '0': case '1':	case '2': case '3':
				    case '4': case '5': case '6': case '7':	
                    case '8': case '9':	
					  if(flags & NZDIGITS)
					  {
					      flags &= ~(SIGNOK | NDIGITS | NZDIGITS);						  
					  }
					  if(flags & DPTOK)
					  {
					  	 if(++num_digits_before_point > MAX_WIDTH_SPECIFIER)
						 {
							  goto match_failure;  							  
						 }
                         else
						 {
							  buf[num_chars_in_buf++] = c; 
						 }						  
					  }
					  else
					  {
						  if(++num_digits_after_point > MAX_PREC_SPECIFIER)
						  {
							  buf[num_chars_in_buf] = NULL_CHAR;
							  //discard extra numeric data if precison exceeds limit
						  }
                          else
						  {
							 buf[num_chars_in_buf++] = c; 
						  }	
					  }
					  goto real_ok;
				   //break;
				   case '+': 
				   case '-':
					 if (flags & SIGNOK )
					 {
						flags &= ~(SIGNOK);
						if(c == '-')
						{
					    	buf[num_chars_in_buf++] = '-';							
						}
						goto real_ok;
					 }
				   break;
				   case '.':
				     if (flags & DPTOK)
					 {
						flags &= ~(DPTOK);
						buf[num_chars_in_buf++] = '.';
						goto real_ok;
					 }
				   break; 
                   			
				}
				/*
				 * If we got here, c is not a legal character
				 * for a number.  Stop accumulating digits.
				 */
				break;
		real_ok:
				/*
				 * c is legal: store it and look at the next.
				 */
				*p++ = c;
				if (--inr > 0)
					inp++;
				else 
					break;		/* end of input */
			}	
			//If we had only a sign, it is no good;
			if (flags & NDIGITS)
			{
			     goto match_failure;
			}
			if(flags & SUPPRESS)
			{
				if (flags & LONG)
					*va_arg(ap, double *) = 0.0;
				else if (flags & LONGLONG)
					*va_arg(ap, long double *) = 0.0;
				else
					*va_arg(ap, float *) = 0.0;
				
			}
			else
			{
				real_t res;
			    *p = NULL_CHAR;
				res = Str_To_Double_Conv(buf);
				if (flags & LONG)
					*va_arg(ap, double *) = res;
				else if (flags & LONGLONG)
					*va_arg(ap, long double *) = res ; 
				else
					*va_arg(ap, float *) = res;
				nassigned++;
			}
			nread += p - buf;
			nconversions++;
		break;
		}
	}
input_failure:
	return (nconversions != 0 ? nassigned : EOF);
match_failure:
	return (nassigned);
}

/*------------------------------------------------------------*
FUNCTION NAME  : Scan_Input_Limit_Chars

DESCRIPTION    : Fill in the given table from the scanset at the given format
                 (just after `[').  Return a pointer to the character past the
                  closing `]'.  The table has a 1 wherever characters should be
                 considered part of the scanset.
								
INPUT          : 

OUTPUT         : 

NOTE           : Scan_Input_Limit_Chars operation is similar to __sccl()

Func ID        : 04.20 

Bugs           :  
-*------------------------------------------------------------*/
 const unsigned char * Scan_Input_Limit_Chars(char *tab, const char *fmt)
{
	int c, n, v;

	/* first `clear' the whole table */
	c = *fmt++;		/* first char hat => negated scanset */
	if (c == '^')
    {
		v = 1;		/* default => accept */
		c = *fmt++;	/* get new first char */
	} 
	else
	{
		v = 0;		/* default => reject */
	}

	/* XXX: Will not work if sizeof(tab*) > sizeof(char) */
	(void) memset(tab, v, 256);

	if (c == 0)
	{
		return (fmt - 1);/* format ended before closing ] */
	}

	/*
	 * Now set the entries corresponding to the actual scanset
	 * to the opposite of the above.
	 *
	 * The first character may be ']' (or '-') without being special;
	 * the last character may be '-'.
	 */
	v = 1 - v;
	for (;;)
	{
		tab[c] = v;		/* take character c */
doswitch:
		n = *fmt++;		/* and examine the next */
		switch (n)
		{

		case 0:			/* format ended too soon */
			return (fmt - 1);

		case '-':
			/*
			 * A scanset of the form
			 *	[01+-]
			 * is defined as `the digit 0, the digit 1,
			 * the character +, the character -', but
			 * the effect of a scanset such as
			 *	[a-zA-Z0-9]
			 * is implementation defined.  The V7 Unix
			 * scanf treats `a-z' as `the letters a through
			 * z', but treats `a-a' as `the letter a, the
			 * character -, and the letter a'.
			 *
			 * For compatibility, the `-' is not considerd
			 * to define a range if the character following
			 * it is either a close bracket (required by ANSI)
			 * or is not numerically greater than the character
			 * we just stored in the table (c).
			 */
			n = *fmt;
			if (n == ']' || n < c)
			{
				c = '-';
				break;	/* resume the for(;;) */
			}
			fmt++;
			/* fill in the range */
			do
			{
			    tab[++c] = v;
			} while (c < n);
			c = n;
			/*
			 * Alas, the V7 Unix scanf also treats formats
			 * such as [a-c-e] as `the letters a through e'.
			 * This too is permitted by the standard....
			 */
			goto doswitch;
			break;

		case ']':		/* end of scanset */
			return (fmt);

		default:		/* just another character */
			c = n;
			break;
		}
	}
	return NULL_PTR;
	/* NOTREACHED */
}

/*------------------------------------------------------------*
FUNCTION NAME  : strtoq

DESCRIPTION    : converts the string pointed to by nptr to a 64-bit, long-long integer representation. 
        This function recognizes (in order) an optional string of spaces, an optional sign, an optional base indicator (0 for octal, X or x for hexadecimal),
        and a string of digits. The first unrecognized character ends the string. A pointer to this unrecognized character is stored in the object addressed by endptr, 
       if endptr is not NULL.

       If base is non-zero, its value determines the set of recognized digits and overrides the optional base indicator character. 
        If base is zero, nptr is assumed to be base 10, unless an optional base indicator character is given
								
INPUT          : nptr - Points to a character string for strtoq() to convert.
                 endptr - Is a result parameter that, if not NULL, returns a string beginning with the first character that strtoq() does not attempt to convert. 
                 base  - Is the base of the string, a value between 0 and 36.
				 
OUTPUT         : returns the converted value, if there is any. If no conversion was performed, strtoq() returns a zero. 
                 If the converted value overflows, strtoq() returns QUAD_MAX or QUAD_MIN (according to the sign of the value) 

NOTE           : 

Func ID        : 04.20 

Bugs           :  
-*------------------------------------------------------------*/
quad_t strtoq(const char *nptr, char **endptr, int base)
{
	const char *s;
	u_quad_t acc;
	unsigned char c;
	u_quad_t qbase, cutoff;
	int neg, any, cutlim;

	/*
	 * Skip white space and pick up leading +/- sign if any.
	 * If base is 0, allow 0x for hex and 0 for octal, else
	 * assume decimal; if base is already 16, allow 0x.
	 */
	s = nptr;
	do 
	{
		c = *s++;
	} while (isspace(c));
	if (c == '-')
	{
		neg = 1;
		c = *s++;
	} else {
		neg = 0;
		if (c == '+')
			c = *s++;
	}
	if ((base == 0 || base == 16) &&
	    c == '0' && (*s == 'x' || *s == 'X'))
	{
		c = s[1];
		s += 2;
		base = 16;
	}
	if (base == 0)
		base = c == '0' ? 8 : 10;

	/*
	 * Compute the cutoff value between legal numbers and illegal
	 * numbers.  That is the largest legal value, divided by the
	 * base.  An input number that is greater than this value, if
	 * followed by a legal input character, is too big.  One that
	 * is equal to this value may be valid or not; the limit
	 * between valid and invalid numbers is then based on the last
	 * digit.  For instance, if the range for quads is
	 * [-9223372036854775808..9223372036854775807] and the input base
	 * is 10, cutoff will be set to 922337203685477580 and cutlim to
	 * either 7 (neg==0) or 8 (neg==1), meaning that if we have
	 * accumulated a value > 922337203685477580, or equal but the
	 * next digit is > 7 (or 8), the number is too big, and we will
	 * return a range error.
	 *
	 * Set any if any `digits' consumed; make it negative to indicate
	 * overflow.
	 */
	qbase = (unsigned)base;
	cutoff = neg ? (u_quad_t)-(QUAD_MIN + QUAD_MAX) + QUAD_MAX : QUAD_MAX;
	cutlim = cutoff % qbase;
	cutoff /= qbase;
	for (acc = 0, any = 0;; c = *s++)
	{
		if (!isascii(c))
			break;
		if (isdigit(c))
			c -= '0';
		else if (isalpha(c))
			c -= isupper(c) ? 'A' - 10 : 'a' - 10;
		else
			break;
		if (c >= base)
			break;
		if (any < 0 || acc > cutoff || (acc == cutoff && c > cutlim))
			any = -1;
		else {
			any = 1;
			acc *= qbase;
			acc += c;
		}
	}
	if (any < 0)
	{
		acc = neg ? QUAD_MIN : QUAD_MAX;
	} 
	else if (neg)
		acc = -acc;
	if (endptr != 0)
		*((const char **)endptr) = any ? s - 1 : nptr;
	return (acc);
}


 /*------------------------------------------------------------*
FUNCTION NAME  : strtoul

DESCRIPTION    : 
								
INPUT          : nptr - points to a sequence of characters that can be interpreted as a numeric value of type unsigned long int.
                 endptr - Is a result parameter that, if not NULL, returns a string beginning with the first character that strtoul() does not attempt to convert. 
                 base  - Is the base of the string, a value between 0 and 36.
				 
OUTPUT         : returns the converted value, if there is any. If no conversion was performed, strtoul() returns a zero. 
                 If the converted value overflows, strtoul() returns ULONG_MAX. 

NOTE           : 

Func ID        : 04.20 

Bugs           :  
-*------------------------------------------------------------*/
unsigned long strtoul(const char *nptr, char **endptr, int base)
{
	const char *s;
	unsigned long acc, cutoff;
	int c;
	int neg, any, cutlim;
	/*
	 * See strtol for comments as to the logic used.
	 */
	s = nptr;
	do {
		c = (unsigned char) *s++;
	} while (isspace(c));
	if (c == '-')
	{
		neg = 1;
		c = *s++;
	} else {
		neg = 0;
		if (c == '+')
			c = *s++;
	}
	if ((base == 0 || base == 16) &&
	    c == '0' && (*s == 'x' || *s == 'X'))
	{
		c = s[1];
		s += 2;
		base = 16;
	}
	if (base == 0)
		base = c == '0' ? 8 : 10;
	cutoff = ULONG_MAX / (unsigned long)base;
	cutlim = ULONG_MAX % (unsigned long)base;
	for (acc = 0, any = 0;; c = (unsigned char) *s++)
	{
		if (isdigit(c))
			c -= '0';
		else if (isalpha(c))
			c -= isupper(c) ? 'A' - 10 : 'a' - 10;
		else
			break;
		if (c >= base)
			break;
		if (any < 0)
			continue;
		if (acc > cutoff || (acc == cutoff && c > cutlim))
		{
			any = -1;
			acc = ULONG_MAX;
			//errno = ERANGE;
		} 
		else
		{
			any = 1;
			acc *= (unsigned long)base;
			acc += c;
		}
	}
	if (neg && any > 0)
		acc = -acc;
	if (endptr != 0)
		*endptr = (char *) (any ? s - 1 : nptr);
	return (acc);
}
