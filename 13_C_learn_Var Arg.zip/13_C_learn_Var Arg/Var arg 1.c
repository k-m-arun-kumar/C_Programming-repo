/* ********************************************************************
FILE                   :  Var arg 1.c

PROGRAM DESCRIPTION    : practise C coding in variable argument

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdarg.h"
#include "stdio.h"

int main()
{
   var_input("Nothing", 1,4,7,10,14);
}

/* ERROR: declaration syntax,*/
/* var_input(...) */

/* ERROR: declaration syntax, been fixed arg occur in end */
/* var_input(... , int i) */

/* ERROR: declaration syntax,*/
/* var_input(char *msg, ...,int i, ...) */

/* ERROR: declaration syntax  */
/* var_input(char *msg, ..., int i) */

/* ERROR: declaration syntax  */
/* var_input(char *msg, ....) */

/* ERROR: declaration syntax  */
/* var_input(char *msg, int i, ....) */

/* FINE: [1] num = 1, [2] num = 4 */
/* var_input(char *msg, ...) */

/* FINE: [1] num = 4, [2] num = 7 */
 var_input(char *msg, int i, ...)
 {
  int tot = 0;
  va_list ptr;
  int num;

  va_start(ptr, msg );
  num = va_arg(ptr, int);
  printf("\n [1] num = %d", num);
  num = va_arg(ptr, int);
  printf("\n [2] num = %d", num);

}
