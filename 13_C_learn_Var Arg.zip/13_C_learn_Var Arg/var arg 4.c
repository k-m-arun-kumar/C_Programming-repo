/* ********************************************************************
FILE                   :  var arg 4.c

PROGRAM DESCRIPTION    : practise C coding in variable argument

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdarg.h"
#include "stdio.h"

struct data
{
   int num;
   int* num_ptr;
};

int main()
{
   int (*func_ptr1)();
   int (*func_ptr2)();

   int func1();
   int func2();

   struct data data_input;

   func_ptr1 = func1;
   func_ptr2 = func2;
   pass_varfunptr("India",func_ptr1, func_ptr2 );

   data_input.num = 9;
   data_input.num_ptr = &data_input.num;
   printf("\n &data_input: %#X, num: %d, &num: %#X", &data_input,data_input.num, &data_input.num);
   pass_varstruct("India", data_input, &data_input);

}

int pass_varfunptr(char *msg, ...)
{
  int (*func_ptr1)();
  int (*func_ptr2)();
  va_list ptr;
  typedef int (*func_ptr)();

  clrscr();
  va_start(ptr, msg );

 /* ERROR: Expression sytnax */
 /* func_ptr1 = va_arg(ptr, int (*)()); */

  func_ptr1 = va_arg(ptr, func_ptr);
  (*func_ptr1)();

  va_end(ptr);
  return 1;
}

int func1()
{
   printf("\n Inside Func 1");
   return 1;
}

int func2()
{
   printf("\n Inside Func 2");
   return 1;
}

int pass_varstruct(char *msg, ...)
{
   va_list ptr;
   struct data data_input, *data_ptr = NULL;

   va_start(ptr, msg );
   data_input = va_arg(ptr, struct data);
   printf("\n Data: %d, Data_ptr: %#X",data_input.num,data_input.num_ptr);

   /* ERROR: Syntax */
   /* data_ptr = va_arg(ptr, (struct data *));  */
   data_ptr = va_arg(ptr, struct data *);

   printf("\n Data_ptr: %#X", data_ptr);
}
