/* ********************************************************************
FILE                   :  var arg 3.c

PROGRAM DESCRIPTION    : practise C coding in variable argument

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  : Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdarg.h"
#include "stdio.h"

int main()
{
   var_input(6, 4.0, 'h', 'i', 'n', 'd');
}

int var_input(int temp, double len,...)
{
  int tot = 0;
  va_list ptr;
  int num;

  clrscr();
  va_start(ptr, len );
  for(;tot < (int)len; ++tot )
  {
    num = va_arg(ptr, int);
    printf("\n [%d] num = %c", tot + 1, num);
  }
  return 1;
}


/* RUN TIME: after mismatch in 1st va_arg, [0] - num =  , does not goes into loop */
/* int var_input(int temp, float len,...)
{
  int tot = 0;
  va_list ptr;
  int num;

  clrscr();
  va_start(ptr, temp );
  num = va_arg(ptr, int);
  printf("\n [%d] num = %c", 0, num);
  for(;tot < len; ++tot )
  {
    num = va_arg(ptr, int);
    printf("\n [%d] num = %c", tot + 1, num);
  }
  return 1;
} */

/* RUN TIME: Display [3] num as garbage */
/* int var_input(int len, int tot, ...)
{
  int tot = 0;
  va_list ptr;
  int num;

  clrscr();
  va_start(ptr, len );
  num = va_arg(ptr, int );
  printf("\n [1] num = %c", num);
  num = va_arg(ptr, char );
  printf("\n [2] num = %c", num);
  num = va_arg(ptr, int );
  printf("\n [3] num = %c", num);
} */

/* RUN TIME: display all data as garbage, due to variable arg list start of with
   differnt data type (int) as that (double ) of next arg of initialized (temp) */

/* int var_input(int temp, double len,...)
{
  int tot = 0;
  va_list ptr;
  int num;

  clrscr();
  va_start(ptr, temp );
  num = va_arg(ptr, double);
  printf("\n [%d] num = %c", 0, num);
  for(;tot < (int)len; ++tot )
  {
    num = va_arg(ptr, int);
    printf("\n [%d] num = %c", tot + 1, num);
  }
  return 1;
} */
