/* ********************************************************************
FILE                   :  var arg 2.c

PROGRAM DESCRIPTION    : practise C coding in variable argument

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  : Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdarg.h"
#include "stdio.h"

int main()
{
   var_input("Nothing", 1,4,7,10,14);
}

int var_input(char *msg, int i, ...)
{
  va_list ptr;
  int num;

  /* if va_arg is used before va_start, WARN: use of ptr before define, RUN TIME: ptr fetches garbage data */
  /* va_start(ptr, msg ); */

  /* FINE: display [1] num = 4, [2] num = 7 */
  /* va_start(ptr, i ); */

  va_start(ptr, msg);

  /* if variable list start of with same data type (int) as that of next arg of initialized (msg or i) ,
     irrespect of ptr initialsed either msg or i, va_arg start fetch from variable list arg */
  num = va_arg(ptr, int);

  printf("\n [1] num = %d", num);

  /* pass var arg by copy */
  pass_varinput(msg, ptr);

  /* pass var arg by reference */
  ref_varinput(msg, &ptr);

 /* va_start(ptr, msg ); */
 /* cause ptr to fetch data from msg  */

  num = va_arg(ptr, int);
  printf("\n [2] num = %d", num);

  /* RUN TIME: a is garbage */
  /* pass_varinput1(msg, ...); */

  /* RUN TIME: a is garbage */
  /* pass_varinput2(msg, ptr); */

   pass_varinput(msg, ptr);
   return 1;
}

int pass_varinput(char *t, va_list ptr)
{
  int c_num;

  c_num = va_arg(ptr, int);
  printf("\n ptr: cpy_num = %d", c_num);
  return 1;
}

int ref_varinput(char *t, va_list *ptr)
{
  int r_num;

  r_num = va_arg(*ptr, int);
  printf("\n *ptr, ref_num = %d", r_num);
  return 1;
}

/*
int pass_varinput1(char *t, ...)
{
  int a;
  va_list ptr;

  va_start(ptr, t);
  a = va_arg(ptr, int);
  printf("\n a = %d", a);

} */

/*
int pass_varinput2(char *t, va_list ptr)
{
  int a;

  va_start(ptr, t);
  a = va_arg(ptr, int);
  printf("\n a = %d", a);

} */
