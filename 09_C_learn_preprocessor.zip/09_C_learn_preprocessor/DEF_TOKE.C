/* ********************************************************************
FILE                   : DEF_TOKE.c

PROGRAM DESCRIPTION    : practise c coding of ## preprocessor

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include<stdio.h>
#include<conio.h>
#define BEGIN_LINE1   0x80
#define BEGIN_LINE(line_num) (BEGIN_LINE##line_num)
void main()
{
  printf("0x%x", BEGIN_LINE(1));
   getch();
}
