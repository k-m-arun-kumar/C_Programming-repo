/* ********************************************************************
FILE                   : TRACE.c

PROGRAM DESCRIPTION    : practise C coding in if preprocessor

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

#define  FORE

#define LOOP 0
/*   #if defined(FORE)
       int i = 9;
       printf("\n i = %d", i);
     #endif  */                  /* Error: printf(\n ..) state decla syntax */

/*    #if defined(FORE)
       #define BACK 10  */       /* Error: at file end, indicate unexpect conditional */


 #if defined(FORE)
   #define BACK 9
 # else
   #undef BACK
 #endif

#undef TEST 9        /* fine, even if TEST is not defined before */

int i = 10;

#if LOOP == 9
  ++i;               /* Error: if compilation comes to execute here */
#else
  #define CHECK "123"

/*  BACK = 100  */   /* Error: declaration syntax */
/*  i += 10;    */   /* Error: if compilation comes to execute here */

#endif

/* #if CHECK == "123"
  BACK = 100
#endif  */           /* Error: CHECK req const expr for #if */

#if i == 10           /* fine, will not compile */
  #define FUN 25
#endif

#if j == 11           /* fine, will not compile */
 #define FUN 23
#endif

#if BACK == i - 1     /* fine, will not compile, even if BACK = 9, i = 10 */
 #define FUN 27
#endif

#ifndef LOOP == i - 1  /* DOESN'T consider i - 1, */
  #define FUN 29
  int k = 25;
#endif


/* #if BACK = 10
#endif */                 /* Error: Lvalue req for BACK */

int main()
{
  printf("\n BACK: %d, CHECK = %s, i = %d", BACK, CHECK, i);
   /* Error: if FORE is undefine */

/* printf("\n FUN : %d", FUN);  */
     /* Error: undefine FUN, even if i = any value */

 /* printf("\n FORE: %d", FORE);
    /* Error: FORE: Expr Syntax  */

   #ifdef LOOP == 9
   #else
     printf("\n k = %d", k+= 40);     /* Error: if conditional doesn't execute */
   #endif

   #if !defined(LOOP)
     printf("\n k = %d", k);
   #endif
}

