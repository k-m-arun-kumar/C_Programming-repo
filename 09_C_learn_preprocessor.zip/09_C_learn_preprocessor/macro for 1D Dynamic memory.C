/* ********************************************************************
FILE                   : macro for 1D Dynamic memory.c

PROGRAM DESCRIPTION    : practise C coding in macro defination 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "alloc.h"
#include "stdlib.h"

#define MACRO_ALLOC 9
#define ALLOC_MEMORY(alloc_ptr, num_element, element_size, debug_id) \
  if(((alloc_ptr) = calloc((num_element), (element_size))) == NULL) \
    printf("\n ERR[%d]: No new memory of size [u] * [u]", (debug_id), (num_element), (element_size));

#define FREE_MEMORY(alloc_ptr, debug_id)  if((alloc_ptr)) \
 free((alloc_ptr)); \
 (alloc_ptr) = NULL;

int *alloc_fun2();

typedef struct
{
   int num;
   char ch;
} data;

int main()
{
   int *allocptr = NULL;            /* point to garbage address if not initialized*/
   data *alloc_ptr = NULL;

   clrscr();

   allocptr = alloc_fun2();
   printf("\n after alloc_fun2:: allocptr: %#X, *allocptr: %d", allocptr, *allocptr);

   alloc_fun3(&alloc_ptr);
   printf("\n after alloc_fun3: &alloc_ptr: %#X, alloc_ptr: %#X, alloc_ptr->num: %d, alloc_ptr->num: %c", &alloc_ptr,alloc_ptr,alloc_ptr->num, alloc_ptr->ch );
   alloc_pas(alloc_ptr);
   printf("\n after alloc_pas: &alloc_ptr: %#X, alloc_ptr: %#X, alloc_ptr->num: %d, alloc_ptr->num: %c", &alloc_ptr,alloc_ptr,alloc_ptr->num, alloc_ptr->ch );

  #if MACRO_ALLOC == 9
    FREE_MEMORY(allocptr, 0)
  #else
    free(allocptr);
  #endif
   printf("\n after freeing: &alloc_ptr: %#X, alloc_ptr: %#X, alloc_ptr->num: %d, alloc_ptr->num: %c", &alloc_ptr,alloc_ptr,alloc_ptr->num, alloc_ptr->ch );

   return 1;
}


int* alloc_fun2()
{
  int *allocptr;

  #ifdef MACRO_ALLOC
     ALLOC_MEMORY(allocptr, 1,sizeof(int), 0)
  #else
    allocptr = calloc(1, sizeof(int));
  #endif
  if(allocptr == NULL)
    return allocptr;
  *allocptr = 20;
  printf("\n inside alloc_fun2: allocptr: %#X, *allocptr: %d", allocptr, *allocptr);
  return allocptr;
}

int alloc_fun3(data **allocptr)
{
  data getdata;

  #ifndef MACRO_ALLOC
     *allocptr = calloc(1, sizeof(int));
  #else
    ALLOC_MEMORY(*allocptr, 1,sizeof(int), 0);
  #endif
  if(*allocptr == NULL)
    return 0;
  getdata.num = 30;
  getdata.ch = 'A';
  memcpy(*allocptr, &getdata, sizeof(data));
  printf("\n inside alloc_fun3: allocptr = %#X, *allocptr: %#X, (*allocptr)->num: %d, (*allocptr)->ch: %c ", \
     allocptr, *allocptr, (*allocptr)->num, (*allocptr)->ch);

  return 1;
}

int alloc_pas(data *allocptr)
{
  printf("\n inside alloc_pas: allocptr: %#X, allocptr->num: %d, allocptr->ch: %c", allocptr, allocptr->num, allocptr->ch);
  #if defined(MACRO_ALLOC)
    FREE_MEMORY(allocptr,0);
  #else
    free(allocptr);
  #endif

  return 1;
}
