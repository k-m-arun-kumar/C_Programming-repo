/* ********************************************************************
FILE                   : define1.c

PROGRAM DESCRIPTION    : practise C coding in preprocessor 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

/* error: due to argument b in loop macro identifier, as defined() takes only macro identifier (eg : loop) 
   as it argument */
/* #if !defined(loop(b)) */
 
#if !defined(loop)
#define loop(b)  for(i = 0; i < b; ++i) \
                   printf("\n i = %d, square of b: %d", i, b * b);

#define square(n,b)  for(i = 0; i < n ; ++i) \
                   printf("\n i = %d, square of b: %d", i, (b) * (b));
#endif

/* error: if macro loop is already defined, will not cause to define FORE macro, so whenever 
   FORE is refered with exception of "FORE" (within double qoutes), cause undeclared identifier(FORE) */
   
/* #if !defined(loop)
   #define FORE 10
   
#endif */

#ifndef hello
    #define FORE 10
/* warning: FORE redefined */	
	#define FORE 1
#endif 

  int exvar = 19; 
   				   
int main()
{
   int invar = 2;
   int i;
   
   loop(invar + 1)
   printf("\n correct format of square");
   
    square(1, invar+ 1)
	
	/* warning infinite loop, as invar++ substiute in b, increments in i < b, every time loop is executed */
    /*loop(invar++) */
	square(1, invar++)
	
	#undef helloworld
	
	/* #undef FORE */
	/* error: undefines FORE macro, so whenever FORE is refered with exception of "FORE" (within double qoutes), 
	   cause undeclared identifier(FORE) */
	   
	printf("\n FORE : %d", FORE );
	
	/* exvar will be replaced by the value = 0 in precompilation process, even if exvar is not declared or 
	if declared and assigned different value other than 0, eg exvar = 19 */
	#if FORE == exvar + 1 
       #define BACK  30
	   printf("\n BACK = %d", BACK);
    #endif
	
	/* error: invalid operator = on FORE 
	#if FORE = 20
	 # define BACK 50
	#endif */
	
 	#if FORE == (1 + FORE) * 2 - 3
       #define DRAW  40
	   printf("\n DRAW = %d", DRAW);
    #endif 
	
	#if FORE == 1 + 1 * 2 - 3
       #define PAINT  60
	   printf("\n PAINT = %d", PAINT);
	#elif !defined (PAINT)  
	  #define PAINT  80
	   printf("\n PAINT = %d", PAINT);
    #endif 
	
	#undef FORE
	
	return 1;
}				   
