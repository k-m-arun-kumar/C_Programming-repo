/* ********************************************************************
FILE                   : stringize # oper.c

PROGRAM DESCRIPTION    : practise C coding in string based preprocessor 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

int main()
{
    clrscr();

   /* printf("\n check : %s",""vandamataram""); */
      /* error: funct call missing ) */

    printf("\n abcd' ? \  defref"  " india: %s \n", "jai hind");

   /* printf("\n abcd' ? \ defref"  " india: %d \n", \ 23);  */
      /* Error: ilegal character \ */

   /* #define display(text)   printf("\n" #text) */
   	/* Error: unterminate string */

    #define display(text)     printf("\n before # oper "#text"  after # oper")

    #define string(text)      printf("\n string: %s", #text)

    display( zebra \     hello \\    \n);
    printf("\n -------------- \n");
    display(\n father nation " " "  gandhi" ji);

    /*  display(\n ask    lfkdk " dfdfdf); */
       /* Error: due to ; missing, due to no. of " odd */

     /* NOTE: / * or * / comments begin or end gives error,
	nested commnets also gives error */

     string(yellow);
     string("""yellow""");   /* fine, no. of " is even */
     string(god is " " " great " fine);

     /* string("""yell"ow") */       
     /* Error: unternimated string, due to odd no of char " */

     printf("\n string: %s","\" i am fine \" ok \" ");

}

