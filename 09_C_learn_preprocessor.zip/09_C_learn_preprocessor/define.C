/* ********************************************************************
FILE                   : define.c

PROGRAM DESCRIPTION    : practise C coding in preprocessor 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


/* #  include "stdio.h , time.h" */   /* Error: unable open stdio.h, time.h */

#   include "stdio.h"
#include "time.h"

#define  FORE 4
# define TEST int i = 46;
#   define CHECK char j = 'c';  int k = 80

#define FUN ++i;
#define FUN ++m;                  /* warning: redefine of FUN, not identical */

/* #define looptest  time(&start);           \
	      for (n = 0; n < 30000; ++n)
		for( k = 0; k < 30000; ++k); \
	      time(&stop);                   \
	      printf("\n elased time : %lf sec", difftime(stop, start)); */
		/* error: decla syntax from statement for( k = 0; ..)
		 to printf("\n elas .....) */

#define loop  time(&start);                  \
	      for (n = 0; n < 30000; ++n)    \
		for( k = 0; k < 30000; ++k); \
	      time(&stop);                   \
	      printf("\n elased time : %lf sec", difftime(stop, start));


#define looptest  for (n = 0; n < 30000; ++n)
		   int o = 9;

/* #define   */                /* error: needs identifer */

#define ABCD 

#define  looparg(n,p)   n * p
#define argloop(n,p)  (n) * (p)

#define SHORTDEF short

int main()
{
   TEST
   CHECK;
   int m = 67;
   int n =0;
   time_t start, stop;
   SHORTDEF z = 23;   

   /* for(int l = 0; l < 4; l++); */   /* Error: undefined l, expr syntax */
   clrscr();

   printf("\n FORE : %d, i = %d, j = %c, k =%d, o =%d, z = %hd",\
      FORE, i, j, k, o, z);

  /* printf("\n BACK : %d", BACK); */  /* Error: undefined BACK, if defined after or not */
  /* printf("\n ABCD : %d", ABCD); */  /* Error: expr syntaz */

   #define BACK  6+FORE
   printf("\n BACK: %d", BACK);

   FUN
   printf("\n m = %d, i = %d", m, i);


   loop
   looptest
   ;

   looparg(5,5);               /* warning: code no effect */
   /* i = looparg(); */        /* error: wrong no. of arg */
   /* i = looparg;   */        /* error: undefined looparg */
   /* i = looparg(3,4,5); */   /* error: wrong no. of arg  */
   /* i = looparg("12", 6); */ /* error: illegal use of ptr */
   i =  looparg(2+4, 'c');

   printf("\n i = %d, !(): %d, (): %d", \
     i, looparg(3+6,2+9), looparg( (3+ 6), (2 +9)));

   printf("\n (): %d, (()) : %d", argloop(3+6,2+9), argloop((3+6),(2+9)));


}
