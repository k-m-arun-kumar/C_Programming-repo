/* ********************************************************************
FILE                   : ## 2.c

PROGRAM DESCRIPTION    : practise C coding in ## preprocessor 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/
#include "stdio.H"


/* #define display(i,j,k,l)        i##k##j  = 23; l##j = #var##k##i ; \
	   printf("\n i##k##j: %d, l##j : %s", i##k##j , #var##k##i ); */
   /* Error: # oper not followed by marco arg name i */

/* case 2 */
/* #define display(i,j,k,l)          i##k##j = 23;      l##j = #l##var##k; \
	     printf("\n i##k##j : %d, l##j: %s", i##k##j, l##j); */

/* case 3 */
/* #define display(i,j,k,l)          i##k##j = 23;      l##j = "l##var##k"; \
	     printf("\n DEF: i##k##j : %d, l##j: %s", i##k##j, l##j); */

#define display(i,j,k,l)          i##k##j = 23##j;   l##j = "#k";     \
	     printf("\n DEF: i##k##j : %d, l##j: %s", i##k##j, l##j); \
	     l##j = #k;                                               \
	     printf("\n l##j = %s",l##j);

     /* NOTE: within "" effect of ## & # is inactive */

/* #define string(i,j)     printf("\n" i##j#i ": %s",#i ); */
   /* error: func call missing ) */

 #define string(i,j)     printf("\n " #i ": %s", #i);

int main()
{
   int aid_free_1;
   char string1[10];
   char *strptr1;

   clrscr();
  /* display(aid_, 1, free_, string); */
  /* case 2: Error: Lvalue req : state missing, ; */
  /* one solution: case 3 define, for error 2  ptr assign rather than array */

    display(aid_, 1, free_, strptr );
    printf("\n aid_free_1 = %d, strptr1: %s", aid_free_1, strptr1);

    string(hello, _world);


}
