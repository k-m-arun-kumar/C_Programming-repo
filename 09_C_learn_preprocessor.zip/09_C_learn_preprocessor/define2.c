/* ********************************************************************
FILE                   : define2.c

PROGRAM DESCRIPTION    : practise C coding in preprocessor 

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

#define text(arg)   printf(#arg "    welcome \n");

/* if display(in, r) is used, then it becomes printf("\n invar = %d", arg1var);,but we require as printf("\n invar = %d", invar);*/
/* #define display(arg1, arg2)   printf("\n " #arg1 "va" #arg2 " = %d", ##arg1va##arg2); */

 #define display(arg1, arg2)   printf("\n in" #arg1 #arg2 " = %d", in##arg1##arg2); 
int func(int arg);

int main()
{
   int invar = 30;
   #define FORE 10
   
   text(please   -   


       says \n hello)
	/* error: ' in say's causes error */   
	/* text(please   -   


       say's \n hello)  */ 
	   
	 display(va ,r)  
	 func(3); 
}

int func(int arg)
{
   printf("\n FORE = %d", FORE);
   return 1;
}
