/* ********************************************************************
FILE                   : token pass ##.c

PROGRAM DESCRIPTION    : practise C coding in token pass preprocessor operation

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  : Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS. 
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdio.h"

/* #define FUNC_DEF  int check(int a)                       \
		  {                                         \
		       a += 10 ;                            \
		       printf("\n check: a = %d", a );      \
		   }                                        \
#define LOOP 8 */              /* ERROR: # not follow in macro define &
					 declaration syntax, but on if a line
					 is empty after last char \, then no error */


int main()
{
   int x3 = 75;
   int j = 56;
   int aid_one = 78;
   char *ctrl = "\n ctrl = %s";
   char *str = "hello";
   char ctrlarr[20] = "\n ctrlarr = %s";

   clrscr();

 #define display(i, j, k)   printf("a##j##k"    #i " = %d, str = %s \n", a##j##k, "a_##str##k");


  /*  #define display(i,j,k)   printf("\n str = %s", a##str##i );
   display(2,as,4);  */
      /* error: undefined symbol astr2 */

   display( 'th"re"e', id, _one );

   printf("\n j = %d", j);
   check(5);

   printf(ctrl, str);
   printf(ctrlarr, str);

}

 #define FUNC_DEF  int check(int a)                          \
		  {                                         \
		       a += 10 ;                            \
		       printf("\n check: a = %d", a );      \
		   }

FUNC_DEF              /* ERROR: DECL syntax if not defined before */

