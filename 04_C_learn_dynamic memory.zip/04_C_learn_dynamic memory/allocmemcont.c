/* ********************************************************************
FILE                   : allocmemcont.c

PROGRAM DESCRIPTION    : practise C coding in dynamic memory allocation

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "stdlib.h"
void allocrowmemory(int ***matrixptr, int size);
void allocmemory(int **, int);

void freemem(int **);
void freewhole(int ***);
void process(int  **const ptr, const int rows, const int columns);
int main()
{
    int rows = 3, i;
int columns = 4, j, index;
int **matrix = NULL;

allocrowmemory(&matrix, rows * sizeof(int *));
allocmemory(matrix, rows * columns * sizeof(int));

printf("\n *matrix : 0x%x", matrix[0]);
for (int i = 1; i < rows; i++)
 {
	matrix[i] = matrix[0] + i * columns;
	printf("\n *(matrix + %d) = 0x%x ", i, matrix[i] );
 }
 
 process(matrix, rows, columns);
 for(i = 0; i < rows; i++)
 {
   printf ("\n ");
   for(j = 0; j < columns; j++)
   {
     index =  i*columns + j ; 
	 /* if *(matrix + index) is used and if matrix = 0x4b0ef8, matrix[0] = 0x4b0f08 and index = 1, then *(matrix + 1) = 0x4b0f18 
	    contains value 10 is not that what we want to access next element, we want to access 0x4b0f0c by using (*matrix + 1),
		which contains 1 in this case, is the correct way to access each element of allocated dynamic mem by matrix variable */
	  printf("\n in main, (*matrix + %d) = 0x%x contains value %d", index, (*matrix + index ), *(*matrix + index) );
   }  			   
 }
 freemem(&matrix[0]); // &matrix[0] is equivalent to matrix 
 freewhole(&matrix);
 return 1;
}
 
void allocrowmemory(int ***matrixptr, int size)
{
   *matrixptr = (int **) malloc(size);
   printf("\n matrix : 0x%x of size in bytes: %u ",  *matrixptr, size);
   return;
}

void allocmemory(int **rowmatrix, int size)
{
   *rowmatrix = (int *) malloc(size); 
   printf("\n matrix[0] : 0x%x of size in bytes: %u ", *rowmatrix, size);
   return;
}
void freemem(int **memptr)
{
  printf("\n free memory matrix[0]: 0x%x", *memptr);
  free(*memptr);
  *memptr = NULL;
  return ;
} 

 void freewhole(int ***ptr)
 {
    printf("\n free whole memory : 0x%x", *ptr);
    free(*ptr);
    *ptr = NULL; 
	return;
 }
 
 void process(int **const ptr, const int rows, const int columns)
 {
	  int i, j, index;
	  for(i = 0; i < rows; i++)
	  {
		   printf ("\n ");
		   for(j = 0; j < columns; j++)
           {
			    index =  (i*columns) + j;  
				/* if matrix = 0x5e0ef8, matrix[0] = 0x5e0f08, and if *(ptr + index ) is used, then 
				*(ptr + index ) = 0x5e0f18 for index = 1 and  **(ptr + 1) = 1 , is not what we want, 
				 we want to access to 0x5e0f0c by using (*ptr + 1) which contains 1 in this case, 
				 is the correct way to access each element of allocated dynamic mem by ptr variable */
			    *(*ptr + index) = 10 * i + j;
				printf("\n *(*matrix + %d) = 0x%x contains value %d", index, (*ptr + index ), *(*ptr + index) );
		   }  			   
	  }
	  return;
 }
 
 
