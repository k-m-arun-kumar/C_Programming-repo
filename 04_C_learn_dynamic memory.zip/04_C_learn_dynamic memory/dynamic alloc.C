/* ********************************************************************
FILE                   : dynamic alloc.c

PROGRAM DESCRIPTION    : practise C coding in dynamic memory allocation

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "alloc.h"

int *alloc_fun2();

typedef struct
{
   int num;
   char ch;
} data;
 
int main()
{
   int *allocptr = NULL;            /* point to garbage address if not initialized*/
   data *alloc_ptr = NULL;

   clrscr();
   printf("\n inside main: allocptr: %#X", allocptr);
   alloc_fun1(allocptr);
   printf("\n after alloc_fun1:: allocptr: %#X, *allocptr: %d ", allocptr, *allocptr);
   /* has garbage address & its data, if not initialized */

   allocptr = alloc_fun2();
   printf("\n after alloc_fun2:: allocptr: %#X, *allocptr: %d", allocptr, *allocptr);
   
   alloc_fun3(&alloc_ptr);
   printf("\n after alloc_fun3: &alloc_ptr: %#X, alloc_ptr: %#X, alloc_ptr->num: %d, alloc_ptr->num: %c", &alloc_ptr,alloc_ptr,alloc_ptr->num, alloc_ptr->ch );
   alloc_pas(alloc_ptr);
   printf("\n after alloc_pas: &alloc_ptr: %#X, alloc_ptr: %#X, alloc_ptr->num: %d, alloc_ptr->num: %c", &alloc_ptr,alloc_ptr,alloc_ptr->num, alloc_ptr->ch );

   free(allocptr);
   printf("\n after freeing: &alloc_ptr: %#X, alloc_ptr: %#X, alloc_ptr->num: %d, alloc_ptr->num: %c", &alloc_ptr,alloc_ptr,alloc_ptr->num, alloc_ptr->ch );

  /* free(*alloc_ptr); */
   return 1;
}

int alloc_fun1(int *allocptr)
{
   allocptr = calloc(1, sizeof(int));
   *allocptr = 10;
   printf("\n inside alloc_fun1:: allocptr: %#X, *allocptr: %d", allocptr, *allocptr);
   /* we lost the starting memory address, to free, it after processing, causes memory leakage */
   return 1;
}

int* alloc_fun2()
{
  int *allocptr;

  allocptr = calloc(1, sizeof(int));
  *allocptr = 20;
  printf("\n inside alloc_fun2: allocptr: %#X, *allocptr: %d", allocptr, *allocptr);
  return allocptr;
}

int alloc_fun3(data **allocptr)
{
  data getdata;

  *allocptr = calloc(1, sizeof(data));
  getdata.num = 30;
  getdata.ch = 'A';
  /* memcpy(allocptr, &getdata, sizeof(data)); */
    /* causes nULL pointer assignment, due allocptr in memcpy, garbage value in access data */
  memcpy(*allocptr, &getdata, sizeof(data));
  printf("\n inside alloc_fun3: allocptr = %#X, *allocptr: %#X, (*allocptr)->num: %d, (*allocptr)->ch: %c ", \
     allocptr, *allocptr, (*allocptr)->num, (*allocptr)->ch);

 /* free(*allocptr);
   free(*allocptr); */
  return 1;
}

int alloc_pas(data *allocptr)
{
  printf("\n inside alloc_pas: allocptr: %#X, allocptr->num: %d, allocptr->ch: %c", allocptr, allocptr->num, allocptr->ch);
  free(allocptr);
 /* free(allocptr); */
  return 1;
}
