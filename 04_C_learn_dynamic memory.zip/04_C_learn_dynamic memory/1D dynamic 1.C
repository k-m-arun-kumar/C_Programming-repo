/* ********************************************************************
FILE                   : 1D dynamic 1.c

PROGRAM DESCRIPTION    : practise C coding in dynamic memory allocation

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "stdlib.h"
#include "string.h"

typedef struct queuenode
{
   unsigned char msgtype;      /* differentiate kind of data in queue */
   unsigned char datalen;      /* variable data's length */
   char *quedatabuff;          /* contains address of data */
} queue_node;

typedef struct
{
  queue_node *que_array;       /* starting address of queue implemented by 1D array */
  unsigned char index;
} queue_head;

queue_head queue_data;

int main()
{
   char temp_data[15];
   queue_node *que_data;
   char int_cvt[3];
   char name[7] = "name";
   int count = 0;
   int num = 3, num_count = 0;

   if(!(queue_data.que_array = calloc(num, sizeof(queue_node))))
      return -1;
   printf("\n 1D dynamic array: que_array: %#X, num: %d, datasize: %d",queue_data.que_array,num, sizeof(queue_node));
   que_data = temp_data;
   que_data->msgtype = num_count + 2;
   /* if int_cvt is pointer and not an array, then run time: Null ptr assignment*/
   sprintf(int_cvt,"%u", que_data->msgtype);
   printf("\n int_cvt: %s",int_cvt);
   strcat(name,int_cvt);
   printf("\n name: %s, strlen(name): %d, sizeof(name): %d\n name Charwise: ", name, strlen(name),sizeof(name));
   while(count < sizeof(name))
      printf("%c",name[count++]);
   /* run time: Null ptr assignment */
   /* memcpy(que_data->quedatabuff,name,sizeof(name));*/
   memcpy(que_data->quedatabuff,name,strlen(name) + 1);
   que_data->datalen = strlen(name) + 1;
   printf("\n quedatabuff: %s, strlen(quedatabuff): %d, sizeof(quedatabuff): %d", \
    que_data->quedatabuff,strlen(que_data->quedatabuff), sizeof(que_data->quedatabuff));
   add_data(num_count, que_data);

   del_data1(num_count, &que_data);
   /* if que_array[index].quedatabuff,is freed before accessing que_data,que_data's quedatabuff is garbage */
   printf("\n que_data: %#X: msgtype: %u, datalen: %u, quedatabuff: %#X, databuff: %s",que_data, \
    que_data->msgtype,que_data->datalen, que_data->quedatabuff, que_data->quedatabuff);
   free(que_data);

   del_data2(num_count, &que_data);
   printf("\n que_data: %#X: msgtype: %u, datalen: %u, quedatabuff: %#X, databuff: %s",que_data, \
    que_data->msgtype,que_data->datalen, que_data->quedatabuff, que_data->quedatabuff);
   free(que_data);

   printf("\n que_array: %#X, que_array + 1: %#X",queue_data.que_array, queue_data.que_array + 1);
   free(queue_data.que_array);
}

int add_data(int index, queue_node *que_data)
{
   queue_data.que_array[index].msgtype = que_data->msgtype;
   (queue_data.que_array + index)->datalen = que_data->datalen;
   if(!(queue_data.que_array[index].quedatabuff = calloc(1, que_data->datalen)))
     return -1;
   memcpy(queue_data.que_array[index].quedatabuff,que_data->quedatabuff,que_data->datalen);
   printf("\n add array[%d]: msgtype: %u, datalen: %u, quedatabuff: %#X, databuff: %s",index,queue_data.que_array[index].msgtype, \
	(queue_data.que_array + index)->datalen, queue_data.que_array[index].quedatabuff,queue_data.que_array[index].quedatabuff );
   return 0;
}

int del_data1(int index, queue_node **que_data)
{
	if(!(*que_data = calloc(1, sizeof(**que_data))))
	  return -1;

    printf("\n del1 array[%d]: msgtype: %u, datalen: %u, quedatabuff: %#X, databuff: %s",index,queue_data.que_array[index].msgtype, \
	 (queue_data.que_array + index)->datalen, queue_data.que_array[index].quedatabuff,queue_data.que_array[index].quedatabuff);
	/* type mismatch in paramter src of memcpy func */
	/* memcpy(*que_data, queue_data.que_array[index] , sizeof(queue_node) + queue_data.que_array[index].datalen); */

	memcpy(*que_data, queue_data.que_array + index , sizeof(queue_node));
    printf("\n que_data Addr: %#X: msgtype: %u, datalen: %u, quedatabuff: %#X, databuff: %s",*que_data, \
     (*que_data)->msgtype,(*que_data)->datalen, (*que_data)->quedatabuff,(*que_data)->quedatabuff);
    /* causes data pointed by quedatabuff in quedata been corrupted */
	/* free(queue_data.que_array[index].quedatabuff); */
	return 1;
}

int del_data2(int index, queue_node **que_data)
{
	char array[10], *arr_ptr = array;

	if(!(*que_data = calloc(1, sizeof(**que_data) + queue_data.que_array[index].datalen )))
	  return -1;
	/* expr syntax error  */
    /* char array[10]; */

    memcpy(arr_ptr, queue_data.que_array[index].quedatabuff,queue_data.que_array[index].datalen);
    printf("\n array: %s, (*que_data)->quedatabuff: %#X, &(*que_data)->quedatabuff: %#X", array, (*que_data)->quedatabuff,&(*que_data)->quedatabuff);
    /* at end in run time: causes null ptr assignment */
    /* arr_ptr = "ptr data"; */
    printf("\n arr_ptr: %s, *que_data + sizeof(queue_node) - sizeof(char *):%#X, quedatabuff Addr: %#X",arr_ptr, \
     *que_data + sizeof(queue_node) - sizeof(char *), (char *)*que_data + sizeof(queue_node) - sizeof(char *));
    memcpy(*que_data, queue_data.que_array + index , sizeof(queue_node) - sizeof(char *));

   /* memcpy((char *)*que_data + sizeof(queue_node) - sizeof(char *), queue_data.que_array[index].quedatabuff,queue_data.que_array[index].datalen);*/
     /* ERROR: ptr req at left side of quedatabuff */
   /* memcpy(*que_data->quedatabuff, queue_data.que_array[index].quedatabuff,queue_data.que_array[index].datalen); */
   /* memcpy(&(*que_data)->quedatabuff, queue_data.que_array[index].quedatabuff,queue_data.que_array[index].datalen); */
    /* warning: non portable ptr conversion */
   /* memcpy(*(*que_data)->quedatabuff, queue_data.que_array[index].quedatabuff,queue_data.que_array[index].datalen); */

   (*que_data)->quedatabuff = (char *)*que_data + sizeof(queue_node);
    memcpy((*que_data)->quedatabuff, queue_data.que_array[index].quedatabuff,queue_data.que_array[index].datalen);
	printf("\n del2 array[%d]: msgtype: %u, datalen: %u, quedatabuff: %#X, databuff: %s",index,queue_data.que_array[index].msgtype, \
	 (queue_data.que_array + index)->datalen, queue_data.que_array[index].quedatabuff,queue_data.que_array[index].quedatabuff);
	printf("\n que_data Addr: %#X: msgtype: %u, datalen: %u, quedatabuff: %#X, databuff: %s",*que_data, \
     (*que_data)->msgtype,(*que_data)->datalen, (*que_data)->quedatabuff,(*que_data)->quedatabuff);
    free(queue_data.que_array[index].quedatabuff);
	return 1;
}
