/* ********************************************************************
FILE                   : 2D dynamic 1.c

PROGRAM DESCRIPTION    : practise C coding in dynamic memory allocation

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "stdlib.h"
#include "string.h"

typedef struct
{
  unsigned char var_datalen;
  void *var_databuff;
} var_data;

int main()
{
   var_data *rec = NULL;
   unsigned char num_rec = 0;

   Insert_Data(&rec, &num_rec);
   Delete_Data(rec, num_rec);
   free(rec);
   return 1;
}

int Insert_Data(void **rec, unsigned char *num_rec)
{
   unsigned char max_rec = 5;

   *rec = calloc(max_rec, sizeof(var_data));
   Add_Data(*rec, num_rec, max_rec);
   return 1;
}

int Add_Data(void *rec, unsigned char *num_rec, unsigned char max_rec)
{
   void *alloc_ptr = NULL;
   char name[10];
   *num_rec = 0;

   do
   {
      printf("\n [%d]: Enter name: ",++*num_rec);
      scanf(" %s", name);
      if(!strcmp(name, "END") || *num_rec > max_rec )
      {
        printf("\n ERR[]: END or Total num matched target[%u] exceeds max [%u]",*num_rec, max_rec);
        --*num_rec;
        break;
      }
      alloc_ptr = malloc(strlen(name) + sizeof('\0'));
      memcpy(alloc_ptr, name, strlen(name) + sizeof('\0'));
      (((var_data *)rec) + *num_rec - 1)->var_databuff = alloc_ptr;
      ((var_data *)rec)[*num_rec - 1].var_datalen = strlen(name) + sizeof('\0');
      printf("\n Entered Name: %s, Disp [%d], Alloc: %#X : Name: %s, name_len: %u",name, *num_rec, ((var_data *)rec)[*num_rec - 1].var_databuff,\
       (char *)((var_data *)rec + *num_rec - 1)->var_databuff, ((var_data *)rec + *num_rec - 1)->var_datalen - sizeof('\0'));
      strcpy(name, "");
   } while(1);
   return 1;
}

int Delete_Data(void *rec, unsigned char num_rec)
{
   unsigned char rec_count = -1;

   if(rec)
   {
      while(++rec_count <= num_rec - 1)
      {
         printf("\n Alloc: %#X, Name: %s, name_len: %u", ((var_data *)rec + rec_count)->var_databuff, \
          (char *)((var_data *)rec)[rec_count].var_databuff, (((var_data *)rec) + rec_count)->var_datalen - sizeof('\0'));
         free((((var_data *)rec) + rec_count)->var_databuff);
      }
      return 1;
   }
   printf("\n ERR[25.2]: REC is NULL, to display its emp record");
   return 1;
}
