/* ********************************************************************
FILE                   : fileformat.c

PROGRAM DESCRIPTION    : practise C coding in file operation

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "stdlib.h"

#define NUM_ELEMENTS 2

int main()
{
    FILE *fptr;
	int num, i;
	int invar;
	char charr[10], dummy[10];
	float ft;
	
	struct record
	{
	   int account;
	   char name[10];        
	} details[NUM_ELEMENTS], *ptr_details;
        void *dis_details;
 
	/* reading of file in "w" mode results leads to garbage values 
	if(fptr = fopen("data.txt", "w")) */
	if(fptr = fopen("data.txt", "w+"))
	{
	  num = fprintf(fptr,"Entered: %#4d %s %#g", 20, "Hello", 2.0 );
	  printf("\n nos of total characters written to file by this fprintf: %d", num);
	 	  
      rewind(fptr);
	  /* results in garbage values 
	   num = fscanf(fptr," %*s %d %s %g", dummy, &invar, charr, &ft); */
	  num = fscanf(fptr,"Entered: %d %s %g", &invar, charr, &ft); 
	  printf("\n nos of items matched by fscanf: %d,invar: %d, charr = %s, ft = %g", num, invar, charr, ft );
      fclose(fptr);
	 
	} 
	else
	 printf("\n cannot write to file");
	 
    if(fptr = fopen("data.txt", "w+"))
    {
	    for(i = 0;  i< NUM_ELEMENTS; ++i)
		{ 
	      printf("\n %d st details, Enter account no: ", i + 1);
	    scanf("%d", &details[i].account);
        printf("\n %d st details, Enter account name: ", i + 1);
        scanf(" %s", details[i].name);
		}
		
		/* data.txt is not readable(other than string datas) been opened from text editor, by unformatted data file
           been used by fwrite()and fread()   */
        if(fwrite(details, sizeof(struct record),NUM_ELEMENTS, fptr) == NUM_ELEMENTS)
        {
		     printf("\n Data written to file");
		     rewind(fptr);
			
             /*  causes program to crash as minimum memory allocation of byte size = sizeof(struct record) * NUM_ELEMENTS is not allocated to dis_details, before using fread()
			 
			  if(fread(dis_details, sizeof(struct record),NUM_ELEMENTS, fptr) == NUM_ELEMENTS) */
			  
			 dis_details = calloc(NUM_ELEMENTS, sizeof(struct record));
             printf("\n memory allocated: %#X",dis_details); 
			 if(fread(dis_details, sizeof(struct record),NUM_ELEMENTS, fptr) == NUM_ELEMENTS)
             {
                 printf("\n read from file");                
                 for( i =0; i < NUM_ELEMENTS; ++i) 
				{  				 
      				  printf("\n entered details from file - %d st details: account: %d, name: %s", i + 1,((struct record *)dis_details + i)->account, ((struct record *)dis_details + i)->name);
  			  
                } 
			 } 
             printf("\n free memory : %#X", dis_details );  
             free(dis_details); 
        }  
        
		/* uncheck this block to check that fwrite(), fread(), which uses unformated data that 
		   integer written to data.txt file by fwrite() cannot be directly read by using text editor  */
        /*if(fwrite(&num, sizeof(num),1, fptr) == 1)
        {
		     rewind(fptr);
             if(fread(&i, sizeof(i),1, fptr) == 1)
                 printf("\n entered details from file: : %d", i );
              
        } */    
    }	 
	 
   return 1;	 
}
