/* ********************************************************************
FILE                   : filesimple.c

PROGRAM DESCRIPTION    : practise C coding in file operation

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"
#include "ctype.h"


int main()
{
    FILE *fptr;
    char charr[55];
    char c;
	fptr = fopen("data.txt", "w");
	
	
        
	if(fptr)
	{
	  printf("\n Enter line 1 the characters terminate with \\n : "); 
	  do
	      putc(toupper(c=getchar()), fptr);
      while(c != '\n');

      printf("\n Enter line 2 the characters terminate with \\n : "); 
	  do
	      putc(toupper(c=getchar()), fptr);
      while(c != '\n');
      printf("enter a char to proceed: ");
      getchar();
      /* data.txt file will be updated only when it encounters fclose() */
	  fclose(fptr);
	}
	else
	  printf("\n File cannot be written");
	  
	if( fptr = fopen("data.txt", "r"))
    { 
	   printf("\n entered characters with uppercase : ");
	   do
	     putchar(c = getc(fptr));
           /* put characterwise from data.txt on screen till end of file reached */  
	   while(!feof(fptr));
         
	   fclose(fptr); 
	}
	else
	{
	   printf("\n file cannnot be opened in read mode");
	}
      

      if(fptr = fopen("data.txt", "w"))
      {
          fputs("This is c lang.", fptr);
          printf("\n enter a string : ");
         /* gets(charr) not working in this case   
          gets(charr) */
          scanf(" %s", charr);
          fputs(charr, fptr);
          fclose(fptr);   
      }
      else
        printf("\n cannot write the file "); 
        
   if( fptr = fopen("data.txt", "r"))
    { 
	   printf("\n entered string from data.txt file : ");
           /* 45 specfies that maximum of 44 = 45 - 1 characters are read, or new line character or
             end  of file is encountered in file, any of these conditons comes first and then store in charr varable*/
	   if(fgets(charr, 45, fptr))
               puts(charr);
           
         
	   fclose(fptr); 
	}
	else
	{
	   printf("\n file cannnot be opened in read mode");
	}
	return 1;	   
	
}
