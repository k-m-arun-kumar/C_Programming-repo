/* ********************************************************************
FILE                   : bit logic oper.c

PROGRAM DESCRIPTION    : practise C coding in bit operation

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

int main()
{
  char a[] = "234";
  unsigned i = 0x48;
  char k = 64, n = -48;
  float f = 45.0;
  int j = -1024, m = 2048;
  int p = 0xf240;

  long l;

  /* clrscr(); */
  /* printf("\n %u", ~a); */   /* error: illegal use of ptr */
  /* printf("\n %u", ~f); */   /* error: illegal use of floating pt */
  l = ~k;                      /* compliment includes sign bit */

  clrscr();
  printf("\n l = %ld, k = %#x, 1st comp k = %d", l,k, 0xff80);

  /* printf("\n %u", a | 0xffff); */ /* error: illegal use of ptr */
  /* printf("\n %u", f | 0xffff); */ /* error: illegal use of floating pt */

  printf("\n 2nd comp of j: %#x, k|j = %#x, j|m = %#x, n|j = %#x, n|m = %#x", \
       ~0x000c + 1, k | j, j | m, n | j, n|m );

  printf("\n k^j = %#x, j^m = %#x, n^j = %#x, n^m = %#x, n^6 = %#x", \
      k^j, j^m, n^j, n^m, n^-6 );
  /*  n in char = 0xD0, convert to type of other operand(int) 0xFFD0 to represent -48 in int */

  printf("\n k&j = %#x, j&m = %#x, n&j = %#x, n&m = %#x", k&j, j&m, n&j, n&m);

  printf("\n j<<-1 = %#x, j<<17 = %#x, j<<4 = %#x", j<<-1, j<<17, j<<4);  /* result 1st 2: 0 0 */
  printf("\n m<<4 = %#x, m>>4 = %#x, sizeof(88): %d, sizeof(32888): %d, sizeof('c'): %d, sizeof(45.0): %d", \
     m<<4, m>>4, sizeof 88, sizeof(32888), sizeof('c'), sizeof(45.0));

  printf("\n j>>-1 = %#x, j>>17 = %#x, j>>2 = %#x", j>>-1, j>>17, j>>2);
     /* result 1st 2: 0xffff 0xffff */

  printf("\n 0xf240>>5 = %#x, 0xf240<<5 = %#x, p>>5 = %#x, p<<5 = %#x", \
    0xf240 >> 5, 0xf240 << 5, p>>5, p<<5);
     /* for hex & octal const are unsigned. for + & - >> vacant with 0 & 1 resp */
}



