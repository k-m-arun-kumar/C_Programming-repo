/* ********************************************************************
FILE                   : bitfield.c

PROGRAM DESCRIPTION    : practise C coding in bit operation

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

/* linker error: undefined main, if main() not defined */

  int m = 45;

  struct sample                   /* warning: zero length stru */
  {
       /* float    a: 1;   */     /* error: not allowed type */
       /* char     b: 2;   */     /* error: not allowed type */
       /* long int c: 3;   */     /* error: not allowed type */
       /* unsigned d: -24; */     /* linker error: illegal OBJ record */
       /* int      e: 17;  */     /* error: bit field too large */

       unsigned f: 3+2-5+3;
       short    g: 5;
       unsigned  : 3;
       int      h: 5;
       int      i: 4;
       unsigned  : 0;              /* align to next byte */
       short    j: 3;
       unsigned  : 0;
       int      k: 3;

  } v = {-1 + 45 /* - m */ , 'c', 17.7, -6};  /* error: ilegal initialization if m is utilized */


int main()
{

  struct sample *ptr;
  unsigned int *uptr;
  struct sample barr[3];

  clrscr();
  printf("\n sample bytes : %d", sizeof(struct sample));

  /* scanf("%hd", &v.g);  */       /* error: must take address of memory location */

  printf("\n v.f = %u, v.g = %hd, v.h = %i, v.i = %d",\
     v.f, v.g, v.h, v.i);

   m += v.f + v.h;
   printf("\n m = %d", m);

   if( v.i < 7 )
     printf("\n v.i < 7 : ~v.i: %d, v.i^v.h: %d", ~v.i, v.i^v.h);

   ptr = &v;
   m = check(ptr);
   printf("\n ptr->h: %d, m = %d", ptr->h, m);

   barr[0].i = 6;
   barr[0].j = 3;
   barr[0].g = 10;
   printf("\n barr[0].i: %d, barr[0].j: %d, barr[0].g: %d", \
     barr[0].i,barr[0].j, barr[0].g);
}


 static int check(struct sample *sptr)
 {
    sptr->h = 20;
    return sptr->h ;
 }


