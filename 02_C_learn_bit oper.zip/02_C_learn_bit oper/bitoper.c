/* ********************************************************************
FILE                   : bitoper.c

PROGRAM DESCRIPTION    : practise C coding in bit operation

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

unsigned bitoper(unsigned bitvar);

int main()
{
   unsigned int unvar = 0xffffff00;
   int invar = unvar, *inptr, var = 0x40f86421;
   char chvar = 05;
   
   struct bitfield
   {
      // unsigned e : 33;  /* error: bit width of e = (33) > sizeof(unsigned) * 8 bits */
	  unsigned a : 2;
	  int b: 3;
      unsigned c: 4;
	  unsigned   : 0;     /* automatically force the next field to be aligned with the beginning of a new word  */
	  unsigned d : 6;     /* begin of next aligment of sizeof(unsigned int) */
	 // unsigned f[3]: 5; /* error: array of bit fields not permited */
   } bitvar = {6,5,11, 63};
   
   struct bitfield *bitptr = &bitvar;

   invar >>= 8;
   unvar >>= 8;
   printf("\n sizeof(int): %d , invar : %#X, unvar = %#X", sizeof(int),invar, unvar);
   /* warning, larger value 6 is trunated to have var.a = 2 a member is 2 bit width, so max value it holds is 0 to 3  */  
 
   /* bitvar.b is an signed int of 3 bit. since 5 in 3bit = 101 in binary, 3rd bit of b member
      represents sign bit. It is a negative number, so 101 in binary of b member is in 2's complement.
	  so bitvar.b = -3. */ 
   
      printf("\n sizeof(bitvar): %d, bitvar.a = %d, b = %d, c = %d, d = %d", sizeof(bitvar), \
           bitvar.a, bitvar.b, bitvar.c, bitvar.d   );
		   
	invar = bitvar.b;
	unvar =  bitvar.b + bitvar.c;
    printf("\n after bitoper arithmetric - invar: %d, unvar:  %u",	invar, unvar);
	
	/* error : & or * operator is not permited on bit field
	
	inptr = &bitvar.b;	   */
	
	/* bitvar.c = 15, bitvar.d = 63, as c member is unsigned 4 bits width and d member is unsigned 6 bits width */
	bitvar.c = bitoper(bitvar.d);
	printf("\n after bitoper(),  bitvar.c: %u", bitvar.c );
	
	bitptr->b = 2;
	printf("\n bitptr->b: %u, bitvar.b : %u", bitptr->b, bitvar.b);
	
	unvar = 0xffffff00;
	/* bit operation & (add),  | (or), ^ (exclusive or), ~ (not) are performed on all bits incl. sign bit, if it is a signed integer or char */
	var |= unvar;
	printf("\n var = %#X", var);
	
	var = 0xf0f0ff00;
	var |= chvar;
	printf("\n var = %#X", var);
	
	var = 0xf0f0ff60;
	chvar |= var;
	printf("\n chvar = %#X, chvar = %d",chvar, chvar);
	
   return 1;
}

unsigned bitoper(unsigned bitvar)
{
   printf("\n in bitoper(), bitvar = %u", bitvar);
   return bitvar;
}
