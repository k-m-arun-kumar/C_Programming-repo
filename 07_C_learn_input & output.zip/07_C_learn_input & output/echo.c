/* ********************************************************************
FILE                   : echo.c

PROGRAM DESCRIPTION    : echo a input char and display a inputed data

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

/* echo_eof.c --- repeating input to end-of-file */
 
#include <stdio.h>
int main(void)
{
    int ch;
 
    /*
     * EOF is a character defined, as a Macro, in the stdio.h header file
     * EOF is a unique invisible character marks end of every file
     * adjustment statement not required so left blank
     */ 
 
    for (ch = getchar(); ch != '\n';   ch = getchar()) 
	{
        putchar(ch);
      
    }
    return 0;
}
