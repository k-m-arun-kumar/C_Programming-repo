/* ********************************************************************
FILE                   :  printf & scanf 1.c

PROGRAM DESCRIPTION    : practise C coding in getting input and display output

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdio.h"

int main()
{
 char c[] = "SHSHH";
 int unsigned b = 100;
 double f = 6.1;
 char ch = 257;
 short s = 23;
 float fl = 4;
 long double e = 8;
 int unsigned long l = 1000;

 printf("\n enter numbers: ");
 scanf  ("%lf %5[a^bcdefaaa] %hd %c %d %f %ld %Lf", &f, c, &  b, &ch, &s, &fl, &l, &e);
 printf("\n  c[%i] = %s, b = %i ,ch = %c, f = %lg, s = %hd,l = %ld , fl = %g, e = %Lg \n \
 c[%i] = %s, b = %d, ch = %c, f = %le, s = %hd, l = %ld, fl = %f, e = %Lf", sizeof c, c, b, ch, f, s,l, fl,e,\
 sizeof(c), c, b, ch, f, s,l, fl, e );

}

/* scanf: actual control character replce with coresponding variable
===================================================================
%lf -> %f   rest fine.does n't take corresponging value
%f -> %lf   rest fine. coressponding data 0.000000
%Lf -> %lf  rest fine.corresponding data garbage
%Lf -> %f   rest fine.does n't take  corresponding value
%Lf -> %d   rest fine.does n't take  corresponding value
%f -> %d    rest fine.corresponding data garbage
%lf -> %d   rest fine.does n't take  corresponding value
%Lf -> %ld  rest fine.does n't take  corresponding value
%Lf -> %s   rest fine.does n't take  corresponding value
%ld -> %s   rest fine.corresponding data garbage
%f -> %c    rest fine, even if corresp data is char.corresponding data garbage
%d -> %s    rest fine.corresponding data garbage
%hd -> %d   fine 
%d -> %hd   fine
%ld -> %d   fine. if 32888 then data taken is 32888 
%d -> %ld   fine. if 32888 then data taken is -32648 
%c -> %d    fine if 320 then data for corresponding char variable is @
%d -> %c    rest fine. if 5 corresponding ascii value is stored in data.
%d -> %5c   rest fine. corresponding data garbage
%s -> %c    fine. 
%c -> %s    rest fine. takes first character only. */
