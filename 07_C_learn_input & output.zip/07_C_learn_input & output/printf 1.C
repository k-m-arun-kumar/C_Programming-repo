/* ********************************************************************
FILE                   :  printf 1.c

PROGRAM DESCRIPTION    : practise C coding in getting input and display output

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdio.h"

int main()
{
 char c[] = "SHSHH";
 int unsigned b = 100;
 double f = 6.1;
 char ch = 257;
 short s = 23;
 float fl = 4;
 long double e = 8;

 /* printf("\n enter numbers: ");
 scanf("%lf%s%d%hd%f%Lf", &f, c, &b, &s,&fl, &e); */

 printf("\n  c[%i] = %s, b = %d ,ch = %c, f = %lg, s = %hd, fl = %g, e = %Lg \n \
 c[%i] = %s, b = %d, ch = %c, f = %le, s = %hd, fl = %f, e = %Lf", sizeof c, c, b, ch, f, s,fl,e,\
 sizeof(c), c, b, ch, f, s, fl, e );

}

/* actual control character replce with coresponding variable
=============================================================
%c -> %d - correct output except conversion of  character to ASCII
%d -> %c - correct output except conversion of  character to ASCII
%hd -> %d - fine 
%d -> %hd - fine 
%lf -> %f - fine 
%f -> %lf - fine 
%s -> %c  - garbage value for particlar data only, rest are fine
%c -> %s  - Null character, rest are fine 

%d -> %f  - run time abnormal termination floating point not linked 

hope rest of conversion gives garbage values from present to rest of 
control string */
