/* ********************************************************************
FILE                   :  Field conversion 1.c

PROGRAM DESCRIPTION    : practise C coding in getting input and display output

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdio.h"

int main()
{
 char c[] = "SHSHH232323";
 int unsigned b = 23423;
 double f = 6434343.1454789455656;
 char ch = 257;
 short s = 23;
 float fl = 4433455.64568334234234;
 long double e = 2332238343.656570056545454;
 int unsigned long l = 1000213213;

 /* printf("\n enter numbers: ");
 scanf("%lf %5[abcde] %hd %c %d %f %ld %Lf", &f, c, &b, &ch, &s, &fl, &l, &e); */
 printf("\n Data  Displayed ");
 printf("\n    c[%i] = %s, b = %i ,ch = %c, f = %5.2lg, \n \
   s = %hd, l = %7.9ld , fl = %18g, e = %5.8Lg \n \
   c[%i] = %2.20s, b = %d, ch = %c, f = %5.3le, \n \
   s = %hd, l = %ld, fl = %f, e = %10.3Lf", \
   sizeof c, c, b, ch, f, s,l, fl, e, \
   sizeof(c), c, b, ch, f, s,l, fl, e );

}

/* field width specification
============================
1: for decimal or character control string, consider 3.4 or 3.1, .3 and .1 has no
impact to display values, and rest of values are displayed correctly.

2: for string control string, consider 2.6 or 2.20, no leading blanks and 
for 2.6, SHHSH2 and for 2.20, full string is displayed.

3: for float with type g,h,e, pecilar results */
 
