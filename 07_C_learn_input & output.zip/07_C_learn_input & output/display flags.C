/* ********************************************************************
FILE                   :  display flags.c

PROGRAM DESCRIPTION    : practise C coding in getting input and display output

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdio.h"

int main()
{
 char c[] = "SHSHH232323";
 double f = 6434343.1454789455656;
 char ch = 320;
 short s = 23;


 printf("\n Data  Displayed ");
 printf("\n    c[%i] = %s, ch = %c, \n \
   s = %####+++++----06.hX, f = %#12.0lg %% \n \
   c[%i] = %+-12s, ch = %  + - 5.10c, \n \
   s = %hX, f = %#12.9lE", \
   sizeof c, c, ch, s, f, \
   sizeof(c), c, ch, s, f );

}

/* 

1: if %+-6hd for var,s, then     s = +23   , is displayed.
2: if %-+6hd for var,s, then     s = +23   , is displayed.
3: if %-0+hd for var,s, then     s = %-0+hd and rest with no effect 
   of control format.
4: if %+-06hd for var,s, then    s = +23   , is displayed.
5: if %+06.2hd for var,s, then   s =    +23, is displayed.
6: if %+06hd for var,s, then     s = +00023, is displayed.
7: if %+-6c for var, ch, then   ch = @     , is displayed.
8: if %+-6.3c for var, ch, then ch = @     , is displayed. 
9: if % 06.2hd for var, s, then  s =     23, is displayed. 
 : if %   06.2hd for var,s then  s =     23, is displayed.
 : if %   +-06.2hd for var,s thens = +23   , is displayed.
 : if %   +-06.hd for var,s thab s = +23   , is displayed.
 : if %   +06.hd for var,s thab  s = +00023, is displayed. 
 : if %  + 06.hd for var,s then  s = +00023, is displayed.
 : if %  + 0 6.hd for var,s then s =  + 0 6.hd  and rest with no 
   effect of control format.
 : if % + - 06.hd for var,s thab s = +23   , is displayed.
 : if % + - 6.10c for var,c thabch = @     , is displayed.
 : if %012s for var,c thab       c =  SHSHH232323, is displayed.
 : if %+-#12s for var,c thab     c = SHSHH232323 , is displayed.
 : if %+-#06.hx for var,s then   s = 0x17  , is displayed.
 : if %+-#06hx for var,s then    s = 0xffe9, is displayed,when s = -23
 : if %+-#06hX for var,s then    s = 0XFFE9, is displayed, when s = -23
 : if %+-#06hd for var,s then    s = -23   , is displayed, when s = -23
 : if %+-#06hD for var,s then    s = +-#06hD and rest with no effect 
   of control format.
 : if %####++++----06hX for var,s then s = 0XFFE9, is displayed.*/
