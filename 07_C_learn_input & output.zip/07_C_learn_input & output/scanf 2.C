/* ********************************************************************
FILE                   :  scanf 2.c

PROGRAM DESCRIPTION    : practise C coding in getting input and display output

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdio.h"

int main()
{
 char c[] = "SHSHH";
 long b = 100;
 double f = 6.1;
 char ch = 257;
 short s = 23;
 printf("\n enter numbers: ");
 scanf("%3D %c %5s %hd", &b, &ch, &c, &s);
 printf("\n  c[%i] = %s, b = %ld ,ch = %c, f = %lf, s = %d \n \
 c[%i] = %s, b = %ld, ch = %c, f = %lf, s = %d", sizeof c, c, b, ch, f, s,\
 sizeof(c), c, b, ch, f, s );

}
