/* ********************************************************************
FILE                   : get_char.c

PROGRAM DESCRIPTION    : practise using getchar

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>
int main()
{
	char letter[20];
	unsigned int count = 0;
	
	for (count = 0; (letter[count] = getchar()) != '\n' ; ++count)
    {
       ;
	}
	return 0;
}

