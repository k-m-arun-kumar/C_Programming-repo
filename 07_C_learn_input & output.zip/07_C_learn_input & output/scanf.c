/* ********************************************************************
FILE                   : scanf.c

PROGRAM DESCRIPTION    : practise return of scanf function

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>

int main ()
 {
   char str[50];
   int ret, num;
     
   printf("Enter hello & num: ");
   ret = scanf("hello %d", &num);
   
   printf("ret = %d, num = %d", ret, num);

   return(0);
}
