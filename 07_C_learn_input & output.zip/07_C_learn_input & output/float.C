/* ********************************************************************
FILE                   :  float.c

PROGRAM DESCRIPTION    : practise C coding in getting input and display output

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/


#include "stdio.h"

int main()
{
 /* char c[] = "SHSHH";
 int unsigned b = 100;
 char ch = 257;
 short s = 23; */
 
 float f = 1234.567890123456789;
 double d= 9876543210.123456789;
 long double e = 876.543;
 float *pf;
 
 printf("\n enter numbers: ");
 scanf("%f %lf %Lf", pf = &f, &d, &e); 
 printf("\n DATA DISPLAYED: ");
 printf("\n  f = %.3g, d = %.5lg, e = %.2Lg, \n \
 f = %e, d = %+010.2le, e = %.2Le, \n \
 f = %.9f, d = %lf, e = %.2Lf", \
 f, d ,e, f, d, e, f, d, e );

}


/* float display
================
1: f = %g, d = %lg, e = %Lg  
   f = 4, d = 9.87654e+09, e = 8

2: f = %g, d = %.9lg, e = %Lg  
   f = 4, d = 9876543210, e = 8

3: if f =%.30f or above, then fraction is same as 30 decimal places.
   same is true for d = %lg

4: if f =%.29f or below, then fraction has respective decimal places.
   same is true for d = %lg

5: d = %.le, d = %.lf
   d = 9.87654e+09, d = 9876543210.123457

6: d = %+010.2le
   d = +009.9e+09

7: d = %3.2le, 
   d = 9.9e+09

8: d = %.2le, d = %.2lf
   d = 9.9e+09, d = 9876543210.12 

9: d = %.4le, d = %.4lf
   d = 9.988e+09, d = 9876543210.1235


 :consider of g type, yet to understand it.
*/ 
