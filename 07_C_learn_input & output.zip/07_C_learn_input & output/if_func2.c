/* ********************************************************************
FILE                   : if_func2.c

PROGRAM DESCRIPTION    : practise of return of scanf and printf function

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Dev-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include <stdio.h>
int local_ptr_pass( int *num_ptr );
int main()
{
	int  number, *num_ptr = &number,ret_num;
    /*
     * 1. printf() function prints hello
     * 2. printf() function returns no of characters printed successfully
     *    as integer, here 5
     * 3. Conditional Expression in if evaluated to 5 which is TRUE
     */
 
  /*
     * 1. scanf() function stores input value at specified address
     * 2. scanf() function returns no of successfully input values
     *    as integer, here 1 
     * 3. Conditional Expression in if evaluated to 1 which is TRUE
     */
 
    if (ret_num = scanf("%d", &number)) 
        printf("\n scanf() = %d",ret_num);
    else
        printf("\n scanf() return 0");
     local_ptr_pass(num_ptr  );
    if (ret_num = printf("\n ret_num = %d",number))
        printf("\n printf() = %d",ret_num);
    else
        printf("\n printf() = 0");
 
    return 0;	
}

int local_ptr_pass( int *num_ptr )
{
	int  ret_num;
	
	printf("\n In local_ptr_pass() = %d",*num_ptr );
	 if (ret_num = printf("\n ret_num = %d",*num_ptr))
        printf("\n printf() = %d",ret_num);
    else
        printf("\n printf() = 0");
   *num_ptr = 25;
       
        return 0;
}

