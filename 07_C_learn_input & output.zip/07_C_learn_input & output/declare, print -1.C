/* ********************************************************************
FILE                   :  declare, print -1.c

PROGRAM DESCRIPTION    : practise C coding in getting input and display output

AUTHOR                :  K.M. Arun Kumar alias Arunkumar Murugeswaran
	 
KNOWN BUGS            :    

NOTE                  :  Compiled and Tested in Turbo-C++ on Windows 7 (32 bit) Desktop OS.
                                    
CHANGE LOGS           : 

*****************************************************************************/

#include "stdio.h"

#define  UNSIGN unsigned
int main()
{
 char c[] = "SHSHH";
 int UNSIGN long b = 655700UL;
 double f ;
 char ch = 257;
 printf("\n enter numbers: ");
 scanf("%lf", &f);
 #define CON 5
 printf("\n  c[%i] = %s, b = %lux ,ch = %c, f = %lf \n \
 c[%i] = %s, b = %lu, ch = %c, f = %lf", sizeof b, c, CON/CON * b, ch, f, \
 sizeof(b), c, b, ch, f );

}
